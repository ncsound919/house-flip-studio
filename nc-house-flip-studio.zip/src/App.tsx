/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Plus, 
  MapPin, 
  Search, 
  TrendingUp, 
  Sparkles, 
  AlertCircle, 
  Layers, 
  X,
  Compass,
  CheckCircle,
  HelpCircle,
  Building,
  Zap
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { PropertyDeal, DealStatus, AgentType, AgentLog } from "./types";
import PipelineBoard from "./components/PipelineBoard";
import DealUnderwriter from "./components/DealUnderwriter";
import AgentStatusPanel from "./components/AgentStatusPanel";
import SupervisorChat from "./components/SupervisorChat";
import ApprovalInbox from "./components/ApprovalInbox";
import FocusWizard from "./components/FocusWizard";
import CompetitiveEdge from "./components/CompetitiveEdge";
import AutonomousPipelineRunner from "./components/AutonomousPipelineRunner";
import PartnersOpsHub from "./components/PartnersOpsHub";
import UserManual from "./components/UserManual";
import InteractiveTour from "./components/InteractiveTour";
import WelcomeHero from "./components/WelcomeHero";
import IntegrationControlCenter from "./components/IntegrationControlCenter";
import { CADStudioView } from "./components/CADStudioView";
import { RepairGuideView } from "./components/RepairGuideView";
import UnifiedPipelineView from "./components/UnifiedPipelineView";
import { Box, Wrench, GitFork, Workflow } from "lucide-react";

export default function App() {
  const [deals, setDeals] = useState<PropertyDeal[]>([]);
  const [selectedDealId, setSelectedDealId] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [activeAgent, setActiveAgent] = useState<AgentType | null>(null);
  const [scoutingCity, setScoutingCity] = useState("Charlotte");
  const [isScouting, setIsScouting] = useState(false);
  const [scoutMessage, setScoutMessage] = useState<string | null>(null);
  
  // Autonomous 1-click single pipeline modal state
  const [isAutoPipelineOpen, setIsAutoPipelineOpen] = useState(false);
  const [autoPipelineTargetDeal, setAutoPipelineTargetDeal] = useState<PropertyDeal | null>(null);
  
  // BFF job queue and human gates states
  const [approvals, setApprovals] = useState<any[]>([]);
  const [activeJob, setActiveJob] = useState<any | null>(null);
  const [isApprovalLoading, setIsApprovalLoading] = useState(false);
  const [viewMode, setViewMode] = useState<"welcome" | "pipeline" | "dashboard" | "cad-studio" | "repair-guide" | "ops-hub" | "moats" | "integrations">("pipeline");
  const [isManualOpen, setIsManualOpen] = useState(false);
  const [isTourActive, setIsTourActive] = useState(false);
  
  // Manual deal modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalStatus, setModalStatus] = useState<DealStatus>("Lead Ingest");
  const [newDealForm, setNewDealForm] = useState({
    address: "",
    city: "Charlotte",
    zip: "",
    askingPrice: "",
    bed: "3",
    bath: "2",
    sqft: "1500",
    yearBuilt: "1970",
    lotSize: "0.25",
    description: ""
  });

  // Sourcing & Real MLS Importer states
  const [liveSearchQuery, setLiveSearchQuery] = useState("");
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [sourcingMode, setSourcingMode] = useState<"auto" | "lookup">("auto");

  // Fetch all deals from server
  const fetchDeals = async () => {
    try {
      const res = await fetch("/api/deals");
      if (res.ok) {
        const data = await res.json();
        setDeals(data);
        if (data.length > 0 && !selectedDealId) {
          setSelectedDealId(data[0].id);
        }
      }
    } catch (err) {
      console.error("Failed to load deals:", err);
    }
  };

  // Fetch all approvals from BFF
  const fetchApprovals = async () => {
    try {
      const res = await fetch("/api/approvals");
      if (res.ok) {
        const data = await res.json();
        setApprovals(data);
      }
    } catch (err) {
      console.error("Failed to load approvals:", err);
    }
  };

  useEffect(() => {
    fetchDeals();
    fetchApprovals();
  }, []);

  const selectedDeal = deals.find((d) => d.id === selectedDealId) || null;

  // Sourcing - Auto-scout leads from target NC City
  const handleAutoScout = async () => {
    setIsScouting(true);
    setScoutMessage("Scout Agent cruising regional tax deliquent and foreclosure rolls...");
    setActiveAgent("Scout");
    
    try {
      const res = await fetch("/api/scout-leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city: scoutingCity })
      });
      
      if (res.ok) {
        const data = await res.json();
        await fetchDeals(); // Reload deals
        setScoutMessage(`Success! Autonomously scouted and logged ${data.count} distressed leads in ${scoutingCity}.`);
        if (data.deals && data.deals.length > 0) {
          setSelectedDealId(data.deals[0].id);
        }
        setTimeout(() => setScoutMessage(null), 5000);
      } else {
        throw new Error("Scouting failed");
      }
    } catch (err) {
      setScoutMessage("Error: Scout Agent service is temporarily rate-limited.");
      setTimeout(() => setScoutMessage(null), 5000);
    } finally {
      setIsScouting(false);
      setActiveAgent(null);
    }
  };

  // Sourcing - Real MLS / Address Lookup & Ingest
  const handleLookupRealProperty = async (addressQuery?: string) => {
    const query = addressQuery || liveSearchQuery;
    if (!query.trim()) return;

    setIsLookingUp(true);
    setScoutMessage(`Verifying real NC public records & MLS for "${query}"...`);
    setActiveAgent("Scout");

    try {
      const res = await fetch("/api/lookup-property", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, city: scoutingCity })
      });

      if (res.ok) {
        const data = await res.json();
        await fetchDeals();
        if (data.deal) {
          setSelectedDealId(data.deal.id);
          setScoutMessage(`✓ Verified real property: ${data.deal.address}, ${data.deal.city}, NC (${data.deal.mlsNumber || data.deal.parcelId}) imported.`);
          setLiveSearchQuery("");
        }
        setTimeout(() => setScoutMessage(null), 5000);
      } else {
        throw new Error("Property lookup failed");
      }
    } catch (err) {
      setScoutMessage("Error: Could not retrieve records for this address. Please verify street name.");
      setTimeout(() => setScoutMessage(null), 5000);
    } finally {
      setIsLookingUp(false);
      setActiveAgent(null);
    }
  };

  // Sourcing - Manual deal addition
  const handleAddDealTrigger = (status: DealStatus) => {
    setModalStatus(status);
    setIsModalOpen(true);
  };

  const handleManualDealSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        address: newDealForm.address,
        city: newDealForm.city,
        zip: newDealForm.zip,
        askingPrice: Number(newDealForm.askingPrice),
        bed: Number(newDealForm.bed),
        bath: Number(newDealForm.bath),
        sqft: Number(newDealForm.sqft),
        yearBuilt: Number(newDealForm.yearBuilt),
        lotSize: Number(newDealForm.lotSize),
        description: newDealForm.description || `Cosmetic fixer-upper bungalow located in ${newDealForm.city}. Great opportunity.`,
        status: modalStatus
      };

      const res = await fetch("/api/deals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const addedDeal = await res.json();
        await fetchDeals();
        setSelectedDealId(addedDeal.id);
        setIsModalOpen(false);
        setNewDealForm({
          address: "",
          city: "Charlotte",
          zip: "",
          askingPrice: "",
          bed: "3",
          bath: "2",
          sqft: "1500",
          yearBuilt: "1970",
          lotSize: "0.25",
          description: ""
        });
      }
    } catch (err) {
      console.error("Failed to add deal manually:", err);
    }
  };

  // Delete Deal
  const handleDeleteDeal = async (dealId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Are you sure you want to delete this property lead?")) return;
    try {
      const res = await fetch(`/api/deals/${dealId}`, { method: "DELETE" });
      if (res.ok) {
        setDeals((prev) => prev.filter((d) => d.id !== dealId));
        if (selectedDealId === dealId) {
          const remaining = deals.filter((d) => d.id !== dealId);
          setSelectedDealId(remaining.length > 0 ? remaining[0].id : null);
        }
      }
    } catch (err) {
      console.error("Failed to delete deal:", err);
    }
  };

  // Status Change inside list / board
  const handleUpdateStatus = async (newStatus: string) => {
    if (!selectedDealId) return;
    try {
      const res = await fetch(`/api/deals/${selectedDealId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus as DealStatus })
      });
      if (res.ok) {
        const updated = await res.json();
        setDeals((prev) => prev.map((d) => (d.id === selectedDealId ? updated : d)));
      }
    } catch (err) {
      console.error("Failed to update status:", err);
    }
  };

  // General Update for Gating Log changes
  const handleUpdateDeal = async (updatedDeal: PropertyDeal) => {
    try {
      const res = await fetch(`/api/deals/${updatedDeal.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedDeal)
      });
      if (res.ok) {
        setDeals((prev) => prev.map((d) => (d.id === updatedDeal.id ? updatedDeal : d)));
      }
    } catch (err) {
      console.error("Failed to update deal logs:", err);
    }
  };

  // Stateful Underwrite Pipeline Runner (BFF API integration)
  const pollJobStatus = async (jobId: string) => {
    try {
      const res = await fetch(`/api/jobs/status/${jobId}`);
      if (res.ok) {
        const job = await res.json();
        setActiveJob(job);
        
        if (job.currentAgent) {
          setActiveAgent(job.currentAgent);
        }
        
        // Dynamically append job events to the current active deal log
        if (selectedDealId && job.events && job.events.length > 0) {
          setDeals((prev) =>
            prev.map((d) =>
              d.id === selectedDealId
                ? { ...d, logs: [...job.events] }
                : d
            )
          );
        }

        if (job.status === "running") {
          setTimeout(() => pollJobStatus(jobId), 1500);
        } else if (job.status === "suspended") {
          setIsAnalyzing(false);
          await fetchApprovals(); // Refresh Approval Inbox to show the user the new gate
        } else if (job.status === "completed") {
          setIsAnalyzing(false);
          setActiveAgent(null);
          setActiveJob(null);
          await fetchDeals(); // Reload updated deal with calculations
          await fetchApprovals(); // Refresh approvals
        } else if (job.status === "failed") {
          setIsAnalyzing(false);
          setActiveAgent(null);
          setActiveJob(null);
        }
      }
    } catch (err) {
      console.error("Polling job status failed:", err);
      setIsAnalyzing(false);
      setActiveAgent(null);
    }
  };

  const handleRunUnderwrite = async () => {
    if (!selectedDealId) return;
    setIsAnalyzing(true);
    setActiveAgent("Scout");
    setActiveJob(null);

    try {
      const res = await fetch("/api/jobs/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dealId: selectedDealId })
      });

      if (res.ok) {
        const data = await res.json();
        pollJobStatus(data.jobId);
      } else {
        throw new Error("Failed to create background underwriting job");
      }
    } catch (err) {
      console.error("Error creating underwriting job:", err);
      setIsAnalyzing(false);
      setActiveAgent(null);
    }
  };

  // Launch 1-Click Autonomous Multi-Agent Pipeline
  const handleLaunchAutonomousPipeline = (deal: PropertyDeal) => {
    setSelectedDealId(deal.id);
    setAutoPipelineTargetDeal(deal);
    setIsAutoPipelineOpen(true);
  };

  const handleCompleteAutonomousPipeline = (updatedDeal: PropertyDeal) => {
    setDeals((prev) => prev.map((d) => (d.id === updatedDeal.id ? updatedDeal : d)));
    setSelectedDealId(updatedDeal.id);
    fetchApprovals(); // Sync gates and inbox
  };

  const handleApprovalAction = async (id: string, action: "approve" | "reject", notes?: string) => {
    setIsApprovalLoading(true);
    try {
      const res = await fetch(`/api/approvals/${id}/action`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, notes })
      });

      if (res.ok) {
        const updatedApproval = await res.json();
        setApprovals((prev) => prev.map((a) => (a.id === id ? updatedApproval : a)));
        
        // If there was an associated suspended job, resume tracking it!
        if (updatedApproval.jobId) {
          setIsAnalyzing(true);
          pollJobStatus(updatedApproval.jobId);
        } else {
          await fetchDeals();
        }
      }
    } catch (err) {
      console.error("Failed to post approval action:", err);
    } finally {
      setIsApprovalLoading(false);
    }
  };

  // Focus Step Wizard callbacks
  const handleRunStepAnalysis = async (step: string) => {
    await handleRunUnderwrite();
  };

  const handleGateApprove = async (gateKey: string) => {
    const matchingPending = approvals.find(
      (a) =>
        a.dealId === selectedDealId &&
        a.status === "pending" &&
        ((gateKey === "compsApproved" && a.category === "comps") ||
          (gateKey === "rehabApproved" && a.category === "rehab") ||
          (gateKey === "complianceApproved" && a.category === "compliance"))
    );

    if (matchingPending) {
      await handleApprovalAction(matchingPending.id, "approve", "Approved via step wizard focus mode.");
    } else {
      // Local structural fallback
      await fetchDeals();
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-300 flex flex-col font-sans selection:bg-emerald-500/20 selection:text-emerald-300 antialiased">
      {/* Top Navigation Bar */}
      <header className="bg-zinc-900/40 border-b border-zinc-800/80 sticky top-0 z-40 px-6 py-4 backdrop-blur-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-sm">
              <Compass className="h-5.5 w-5.5" />
            </div>
             <div>
              <h1 className="text-md font-extrabold tracking-tight text-zinc-100 uppercase">NC House Flip Studio</h1>
              <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">My Smart AI House Helper</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={() => setIsManualOpen(true)}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-300 hover:text-zinc-100 text-xs font-extrabold shadow-xs transition cursor-pointer"
              title="Open the simple step-by-step guide"
              id="help-guide-button"
            >
              <HelpCircle className="h-4 w-4 text-emerald-400 animate-pulse" />
              <span className="hidden sm:inline">Simple Guide</span>
            </button>

            {selectedDeal && (
              <button
                type="button"
                onClick={() => handleLaunchAutonomousPipeline(selectedDeal)}
                className="hidden sm:flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-extrabold shadow-sm transition border border-emerald-400/30 cursor-pointer"
                title="Let the AI helpers automatically fill in the math"
              >
                <Zap className="h-3.5 w-3.5 fill-white" />
                <span>Go For It! (Auto Math)</span>
              </button>
            )}

            <div className="flex items-center space-x-1.5 bg-zinc-950 p-1.5 rounded-xl border border-zinc-850/80 overflow-x-auto max-w-full">
              <button
                onClick={() => setViewMode("pipeline")}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition uppercase tracking-wider cursor-pointer flex items-center space-x-1.5 ${
                  viewMode === "pipeline" || viewMode === "dashboard"
                    ? "bg-emerald-600 text-zinc-100 shadow-xs"
                    : "text-zinc-400 hover:text-zinc-250"
                }`}
                title="Unified 6-stage end-to-end deal pipeline and execution studio"
              >
                <Workflow className="h-3.5 w-3.5" />
                <span>Unified Pipeline</span>
              </button>
              <button
                onClick={() => setViewMode("cad-studio")}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition uppercase tracking-wider cursor-pointer flex items-center space-x-1 ${
                  viewMode === "cad-studio"
                    ? "bg-emerald-600 text-zinc-100 shadow-xs"
                    : "text-zinc-400 hover:text-zinc-250"
                }`}
                title="3D CAD house floorplans and spatial repair protocols"
              >
                <Box className="h-3 w-3" />
                <span>3D CAD Fix</span>
              </button>
              <button
                onClick={() => setViewMode("repair-guide")}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition uppercase tracking-wider cursor-pointer flex items-center space-x-1 ${
                  viewMode === "repair-guide"
                    ? "bg-emerald-600 text-zinc-100 shadow-xs"
                    : "text-zinc-400 hover:text-zinc-250"
                }`}
                title="Step-by-step repair guides, NC code SOPs, and verified local contractors"
              >
                <Wrench className="h-3 w-3" />
                <span>NC Code & Trades</span>
              </button>
              <button
                onClick={() => setViewMode("ops-hub")}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition uppercase tracking-wider cursor-pointer flex items-center space-x-1 ${
                  viewMode === "ops-hub"
                    ? "bg-emerald-600 text-zinc-100 shadow-xs"
                    : "text-zinc-400 hover:text-zinc-250"
                }`}
                title="Walkthrough checklists and builder tools"
              >
                <Compass className="h-3 w-3" />
                <span>Walkthrough</span>
              </button>
              <button
                onClick={() => setViewMode("moats")}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition uppercase tracking-wider cursor-pointer ${
                  viewMode === "moats"
                    ? "bg-emerald-600 text-zinc-100 shadow-xs"
                    : "text-zinc-400 hover:text-zinc-250"
                }`}
                title="See how much money you can save"
              >
                Our Savings
              </button>
              <button
                onClick={() => setViewMode("integrations")}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition uppercase tracking-wider cursor-pointer ${
                  viewMode === "integrations"
                    ? "bg-emerald-600 text-zinc-100 shadow-xs"
                    : "text-zinc-400 hover:text-zinc-250"
                }`}
                title="Configure Ollama, Stripe, Gmail, Drive & Calendar"
              >
                Integrations
              </button>
              <button
                onClick={() => setViewMode("welcome")}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition uppercase tracking-wider cursor-pointer ${
                  viewMode === "welcome"
                    ? "bg-emerald-600 text-zinc-100 shadow-xs"
                    : "text-zinc-400 hover:text-zinc-250"
                }`}
                title="Go back to the welcome start screen"
              >
                Guide
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Workspace Layout */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 lg:p-6 space-y-6">
        {viewMode === "welcome" ? (
          <WelcomeHero
            onStartTour={() => {
              setViewMode("pipeline");
              setIsTourActive(true);
            }}
            onEnterApp={() => setViewMode("pipeline")}
            onOpenManual={() => setIsManualOpen(true)}
          />
        ) : viewMode === "integrations" ? (
          <IntegrationControlCenter activeDeal={selectedDeal} onUpdateDeal={handleUpdateDeal} />
        ) : viewMode === "moats" ? (
          <CompetitiveEdge />
        ) : viewMode === "cad-studio" ? (
          selectedDeal ? (
            <CADStudioView deal={selectedDeal} onUpdateDeal={handleUpdateDeal} />
          ) : (
            <div className="py-20 text-center flex flex-col items-center justify-center bg-zinc-900/40 border border-zinc-800/80 rounded-3xl p-6">
              <Box className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
              <h3 className="font-bold text-zinc-300 text-sm uppercase tracking-wider">Please Choose a House First!</h3>
              <p className="text-xs text-zinc-500 mt-1.5 max-w-sm leading-relaxed">
                Go to the <strong>Unified Pipeline</strong>, select any house, or explore the 3D CAD model directly from Stage 3!
              </p>
            </div>
          )
        ) : viewMode === "repair-guide" ? (
          selectedDeal ? (
            <RepairGuideView
              deals={deals}
              activeDeal={selectedDeal}
              onSelectDeal={(deal) => setSelectedDealId(deal.id)}
              onUpdateDeal={handleUpdateDeal}
            />
          ) : (
            <div className="py-20 text-center flex flex-col items-center justify-center bg-zinc-900/40 border border-zinc-800/80 rounded-3xl p-6">
              <Wrench className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
              <h3 className="font-bold text-zinc-300 text-sm uppercase tracking-wider">Please Choose a House First!</h3>
              <p className="text-xs text-zinc-500 mt-1.5 max-w-sm leading-relaxed">
                Go to the <strong>Unified Pipeline</strong>, select a house, or generate step-by-step repair plans directly in Stage 4!
              </p>
            </div>
          )
        ) : viewMode === "ops-hub" ? (
          selectedDeal ? (
            <PartnersOpsHub deal={selectedDeal} onUpdateDeal={handleUpdateDeal} />
          ) : (
            <div className="py-20 text-center flex flex-col items-center justify-center bg-zinc-900/40 border border-zinc-800/80 rounded-3xl p-6">
              <Compass className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
              <h3 className="font-bold text-zinc-300 text-sm uppercase tracking-wider">Please Choose a House First!</h3>
              <p className="text-xs text-zinc-500 mt-1.5 max-w-sm leading-relaxed">
                Go to the <strong>Unified Pipeline</strong>, select a house, or access walkthrough checklists directly in Stage 5!
              </p>
            </div>
          )
        ) : (
          /* UNIFIED PIPELINE VIEW */
          <UnifiedPipelineView
            deals={deals}
            selectedDealId={selectedDealId}
            onSelectDeal={(id) => setSelectedDealId(id)}
            onUpdateDeal={handleUpdateDeal}
            onAddDealTrigger={handleAddDealTrigger}
            onDeleteDeal={handleDeleteDeal}
            onLaunchAutonomousPipeline={handleLaunchAutonomousPipeline}
            scoutingCity={scoutingCity}
            setScoutingCity={setScoutingCity}
            isScouting={isScouting}
            onAutoScout={handleAutoScout}
            liveSearchQuery={liveSearchQuery}
            setLiveSearchQuery={setLiveSearchQuery}
            isLookingUp={isLookingUp}
            onLookupRealProperty={handleLookupRealProperty}
            sourcingMode={sourcingMode}
            setSourcingMode={setSourcingMode}
            scoutMessage={scoutMessage}
            approvals={approvals}
            onApprovalAction={handleApprovalAction}
            isApprovalLoading={isApprovalLoading}
            activeAgent={activeAgent}
            isAnalyzing={isAnalyzing}
            onRunUnderwrite={handleRunUnderwrite}
            onUpdateStatus={handleUpdateStatus}
          />
        )}
      </main>

      {/* Manual Lead Adding Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-zinc-900 rounded-3xl border border-zinc-800 shadow-2xl max-w-lg w-full overflow-hidden flex flex-col"
            >
              {/* Header */}
              <div className="bg-zinc-950/80 border-b border-zinc-800 p-5 flex items-center justify-between">
                <h3 className="font-extrabold text-sm text-zinc-100">Add Manual NC Property Lead</h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-1.5 hover:bg-zinc-800 rounded-lg text-zinc-400 hover:text-zinc-200 transition"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleManualDealSubmit} className="p-5 space-y-4 text-xs font-medium text-zinc-300 overflow-y-auto max-h-[80vh]">
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <label className="block text-zinc-400 mb-1">Street Address</label>
                    <input
                      required
                      type="text"
                      value={newDealForm.address}
                      onChange={(e) => setNewDealForm({ ...newDealForm, address: e.target.value })}
                      placeholder="e.g. 124 Oak Ave"
                      className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 placeholder-zinc-600 font-medium focus:outline-hidden"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-zinc-400 mb-1">NC City</label>
                      <select
                        value={newDealForm.city}
                        onChange={(e) => setNewDealForm({ ...newDealForm, city: e.target.value })}
                        className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 font-medium focus:outline-hidden"
                      >
                        <option value="Charlotte">Charlotte</option>
                        <option value="Durham">Durham</option>
                        <option value="Greensboro">Greensboro</option>
                        <option value="Raleigh">Raleigh</option>
                        <option value="Wilmington">Wilmington</option>
                        <option value="Asheville">Asheville</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-zinc-400 mb-1">ZIP Code</label>
                      <input
                        required
                        type="text"
                        value={newDealForm.zip}
                        onChange={(e) => setNewDealForm({ ...newDealForm, zip: e.target.value })}
                        placeholder="e.g. 28205"
                        className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 placeholder-zinc-600 font-medium focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-zinc-400 mb-1">Bedrooms</label>
                      <input
                        required
                        type="number"
                        value={newDealForm.bed}
                        onChange={(e) => setNewDealForm({ ...newDealForm, bed: e.target.value })}
                        className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 font-medium focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-zinc-400 mb-1">Bathrooms</label>
                      <input
                        required
                        type="number"
                        step="0.5"
                        value={newDealForm.bath}
                        onChange={(e) => setNewDealForm({ ...newDealForm, bath: e.target.value })}
                        className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 font-medium focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-zinc-400 mb-1">Sqft</label>
                      <input
                        required
                        type="number"
                        value={newDealForm.sqft}
                        onChange={(e) => setNewDealForm({ ...newDealForm, sqft: e.target.value })}
                        className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 font-medium focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-zinc-400 mb-1">Year Built</label>
                      <input
                        required
                        type="number"
                        value={newDealForm.yearBuilt}
                        onChange={(e) => setNewDealForm({ ...newDealForm, yearBuilt: e.target.value })}
                        className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 font-medium focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-zinc-400 mb-1">Lot Size (Acres)</label>
                      <input
                        required
                        type="number"
                        step="0.01"
                        value={newDealForm.lotSize}
                        onChange={(e) => setNewDealForm({ ...newDealForm, lotSize: e.target.value })}
                        className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 font-medium focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-zinc-400 mb-1">Asking Price ($)</label>
                      <input
                        required
                        type="number"
                        value={newDealForm.askingPrice}
                        onChange={(e) => setNewDealForm({ ...newDealForm, askingPrice: e.target.value })}
                        placeholder="e.g. 150000"
                        className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 placeholder-zinc-600 font-medium focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-zinc-400 mb-1">Description / Distressed Details</label>
                    <textarea
                      value={newDealForm.description}
                      onChange={(e) => setNewDealForm({ ...newDealForm, description: e.target.value })}
                      placeholder="e.g. Rotted crawlspace floor joists, dated bathroom, old heat pump, but located in premium school district..."
                      rows={3}
                      className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl p-2.5 focus:ring-1 focus:ring-emerald-500/50 focus:bg-zinc-900 text-zinc-100 placeholder-zinc-600 font-medium focus:outline-hidden"
                    />
                  </div>
                </div>

                {/* Footer buttons */}
                <div className="flex justify-end space-x-2 pt-4 border-t border-zinc-800">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-zinc-300 font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-xs cursor-pointer"
                  >
                    Log Lead Property
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 1-Click Autonomous Multi-Agent Pipeline Runner Modal */}
      {isAutoPipelineOpen && autoPipelineTargetDeal && (
        <AutonomousPipelineRunner
          deal={autoPipelineTargetDeal}
          isOpen={isAutoPipelineOpen}
          onClose={() => setIsAutoPipelineOpen(false)}
          onComplete={handleCompleteAutonomousPipeline}
        />
      )}

      {/* User Manual Modal & Interactive Tour Overlay */}
      <UserManual
        isOpen={isManualOpen}
        onClose={() => setIsManualOpen(false)}
        onStartInteractiveTour={() => setIsTourActive(true)}
      />

      <InteractiveTour
        isActive={isTourActive}
        onClose={() => setIsTourActive(false)}
        onComplete={() => setIsTourActive(false)}
      />

      {/* Brief Footer */}
      <footer className="bg-zinc-950 border-t border-zinc-900 py-6 mt-12 text-center text-[10px] text-zinc-500 font-medium">
        <p>© 2026 NC House Flip Studio. All rights reserved. Compliance optimized for NC House Bill 797 standards.</p>
      </footer>
    </div>
  );
}
