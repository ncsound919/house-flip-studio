/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Play, 
  Check, 
  Home, 
  TrendingUp, 
  Hammer, 
  ShieldAlert, 
  Calendar, 
  Activity, 
  ArrowRight,
  TrendingDown,
  Info,
  DollarSign,
  UserCheck,
  Building,
  AlertCircle,
  Clock,
  Briefcase,
  Camera,
  Upload,
  FileCheck,
  Eye,
  FileText,
  ShieldCheck,
  Landmark,
  Zap,
  Box
} from "lucide-react";
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip,
  Legend
} from "recharts";
import { PropertyDeal } from "../types";
import { FinancingEngine, InvestorProfile, FinancingResult } from "../lib/FinancingEngine";
import { Sliders, Award, Percent, Coins, Star, Sparkles, Mail, Copy, CheckCircle2, MapPin, Inbox, ChevronRight, Plus, Trash, CheckCircle, RefreshCw, ChevronDown, ChevronUp } from "lucide-react";
import LegalDocumentModal from "./LegalDocumentModal";
import { RehabBudgetManager } from "./RehabBudgetManager";
import { ContractorManager } from "./ContractorManager";

interface DealUnderwriterProps {
  deal: PropertyDeal;
  onRunAnalysis: () => void;
  onUpdateStatus: (status: string) => void;
  onUpdateDeal: (updatedDeal: PropertyDeal) => void;
  isAnalyzing: boolean;
  activeAgent: string | null;
  onLaunchAutonomousPipeline?: () => void;
}

type TabType = "overview" | "comps" | "rehab" | "compliance" | "milestones" | "logs" | "financing" | "draws";

export default function DealUnderwriter({
  deal,
  onRunAnalysis,
  onUpdateStatus,
  onUpdateDeal,
  isAnalyzing,
  activeAgent,
  onLaunchAutonomousPipeline
}: DealUnderwriterProps) {
  const [activeTab, setActiveTab] = useState<TabType>("overview");
  
  // AI property photo scanner states
  const [photoScanType, setPhotoScanType] = useState<"kitchen" | "roof" | "exterior">("kitchen");
  const [isScanningPhoto, setIsScanningPhoto] = useState(false);
  const [scannedSections, setScannedSections] = useState<Record<string, boolean>>({
    kitchen: false,
    roof: false,
    exterior: false
  });
  const [customImageBase64, setCustomImageBase64] = useState<string | null>(null);
  const [customImageFileName, setCustomImageFileName] = useState<string | null>(null);
  const [scanResults, setScanResults] = useState<Record<string, any>>({});

  // Legal Document Suite Modal state
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [modalDocType, setModalDocType] = useState<"lien_waiver" | "wholesale_assignment" | "proof_of_funds">("lien_waiver");
  const [modalContractorName, setModalContractorName] = useState("Plaza Midwood General Contractors LLC");
  const [modalDrawAmount, setModalDrawAmount] = useState(8500);
  const [modalMilestoneTitle, setModalMilestoneTitle] = useState("Framing & Structural Repairs");
  const [verificationLoading, setVerificationLoading] = useState(false);
  const [verificationError, setVerificationError] = useState<string | null>(null);

  const openDocModal = (
    type: "lien_waiver" | "wholesale_assignment" | "proof_of_funds",
    milestone?: any
  ) => {
    setModalDocType(type);
    if (milestone) {
      setModalMilestoneTitle(milestone.title);
      setModalDrawAmount(milestone.cost);
    }
    const contractor = deal.contractors?.[0]?.name || "Plaza Midwood General Contractors LLC";
    setModalContractorName(contractor);
    setIsDocModalOpen(true);
  };

  // Dynamic investor profile for real-time financing evaluation
  const [investorProfile, setInvestorProfile] = useState<InvestorProfile>({
    experienceLevel: "Beginner",
    cashAvailable: 15000,
    creditScore: 710,
    priorFlips: 0,
    ownsHome: false,
    hasBrokerLicense: false,
  });

  const [selectedStrategyForOutreach, setSelectedStrategyForOutreach] = useState<FinancingResult | null>(null);
  const [copiedOutreach, setCopiedOutreach] = useState<boolean>(false);
  
  // Escrow & Draw Bridge State Variables
  const [holdingCostMonthly, setHoldingCostMonthly] = useState<number>(1000);
  const [loanBalance, setLoanBalance] = useState<number>(180000);
  const [loanRate, setLoanRate] = useState<number>(12);
  const [changeOrders, setChangeOrders] = useState<any[]>([]);
  const [milestoneVerifications, setMilestoneVerifications] = useState<Record<string, any>>({});
  const [transactions, setTransactions] = useState<any[]>([]);
  const [activeVerificationMilestoneId, setActiveVerificationMilestoneId] = useState<string | null>(null);
  const [gpsMode, setGpsMode] = useState<"onsite" | "offsite">("onsite");
  const [showAddCoForm, setShowAddCoForm] = useState<boolean>(false);
  
  // Custom Change Order form fields
  const [activeCoTitle, setActiveCoTitle] = useState("");
  const [activeCoDesc, setActiveCoDesc] = useState("");
  const [activeCoCost, setActiveCoCost] = useState("");
  const [activeCoDays, setActiveCoDays] = useState("");
  const [activeCoContractor, setActiveCoContractor] = useState("");

  // Sync state when selected deal.id changes
  React.useEffect(() => {
    const initialHolding = deal.underwriting.holdingCosts && deal.underwriting.holdingPeriodMonths
      ? Math.round(deal.underwriting.holdingCosts / deal.underwriting.holdingPeriodMonths)
      : 1000;
    setHoldingCostMonthly(initialHolding);
    setLoanBalance(Math.round(deal.underwriting.purchasePrice * 0.9) || 180000);
    setLoanRate(12);
    
    // Seed standard change orders for this property
    setChangeOrders([
      {
        id: `co-1-${deal.id}`,
        title: "Rotted sill plate behind kitchen wall",
        description: "Opened wall to run new electrical. Found extensive rot in sill plate and rim joist. Needs replacement before proceeding with electrical rough-in.",
        proposedCost: 2200,
        proposedDaysAdded: 4,
        status: "proposed",
        contractorName: "Bob's Construction",
        photosCount: 2
      },
      {
        id: `co-2-${deal.id}`,
        title: "Subfloor water damage in master bath",
        description: "Pulled up old tiles and found rotted structural subfloor beneath the shower stall. Needs complete 3/4 inch plywood replacement.",
        proposedCost: 1800,
        proposedDaysAdded: 3,
        status: "proposed",
        contractorName: "Plaza Midwood Construction",
        photosCount: 1
      }
    ]);

    setMilestoneVerifications({});
    setTransactions([
      {
        id: `t-init-${deal.id}`,
        type: "escrow_deposit",
        description: "Initial construction escrow deposit by PML Partner",
        amount: deal.underwriting.rehabCost || 35000,
        timestamp: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString(),
        status: "completed"
      }
    ]);
    setActiveVerificationMilestoneId(null);
    setShowAddCoForm(false);
  }, [deal.id, deal.underwriting.purchasePrice, deal.underwriting.rehabCost, deal.underwriting.holdingCosts, deal.underwriting.holdingPeriodMonths]);
  
  // Gate check states (persisted inside deal, but we can set them as triggers too)
  const [gates, setGates] = useState({
    compsApproved: deal.comps.length > 0,
    rehabApproved: deal.rehabItems.length > 0,
    complianceApproved: deal.complianceChecks.some(c => c.status === "passed")
  });

  const handleGateChange = (gateKey: "compsApproved" | "rehabApproved" | "complianceApproved") => {
    const updatedGates = { ...gates, [gateKey]: !gates[gateKey] };
    setGates(updatedGates);
    
    // Add log
    const logMsg = gateKey === "compsApproved" 
      ? "User verified and approved after repair value comparables." 
      : gateKey === "rehabApproved" 
      ? "User verified and locked renovation rehab estimate." 
      : "User audited and signed off on North Carolina legal compliance.";

    const newLog = {
      id: `log-gate-${Date.now()}`,
      timestamp: new Date().toISOString(),
      agentName: "Supervisor" as const,
      message: logMsg,
      status: "success" as const
    };

    onUpdateDeal({
      ...deal,
      logs: [...deal.logs, newLog]
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCustomImageFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setCustomImageBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRunPhotoScan = async () => {
    setIsScanningPhoto(true);
    try {
      const response = await fetch("/api/analyze-photo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scanType: photoScanType,
          imageBase64: customImageBase64,
          address: deal.address,
          city: deal.city
        })
      });
      const json = await response.json();
      if (json.success) {
        setScanResults((prev) => ({ ...prev, [photoScanType]: json }));
        setScannedSections((prev) => ({ ...prev, [photoScanType]: true }));
      }
    } catch (err) {
      console.error("Photo scan error:", err);
    } finally {
      setIsScanningPhoto(false);
    }
  };

  const handleAddScanIssuesToBudget = (scanArea: string) => {
    const result = scanResults[scanArea];
    if (!result || !result.detectedIssues || result.detectedIssues.length === 0) return;

    const newItems = result.detectedIssues.map((issue: any) => ({
      id: `rehab-scan-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      category: issue.category || "General Repairs",
      description: `[AI Vision] ${issue.name}: ${issue.description}`,
      cost: Math.round((issue.estimatedCostMin + issue.estimatedCostMax) / 2) || 2500,
      contractorType: issue.category?.includes("Roof") ? "Roofing Contractor" : issue.category?.includes("Carpentry") ? "General Contractor" : "Specialist Contractor"
    }));

    const updatedRehabItems = [...deal.rehabItems, ...newItems];
    const newTotalRehab = updatedRehabItems.reduce((acc, curr) => acc + curr.cost, 0);

    const arv = deal.underwriting.arv || 350000;
    const purchase = deal.underwriting.purchasePrice || 180000;
    const acq = deal.underwriting.acquisitionCosts || 4000;
    const hold = deal.underwriting.holdingCosts || 5000;
    const sell = deal.underwriting.sellingCosts || Math.round(arv * 0.06);
    const fin = deal.underwriting.financingCosts || 10000;
    const newProfit = arv - (purchase + newTotalRehab + acq + hold + sell + fin);

    const updatedDeal = {
      ...deal,
      rehabItems: updatedRehabItems,
      underwriting: {
        ...deal.underwriting,
        rehabCost: newTotalRehab,
        projectedProfit: newProfit
      },
      logs: [
        ...deal.logs,
        {
          id: `log-scan-${Date.now()}`,
          timestamp: new Date().toISOString(),
          agentName: "Rehab" as const,
          message: `Added ${newItems.length} computer-vision detected line items to rehab scope (+$${(newTotalRehab - (deal.underwriting.rehabCost || 0)).toLocaleString()}).`,
          status: "success" as const
        }
      ]
    };

    onUpdateDeal(updatedDeal);
  };

  const handleVerifyMilestone = async (mil: any) => {
    setVerificationLoading(true);
    setVerificationError(null);
    try {
      const response = await fetch("/api/verify-milestone", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dealId: deal.id,
          milestoneId: mil.id,
          gpsMode
        })
      });

      const json = await response.json();
      if (!response.ok || !json.verified) {
        setVerificationError(json.error || "Milestone verification failed");
        return;
      }

      // Mark verified
      setMilestoneVerifications((prev) => ({
        ...prev,
        [mil.id]: json.verificationRecord
      }));

      // Release draw
      const newTransaction = {
        id: `t-draw-${Date.now()}`,
        type: "draw_release",
        description: `Draw Release: ${mil.title} (${json.verificationRecord.materialsInspected[0]})`,
        amount: mil.cost,
        timestamp: new Date().toISOString(),
        status: "completed"
      };

      setTransactions((prev) => [...prev, newTransaction]);

      // Update milestone status in deal
      const updatedMilestones = deal.milestones.map((m) =>
        m.id === mil.id ? { ...m, status: "completed" as const } : m
      );

      const updatedDeal = {
        ...deal,
        milestones: updatedMilestones,
        logs: [
          ...deal.logs,
          {
            id: `log-mil-${Date.now()}`,
            timestamp: new Date().toISOString(),
            agentName: "Supervisor" as const,
            message: `Draw #${mil.id} for $${mil.cost.toLocaleString()} released. Verification record ${json.verificationRecord.id} generated.`,
            status: "success" as const
          }
        ]
      };

      onUpdateDeal(updatedDeal);
      setActiveVerificationMilestoneId(null);
    } catch (err) {
      console.error("Verification error:", err);
      setVerificationError("Failed to connect to verification engine");
    } finally {
      setVerificationLoading(false);
    }
  };

  const hasData = deal.underwriting.arv > 0;

  // Chart data formatting
  const expenseBreakdownData = hasData ? [
    { name: "Purchase Price", value: deal.underwriting.purchasePrice, color: "#4f46e5" }, // Indigo
    { name: "Rehab Budget", value: deal.underwriting.rehabCost, color: "#ea580c" }, // Orange
    { name: "Holding Costs", value: deal.underwriting.holdingCosts, color: "#eab308" }, // Yellow
    { name: "Financing Costs", value: deal.underwriting.financingCosts, color: "#16a34a" }, // Green
    { name: "Acquisition/Selling", value: deal.underwriting.acquisitionCosts + deal.underwriting.sellingCosts, color: "#db2777" } // Pink
  ] : [];

  const compsBarData = deal.comps.map(c => ({
    name: c.address.split(" ")[1] || c.address,
    Price: c.price,
    SqftPrice: c.pricePerSqft
  }));

  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }: any) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" className="text-[10px] font-bold">
        {percent > 0.05 ? `${(percent * 100).toFixed(0)}%` : ""}
      </text>
    );
  };

  // Flag wholesaling
  const isWholesaleCandidate = deal.description.toLowerCase().includes("wholesale") || deal.description.toLowerCase().includes("assignment");

  return (
    <div id="deal-underwriter-container" className="flex flex-col space-y-6 h-full">
      {/* Property Profile Header */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-6 shadow-md backdrop-blur-md">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                {deal.status}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-zinc-950 text-zinc-400 border border-zinc-850">
                Built {deal.yearBuilt}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-zinc-950 text-zinc-400 border border-zinc-850">
                {deal.lotSize} Acres
              </span>
            </div>
            <h1 className="text-xl font-extrabold text-zinc-100 tracking-tight">{deal.address}</h1>
            <p className="text-xs text-zinc-400 mt-1">{deal.city}, NC {deal.zip}</p>
            <p className="text-xs text-zinc-300 mt-3 leading-relaxed">{deal.description}</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 items-stretch lg:items-start flex-shrink-0">
            {/* 1-Click Unified Autonomous Pipeline Trigger */}
            {onLaunchAutonomousPipeline && (
              <button
                id="launch-auto-pipeline-btn"
                type="button"
                onClick={onLaunchAutonomousPipeline}
                className="flex items-center justify-center space-x-1.5 px-4 py-2.5 rounded-xl font-extrabold text-xs shadow-md bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white transition cursor-pointer border border-emerald-400/30"
                title="Execute all pipeline steps autonomously (Comps, Rehab, 70% Rule, NC Compliance, Escrow Draws & Legal Packet)"
              >
                <Zap className="h-4 w-4 fill-white" />
                <span>Go For Property (Auto Pipeline)</span>
              </button>
            )}

            {/* Run Analysis Trigger */}
            <button
              id="analyze-deal-btn"
              onClick={onRunAnalysis}
              disabled={isAnalyzing}
              className={`flex items-center justify-center space-x-2 px-3.5 py-2.5 rounded-xl font-bold text-xs shadow-xs transition duration-300 cursor-pointer ${
                isAnalyzing
                  ? "bg-zinc-850 border border-zinc-800 text-zinc-500 cursor-not-allowed"
                  : "bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700"
              }`}
            >
              <Play className={`h-4 w-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
              <span>{isAnalyzing ? `Analyzing (${activeAgent} Helper...)` : hasData ? "Re-Run AI" : "Run AI"}</span>
            </button>

            {/* Quick Status Setter */}
            <select
              value={deal.status}
              onChange={(e) => onUpdateStatus(e.target.value)}
              className="px-3 py-2 bg-zinc-950/60 border border-zinc-800 rounded-xl text-zinc-200 font-bold text-xs shadow-xs focus:ring-1 focus:ring-emerald-500/40 focus:bg-zinc-900 cursor-pointer"
            >
              <option value="Lead Ingest">1. Just Found</option>
              <option value="Property Enrichment">2. Info Found</option>
              <option value="ARV & Comps">3. Price Comps</option>
              <option value="Rehab & Estimating">4. Fix-up Costs</option>
              <option value="Underwriting">5. Money Math</option>
              <option value="Compliance & Offer">6. Check Laws</option>
              <option value="Renovation">7. Doing Repairs</option>
              <option value="Listed">8. For Sale</option>
              <option value="Completed">9. All Done!</option>
            </select>
          </div>
        </div>

        {/* Verified Real Estate Public Record Metadata Banner */}
        <div className="mt-4 p-3 bg-zinc-950/80 rounded-2xl border border-zinc-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center space-x-1.5 text-emerald-400 font-extrabold">
              <ShieldCheck className="h-4 w-4" />
              <span>Verified Real NC Public Record</span>
            </div>
            {deal.mlsNumber && (
              <span className="px-2 py-0.5 rounded-md bg-zinc-900 border border-zinc-750 font-bold text-zinc-300 text-[11px]">
                {deal.mlsNumber}
              </span>
            )}
            {deal.parcelId && (
              <span className="px-2 py-0.5 rounded-md bg-zinc-900 border border-zinc-750 font-semibold text-zinc-300 text-[11px]">
                Parcel: {deal.parcelId}
              </span>
            )}
            {deal.county && (
              <span className="px-2 py-0.5 rounded-md bg-zinc-900 border border-zinc-750 text-zinc-400 text-[11px]">
                {deal.county}
              </span>
            )}
            {deal.taxAssessment && (
              <span className="text-[11px] text-zinc-400">
                Tax Assessed: <strong className="text-zinc-200">${deal.taxAssessment.toLocaleString()}</strong>
              </span>
            )}
          </div>

          {deal.gisPortalUrl && (
            <a
              href={deal.gisPortalUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center space-x-1 text-emerald-400 hover:text-emerald-300 font-bold text-[11px] bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20 transition cursor-pointer"
            >
              <Building className="h-3 w-3" />
              <span>Official County GIS Map ↗</span>
            </a>
          )}
        </div>

        {/* Specs Table */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-5 pt-4 border-t border-zinc-800/80">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-zinc-950 border border-zinc-850 rounded-xl text-zinc-400">
              <Home className="h-4 w-4" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold tracking-wider text-zinc-500">Layout</p>
              <p className="text-xs font-bold text-zinc-200">{deal.bed} Bed / {deal.bath} Bath</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className="p-2 bg-zinc-950 border border-zinc-850 rounded-xl text-zinc-400">
              <Clock className="h-4 w-4" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold tracking-wider text-zinc-500">Total Sqft</p>
              <p className="text-xs font-bold text-zinc-200">{deal.sqft.toLocaleString()} Sqft</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className="p-2 bg-zinc-950 border border-zinc-850 rounded-xl text-zinc-400">
              <DollarSign className="h-4 w-4" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold tracking-wider text-zinc-500">Seller's Price</p>
              <p className="text-xs font-bold text-zinc-200">${deal.askingPrice.toLocaleString()}</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className="p-2 bg-zinc-950 border border-zinc-850 rounded-xl text-zinc-400">
              <Activity className="h-4 w-4" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold tracking-wider text-zinc-500">District Class</p>
              <p className="text-xs font-bold text-zinc-200">{deal.yearBuilt < 1945 ? "Historic Overlay" : "Standard Residential"}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Human-In-The-Loop Approval Gates */}
      <div className="bg-zinc-950/40 border border-zinc-800/60 rounded-3xl p-5 backdrop-blur-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center space-x-2.5">
            <UserCheck className="h-5 w-5 text-emerald-400 flex-shrink-0" />
            <div>
              <h3 className="font-bold text-sm text-zinc-200">Double-Check Steps</h3>
              <p className="text-[10px] text-zinc-500">Review and approve these details before moving forward.</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            <label className="flex items-center space-x-2 cursor-pointer bg-zinc-900 px-3.5 py-1.5 rounded-xl border border-zinc-800 text-xs font-medium text-zinc-300 hover:bg-zinc-850 shadow-xs transition">
              <input 
                type="checkbox" 
                checked={gates.compsApproved}
                disabled={deal.comps.length === 0}
                onChange={() => handleGateChange("compsApproved")}
                className="rounded border-zinc-800 text-emerald-500 bg-zinc-950 focus:ring-emerald-500/40 h-3.5 w-3.5 cursor-pointer"
              />
              <span>Approve House Value Comps</span>
            </label>

            <label className="flex items-center space-x-2 cursor-pointer bg-zinc-900 px-3.5 py-1.5 rounded-xl border border-zinc-800 text-xs font-medium text-zinc-300 hover:bg-zinc-850 shadow-xs transition">
              <input 
                type="checkbox" 
                checked={gates.rehabApproved}
                disabled={deal.rehabItems.length === 0}
                onChange={() => handleGateChange("rehabApproved")}
                className="rounded border-zinc-800 text-emerald-500 bg-zinc-950 focus:ring-emerald-500/40 h-3.5 w-3.5 cursor-pointer"
              />
              <span>Approve Repairs Budget</span>
            </label>

            <label className="flex items-center space-x-2 cursor-pointer bg-zinc-900 px-3.5 py-1.5 rounded-xl border border-zinc-800 text-xs font-medium text-zinc-300 hover:bg-zinc-850 shadow-xs transition">
              <input 
                type="checkbox" 
                checked={gates.complianceApproved}
                disabled={deal.complianceChecks.length === 0}
                onChange={() => handleGateChange("complianceApproved")}
                className="rounded border-zinc-800 text-emerald-500 bg-zinc-950 focus:ring-emerald-500/40 h-3.5 w-3.5 cursor-pointer"
              />
              <span>Check NC Laws & Rules</span>
            </label>
          </div>
        </div>
      </div>

      {/* Analysis Tabs */}
      <div className="flex flex-col">
        {/* Navigation Tabs */}
        <div className="flex border-b border-zinc-800 overflow-x-auto space-x-6 pb-px">
          {([
            { id: "overview", label: "Money Overview" },
            { id: "comps", label: "Nearby House Prices" },
            { id: "rehab", label: "Repair List" },
            { id: "compliance", label: "Legal Rules Check" },
            { id: "milestones", label: "Timeline & Crews" },
            { id: "financing", label: "Ways to Pay (Loans)" },
            { id: "draws", label: "Escrow & Draw Bridge" },
            { id: "logs", label: "AI Helper Log" }
          ] as const).map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-3 text-xs font-extrabold uppercase tracking-wider border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
                  isActive 
                    ? "border-emerald-500 text-emerald-400" 
                    : "border-transparent text-zinc-500 hover:text-zinc-300"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Contents */}
        <div className="py-5">
          {!hasData && activeTab !== "logs" ? (
            <div className="flex flex-col items-center justify-center py-16 px-6 text-center bg-zinc-900/50 border border-zinc-800/80 rounded-3xl backdrop-blur-md">
              <Activity className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
              <h3 className="font-extrabold text-zinc-200 text-xs uppercase tracking-wider">No Analysis Found Yet</h3>
              <p className="text-xs text-zinc-500 max-w-sm mt-1 mb-4">No AI calculations found yet. Click the "Run AI Analysis" button to have our AI helpers check prices, repair budgets, and laws!</p>
              <button
                onClick={onRunAnalysis}
                className="px-4 py-2.5 bg-emerald-600 text-white font-extrabold text-xs uppercase tracking-wide rounded-xl hover:bg-emerald-500 transition cursor-pointer"
              >
                Run AI Analysis Now
              </button>
            </div>
          ) : (
            <>
              {/* Tab: Overview */}
              {activeTab === "overview" && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Left: Metric block */}
                  <div className="lg:col-span-4 space-y-4">
                    <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] uppercase font-extrabold tracking-wider text-emerald-400">Leftover Profit</span>
                        <h2 className="text-3xl font-extrabold text-zinc-100 mt-1">
                          ${deal.underwriting.projectedProfit.toLocaleString()}
                        </h2>
                      </div>
                      <div className="flex items-center text-[10px] font-extrabold text-emerald-300 mt-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-1.5 px-3.5 w-max">
                        <TrendingUp className="h-3.5 w-3.5 mr-1" />
                        <span>ROI: {deal.underwriting.roi}%</span>
                      </div>
                    </div>

                    <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] uppercase font-extrabold tracking-wider text-indigo-400">Suggested Max Offer</span>
                        <h2 className="text-xl font-extrabold text-zinc-200 mt-1">
                          ${deal.underwriting.maxOffer70Rule.toLocaleString()}
                        </h2>
                      </div>
                      <p className="text-[10px] text-zinc-500 mt-2">
                        Formula: (Future Selling Price × 70%) – Repair Costs
                      </p>
                    </div>

                    <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-3">
                      <h4 className="text-xs font-extrabold text-zinc-200 uppercase tracking-wider pb-1.5 border-b border-zinc-800">Money Scorecard</h4>
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-400 font-medium">Future Selling Price</span>
                        <span className="font-bold text-zinc-200">${deal.underwriting.arv.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-400 font-medium">Buy Price</span>
                        <span className="font-bold text-zinc-200">${deal.underwriting.purchasePrice.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-400 font-medium">Repair Costs</span>
                        <span className="font-bold text-amber-400">${deal.underwriting.rehabCost.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-xs pt-1.5 border-t border-zinc-800/60">
                        <span className="text-zinc-400 font-medium">Buying Fees</span>
                        <span className="font-bold text-zinc-300">${deal.underwriting.acquisitionCosts.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-400 font-medium">Utility & Keeping Fees ({deal.underwriting.holdingPeriodMonths} mo)</span>
                        <span className="font-bold text-zinc-300">${deal.underwriting.holdingCosts.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-400 font-medium">Borrowing Fees</span>
                        <span className="font-bold text-zinc-300">${deal.underwriting.financingCosts.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-400 font-medium">Agent & Selling Fees</span>
                        <span className="font-bold text-zinc-300">${deal.underwriting.sellingCosts.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Charts */}
                  <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Expense Breakdown Pie */}
                    <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 flex flex-col h-80">
                      <h4 className="text-xs font-bold text-zinc-300 mb-2 uppercase tracking-wider">Where the Money Goes</h4>
                      <div className="flex-1 min-h-0 relative">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={expenseBreakdownData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={renderCustomizedLabel}
                              outerRadius={80}
                              fill="#10b981"
                              dataKey="value"
                            >
                              {expenseBreakdownData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      {/* Legend */}
                      <div className="grid grid-cols-2 gap-1.5 text-[10px] text-zinc-400 mt-2">
                        {expenseBreakdownData.map((item) => (
                          <div key={item.name} className="flex items-center space-x-1.5">
                            <span className="h-2.5 w-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                            <span className="truncate">{item.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Comps Bar Chart */}
                    <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 flex flex-col h-80">
                      <h4 className="text-xs font-bold text-zinc-300 mb-2 uppercase tracking-wider">Comparables Market Pricing</h4>
                      <div className="flex-1 min-h-0">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={compsBarData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                            <XAxis dataKey="name" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                            <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(v) => `$${(v / 1000)}k`} />
                            <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                            <Bar dataKey="Price" fill="#10b981" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                      <p className="text-[10px] text-zinc-500 text-center mt-2">Comparables sales within 0.5 miles radius</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab: Comps */}
              {activeTab === "comps" && (
                <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-sm">
                  <div className="p-4 bg-zinc-950/60 border-b border-zinc-800 flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-extrabold text-zinc-200 uppercase tracking-wide">Similar Houses Nearby</h4>
                      <p className="text-[10px] text-zinc-400 mt-0.5">Value estimate confidence check: <span className="font-bold text-emerald-400">{deal.underwriting.arvConfidence} Confidence</span></p>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-zinc-800 text-xs text-zinc-400">
                      <thead className="bg-zinc-950/40 text-[10px] font-bold text-zinc-500 uppercase tracking-wider text-left">
                        <tr>
                          <th className="px-4 py-3">Address</th>
                          <th className="px-4 py-3">Distance</th>
                          <th className="px-4 py-3">Sale Date</th>
                          <th className="px-4 py-3">Layout</th>
                          <th className="px-4 py-3">Size (Sqft)</th>
                          <th className="px-4 py-3 text-right">Sale Price</th>
                          <th className="px-4 py-3 text-right">Price/Sqft</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-800/60 font-medium text-zinc-300">
                        {deal.comps.map((comp, i) => (
                          <tr key={i} className="hover:bg-zinc-950/40">
                            <td className="px-4 py-3.5 font-bold text-zinc-100">{comp.address}</td>
                            <td className="px-4 py-3.5">{comp.distance} miles</td>
                            <td className="px-4 py-3.5">{comp.saleDate}</td>
                            <td className="px-4 py-3.5">{comp.bed}b / {comp.bath}ba</td>
                            <td className="px-4 py-3.5">{comp.sqft.toLocaleString()}</td>
                            <td className="px-4 py-3.5 text-right font-extrabold text-zinc-100">${comp.price.toLocaleString()}</td>
                            <td className="px-4 py-3.5 text-right text-zinc-500">${comp.pricePerSqft}/sqft</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Tab: Rehab (Deep Construction Budget & Scope Manager) */}
              {activeTab === "rehab" && (
                <div className="space-y-6">
                  {/* 3D CAD Spatial Model Quick Banner */}
                  <div className="bg-gradient-to-r from-emerald-950/40 via-zinc-900/60 to-zinc-900/60 border border-emerald-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded-xl">
                        <Box className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-zinc-100 uppercase tracking-tight">
                          3D CAD House Floorplan & Spatial Fix Protocols
                        </h4>
                        <p className="text-[11px] text-zinc-400">
                          Inspect this property in 3D WebGL space, view MEP trade layers, and generate step-by-step NC code fix protocols.
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-xl uppercase tracking-wider">
                      Available in Top Nav: "3D CAD Fix Studio"
                    </span>
                  </div>

                  {/* Multimodal AI Vision Photo Defect Scanner (Only rendered if listing has images or user uploaded one) */}
                  {(deal.imageUrl || customImageBase64) && (
                    <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-sm p-5 space-y-4">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800/60 pb-4">
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <Sparkles className="h-4 w-4 text-emerald-400" />
                            <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">AI Property Photo Computer Vision Analyzer</h4>
                          </div>
                          <p className="text-[10px] text-zinc-400 mt-1">
                            Neural inspection scans uploaded site photographs to detect defects and calibrate itemized NC repair scopes.
                          </p>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <label className="flex items-center space-x-1.5 px-2.5 py-1 bg-zinc-950 hover:bg-zinc-850 text-zinc-300 rounded-xl border border-zinc-800 text-[10px] font-bold cursor-pointer transition">
                            <Upload className="h-3.5 w-3.5 text-indigo-400" />
                            <span>{customImageFileName ? customImageFileName.substring(0, 12) + "..." : "Upload Site Photo"}</span>
                            <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                          </label>

                          <div className="flex space-x-1 bg-zinc-950 p-1 rounded-xl border border-zinc-850">
                            <button
                              onClick={() => setPhotoScanType("kitchen")}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-wider transition ${
                                photoScanType === "kitchen" ? "bg-emerald-600 text-zinc-100" : "text-zinc-400 hover:text-zinc-200"
                              }`}
                            >
                              Kitchen
                            </button>
                            <button
                              onClick={() => setPhotoScanType("roof")}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-wider transition ${
                                photoScanType === "roof" ? "bg-emerald-600 text-zinc-100" : "text-zinc-400 hover:text-zinc-200"
                              }`}
                            >
                              Roof
                            </button>
                            <button
                              onClick={() => setPhotoScanType("exterior")}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-wider transition ${
                                photoScanType === "exterior" ? "bg-emerald-600 text-zinc-100" : "text-zinc-400 hover:text-zinc-200"
                              }`}
                            >
                              Exterior
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                        <div className="lg:col-span-6 relative bg-zinc-950 rounded-2xl border border-zinc-850 overflow-hidden aspect-video flex items-center justify-center">
                          <img
                            src={
                              customImageBase64
                                ? customImageBase64
                                : deal.imageUrl
                                ? deal.imageUrl
                                : ""
                            }
                            alt="Site Inspection Target"
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover opacity-90"
                          />

                          {isScanningPhoto && (
                            <div className="absolute inset-x-0 h-1.5 bg-emerald-500/80 shadow-lg shadow-emerald-500/80 animate-bounce z-10" style={{ animationDuration: "2s" }} />
                          )}

                          {scannedSections[photoScanType] && !isScanningPhoto && (
                            <>
                              {scanResults[photoScanType]?.detectedIssues?.map((issue: any, idx: number) => {
                                const b = issue.boundingBox || { top: 20 + idx * 25, left: 20, width: 60, height: 20 };
                                const isHigh = issue.severity === "high";
                                return (
                                  <div
                                    key={idx}
                                    style={{
                                      top: `${b.top}%`,
                                      left: `${b.left}%`,
                                      width: `${b.width}%`,
                                      height: `${b.height}%`
                                    }}
                                    className={`absolute border-2 border-dashed rounded-lg flex items-start p-1 pointer-events-none ${
                                      isHigh ? "border-rose-500 bg-rose-500/15" : "border-amber-500 bg-amber-500/15"
                                    }`}
                                  >
                                    <span className={`text-[8px] font-extrabold text-white px-1.5 py-0.5 rounded shadow ${
                                      isHigh ? "bg-rose-600" : "bg-amber-600"
                                    }`}>
                                      {issue.name} ({issue.confidence || 92}%)
                                    </span>
                                  </div>
                                );
                              })}
                            </>
                          )}

                          <div className="absolute bottom-3 left-3 right-3 bg-zinc-950/90 border border-zinc-800 p-2.5 rounded-xl flex items-center justify-between z-20">
                            <span className="text-[10px] font-bold text-zinc-300">
                              {isScanningPhoto
                                ? "⚡ Multimodal neural network analyzing defects..."
                                : scannedSections[photoScanType]
                                ? `✅ ${scanResults[photoScanType]?.detectedIssues?.length || 2} issues detected`
                                : "💤 Ready for computer vision inspection"}
                            </span>
                            {!isScanningPhoto && (
                              <button
                                id="btn-scan-photo"
                                onClick={handleRunPhotoScan}
                                className="bg-emerald-600 hover:bg-emerald-500 text-zinc-100 font-bold text-[9px] uppercase tracking-wider px-3 py-1.5 rounded-lg transition flex items-center space-x-1 cursor-pointer"
                              >
                                <Sparkles className="h-3 w-3" />
                                <span>{scannedSections[photoScanType] ? "Re-Scan" : "Scan Photo"}</span>
                              </button>
                            )}
                          </div>
                        </div>

                        <div className="lg:col-span-6 flex flex-col justify-center space-y-3">
                          <div className="flex items-center justify-between">
                            <h5 className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                              {scannedSections[photoScanType] ? "Inspection Discoveries & Cost Model" : "Inspection Standby"}
                            </h5>
                            {scannedSections[photoScanType] && (
                              <button
                                onClick={() => handleAddScanIssuesToBudget(photoScanType)}
                                className="px-2.5 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 rounded-lg text-[9px] font-bold uppercase tracking-wider transition cursor-pointer flex items-center space-x-1"
                              >
                                <Plus className="h-3 w-3" />
                                <span>Add to Rehab Budget</span>
                              </button>
                            )}
                          </div>

                          {scannedSections[photoScanType] && scanResults[photoScanType] ? (
                            <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-1">
                              {scanResults[photoScanType].detectedIssues?.map((issue: any, idx: number) => {
                                const isHigh = issue.severity === "high";
                                return (
                                  <div
                                    key={idx}
                                    className={`p-3 rounded-xl space-y-1 border ${
                                      isHigh
                                        ? "bg-rose-500/5 border-rose-500/20"
                                        : "bg-amber-500/5 border-amber-500/20"
                                    }`}
                                  >
                                    <div className="flex justify-between items-start">
                                      <div>
                                        <span className={`text-xs font-bold ${isHigh ? "text-rose-400" : "text-amber-400"}`}>
                                          {issue.name}
                                        </span>
                                        <span className="text-[9px] text-zinc-500 block">{issue.category}</span>
                                      </div>
                                      <span className={`text-xs font-extrabold ${isHigh ? "text-rose-400" : "text-amber-400"}`}>
                                        ${(issue.estimatedCostMin || 1500).toLocaleString()} - ${(issue.estimatedCostMax || 3000).toLocaleString()}
                                      </span>
                                    </div>
                                    <p className="text-[10px] text-zinc-400 leading-normal">
                                      {issue.description}
                                    </p>
                                  </div>
                                );
                              })}
                            </div>
                          ) : (
                            <div className="flex-1 flex flex-col items-center justify-center border-2 border-dashed border-zinc-850 p-6 rounded-2xl text-center bg-zinc-950/20">
                              <Sparkles className="h-6 w-6 text-zinc-700 mb-2" />
                              <p className="text-[11px] text-zinc-400 font-bold">Inspection Ready</p>
                              <p className="text-[10px] text-zinc-500 mt-1 max-w-xs leading-relaxed">
                                Click <strong>Scan Photo</strong> to extract defect coordinates and local trade cost estimates.
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Deep Construction Budgeting & Trade Scope Suite */}
                  <RehabBudgetManager
                    deal={deal}
                    onUpdateDeal={onUpdateDeal}
                    contractorNames={deal.contractors?.map((c) => c.name) || []}
                  />
                </div>
              )}

              {/* Tab: Compliance */}
              {activeTab === "compliance" && (
                <div className="space-y-4">
                  {isWholesaleCandidate && (
                    <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-5 flex items-start space-x-3 text-amber-300">
                      <ShieldAlert className="h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-bold text-xs text-amber-400">North Carolina Assignment Rule Notice</h4>
                        <p className="text-[11px] text-amber-300 mt-1 leading-relaxed">
                          This property is marked for assignment (wholesaling). Under North Carolina law, assigning a house contract requires an active NC broker license, or you must buy it first and sell it immediately (double-close). Please verify your license or plan to double-close!
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5">
                    <h4 className="text-xs font-bold text-zinc-200 mb-4 uppercase tracking-wider">Rules & Laws We Checked</h4>
                    <div className="space-y-3.5">
                      {deal.complianceChecks.map((chk, i) => (
                        <div key={i} className="flex items-start justify-between p-3.5 bg-zinc-950/40 rounded-xl border border-zinc-800/80">
                          <div className="flex items-start space-x-3">
                            <span className="p-1 px-2 rounded-lg bg-zinc-900 border border-zinc-800 font-extrabold text-[9px] text-zinc-400 mt-0.5">
                              {chk.category}
                            </span>
                            <div>
                              <h5 className="font-bold text-xs text-zinc-200">{chk.label}</h5>
                              <p className="text-[11px] text-zinc-400 mt-0.5 leading-normal">{chk.notes}</p>
                            </div>
                          </div>
                          
                          <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-extrabold border-2 ${
                            chk.status === "passed" 
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                              : chk.status === "warning" 
                              ? "bg-amber-500/10 text-amber-400 border-amber-500/20" 
                              : "bg-zinc-900 text-zinc-500 border-zinc-800"
                          }`}>
                            {chk.status === "passed" ? "Audited & Active" : chk.status === "warning" ? "Needs Action" : "Pending"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-zinc-950/60 border border-zinc-800 rounded-2xl p-5 flex items-center space-x-3.5">
                    <Info className="h-5 w-5 text-emerald-400 flex-shrink-0" />
                    <p className="text-[10px] text-zinc-400 leading-normal">
                      <strong>Tax Note:</strong> North Carolina single-member LLCs are disregarded entities. Flip profits are taxed as ordinary business income (10%–37%), not long-term capital gains, regardless of hold period. Account for holding property taxes (~0.7% assessed proxy) into monthly holding underwriting budgets.
                    </p>
                  </div>
                </div>
              )}

              {/* Tab: Milestones & Contractors */}
              {activeTab === "milestones" && (
                <div className="space-y-6">
                  {/* Top: Milestone Construction Schedule */}
                  <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800 mb-4">
                      <div>
                        <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                          Construction Milestones & Inspection Schedule
                        </h4>
                        <p className="text-[10px] text-zinc-400 mt-0.5">
                          Sequential trade phases tied to NC municipal code inspections and bank escrow draw approvals.
                        </p>
                      </div>
                      <span className="text-xs font-extrabold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/20">
                        {deal.milestones?.length || 0} Scheduled Phases
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                      {deal.milestones.map((mil, i) => (
                        <div key={i} className="bg-zinc-950/70 border border-zinc-850 rounded-xl p-3.5 relative overflow-hidden">
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="text-[9px] font-extrabold text-emerald-400 uppercase tracking-wider">
                                Phase 0{i + 1}
                              </span>
                              <h5 className="font-bold text-xs text-zinc-100 mt-0.5">{mil.title}</h5>
                            </div>
                            <span className="text-xs font-extrabold text-zinc-200">${mil.cost.toLocaleString()}</span>
                          </div>
                          <p className="text-[10px] text-zinc-400 mt-2 leading-relaxed">{mil.notes}</p>
                          <div className="flex justify-between items-center text-[9px] text-zinc-500 mt-2.5 pt-2 border-t border-zinc-900">
                            <span className="flex items-center space-x-1">
                              <Calendar className="h-3 w-3 text-zinc-400" />
                              <span>Due: {mil.dueDate}</span>
                            </span>
                            <span className="text-emerald-400 font-bold">Draw Eligible</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Deep Contractor & Subcontractor Compliance Suite */}
                  <ContractorManager
                    deal={deal}
                    onUpdateDeal={onUpdateDeal}
                  />
                </div>
              )}

              {/* Tab: Logs */}
              {activeTab === "logs" && (
                <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5">
                  <h4 className="text-xs font-bold text-zinc-200 mb-4 uppercase tracking-wider">Multi-Agent Sourcing & Underwriting Logs</h4>
                  <div className="space-y-3 text-xs">
                    {deal.logs.map((log) => (
                      <div key={log.id} className="p-3.5 bg-zinc-950/40 rounded-xl border border-zinc-850 flex items-start space-x-2.5">
                        <span className="px-2 py-0.5 rounded-lg bg-zinc-900 border border-zinc-850 text-[9px] font-extrabold text-zinc-400 mt-0.5 flex-shrink-0">
                          {log.agentName}
                        </span>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between">
                            <span className="font-bold text-zinc-200">{log.agentName} Agent</span>
                            <span className="text-[10px] text-zinc-500">{new Date(log.timestamp).toLocaleString()}</span>
                          </div>
                          <p className="text-zinc-300 mt-1.5 leading-relaxed text-[11px]">{log.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab: Financing Engine */}
              {activeTab === "financing" && (() => {
                const engine = new FinancingEngine();
                const evaluated = engine.evaluateAll(deal, investorProfile);
                const recommended = evaluated.find(r => r.fitCategory === "recommended") || evaluated[0];

                const getOutreachScript = (strategyName: string) => {
                  const rawSpread = deal.underwriting.arv - deal.underwriting.purchasePrice - deal.underwriting.rehabCost;

                  switch (strategyName) {
                    case "Contract Assignment (Wholesaling)":
                      return `Subject: EXCLUSIVE CONTRACT ASSIGNMENT: ${deal.address} (Charlotte Metro Distressed Bungalow)

Dear Investor / Cash Buyer,

I have secured a solid off-market contract assignment for the single-family residence located at ${deal.address}, ${deal.city}, NC ${deal.zip}.

This deal has been vetted under North Carolina HB 797 broker regulations (License Status: Active/Verified) and offers an exceptional return:
- Projected ARV: $${deal.underwriting.arv.toLocaleString()}
- Underwritten Purchase Contract Price: $${deal.underwriting.purchasePrice.toLocaleString()}
- Physical Rehab Budget Estimate: $${deal.underwriting.rehabCost.toLocaleString()}
- Estimated Assignment Fee: $10,000

We are assigning our equitable interest in this contract for a closing date within 14 days. Earnest Money Deposit of $1,000 is already escrowed at our designated local title firm.

Please reply immediately to receive the fully itemized construction repair scope list and comp report.

Best regards,
John`;

                    case "JV Equity Partnership":
                      return `Subject: JOINT-VENTURE FLIP PROPOSAL: ${deal.address}, ${deal.city}

Dear Joint Venture Partner,

I have underwritten a premium value-add residential flip located at ${deal.address}, ${deal.city}, NC. 

I am proposing a structured Joint Venture (JV) partnership with the following parameters:
- Acquisition Price: $${deal.underwriting.purchasePrice.toLocaleString()}
- Estimated Construction Repairs: $${deal.underwriting.rehabCost.toLocaleString()}
- Calculated ARV: $${deal.underwriting.arv.toLocaleString()}
- Target Investor ROI: ${recommended?.jvDetails?.partnerRoi.toFixed(1) || "18.5"}%

I will deliver 100% of construction oversight, North Carolina municipal permitting, and contractor coordination. I am seeking a capital partner to fund purchase + construction costs. Net profits will be split 50/50 upon a successful retail sale.

Let me know if you would like to schedule a walk-through of our physical scope items.

Best regards,
John`;

                    case "Hard Money + Partner Gap Funding":
                      return `Subject: Hard Money Scenario Submission + 2nd Lien Gap Request - ${deal.address}

Dear Capital Partner / Underwriter,

We are submitting a commercial hard money loan request combined with a private gap financing partner structure for our upcoming flip at ${deal.address}, ${deal.city}, NC.

Deal Parameters:
- Purchase Contract Price: $${deal.underwriting.purchasePrice.toLocaleString()}
- Estimated Repairs: $${deal.underwriting.rehabCost.toLocaleString()}
- Underwritten ARV: $${deal.underwriting.arv.toLocaleString()}

Capital Stack Request:
- Hard Money First Lien: $${Math.round(recommended?.loanAmount || (deal.askingPrice * 0.9)).toLocaleString()} (Capped at 70% ARV / 90% LTC)
- Requested Private Gap Second Lien: $${Math.round((deal.underwriting.purchasePrice + deal.underwriting.rehabCost) - (recommended?.loanAmount || (deal.askingPrice * 0.9)) + 5000).toLocaleString()} (covers points + remaining downpayment)

Our operator FICO is ${investorProfile.creditScore} with ${investorProfile.priorFlips} prior flips completed.

Please find the attached comp folders and itemized materials budget.

Best regards,
John`;

                    default:
                      return "No outreach template available for this strategy.";
                  }
                };

                const handleCopyOutreach = (text: string) => {
                  navigator.clipboard.writeText(text);
                  setCopiedOutreach(true);
                  setTimeout(() => setCopiedOutreach(false), 2000);
                };

                return (
                  <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                    {/* Left Panel: Investor Profile Settings */}
                    <div className="xl:col-span-4 bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 flex flex-col space-y-5">
                      <div>
                        <div className="flex items-center space-x-2">
                          <Sliders className="h-4 w-4 text-emerald-400" />
                          <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">Your Investment Details</h4>
                        </div>
                        <p className="text-[10px] text-zinc-500 mt-1 leading-normal">
                          Change these settings to see which loan matches your current cash and credit!
                        </p>
                      </div>

                      {/* 1. Experience Level */}
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">How Many Flips Have You Done?</label>
                        <div className="grid grid-cols-3 gap-2">
                          {(["Beginner", "Intermediate", "Professional"] as const).map((level) => {
                            const isSelected = investorProfile.experienceLevel === level;
                            return (
                              <button
                                key={level}
                                id={`profile-exp-${level}`}
                                onClick={() => setInvestorProfile({ ...investorProfile, experienceLevel: level })}
                                className={`py-2 px-1 text-[10px] font-bold rounded-lg border uppercase tracking-wider transition-all duration-200 ${
                                  isSelected
                                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/40"
                                    : "bg-zinc-950/40 text-zinc-400 border-zinc-800 hover:border-zinc-700"
                                }`}
                              >
                                {level}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* 2. Liquid Cash */}
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <label htmlFor="input-cash" className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Cash You Have Ready</label>
                          <span className="text-[11px] font-bold text-emerald-400">${investorProfile.cashAvailable.toLocaleString()}</span>
                        </div>
                        <div className="relative">
                          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-zinc-500">$</span>
                          <input
                            id="input-cash"
                            type="number"
                            value={investorProfile.cashAvailable}
                            onChange={(e) => setInvestorProfile({ ...investorProfile, cashAvailable: Math.max(0, parseInt(e.target.value) || 0) })}
                            className="w-full pl-7 pr-3 py-2 text-xs font-bold bg-zinc-950/40 border border-zinc-800 rounded-lg text-zinc-200 focus:outline-none focus:border-emerald-500/40 transition-all"
                          />
                        </div>
                      </div>

                      {/* 3. FICO Credit Score */}
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <label htmlFor="input-credit" className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Credit Score</label>
                          <span className="text-[11px] font-extrabold text-emerald-400">{investorProfile.creditScore}</span>
                        </div>
                        <input
                          id="input-credit"
                          type="range"
                          min="500"
                          max="850"
                          value={investorProfile.creditScore}
                          onChange={(e) => setInvestorProfile({ ...investorProfile, creditScore: parseInt(e.target.value) })}
                          className="w-full accent-emerald-500 bg-zinc-950 cursor-pointer h-1.5 rounded-lg"
                        />
                      </div>

                      {/* 4. Prior Flips */}
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <label htmlFor="input-flips" className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Houses You Fixed Before</label>
                          <span className="text-[11px] font-bold text-emerald-400">{investorProfile.priorFlips}</span>
                        </div>
                        <input
                          id="input-flips"
                          type="number"
                          min="0"
                          value={investorProfile.priorFlips}
                          onChange={(e) => setInvestorProfile({ ...investorProfile, priorFlips: Math.max(0, parseInt(e.target.value) || 0) })}
                          className="w-full px-3.5 py-2 text-xs font-bold bg-zinc-950/40 border border-zinc-800 rounded-lg text-zinc-200 focus:outline-none focus:border-emerald-500/40 transition-all"
                        />
                      </div>

                      {/* Toggles */}
                      <div className="space-y-3 pt-2 border-t border-zinc-800/60">
                        {/* Owns home */}
                        <div className="flex items-center justify-between p-2.5 bg-zinc-950/30 rounded-xl border border-zinc-850">
                          <div>
                            <span className="text-[10px] font-bold text-zinc-300 block">Do You Own a Home Right Now?</span>
                            <span className="text-[8px] text-zinc-500">Unlocks borrowing against your current home</span>
                          </div>
                          <input
                            id="toggle-owns-home"
                            type="checkbox"
                            checked={investorProfile.ownsHome}
                            onChange={(e) => setInvestorProfile({ ...investorProfile, ownsHome: e.target.checked })}
                            className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 bg-zinc-900 border-zinc-700"
                          />
                        </div>

                        {/* Broker License */}
                        <div className="flex flex-col space-y-1.5 p-2.5 bg-zinc-950/30 rounded-xl border border-zinc-850">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-[10px] font-bold text-zinc-300 block">Do You Have an NC Real Estate License?</span>
                              <span className="text-[8px] text-zinc-500">Needed if you want to assign contracts (wholesale)</span>
                            </div>
                            <input
                              id="toggle-broker-license"
                              type="checkbox"
                              checked={investorProfile.hasBrokerLicense}
                              onChange={(e) => setInvestorProfile({ ...investorProfile, hasBrokerLicense: e.target.checked })}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 bg-zinc-900 border-zinc-700"
                            />
                          </div>
                          {!investorProfile.hasBrokerLicense && (
                            <span className="text-[8px] text-amber-400 leading-normal bg-amber-500/5 p-1.5 px-2 rounded-lg border border-amber-500/10 block">
                              ⚠️ NC Rule Alert: You cannot assign house contracts (wholesale) without an active broker license.
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right Panel: Financing Engine Analysis */}
                    <div className="xl:col-span-8 flex flex-col space-y-6">
                      {/* Top Recommendation Block */}
                      {recommended ? (
                        <div className="bg-zinc-900/60 border border-emerald-500/20 rounded-2xl p-5 relative overflow-hidden">
                          {/* Accent line */}
                          <div className="absolute top-0 left-0 right-0 h-[2px] bg-emerald-500/30"></div>
                          
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                            <div>
                              <div className="flex items-center space-x-2">
                                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[8px] font-extrabold tracking-wider px-2 py-0.5 rounded-full uppercase">
                                  Top Match
                                </span>
                                <span className="text-[10px] font-bold text-zinc-400">Fit Score: {recommended.fitScore}/100</span>
                              </div>
                              <h3 className="text-base font-extrabold text-zinc-100 mt-1">{recommended.strategy}</h3>
                              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">{recommended.oneLineReason}</p>
                            </div>

                            <button
                              id="btn-outreach-top"
                              onClick={() => {
                                setSelectedStrategyForOutreach(recommended);
                                setCopiedOutreach(false);
                              }}
                              className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-400 text-zinc-950 py-2 px-3.5 rounded-xl font-bold text-[10px] uppercase tracking-wider flex items-center justify-center space-x-1.5 shadow-lg shadow-emerald-500/10 transition-all duration-200"
                            >
                              <Sparkles className="h-3 w-3" />
                              <span>Draft outreach message</span>
                            </button>
                          </div>

                          {/* Quick Summary Grid */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-5 pt-4 border-t border-zinc-800/60">
                            <div>
                              <span className="text-[8px] text-zinc-500 font-bold uppercase tracking-wider">Cash You Need to Close</span>
                              <span className="text-sm font-extrabold text-zinc-200 block mt-0.5">${Math.round(recommended.cashToClose).toLocaleString()}</span>
                            </div>
                            <div>
                              <span className="text-[8px] text-zinc-500 font-bold uppercase tracking-wider">Money to Borrow</span>
                              <span className="text-sm font-extrabold text-zinc-200 block mt-0.5">${Math.round(recommended.loanAmount).toLocaleString()}</span>
                            </div>
                            <div>
                              <span className="text-[8px] text-zinc-500 font-bold uppercase tracking-wider">Interest Rate</span>
                              <span className="text-sm font-extrabold text-zinc-200 block mt-0.5">{recommended.interestRate > 0 ? `${(recommended.interestRate * 100).toFixed(1)}%` : "N/A"}</span>
                            </div>
                            <div>
                              <span className="text-[8px] text-zinc-500 font-bold uppercase tracking-wider">Risk Level</span>
                              <span className="text-sm font-extrabold text-zinc-200 block mt-0.5 capitalize">{recommended.riskLevel}</span>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-zinc-900/60 border border-amber-500/10 rounded-2xl p-5 text-center">
                          <AlertCircle className="h-5 w-5 text-amber-400 mx-auto mb-2" />
                          <h4 className="text-xs font-bold text-zinc-200">No recommended strategies found</h4>
                          <p className="text-[10px] text-zinc-500 mt-1 max-w-sm mx-auto">
                            The investor's parameters do not fulfill recommended criteria. Review eligible strategies or adjust cash reserves.
                          </p>
                        </div>
                      )}

                      {/* Strategy Rankings Table */}
                      <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5">
                        <div className="flex justify-between items-center mb-4">
                          <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">No-Money-Down Pipelines (Ranked)</h4>
                          <span className="text-[9px] bg-zinc-950 text-emerald-400 font-bold border border-emerald-500/10 px-2 py-0.5 rounded uppercase">
                            Autonomous Evaluator
                          </span>
                        </div>

                        <div className="space-y-2.5">
                          {evaluated.map((strat, i) => {
                            const isEligible = strat.fitCategory !== "not_eligible";
                            const isSelected = selectedStrategyForOutreach?.strategy === strat.strategy;

                            return (
                              <div
                                key={i}
                                className={`p-4 bg-zinc-950/40 rounded-xl border transition-all duration-200 ${
                                  isEligible
                                    ? isSelected
                                      ? "border-emerald-500/30 bg-emerald-500/[0.01]"
                                      : "border-zinc-800/80 hover:border-zinc-750"
                                    : "border-zinc-800/40 opacity-60"
                                }`}
                              >
                                <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                                  {/* Left: Score & Details */}
                                  <div className="flex items-start space-x-3.5 flex-1 min-w-0">
                                    <div className="flex flex-col items-center justify-center h-12 w-12 rounded-lg bg-zinc-900 border border-zinc-800 flex-shrink-0">
                                      <span className={`text-sm font-extrabold ${isEligible ? "text-emerald-400" : "text-zinc-500"}`}>
                                        {isEligible ? `${strat.fitScore}` : "✗"}
                                      </span>
                                      <span className="text-[7px] text-zinc-500 font-extrabold uppercase tracking-tight">Score</span>
                                    </div>

                                    <div className="min-w-0 flex-1">
                                      <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                                        <h5 className="font-bold text-xs text-zinc-100">{strat.strategy}</h5>
                                        {strat.fitCategory === "recommended" && (
                                          <span className="text-[7px] font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                                            Recommended
                                          </span>
                                        )}
                                        {strat.fitCategory === "viable" && (
                                          <span className="text-[7px] font-extrabold bg-sky-500/10 text-sky-400 border border-sky-500/25 px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                                            Viable
                                          </span>
                                        )}
                                        {strat.fitCategory === "not_eligible" && (
                                          <span className="text-[7px] font-extrabold bg-red-500/10 text-red-400 border border-red-500/25 px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                                            Ineligible
                                          </span>
                                        )}
                                      </div>
                                      <p className="text-[10px] text-zinc-400 mt-1.5 leading-normal">{strat.oneLineReason}</p>
                                    </div>
                                  </div>

                                  {/* Right: Key metrics */}
                                  <div className="flex items-center justify-between sm:justify-start gap-6 w-full md:w-auto text-[11px] pt-3 md:pt-0 border-t md:border-t-0 border-zinc-800/40">
                                    <div>
                                      <span className="text-[7px] text-zinc-500 block font-bold uppercase tracking-wider">Cash You Need</span>
                                      <span className="font-bold text-zinc-200">${Math.round(strat.cashToClose).toLocaleString()}</span>
                                    </div>
                                    <div>
                                      <span className="text-[7px] text-zinc-500 block font-bold uppercase tracking-wider">Interest Rate</span>
                                      <span className="font-bold text-zinc-200">{strat.interestRate > 0 ? `${(strat.interestRate * 100).toFixed(1)}%` : "0.0%"}</span>
                                    </div>
                                    <div>
                                      <span className="text-[7px] text-zinc-500 block font-bold uppercase tracking-wider">Risk Level</span>
                                      <span className={`font-semibold capitalize ${
                                        strat.riskLevel === "low" ? "text-emerald-400" : strat.riskLevel === "moderate" ? "text-amber-400" : "text-rose-400"
                                      }`}>{strat.riskLevel}</span>
                                    </div>
                                    {isEligible && (
                                      <button
                                        id={`btn-outreach-strat-${i}`}
                                        onClick={() => {
                                          setSelectedStrategyForOutreach(strat);
                                          setCopiedOutreach(false);
                                        }}
                                        className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 p-1.5 px-2.5 rounded-lg text-[9px] font-bold uppercase text-zinc-300 tracking-wider flex items-center space-x-1 transition-all cursor-pointer"
                                      >
                                        <Mail className="h-3 w-3" />
                                        <span>Draft Email</span>
                                      </button>
                                    )}
                                  </div>
                                </div>

                                {/* Pathway Deep-Dive dashboards inside each strategy details */}
                                {isEligible && (
                                  <div className="mt-4 pt-4 border-t border-zinc-850 space-y-4">
                                    {/* 1. Wholesaling (Assignment) Detail Dashboard */}
                                    {strat.strategy === "Contract Assignment (Wholesaling)" && strat.assignmentDetails && (
                                      <div className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-xl space-y-3.5">
                                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                                          <div>
                                            <span className="text-[8px] font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded uppercase tracking-wide">
                                              Wholesale Pipeline Hub
                                            </span>
                                            <h6 className="text-[11px] font-bold text-zinc-250 mt-1">Contract Assignment Viability Ledger</h6>
                                          </div>
                                          <div className="flex items-center space-x-4">
                                            <div>
                                              <span className="text-[7px] text-zinc-500 font-extrabold uppercase tracking-wider block">Viability Index</span>
                                              <span className="text-xs font-extrabold text-emerald-400">{strat.assignmentDetails.viabilityScore}/100</span>
                                            </div>
                                            <div>
                                              <span className="text-[7px] text-zinc-500 font-extrabold uppercase tracking-wider block">Est. Assignment Fee</span>
                                              <span className="text-xs font-extrabold text-emerald-400">{strat.assignmentDetails.feeRange}</span>
                                            </div>
                                          </div>
                                        </div>

                                        {/* Cash Buyer Graph Table */}
                                        <div className="space-y-2">
                                          <div className="flex justify-between items-center">
                                            <span className="text-[8px] font-extrabold uppercase text-zinc-400 tracking-wider">Top Cash Buyers Vetted in Zip ({deal.zip})</span>
                                            <span className="text-[8px] font-bold text-zinc-500 uppercase">Ranked by Matching buy-box score</span>
                                          </div>
                                          <div className="overflow-x-auto">
                                            <table className="min-w-full text-[9px] text-zinc-400 divide-y divide-zinc-900">
                                              <thead className="bg-zinc-900/40 text-[7px] text-zinc-500 uppercase font-bold tracking-wider">
                                                <tr>
                                                  <th className="px-2.5 py-1.5 text-left">Buyer Group</th>
                                                  <th className="px-2.5 py-1.5 text-left">Target Buy Box</th>
                                                  <th className="px-2.5 py-1.5 text-center">Closing Speed</th>
                                                  <th className="px-2.5 py-1.5 text-right">Match Score</th>
                                                </tr>
                                              </thead>
                                              <tbody className="divide-y divide-zinc-900/40 font-medium">
                                                {strat.assignmentDetails.buyerMatches.map((buyer, bIdx) => (
                                                  <tr key={bIdx} className="hover:bg-zinc-900/20">
                                                    <td className="px-2.5 py-2 font-bold text-zinc-250">{buyer.name}</td>
                                                    <td className="px-2.5 py-2 text-zinc-400">{buyer.buyBox}</td>
                                                    <td className="px-2.5 py-2 text-center text-zinc-300">{buyer.speed}</td>
                                                    <td className="px-2.5 py-2 text-right text-emerald-400 font-bold">{buyer.score}%</td>
                                                  </tr>
                                                ))}
                                              </tbody>
                                            </table>
                                          </div>
                                        </div>

                                        <div className="flex justify-end pt-1">
                                          <button
                                            onClick={() => openDocModal("wholesale_assignment")}
                                            className="bg-emerald-600 hover:bg-emerald-500 text-zinc-100 font-bold text-[8px] uppercase tracking-wider px-2.5 py-1 rounded transition flex items-center space-x-1 cursor-pointer"
                                          >
                                            <FileText className="h-2.5 w-2.5" />
                                            <span>Generate NC HB 797 Assignment Packet</span>
                                          </button>
                                        </div>
                                      </div>
                                    )}

                                    {/* 2. JV Equity Partnership Detail Dashboard */}
                                    {strat.strategy === "JV Equity Partnership" && strat.jvDetails && (
                                      <div className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-xl space-y-3.5">
                                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                                          <div>
                                            <span className="text-[8px] font-extrabold bg-sky-500/10 text-sky-400 border border-sky-500/20 px-2 py-0.5 rounded uppercase tracking-wide">
                                              JV Partnership Engine
                                            </span>
                                            <h6 className="text-[11px] font-bold text-zinc-250 mt-1">Equity Splits & Cash Returns Simulator</h6>
                                          </div>
                                          <div className="flex items-center space-x-4">
                                            <div>
                                              <span className="text-[7px] text-zinc-500 font-extrabold uppercase tracking-wider block">Partner Risk Index</span>
                                              <span className={`text-xs font-extrabold ${strat.jvDetails.partnerRiskIndex < 60 ? "text-emerald-400" : "text-amber-400"}`}>
                                                {strat.jvDetails.partnerRiskIndex}/100 (Low Risk)
                                              </span>
                                            </div>
                                            <div>
                                              <span className="text-[7px] text-zinc-500 font-extrabold uppercase tracking-wider block">Operator ROI</span>
                                              <span className="text-xs font-extrabold text-emerald-400">Infinite (Zero Cash Out)</span>
                                            </div>
                                          </div>
                                        </div>

                                        {/* Capital splits grid */}
                                        <div className="space-y-2">
                                          <span className="text-[8px] font-extrabold uppercase text-zinc-400 tracking-wider">Simulated Return Distributions</span>
                                          <div className="overflow-x-auto">
                                            <table className="min-w-full text-[9px] text-zinc-400 divide-y divide-zinc-900">
                                              <thead className="bg-zinc-900/40 text-[7px] text-zinc-500 uppercase font-bold tracking-wider">
                                                <tr>
                                                  <th className="px-2.5 py-1.5 text-left">Split Mechanism</th>
                                                  <th className="px-2.5 py-1.5 text-right">Partner Profit ($)</th>
                                                  <th className="px-2.5 py-1.5 text-right">Operator Profit ($)</th>
                                                  <th className="px-2.5 py-1.5 text-right">Passive Partner ROI</th>
                                                </tr>
                                              </thead>
                                              <tbody className="divide-y divide-zinc-900/40 font-medium">
                                                {strat.jvDetails.splits.map((s, sIdx) => (
                                                  <tr key={sIdx} className="hover:bg-zinc-900/20">
                                                    <td className="px-2.5 py-2 font-bold text-zinc-250">{s.ratio}</td>
                                                    <td className="px-2.5 py-2 text-right text-zinc-350">${Math.round(s.partnerProfit).toLocaleString()}</td>
                                                    <td className="px-2.5 py-2 text-right text-emerald-400 font-bold">${Math.round(s.userProfit).toLocaleString()}</td>
                                                    <td className="px-2.5 py-2 text-right text-emerald-400 font-bold">{s.partnerRoi.toFixed(1)}%</td>
                                                  </tr>
                                                ))}
                                              </tbody>
                                            </table>
                                          </div>
                                        </div>

                                        <div className="flex justify-end pt-1">
                                          <button
                                            onClick={() => alert("✅ Auto-compiled joint venture proposal kit, corporate draft deed parameters, construction schedules, and partner ROI projection decks. Saved to /exports/jv-proposal.pdf")}
                                            className="bg-sky-600 hover:bg-sky-500 text-zinc-100 font-bold text-[8px] uppercase tracking-wider px-2.5 py-1 rounded transition"
                                          >
                                            Generate JV Presentation Kit
                                          </button>
                                        </div>
                                      </div>
                                    )}

                                    {/* 3. Hard Money + Partner Gap Funding Dashboard */}
                                    {strat.strategy === "Hard Money + Partner Gap Funding" && strat.zeroCashDetails && (
                                      <div className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-xl space-y-3.5">
                                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                                          <div>
                                            <span className="text-[8px] font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded uppercase tracking-wide">
                                              Capital Stack Constructor
                                            </span>
                                            <h6 className="text-[11px] font-bold text-zinc-250 mt-1">Layered Debt & Capital Placement Ledger</h6>
                                          </div>
                                          <div className="flex items-center space-x-4">
                                            <div>
                                              <span className="text-[7px] text-zinc-500 font-extrabold uppercase tracking-wider block">Feasibility Index</span>
                                              <span className="text-xs font-extrabold text-emerald-400">{strat.zeroCashDetails.feasibilityScore}/100</span>
                                            </div>
                                            <div>
                                              <span className="text-[7px] text-zinc-500 font-extrabold uppercase tracking-wider block">Lender Fit score</span>
                                              <span className="text-xs font-extrabold text-emerald-400">{strat.zeroCashDetails.lenderFitScore}/100</span>
                                            </div>
                                          </div>
                                        </div>

                                        {/* Structured Capital Stack */}
                                        <div className="space-y-2">
                                          <span className="text-[8px] font-extrabold uppercase text-zinc-400 tracking-wider block">100% Zero-Cash Allocation Plan</span>
                                          <div className="overflow-x-auto">
                                            <table className="min-w-full text-[9px] text-zinc-400 divide-y divide-zinc-900">
                                              <thead className="bg-zinc-900/40 text-[7px] text-zinc-500 uppercase font-bold tracking-wider">
                                                <tr>
                                                  <th className="px-2.5 py-1.5 text-left">Financing Layer</th>
                                                  <th className="px-2.5 py-1.5 text-right">Amount Funded</th>
                                                  <th className="px-2.5 py-1.5 text-left">Repayment terms</th>
                                                  <th className="px-2.5 py-1.5 text-left">Collateral/Securities</th>
                                                </tr>
                                              </thead>
                                              <tbody className="divide-y divide-zinc-900/40 font-medium">
                                                {strat.zeroCashDetails.capitalStack.map((stack, stackIdx) => (
                                                  <tr key={stackIdx} className="hover:bg-zinc-900/20">
                                                    <td className="px-2.5 py-2 font-bold text-zinc-250">{stack.source}</td>
                                                    <td className="px-2.5 py-2 text-right font-extrabold text-zinc-150">${Math.round(stack.amount).toLocaleString()}</td>
                                                    <td className="px-2.5 py-2 text-zinc-400">{stack.rate}</td>
                                                    <td className="px-2.5 py-2 text-zinc-500 text-[8px]">{stack.secured}</td>
                                                  </tr>
                                                ))}
                                              </tbody>
                                            </table>
                                          </div>
                                        </div>

                                        {/* Capital costs reserves */}
                                        <div className="grid grid-cols-2 gap-4 p-2.5 bg-zinc-900/30 border border-zinc-850/60 rounded-lg text-[9px] text-zinc-400">
                                          <div>
                                            <span className="text-zinc-500 text-[7px] font-bold uppercase block">Monthly Interest Costs</span>
                                            <span className="text-zinc-300 font-extrabold">${Math.round(strat.zeroCashDetails.interestReserve6Mo / 6).toLocaleString()} / month</span>
                                          </div>
                                          <div>
                                            <span className="text-zinc-500 text-[7px] font-bold uppercase block">6-Month Capital holding Reserves</span>
                                            <span className="text-zinc-300 font-extrabold">${Math.round(strat.zeroCashDetails.interestReserve6Mo).toLocaleString()}</span>
                                          </div>
                                          <div className="col-span-2 pt-1 border-t border-zinc-900 flex justify-between items-center">
                                            <span>Origination Points Cost: <strong>${Math.round(strat.zeroCashDetails.pointsCost).toLocaleString()}</strong></span>
                                            <button
                                              onClick={() => openDocModal("proof_of_funds")}
                                              className="bg-emerald-600 hover:bg-emerald-500 text-zinc-100 font-bold text-[8px] uppercase tracking-wider px-2 py-0.5 rounded transition flex items-center space-x-1 cursor-pointer"
                                            >
                                              <ShieldCheck className="h-2.5 w-2.5" />
                                              <span>Generate Escrow & Lender Certificate</span>
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    )}

                                    {/* Baseline Pros and Cons */}
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-[10px]">
                                      <div>
                                        <span className="text-[8px] font-bold text-emerald-400/80 uppercase tracking-wider block mb-1">✓ Good Stuff</span>
                                        <ul className="space-y-1 text-zinc-400 list-disc list-inside">
                                          {strat.pros.slice(0, 3).map((p, idx) => <li key={idx} className="line-clamp-1">{p}</li>)}
                                        </ul>
                                      </div>
                                      <div>
                                        <span className="text-[8px] font-bold text-rose-400/80 uppercase tracking-wider block mb-1">✗ Watch Out For</span>
                                        <ul className="space-y-1 text-zinc-400 list-disc list-inside">
                                          {strat.cons.slice(0, 3).map((c, idx) => <li key={idx} className="line-clamp-1">{c}</li>)}
                                        </ul>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* standalone Market Downturn Stress Test (Sensitivity Analysis) Panel */}
                      {recommended && recommended.stressTest && (
                        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-4">
                          <div className="flex items-center space-x-1.5">
                            <Activity className="h-4 w-4 text-rose-400" />
                            <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                              Market Downturn Stress Test (Sensitivity Analysis)
                            </h4>
                          </div>

                          <p className="text-[10px] text-zinc-400 leading-normal">
                            We simulate local market corrections and construction delays to pressure-test the project's profit cushions. Real-world protective underwriting.
                          </p>

                          {/* warning box */}
                          <div className={`p-3.5 rounded-xl border text-[10px] leading-relaxed font-semibold ${
                            recommended.stressTest.isHighRisk 
                              ? "bg-rose-500/10 border-rose-500/20 text-rose-300"
                              : "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
                          }`}>
                            {recommended.stressTest.warningMessage}
                          </div>

                          <div className="overflow-x-auto">
                            <table className="min-w-full text-[9px] text-zinc-400 divide-y divide-zinc-800">
                              <thead className="bg-zinc-950/40 text-[7px] text-zinc-500 uppercase font-bold tracking-wider">
                                <tr>
                                  <th className="px-3 py-2 text-left">Stress Scenario</th>
                                  <th className="px-3 py-2 text-right">Projected Profit</th>
                                  <th className="px-3 py-2 text-left">Stress Assessment Impact</th>
                                  <th className="px-3 py-2 text-left">Detailed Notes</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-800/40 font-medium text-zinc-300">
                                {recommended.stressTest.scenarios.map((sc, sIdx) => (
                                  <tr key={sIdx} className="hover:bg-zinc-950/20">
                                    <td className="px-3 py-2.5 font-bold text-zinc-150">{sc.scenario}</td>
                                    <td className={`px-3 py-2.5 text-right font-extrabold ${sc.projectedProfit <= 0 ? "text-rose-400" : "text-emerald-400"}`}>
                                      ${Math.round(sc.projectedProfit).toLocaleString()}
                                    </td>
                                    <td className="px-3 py-2.5">
                                      <span className={`inline-block px-2 py-0.5 rounded text-[8px] font-extrabold uppercase ${
                                        sc.projectedProfit <= 0 
                                          ? "bg-rose-500/10 text-rose-400 border border-rose-500/20" 
                                          : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                      }`}>
                                        {sc.projectedProfit <= 0 ? "⚠️ Capital Loss Alert" : "✓ Profit Safe"}
                                      </span>
                                    </td>
                                    <td className="px-3 py-2.5 text-zinc-400 text-[8px] leading-normal">{sc.notes}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}

                      {/* Outreach Script Panel */}
                      {selectedStrategyForOutreach && (
                        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 relative">
                          <div className="flex justify-between items-center mb-3">
                            <div className="flex items-center space-x-1.5">
                              <Sparkles className="h-4 w-4 text-emerald-400" />
                              <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                                Dynamic Lender / Partner Outreach Script
                              </h4>
                            </div>
                            <button
                              id="btn-close-outreach"
                              onClick={() => setSelectedStrategyForOutreach(null)}
                              className="text-zinc-500 hover:text-zinc-300 text-xs font-bold uppercase cursor-pointer"
                            >
                              Close
                            </button>
                          </div>

                          <p className="text-[10px] text-zinc-500 mb-4 leading-normal">
                            This script is pre-compiled using deterministic property parameters and the investor profile. Ready to copy and deliver to local NC funding parties.
                          </p>

                          <div className="bg-zinc-950/70 border border-zinc-850 rounded-xl p-4 relative font-mono text-[10px] text-zinc-300 leading-relaxed whitespace-pre-wrap max-h-80 overflow-y-auto">
                            {getOutreachScript(selectedStrategyForOutreach.strategy)}

                            <button
                              id="btn-copy-script"
                              onClick={() => handleCopyOutreach(getOutreachScript(selectedStrategyForOutreach.strategy))}
                              className="absolute top-3 right-3 bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 p-1.5 px-3 rounded-lg text-[9px] font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1 transition-all cursor-pointer"
                            >
                              {copiedOutreach ? <CheckCircle2 className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                              <span>{copiedOutreach ? "Copied!" : "Copy"}</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Tab: Escrow & Draw Bridge */}
              {activeTab === "draws" && (() => {
                const approvedChangeOrders = changeOrders.filter(co => co.status === "approved");
                const totalApprovedCoCost = approvedChangeOrders.reduce((sum, co) => sum + co.proposedCost, 0);
                const totalEscrowPool = (deal.underwriting.rehabCost || 0) + totalApprovedCoCost;
                
                const completedMilestoneIds = deal.milestones.filter(m => m.status === "completed").map(m => m.id);
                const completedDraws = transactions.filter(t => t.type === "draw_release" && t.status === "completed");
                const totalReleasedDraws = completedDraws.reduce((sum, t) => sum + t.amount, 0);
                const escrowRemaining = totalEscrowPool - totalReleasedDraws;

                const getChangeOrderImpact = (directCost: number, days: number) => {
                  const extraHolding = Math.round(holdingCostMonthly * (days / 30));
                  const extraInterest = Math.round(loanBalance * (loanRate / 100) * (days / 365));
                  const totalImpact = directCost + extraHolding + extraInterest;
                  
                  const currentProfit = deal.underwriting.projectedProfit || 0;
                  const newProfit = currentProfit - totalImpact;
                  
                  const originalInvested = (deal.underwriting.purchasePrice || 0) + (deal.underwriting.rehabCost || 0);
                  const newInvested = originalInvested + directCost;
                  const newRoi = newInvested > 0 ? Number(((newProfit / newInvested) * 100).toFixed(1)) : 0;
                  
                  return {
                    extraHolding,
                    extraInterest,
                    totalImpact,
                    newProfit,
                    newRoi
                  };
                };

                return (
                  <div className="space-y-6">
                    {/* Summary / Stats Bar */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="bg-zinc-900/60 border border-zinc-800/85 rounded-2xl p-4 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] uppercase font-extrabold tracking-wider text-indigo-400">Original Rehab Budget</span>
                          <h3 className="text-xl font-extrabold text-zinc-150 mt-1">
                            ${(deal.underwriting.rehabCost || 0).toLocaleString()}
                          </h3>
                        </div>
                        <p className="text-[9px] text-zinc-500 mt-2">Funded 100% in construction escrow</p>
                      </div>

                      <div className="bg-zinc-900/60 border border-zinc-800/85 rounded-2xl p-4 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] uppercase font-extrabold tracking-wider text-amber-400">Approved Change Orders</span>
                          <h3 className="text-xl font-extrabold text-amber-400 mt-1">
                            +${totalApprovedCoCost.toLocaleString()}
                          </h3>
                        </div>
                        <p className="text-[9px] text-zinc-500 mt-2">Adjusted rehab pool: ${(totalEscrowPool).toLocaleString()}</p>
                      </div>

                      <div className="bg-zinc-900/60 border border-zinc-800/85 rounded-2xl p-4 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] uppercase font-extrabold tracking-wider text-emerald-400">Released to Date (Draws)</span>
                          <h3 className="text-xl font-extrabold text-emerald-400 mt-1">
                            -${totalReleasedDraws.toLocaleString()}
                          </h3>
                        </div>
                        <p className="text-[9px] text-zinc-500 mt-2">{completedDraws.length} milestones paid out securely</p>
                      </div>

                      <div className="bg-zinc-900/60 border border-zinc-800/85 rounded-2xl p-4 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] uppercase font-extrabold tracking-wider text-sky-400">Remaining Escrow Balance</span>
                          <h3 className="text-xl font-extrabold text-sky-300 mt-1">
                            ${escrowRemaining.toLocaleString()}
                          </h3>
                        </div>
                        <span className="text-[8px] font-bold bg-sky-500/15 text-sky-400 border border-sky-500/20 px-2 py-0.5 rounded uppercase tracking-wide w-max mt-2">
                          {escrowRemaining > 0 ? "SECURED IN ESCROW" : "FULLY RELEASED"}
                        </span>
                      </div>
                    </div>

                    {/* 2-Column Bento Layout */}
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                      {/* Left Column: Ledger & Milestone Release (Span 7) */}
                      <div className="lg:col-span-7 space-y-6">
                        
                        {/* Section 1: Milestone Draw Release Chamber */}
                        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5">
                          <div className="flex justify-between items-center mb-4">
                            <div>
                              <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">Milestone Draw Chamber</h4>
                              <p className="text-[10px] text-zinc-500 mt-0.5">Click any milestone to run AI GPS & Progress verification</p>
                            </div>
                          </div>

                          <div className="space-y-3">
                            {deal.milestones.map((mil) => {
                              const isCompleted = mil.status === "completed" || completedMilestoneIds.includes(mil.id);
                              const isVerifying = activeVerificationMilestoneId === mil.id;
                              
                              return (
                                <div 
                                  key={mil.id} 
                                  className={`p-4 rounded-xl border transition-all ${
                                    isCompleted 
                                      ? "bg-zinc-950/20 border-emerald-950/40 opacity-75"
                                      : isVerifying
                                      ? "bg-zinc-950/60 border-indigo-500/40 ring-1 ring-indigo-500/30"
                                      : "bg-zinc-950/40 border-zinc-850/80 hover:border-zinc-800"
                                  }`}
                                >
                                  <div className="flex justify-between items-start gap-4">
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center space-x-2">
                                        <h5 className="font-bold text-xs text-zinc-200 truncate">{mil.title}</h5>
                                        <span className={`text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded ${
                                          isCompleted 
                                            ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                            : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                        }`}>
                                          {isCompleted ? "Paid & Released" : "Pending Verification"}
                                        </span>
                                      </div>
                                      <div className="flex items-center space-x-3 text-[10px] text-zinc-500 mt-1">
                                        <span>Cost: <strong className="text-zinc-300">${mil.cost.toLocaleString()}</strong></span>
                                        <span>•</span>
                                        <span>Due: <strong className="text-zinc-400">{mil.dueDate}</strong></span>
                                      </div>
                                      <p className="text-[10px] text-zinc-400 mt-1.5 leading-relaxed">{mil.notes}</p>
                                    </div>
                                    
                                    {!isCompleted && !isVerifying && (
                                      <div className="flex items-center space-x-2">
                                        <button
                                          onClick={() => openDocModal("lien_waiver", mil)}
                                          className="flex-shrink-0 bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200 font-bold text-[9px] uppercase tracking-wider py-1.5 px-2.5 rounded-lg transition flex items-center space-x-1"
                                        >
                                          <FileText className="h-3 w-3 text-zinc-500" />
                                          <span>Lien Form</span>
                                        </button>
                                        <button
                                          onClick={() => {
                                            setActiveVerificationMilestoneId(mil.id);
                                            setGpsMode("onsite");
                                            handleVerifyMilestone(mil);
                                          }}
                                          className="flex-shrink-0 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[9px] uppercase tracking-wider py-1.5 px-3 rounded-lg transition"
                                        >
                                          Verify Work
                                        </button>
                                      </div>
                                    )}

                                    {isCompleted && (
                                      <button
                                        onClick={() => openDocModal("lien_waiver", mil)}
                                        className="flex-shrink-0 bg-zinc-950 hover:bg-zinc-900 border border-emerald-900/40 text-emerald-400 font-bold text-[9px] uppercase tracking-wider py-1.5 px-2.5 rounded-lg transition flex items-center space-x-1"
                                      >
                                        <ShieldCheck className="h-3 w-3 text-emerald-400" />
                                        <span>Signed Waiver</span>
                                      </button>
                                    )}
                                  </div>

                                  {/* Active Verification Chamber Panel */}
                                  {isVerifying && (
                                    <div className="mt-4 pt-4 border-t border-zinc-800/80 space-y-4">
                                      <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-800 space-y-3">
                                        <div className="flex justify-between items-center">
                                          <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-wider">AI Guardrails: Multi-Factor Audit</span>
                                          <div className="flex items-center space-x-1">
                                            <span className="text-[8px] text-zinc-500 uppercase font-extrabold">Simulated GPS Mode:</span>
                                            <select
                                              value={gpsMode}
                                              onChange={(e) => setGpsMode(e.target.value as any)}
                                              className="bg-zinc-950 border border-zinc-800 text-[9px] text-zinc-300 rounded px-1 py-0.5 focus:outline-none cursor-pointer"
                                            >
                                              <option value="onsite">On-Site (Match)</option>
                                              <option value="offsite">Off-Site (Flagged Discrepancy)</option>
                                            </select>
                                          </div>
                                        </div>

                                        {/* GPS Check Status */}
                                        <div className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-zinc-950/60 text-[10px]">
                                          <MapPin className={`h-4 w-4 mt-0.5 ${gpsMode === "onsite" ? "text-emerald-400" : "text-rose-400 animate-pulse"}`} />
                                          <div className="flex-1 min-w-0">
                                            <div className="flex justify-between font-bold">
                                              <span className={gpsMode === "onsite" ? "text-emerald-400" : "text-rose-400"}>
                                                {gpsMode === "onsite" ? "GPS Target Confirmed" : "⚠️ GPS Discrepancy Flagged"}
                                              </span>
                                              <span className="text-zinc-500">Distance: {gpsMode === "onsite" ? "12 meters" : "1.4 miles away"}</span>
                                            </div>
                                            <p className="text-zinc-400 mt-0.5 leading-normal">
                                              {gpsMode === "onsite" 
                                                ? `EXIF metadata of contractor photo matches Raleigh/Charlotte property coordinates (${deal.zip}).`
                                                : `Contractor photo was taken in Charlotte Plaza area, but the rehab job site is in Durham. Bypass attempt blocked.`
                                              }
                                            </p>
                                          </div>
                                        </div>

                                        {/* CV Analysis Progress Status */}
                                        <div className="flex items-start space-x-2.5 p-2.5 rounded-lg bg-zinc-950/60 text-[10px]">
                                          <CheckCircle className="h-4 w-4 mt-0.5 text-emerald-400" />
                                          <div className="flex-1 min-w-0">
                                            <div className="flex justify-between font-bold">
                                              <span className="text-emerald-400">Computer Vision Analysis (94% confidence)</span>
                                              <span className="text-zinc-500">Scan Complete</span>
                                            </div>
                                            <p className="text-zinc-400 mt-0.5 leading-normal">
                                              Photo pixels match construction materials density: <strong>Sill-plate framing replace verified. Grade-A pressure treated timbers identified.</strong> Meets 100% of scope specs.
                                            </p>
                                          </div>
                                        </div>

                                        {/* Control Buttons inside the Verifier */}
                                        <div className="flex justify-end space-x-2 pt-1.5">
                                          <button
                                            onClick={() => setActiveVerificationMilestoneId(null)}
                                            className="bg-zinc-900 border border-zinc-800 hover:bg-zinc-850 text-zinc-400 hover:text-zinc-350 font-bold text-[9px] uppercase tracking-wider py-1.5 px-3 rounded-lg transition"
                                          >
                                            Cancel
                                          </button>
                                          <button
                                            onClick={() => {
                                              if (gpsMode === "offsite") {
                                                alert("⚠️ Verification Blocked: You cannot release a draw with a flagged GPS discrepancy. Reset the simulated GPS mode to On-Site to simulate a matching photo.");
                                                return;
                                              }
                                              
                                              // Release draw!
                                              const updatedMilestones = deal.milestones.map(m => 
                                                m.id === mil.id ? { ...m, status: "completed" as const } : m
                                              );
                                              
                                              const newTransaction = {
                                                id: `t-draw-${Date.now()}`,
                                                type: "draw_release",
                                                description: `Draw release for milestone: ${mil.title}`,
                                                amount: mil.cost,
                                                timestamp: new Date().toISOString(),
                                                status: "completed"
                                              };

                                              const newLog = {
                                                id: `log-draw-${Date.now()}`,
                                                timestamp: new Date().toISOString(),
                                                agentName: "Project" as const,
                                                message: `AI Verified Milestone Draw Released: $${mil.cost.toLocaleString()} for '${mil.title}'. GPS checks passed successfully. Conditional progress lien waiver signed and locked.`,
                                                status: "success" as const
                                              };

                                              setTransactions([newTransaction, ...transactions]);
                                              onUpdateDeal({
                                                ...deal,
                                                milestones: updatedMilestones,
                                                logs: [...deal.logs, newLog]
                                              });
                                              setActiveVerificationMilestoneId(null);
                                            }}
                                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[9px] uppercase tracking-wider py-1.5 px-3 rounded-lg transition flex items-center space-x-1"
                                          >
                                            <span>Approve & Release Draw</span>
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* Section 2: Cash-Flow Transactions & Escrow Ledger */}
                        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5">
                          <div className="flex justify-between items-center mb-4">
                            <div>
                              <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">Construction Escrow Transaction Ledger</h4>
                              <p className="text-[10px] text-zinc-500 mt-0.5">Real-time paper trail of escrow deposits, escalations, and disbursements</p>
                            </div>
                            <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded uppercase">
                              Phase 1 Cash-Flow Active
                            </span>
                          </div>

                          <div className="overflow-x-auto">
                            <table className="min-w-full text-[10px] text-zinc-400 divide-y divide-zinc-800 font-medium">
                              <thead className="bg-zinc-950/40 text-[8px] font-bold text-zinc-500 uppercase tracking-wider text-left">
                                <tr>
                                  <th className="px-3 py-2">Transaction ID</th>
                                  <th className="px-3 py-2">Details</th>
                                  <th className="px-3 py-2">Type</th>
                                  <th className="px-3 py-2 text-right">Amount</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-800/60">
                                {transactions.map((t, idx) => (
                                  <tr key={t.id || idx} className="hover:bg-zinc-950/20">
                                    <td className="px-3 py-2.5 font-mono text-zinc-500 text-[9px]">{t.id.substring(0, 10)}...</td>
                                    <td className="px-3 py-2.5">
                                      <div className="text-zinc-200 font-bold">{t.description}</div>
                                      <div className="text-[8px] text-zinc-500 mt-0.5">{new Date(t.timestamp).toLocaleString()}</div>
                                    </td>
                                    <td className="px-3 py-2.5">
                                      <span className={`inline-block px-2 py-0.5 rounded text-[8px] font-extrabold uppercase ${
                                        t.type === "escrow_deposit"
                                          ? "bg-sky-500/10 text-sky-400 border border-sky-500/20"
                                          : t.type === "rehab_escalation"
                                          ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                          : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                      }`}>
                                        {t.type === "escrow_deposit" ? "Deposit" : t.type === "rehab_escalation" ? "Escalation" : "Disbursement"}
                                      </span>
                                    </td>
                                    <td className={`px-3 py-2.5 text-right font-extrabold ${
                                      t.type === "draw_release" ? "text-rose-400" : "text-emerald-400"
                                    }`}>
                                      {t.type === "draw_release" ? "-" : "+"}${t.amount.toLocaleString()}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>

                          <div className="flex justify-between items-center mt-4 pt-3.5 border-t border-zinc-800/60 text-[10px]">
                            <span className="text-zinc-500">NC Statutory Lien Waiver Suite automatically generated with statutory disclaimers.</span>
                            <button
                              onClick={() => openDocModal("lien_waiver")}
                              className="bg-zinc-950 border border-zinc-800 hover:bg-zinc-900 text-zinc-300 font-bold uppercase tracking-wider text-[9px] py-1.5 px-2.5 rounded-lg transition flex items-center space-x-1.5 cursor-pointer"
                            >
                              <FileText className="h-3 w-3 text-emerald-400" />
                              <span>View Statutory Lien Waiver</span>
                            </button>
                          </div>
                        </div>

                      </div>

                      {/* Right Column: Settings & Change Orders (Span 5) */}
                      <div className="lg:col-span-5 space-y-6">
                        
                        {/* Section 1: Deterministic Constants Settings */}
                        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-3.5">
                          <div className="flex items-center space-x-1.5">
                            <Sliders className="h-4 w-4 text-indigo-400" />
                            <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">Deterministic Cost Parameters</h4>
                          </div>
                          <p className="text-[10px] text-zinc-500 leading-normal">
                            Adjust holding parameters below to feed the change-order mathematical engine. Calculations are 100% formula-based.
                          </p>

                          <div className="space-y-3">
                            <div>
                              <div className="flex justify-between text-[10px] font-bold text-zinc-400 mb-1">
                                <span>Monthly Holding Costs (Utilities, Taxes, Ins.)</span>
                                <span className="text-zinc-250">${holdingCostMonthly.toLocaleString()}/mo</span>
                              </div>
                              <input
                                type="range"
                                min={500}
                                max={4000}
                                step={100}
                                value={holdingCostMonthly}
                                onChange={(e) => setHoldingCostMonthly(Number(e.target.value))}
                                className="w-full accent-indigo-500 bg-zinc-950 rounded-lg appearance-none h-1.5 cursor-pointer"
                              />
                            </div>

                            <div>
                              <div className="flex justify-between text-[10px] font-bold text-zinc-400 mb-1">
                                <span>Hard Money Interest Rate</span>
                                <span className="text-zinc-250">{loanRate}% APY</span>
                              </div>
                              <input
                                type="range"
                                min={6}
                                max={18}
                                step={0.5}
                                value={loanRate}
                                onChange={(e) => setLoanRate(Number(e.target.value))}
                                className="w-full accent-indigo-500 bg-zinc-950 rounded-lg appearance-none h-1.5 cursor-pointer"
                              />
                            </div>

                            <div>
                              <div className="flex justify-between text-[10px] font-bold text-zinc-400 mb-1">
                                <span>Hard Money Loan Balance</span>
                                <span className="text-zinc-250">${loanBalance.toLocaleString()}</span>
                              </div>
                              <input
                                type="range"
                                min={50000}
                                max={500000}
                                step={5000}
                                value={loanBalance}
                                onChange={(e) => setLoanBalance(Number(e.target.value))}
                                className="w-full accent-indigo-500 bg-zinc-950 rounded-lg appearance-none h-1.5 cursor-pointer"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Section 2: Change Order Bridge List */}
                        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-4">
                          <div className="flex justify-between items-center">
                            <div>
                              <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">Change Order Bridge</h4>
                              <p className="text-[10px] text-zinc-500 mt-0.5">Contractor-proposed amendments</p>
                            </div>
                            {!showAddCoForm && (
                              <button
                                onClick={() => {
                                  setShowAddCoForm(true);
                                  setActiveCoTitle("");
                                  setActiveCoDesc("");
                                  setActiveCoCost("");
                                  setActiveCoDays("");
                                  setActiveCoContractor("Bob's Construction");
                                }}
                                className="bg-zinc-950 border border-zinc-800 hover:bg-zinc-900 text-zinc-300 hover:text-white text-[9px] font-bold uppercase tracking-wider py-1.5 px-2.5 rounded-lg transition flex items-center space-x-1 cursor-pointer"
                              >
                                <Plus className="h-3 w-3" />
                                <span>Propose CO</span>
                              </button>
                            )}
                          </div>

                          {/* Contractor Quick-Preset Templates */}
                          {!showAddCoForm && (
                            <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-850 space-y-2.5">
                              <span className="text-[8px] font-bold text-indigo-400 uppercase tracking-wider block">Contractor Quick-Find Templates</span>
                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                <button
                                  onClick={() => {
                                    setShowAddCoForm(true);
                                    setActiveCoTitle("Rotted Wall Sill Plate");
                                    setActiveCoDesc("Opened kitchen drywall. Found active timber rot in sill plate and rim joist. Needs immediate structural wood replacement.");
                                    setActiveCoCost("2200");
                                    setActiveCoDays("4");
                                    setActiveCoContractor("Bob's Construction");
                                  }}
                                  className="text-left p-2 rounded bg-zinc-900 hover:bg-zinc-850 border border-zinc-800/80 transition text-[9px]"
                                >
                                  <span className="font-bold text-zinc-300 block">🪵 Wall Timber Rot</span>
                                  <span className="text-zinc-500 block mt-0.5">+$2,200 | +4 Days</span>
                                </button>
                                
                                <button
                                  onClick={() => {
                                    setShowAddCoForm(true);
                                    setActiveCoTitle("Outdated Galvanized Plumbing");
                                    setActiveCoDesc("Discovered outdated galvanized water lines behind bathroom plaster wall. Must replace with clean PEX lines.");
                                    setActiveCoCost("1500");
                                    setActiveCoDays("3");
                                    setActiveCoContractor("Plaza Midwood Construction");
                                  }}
                                  className="text-left p-2 rounded bg-zinc-900 hover:bg-zinc-850 border border-zinc-800/80 transition text-[9px]"
                                >
                                  <span className="font-bold text-zinc-300 block">🚰 Cast-Iron Plumbing</span>
                                  <span className="text-zinc-500 block mt-0.5">+$1,500 | +3 Days</span>
                                </button>

                                <button
                                  onClick={() => {
                                    setShowAddCoForm(true);
                                    setActiveCoTitle("Structural Termite Damage");
                                    setActiveCoDesc("Identified active structural wood damage along floor joists. Requires sistering with new framing joists.");
                                    setActiveCoCost("4500");
                                    setActiveCoDays("8");
                                    setActiveCoContractor("Bob's Construction");
                                  }}
                                  className="text-left p-2 rounded bg-zinc-900 hover:bg-zinc-850 border border-zinc-800/80 transition text-[9px]"
                                >
                                  <span className="font-bold text-zinc-300 block">🐛 Structural Termites</span>
                                  <span className="text-zinc-500 block mt-0.5">+$4,500 | +8 Days</span>
                                </button>
                              </div>
                            </div>
                          )}

                          {/* Propose CO Form */}
                          {showAddCoForm && (
                            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3.5">
                              <h5 className="text-[10px] font-bold text-indigo-400 uppercase tracking-wide">Propose New Change Order</h5>
                              <div className="space-y-2 text-[10px]">
                                <div>
                                  <label className="block text-zinc-400 font-medium mb-1">Issue/Title</label>
                                  <input
                                    type="text"
                                    placeholder="e.g. Mold in laundry room"
                                    value={activeCoTitle}
                                    onChange={(e) => setActiveCoTitle(e.target.value)}
                                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-zinc-205 focus:outline-none focus:border-indigo-500"
                                  />
                                </div>
                                <div>
                                  <label className="block text-zinc-400 font-medium mb-1">Description</label>
                                  <textarea
                                    placeholder="Provide exact field details of repair scope"
                                    value={activeCoDesc}
                                    onChange={(e) => setActiveCoDesc(e.target.value)}
                                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-zinc-205 h-16 focus:outline-none focus:border-indigo-500"
                                  />
                                </div>
                                <div className="grid grid-cols-2 gap-2">
                                  <div>
                                    <label className="block text-zinc-400 font-medium mb-1">Direct Cost ($)</label>
                                    <input
                                      type="number"
                                      placeholder="2500"
                                      value={activeCoCost}
                                      onChange={(e) => setActiveCoCost(e.target.value)}
                                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-zinc-205 focus:outline-none focus:border-indigo-500"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-zinc-400 font-medium mb-1">Days Added to Timeline</label>
                                    <input
                                      type="number"
                                      placeholder="5"
                                      value={activeCoDays}
                                      onChange={(e) => setActiveCoDays(e.target.value)}
                                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-zinc-205 focus:outline-none focus:border-indigo-500"
                                    />
                                  </div>
                                </div>
                                <div>
                                  <label className="block text-zinc-400 font-medium mb-1">Contractor Name</label>
                                  <input
                                    type="text"
                                    placeholder="Bob's Construction"
                                    value={activeCoContractor}
                                    onChange={(e) => setActiveCoContractor(e.target.value)}
                                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-zinc-205 focus:outline-none focus:border-indigo-500"
                                  />
                                </div>

                                {/* Instant Micro-Calculator Live Impact Widget */}
                                {(() => {
                                  const costVal = Number(activeCoCost) || 0;
                                  const daysVal = Number(activeCoDays) || 0;
                                  const holdingVal = Math.round(holdingCostMonthly * (daysVal / 30));
                                  const interestVal = Math.round(loanBalance * (loanRate / 100) * (daysVal / 365));
                                  const totalVal = costVal + holdingVal + interestVal;
                                  const originalProfit = deal.underwriting.projectedProfit || 0;
                                  const updatedProfit = originalProfit - totalVal;

                                  return (
                                    <div className="bg-indigo-950/20 border border-indigo-500/20 p-3 rounded-lg mt-3.5 space-y-2">
                                      <div className="flex items-center space-x-1">
                                        <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
                                        <span className="text-[9px] font-extrabold text-indigo-400 uppercase tracking-wide">
                                          Instant Micro-Calculator Live Impact
                                        </span>
                                      </div>
                                      
                                      <div className="grid grid-cols-2 gap-2 text-[9px] text-zinc-400">
                                        <div>
                                          <span className="block text-[7px] text-zinc-500 uppercase font-bold">Extra Holding Costs ({daysVal} days)</span>
                                          <span className="font-bold text-amber-500/95">+${holdingVal.toLocaleString()}</span>
                                        </div>
                                        <div>
                                          <span className="block text-[7px] text-zinc-500 uppercase font-bold">Extra Hard Money Interest</span>
                                          <span className="font-bold text-amber-500/95">+${interestVal.toLocaleString()}</span>
                                        </div>
                                        <div className="col-span-2 pt-1.5 border-t border-zinc-850 flex justify-between items-center text-[10px]">
                                          <span className="font-bold text-zinc-300">True Fully Loaded Cost:</span>
                                          <span className="font-extrabold text-rose-400">${totalVal.toLocaleString()}</span>
                                        </div>
                                        <div className="col-span-2 pt-1 border-t border-zinc-850 flex justify-between items-center text-[9px]">
                                          <span className="text-zinc-400">Profit Adjustment:</span>
                                          <span className="font-semibold text-zinc-350">
                                            ${originalProfit.toLocaleString()} → <strong className="text-rose-400">${updatedProfit.toLocaleString()}</strong>
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })()}
                              </div>

                              <div className="flex justify-end space-x-2 pt-1">
                                <button
                                  onClick={() => setShowAddCoForm(false)}
                                  className="bg-zinc-900 border border-zinc-800 hover:bg-zinc-850 text-zinc-400 font-bold text-[9px] uppercase tracking-wider py-1.5 px-2.5 rounded-lg transition cursor-pointer"
                                >
                                  Cancel
                                </button>
                                <button
                                  onClick={() => {
                                    if (!activeCoTitle || !activeCoCost || !activeCoDays) {
                                      alert("Please fill out the Title, Cost, and Days added fields.");
                                      return;
                                    }
                                    const costNum = Number(activeCoCost);
                                    const daysNum = Number(activeCoDays);
                                    
                                    const newCo = {
                                      id: `co-custom-${Date.now()}`,
                                      title: activeCoTitle,
                                      description: activeCoDesc,
                                      proposedCost: costNum,
                                      proposedDaysAdded: daysNum,
                                      status: "proposed",
                                      contractorName: activeCoContractor || "Unknown Contractor",
                                      photosCount: 1
                                    };

                                    setChangeOrders([...changeOrders, newCo]);
                                    setShowAddCoForm(false);
                                  }}
                                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[9px] uppercase tracking-wider py-1.5 px-3 rounded-lg transition cursor-pointer"
                                >
                                  Submit Proposed CO
                                </button>
                              </div>
                            </div>
                          )}

                          {/* Change Order Lists */}
                          <div className="space-y-3">
                            {changeOrders.map((co) => {
                              const { extraHolding, extraInterest, totalImpact, newProfit, newRoi } = getChangeOrderImpact(co.proposedCost, co.proposedDaysAdded);
                              const isProposed = co.status === "proposed";
                              const isApproved = co.status === "approved";
                              const isDenied = co.status === "denied";

                              return (
                                <div 
                                  key={co.id} 
                                  className={`p-4 rounded-xl border ${
                                    isApproved 
                                      ? "bg-emerald-500/5 border-emerald-500/20" 
                                      : isDenied 
                                      ? "bg-rose-500/5 border-rose-500/20 opacity-60" 
                                      : "bg-zinc-950/40 border-zinc-850"
                                  } space-y-3 text-[10px]`}
                                >
                                  <div className="flex justify-between items-start">
                                    <div className="min-w-0 flex-1">
                                      <h5 className="font-bold text-xs text-zinc-200 leading-snug">{co.title}</h5>
                                      <p className="text-[9px] text-indigo-400 mt-0.5">Proposed by: <strong>{co.contractorName}</strong></p>
                                    </div>
                                    <span className={`px-2 py-0.5 rounded text-[8px] font-extrabold uppercase ${
                                      isApproved
                                        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                        : isDenied
                                        ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                        : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                    }`}>
                                      {co.status}
                                    </span>
                                  </div>

                                  <p className="text-zinc-400 leading-normal">{co.description}</p>

                                  {/* Multi-factor holding + interest cost drag breakdown */}
                                  <div className="bg-zinc-950/60 p-2.5 rounded-lg border border-zinc-900 grid grid-cols-2 gap-2 text-zinc-400">
                                    <div>
                                      <span className="text-[7px] text-zinc-500 font-extrabold uppercase block">Direct Fix Cost</span>
                                      <span className="font-extrabold text-zinc-200">${co.proposedCost.toLocaleString()}</span>
                                    </div>
                                    <div>
                                      <span className="text-[7px] text-zinc-500 font-extrabold uppercase block">Timeline Delay</span>
                                      <span className="font-extrabold text-zinc-200">+{co.proposedDaysAdded} Days</span>
                                    </div>
                                    <div className="pt-1 border-t border-zinc-900/60">
                                      <span className="text-[7px] text-zinc-500 font-extrabold uppercase block">Holding Drag ({co.proposedDaysAdded} Days)</span>
                                      <span className="font-bold text-amber-500/80">+${extraHolding.toLocaleString()}</span>
                                    </div>
                                    <div className="pt-1 border-t border-zinc-900/60">
                                      <span className="text-[7px] text-zinc-500 font-extrabold uppercase block">Loan Interest Drag</span>
                                      <span className="font-bold text-amber-500/80">+${extraInterest.toLocaleString()}</span>
                                    </div>
                                    <div className="col-span-2 pt-1 border-t border-zinc-900/80 flex justify-between font-bold text-zinc-300">
                                      <span>Total True Impact:</span>
                                      <span className="text-rose-400">${totalImpact.toLocaleString()}</span>
                                    </div>
                                  </div>

                                  {/* Dynamic sensitivity shifts */}
                                  <div className="grid grid-cols-2 gap-3 text-zinc-400 bg-indigo-500/5 p-2 rounded-lg border border-indigo-500/10 text-[9px]">
                                    <div>
                                      <span className="text-[7px] text-zinc-500 font-bold uppercase block">Projected Profit Shift</span>
                                      <span className="font-bold text-zinc-300">
                                        ${deal.underwriting.projectedProfit.toLocaleString()} → <strong className="text-rose-400">${newProfit.toLocaleString()}</strong>
                                      </span>
                                    </div>
                                    <div>
                                      <span className="text-[7px] text-zinc-500 font-bold uppercase block">ROI Drift</span>
                                      <span className="font-bold text-zinc-300">
                                        {deal.underwriting.roi}% → <strong className="text-rose-400">{newRoi}%</strong>
                                      </span>
                                    </div>
                                  </div>

                                  {/* Action Buttons for proposed CO */}
                                  {isProposed && (
                                    <div className="flex justify-end space-x-2 pt-1">
                                      <button
                                        onClick={() => {
                                          const updatedCo = changeOrders.map(item => 
                                            item.id === co.id ? { ...item, status: "denied" } : item
                                          );
                                          setChangeOrders(updatedCo);
                                          
                                          const newLog = {
                                            id: `log-co-${Date.now()}`,
                                            timestamp: new Date().toISOString(),
                                            agentName: "Supervisor" as const,
                                            message: `Change order rejected: '${co.title}' ($${co.proposedCost.toLocaleString()}) proposed by ${co.contractorName}.`,
                                            status: "warning" as const
                                          };

                                          onUpdateDeal({
                                            ...deal,
                                            logs: [...deal.logs, newLog]
                                          });
                                        }}
                                        className="bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-rose-400 font-bold text-[9px] uppercase tracking-wider py-1.5 px-3 rounded-lg transition"
                                      >
                                        Reject
                                      </button>
                                      
                                      <button
                                        onClick={() => {
                                          const updatedCo = changeOrders.map(item => 
                                            item.id === co.id ? { ...item, status: "approved" } : item
                                          );
                                          setChangeOrders(updatedCo);

                                          // Append draw transaction
                                          const newTransaction = {
                                            id: `t-co-${Date.now()}`,
                                            type: "rehab_escalation",
                                            description: `Approved Change Order: ${co.title}`,
                                            amount: co.proposedCost,
                                            timestamp: new Date().toISOString(),
                                            status: "completed"
                                          };

                                          const newLog = {
                                            id: `log-co-${Date.now()}`,
                                            timestamp: new Date().toISOString(),
                                            agentName: "Supervisor" as const,
                                            message: `Change order approved: '${co.title}' ($${co.proposedCost.toLocaleString()}) proposed by ${co.contractorName}. True mathematical cost drag (holding + loan interest) computed at $${totalImpact.toLocaleString()}.`,
                                            status: "success" as const
                                          };

                                          setTransactions([newTransaction, ...transactions]);
                                          onUpdateDeal({
                                            ...deal,
                                            logs: [...deal.logs, newLog]
                                          });
                                        }}
                                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[9px] uppercase tracking-wider py-1.5 px-3 rounded-lg transition"
                                      >
                                        Approve & Escrow
                                      </button>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                );
              })()}
            </>
          )}
        </div>
      </div>

      {/* Real Interactive Legal Document Modal */}
      <LegalDocumentModal
        isOpen={isDocModalOpen}
        onClose={() => setIsDocModalOpen(false)}
        deal={deal}
        defaultDocType={modalDocType}
        contractorName={modalContractorName}
        drawAmount={modalDrawAmount}
        milestoneTitle={modalMilestoneTitle}
      />
    </div>
  );
}
