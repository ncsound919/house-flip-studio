/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  DollarSign, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  FileText, 
  Sliders, 
  Building, 
  Hammer, 
  Sparkles, 
  Layers, 
  Wrench,
  ChevronDown,
  ChevronUp,
  Download,
  ShieldCheck,
  Zap,
  Edit2
} from "lucide-react";
import { PropertyDeal, RehabLineItem, ChangeOrder } from "../types";

interface RehabBudgetManagerProps {
  deal: PropertyDeal;
  onUpdateDeal: (updated: PropertyDeal) => void;
  contractorNames?: string[];
}

export const NC_REGIONAL_BENCHMARKS = [
  { region: "Charlotte Metro", low: 42, avg: 50, high: 62, desc: "Mecklenburg, Union, Cabarrus" },
  { region: "Raleigh / Triangle", low: 45, avg: 54, high: 66, desc: "Wake, Durham, Orange" },
  { region: "Greensboro / Triad", low: 35, avg: 42, high: 52, desc: "Guilford, Forsyth" },
  { region: "Wilmington / Coast", low: 48, avg: 56, high: 68, desc: "New Hanover, Brunswick" },
  { region: "Asheville / Mountains", low: 50, avg: 60, high: 74, desc: "Buncombe, Henderson" }
];

export const TRADE_CATEGORIES = [
  "All Categories",
  "Demolition & Framing",
  "Roofing & Gutters",
  "Mechanical & HVAC",
  "Electrical & Service",
  "Plumbing & Fixtures",
  "Kitchen & Cabinetry",
  "Bathrooms & Tile",
  "Drywall & Paint",
  "Flooring (LVP & Hardwood)",
  "Exterior & Windows",
  "Permits & Architectural"
];

export const RehabBudgetManager: React.FC<RehabBudgetManagerProps> = ({
  deal,
  onUpdateDeal,
  contractorNames = []
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All Categories");
  const [selectedRegion, setSelectedRegion] = useState<string>(
    deal.city.toLowerCase().includes("raleigh") || deal.city.toLowerCase().includes("durham")
      ? "Raleigh / Triangle"
      : deal.city.toLowerCase().includes("greensboro") || deal.city.toLowerCase().includes("winston")
      ? "Greensboro / Triad"
      : deal.city.toLowerCase().includes("wilmington")
      ? "Wilmington / Coast"
      : deal.city.toLowerCase().includes("asheville")
      ? "Asheville / Mountains"
      : "Charlotte Metro"
  );

  // Modals & UI States
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState(false);
  const [isAddChangeOrderModalOpen, setIsAddChangeOrderModalOpen] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<"items" | "change_orders" | "benchmarks">("items");

  // Add line item form
  const [newItemForm, setNewItemForm] = useState<{
    category: string;
    name: string;
    materialCost: number;
    laborCost: number;
    notes: string;
    assignedContractor: string;
  }>({
    category: "Kitchen & Cabinetry",
    name: "",
    materialCost: 0,
    laborCost: 0,
    notes: "",
    assignedContractor: contractorNames[0] || "Queen City Premier Contracting LLC"
  });

  // Add change order form
  const [newChangeOrderForm, setNewChangeOrderForm] = useState<{
    description: string;
    contractorName: string;
    trade: string;
    costImpact: number;
    reason: string;
  }>({
    description: "",
    contractorName: contractorNames[0] || "Queen City Premier Contracting LLC",
    trade: "General Contracting",
    costImpact: 0,
    reason: "Discovered during wall tear-off (unforeseen framing defect)"
  });

  // Calculations
  const rehabItems = deal.rehabItems || [];
  const changeOrders = deal.changeOrders || [];

  const rawBaseRehab = rehabItems.reduce((acc, item) => acc + item.cost, 0);
  const materialTotal = rehabItems.reduce((acc, item) => acc + (item.materialCost || Math.round(item.cost * 0.52)), 0);
  const laborTotal = rehabItems.reduce((acc, item) => acc + (item.laborCost || Math.round(item.cost * 0.48)), 0);

  const contingencyRate = deal.underwriting?.contingencyRate || 15;
  const contingencyAmount = Math.round(rawBaseRehab * (contingencyRate / 100));

  const approvedChangeOrdersTotal = changeOrders
    .filter((co) => co.status === "approved")
    .reduce((acc, co) => acc + co.costImpact, 0);

  const pendingChangeOrdersTotal = changeOrders
    .filter((co) => co.status === "pending")
    .reduce((acc, co) => acc + co.costImpact, 0);

  const totalCalculatedRehab = rawBaseRehab + contingencyAmount + approvedChangeOrdersTotal;
  const costPerSqft = deal.sqft > 0 ? Math.round(totalCalculatedRehab / deal.sqft) : 0;

  // Selected region benchmark
  const activeBenchmark = NC_REGIONAL_BENCHMARKS.find((b) => b.region === selectedRegion) || NC_REGIONAL_BENCHMARKS[0];

  // Handlers
  const handleContingencyChange = (newRate: number) => {
    const newContingency = Math.round(rawBaseRehab * (newRate / 100));
    const newTotal = rawBaseRehab + newContingency + approvedChangeOrdersTotal;
    
    // Recalculate 70% rule MAO and profit
    const arv = deal.underwriting.arv;
    const maxOffer70Rule = Math.round(arv * 0.7 - newTotal);
    const purchasePrice = Math.min(deal.askingPrice, maxOffer70Rule);
    const totalCost = purchasePrice + newTotal + deal.underwriting.acquisitionCosts + deal.underwriting.holdingCosts + deal.underwriting.sellingCosts + deal.underwriting.financingCosts;
    const projectedProfit = arv - totalCost;
    const roi = Math.round((projectedProfit / (purchasePrice + newTotal)) * 10000) / 100;

    onUpdateDeal({
      ...deal,
      underwriting: {
        ...deal.underwriting,
        contingencyRate: newRate,
        contingencyAmount: newContingency,
        rehabCost: newTotal,
        baseRehabCost: rawBaseRehab,
        maxOffer70Rule,
        projectedProfit,
        roi
      }
    });
  };

  const handleAddItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemForm.name.trim()) return;

    const totalCost = Number(newItemForm.materialCost) + Number(newItemForm.laborCost);
    const newItem: RehabLineItem = {
      id: `rehab-item-${Date.now()}`,
      category: newItemForm.category,
      name: newItemForm.name,
      cost: totalCost,
      materialCost: Number(newItemForm.materialCost),
      laborCost: Number(newItemForm.laborCost),
      notes: newItemForm.notes || "Itemized trade estimate based on NC residential building standards.",
      assignedContractor: newItemForm.assignedContractor,
      status: "estimated"
    };

    const updatedItems = [...rehabItems, newItem];
    const newRawBase = updatedItems.reduce((acc, it) => acc + it.cost, 0);
    const newContingency = Math.round(newRawBase * (contingencyRate / 100));
    const newTotal = newRawBase + newContingency + approvedChangeOrdersTotal;

    const arv = deal.underwriting.arv;
    const maxOffer70Rule = Math.round(arv * 0.7 - newTotal);
    const purchasePrice = Math.min(deal.askingPrice, maxOffer70Rule);
    const totalCostProj = purchasePrice + newTotal + deal.underwriting.acquisitionCosts + deal.underwriting.holdingCosts + deal.underwriting.sellingCosts + deal.underwriting.financingCosts;
    const projectedProfit = arv - totalCostProj;
    const roi = Math.round((projectedProfit / (purchasePrice + newTotal)) * 10000) / 100;

    onUpdateDeal({
      ...deal,
      rehabItems: updatedItems,
      underwriting: {
        ...deal.underwriting,
        rehabCost: newTotal,
        baseRehabCost: newRawBase,
        contingencyAmount: newContingency,
        maxOffer70Rule,
        projectedProfit,
        roi
      }
    });

    setNewItemForm({
      category: "Kitchen & Cabinetry",
      name: "",
      materialCost: 0,
      laborCost: 0,
      notes: "",
      assignedContractor: contractorNames[0] || "Queen City Premier Contracting LLC"
    });
    setIsAddItemModalOpen(false);
  };

  const handleDeleteItem = (index: number) => {
    const updatedItems = rehabItems.filter((_, idx) => idx !== index);
    const newRawBase = updatedItems.reduce((acc, it) => acc + it.cost, 0);
    const newContingency = Math.round(newRawBase * (contingencyRate / 100));
    const newTotal = newRawBase + newContingency + approvedChangeOrdersTotal;

    const arv = deal.underwriting.arv;
    const maxOffer70Rule = Math.round(arv * 0.7 - newTotal);
    const purchasePrice = Math.min(deal.askingPrice, maxOffer70Rule);
    const totalCostProj = purchasePrice + newTotal + deal.underwriting.acquisitionCosts + deal.underwriting.holdingCosts + deal.underwriting.sellingCosts + deal.underwriting.financingCosts;
    const projectedProfit = arv - totalCostProj;
    const roi = Math.round((projectedProfit / (purchasePrice + newTotal)) * 10000) / 100;

    onUpdateDeal({
      ...deal,
      rehabItems: updatedItems,
      underwriting: {
        ...deal.underwriting,
        rehabCost: newTotal,
        baseRehabCost: newRawBase,
        contingencyAmount: newContingency,
        maxOffer70Rule,
        projectedProfit,
        roi
      }
    });
  };

  const handleToggleItemStatus = (index: number) => {
    const current = rehabItems[index].status || "estimated";
    const nextStatus: RehabLineItem["status"] =
      current === "estimated"
        ? "contracted"
        : current === "contracted"
        ? "in_progress"
        : current === "in_progress"
        ? "completed"
        : "estimated";

    const updatedItems = [...rehabItems];
    updatedItems[index] = { ...updatedItems[index], status: nextStatus };

    onUpdateDeal({
      ...deal,
      rehabItems: updatedItems
    });
  };

  const handleAddChangeOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChangeOrderForm.description.trim()) return;

    const newCO: ChangeOrder = {
      id: `co-${Date.now()}`,
      orderNumber: `CO-#00${changeOrders.length + 1}`,
      date: new Date().toISOString().split("T")[0],
      description: newChangeOrderForm.description,
      contractorName: newChangeOrderForm.contractorName,
      trade: newChangeOrderForm.trade,
      costImpact: Number(newChangeOrderForm.costImpact),
      status: "approved",
      reason: newChangeOrderForm.reason
    };

    const updatedCOs = [...changeOrders, newCO];
    const newApprovedCOTotal = updatedCOs
      .filter((c) => c.status === "approved")
      .reduce((acc, c) => acc + c.costImpact, 0);

    const newTotal = rawBaseRehab + contingencyAmount + newApprovedCOTotal;
    const arv = deal.underwriting.arv;
    const maxOffer70Rule = Math.round(arv * 0.7 - newTotal);
    const purchasePrice = Math.min(deal.askingPrice, maxOffer70Rule);
    const totalCostProj = purchasePrice + newTotal + deal.underwriting.acquisitionCosts + deal.underwriting.holdingCosts + deal.underwriting.sellingCosts + deal.underwriting.financingCosts;
    const projectedProfit = arv - totalCostProj;
    const roi = Math.round((projectedProfit / (purchasePrice + newTotal)) * 10000) / 100;

    onUpdateDeal({
      ...deal,
      changeOrders: updatedCOs,
      underwriting: {
        ...deal.underwriting,
        rehabCost: newTotal,
        changeOrdersTotal: newApprovedCOTotal,
        maxOffer70Rule,
        projectedProfit,
        roi
      }
    });

    setNewChangeOrderForm({
      description: "",
      contractorName: contractorNames[0] || "Queen City Premier Contracting LLC",
      trade: "General Contracting",
      costImpact: 0,
      reason: "Discovered during structural inspection"
    });
    setIsAddChangeOrderModalOpen(false);
  };

  const handleToggleChangeOrderStatus = (coId: string) => {
    const updatedCOs = changeOrders.map((co) => {
      if (co.id === coId) {
        const nextStatus: ChangeOrder["status"] =
          co.status === "approved" ? "rejected" : co.status === "rejected" ? "pending" : "approved";
        return { ...co, status: nextStatus };
      }
      return co;
    });

    const newApprovedCOTotal = updatedCOs
      .filter((c) => c.status === "approved")
      .reduce((acc, c) => acc + c.costImpact, 0);

    const newTotal = rawBaseRehab + contingencyAmount + newApprovedCOTotal;
    const arv = deal.underwriting.arv;
    const maxOffer70Rule = Math.round(arv * 0.7 - newTotal);
    const purchasePrice = Math.min(deal.askingPrice, maxOffer70Rule);
    const totalCostProj = purchasePrice + newTotal + deal.underwriting.acquisitionCosts + deal.underwriting.holdingCosts + deal.underwriting.sellingCosts + deal.underwriting.financingCosts;
    const projectedProfit = arv - totalCostProj;
    const roi = Math.round((projectedProfit / (purchasePrice + newTotal)) * 10000) / 100;

    onUpdateDeal({
      ...deal,
      changeOrders: updatedCOs,
      underwriting: {
        ...deal.underwriting,
        rehabCost: newTotal,
        changeOrdersTotal: newApprovedCOTotal,
        maxOffer70Rule,
        projectedProfit,
        roi
      }
    });
  };

  const filteredItems = rehabItems.filter((item) => {
    if (selectedCategory === "All Categories") return true;
    return item.category.toLowerCase().includes(selectedCategory.toLowerCase()) ||
      selectedCategory.toLowerCase().includes(item.category.toLowerCase());
  });

  return (
    <div className="space-y-6">
      {/* 1. Deep Construction Budget Summary Ribbon */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-zinc-900/70 border border-zinc-800 p-4 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-zinc-400">Base Trade Repairs</span>
            <Hammer className="h-3.5 w-3.5 text-zinc-500" />
          </div>
          <p className="text-xl font-extrabold text-zinc-100 mt-1">${rawBaseRehab.toLocaleString()}</p>
          <div className="flex items-center space-x-2 text-[9px] text-zinc-400 mt-1">
            <span>Mat: ${(materialTotal).toLocaleString()}</span>
            <span>•</span>
            <span>Lab: ${(laborTotal).toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 p-4 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-zinc-400">Contingency Reserve</span>
            <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
              {contingencyRate}%
            </span>
          </div>
          <p className="text-xl font-extrabold text-amber-400 mt-1">${contingencyAmount.toLocaleString()}</p>
          <p className="text-[9px] text-zinc-500 mt-1">Unforeseen structural buffer</p>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 p-4 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-zinc-400">Approved Change Orders</span>
            <FileText className="h-3.5 w-3.5 text-zinc-500" />
          </div>
          <p className="text-xl font-extrabold text-indigo-400 mt-1">
            +${approvedChangeOrdersTotal.toLocaleString()}
          </p>
          <p className="text-[9px] text-zinc-500 mt-1">{changeOrders.length} logged change orders</p>
        </div>

        <div className="bg-zinc-900/70 border border-emerald-500/30 p-4 rounded-2xl relative overflow-hidden bg-gradient-to-br from-zinc-900/90 to-emerald-950/20">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-emerald-400">Total Rehab Budget</span>
            <DollarSign className="h-3.5 w-3.5 text-emerald-400" />
          </div>
          <p className="text-2xl font-extrabold text-emerald-300 mt-1">${totalCalculatedRehab.toLocaleString()}</p>
          <p className="text-[9px] text-emerald-400/80 font-bold mt-1">${costPerSqft}/sqft total cost</p>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 p-4 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-zinc-400">NC Market Benchmark</span>
            <span className="text-[9px] font-bold text-zinc-300">{selectedRegion.split(" ")[0]}</span>
          </div>
          <div className="mt-1">
            <div className="flex justify-between items-baseline">
              <span className="text-sm font-extrabold text-zinc-200">${costPerSqft}/sqft</span>
              <span className="text-[10px] text-zinc-400">Target: ${activeBenchmark.avg}/sqft</span>
            </div>
            <div className="w-full bg-zinc-950 h-1.5 rounded-full overflow-hidden mt-1.5">
              <div 
                className={`h-full ${costPerSqft <= activeBenchmark.avg ? 'bg-emerald-500' : costPerSqft <= activeBenchmark.high ? 'bg-amber-500' : 'bg-rose-500'}`}
                style={{ width: `${Math.min(100, Math.max(15, (costPerSqft / activeBenchmark.high) * 100))}%` }}
              />
            </div>
          </div>
          <span className={`text-[9px] font-bold mt-1 ${costPerSqft <= activeBenchmark.avg ? 'text-emerald-400' : 'text-amber-400'}`}>
            {costPerSqft <= activeBenchmark.low ? "Lean / Cosmetic Scope" : costPerSqft <= activeBenchmark.high ? "Standard Value-Add" : "Heavy Gut Renovation"}
          </span>
        </div>
      </div>

      {/* 2. Sub-Tab Navigation Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-zinc-950/80 p-2 rounded-2xl border border-zinc-850">
        <div className="flex space-x-1.5">
          <button
            type="button"
            onClick={() => setActiveSubTab("items")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition uppercase tracking-wider cursor-pointer ${
              activeSubTab === "items"
                ? "bg-emerald-600 text-white shadow-xs"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Itemized Scope ({rehabItems.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab("change_orders")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition uppercase tracking-wider cursor-pointer ${
              activeSubTab === "change_orders"
                ? "bg-emerald-600 text-white shadow-xs"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Change Orders ({changeOrders.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab("benchmarks")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition uppercase tracking-wider cursor-pointer ${
              activeSubTab === "benchmarks"
                ? "bg-emerald-600 text-white shadow-xs"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            NC Regional Cost Matrix
          </button>
        </div>

        <div className="flex items-center space-x-2">
          {/* Contingency slider inline */}
          <div className="flex items-center space-x-2 bg-zinc-900 px-3 py-1.5 rounded-xl border border-zinc-800 text-xs">
            <span className="text-[10px] text-zinc-400 font-bold uppercase">Contingency:</span>
            {[10, 15, 20, 25].map((rate) => (
              <button
                key={rate}
                onClick={() => handleContingencyChange(rate)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition ${
                  contingencyRate === rate
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                    : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                {rate}%
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setShowExportModal(true)}
            className="flex items-center space-x-1 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-850 text-zinc-300 border border-zinc-800 rounded-xl text-xs font-bold transition cursor-pointer"
            title="Export / Print Scope of Work"
          >
            <Download className="h-3 w-3" />
            <span className="hidden sm:inline">Export SOW</span>
          </button>

          <button
            type="button"
            onClick={() => setIsAddItemModalOpen(true)}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-sm"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Add Item</span>
          </button>
        </div>
      </div>

      {/* 3. Sub-Tab 1: Itemized Trade Line Items */}
      {activeSubTab === "items" && (
        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-sm">
          {/* Category Filter Pills */}
          <div className="p-3 bg-zinc-950/50 border-b border-zinc-800/80 flex items-center space-x-2 overflow-x-auto">
            {TRADE_CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-bold whitespace-nowrap transition cursor-pointer ${
                  selectedCategory === cat
                    ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-extrabold"
                    : "text-zinc-400 hover:text-zinc-200 border border-transparent"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-zinc-800 text-xs text-zinc-300">
              <thead className="bg-zinc-950/60 text-[10px] font-bold text-zinc-500 uppercase tracking-wider text-left">
                <tr>
                  <th className="px-4 py-3">Trade Category</th>
                  <th className="px-4 py-3">Scope Description & Code Specs</th>
                  <th className="px-4 py-3">Material Cost</th>
                  <th className="px-4 py-3">Labor Cost</th>
                  <th className="px-4 py-3 text-right">Total Cost</th>
                  <th className="px-4 py-3">Assigned Crew</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-3 py-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50 font-medium">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-12 text-center text-zinc-500">
                      No repair items in this category. Click <strong>+ Add Item</strong> to create an itemized scope entry.
                    </td>
                  </tr>
                ) : (
                  filteredItems.map((item, idx) => {
                    const realIndex = rehabItems.indexOf(item);
                    const matCost = item.materialCost || Math.round(item.cost * 0.52);
                    const labCost = item.laborCost || Math.round(item.cost * 0.48);
                    const status = item.status || "estimated";

                    return (
                      <tr key={item.id || idx} className="hover:bg-zinc-950/40 transition-colors">
                        <td className="px-4 py-3.5">
                          <span className="inline-block px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold bg-zinc-950 border border-zinc-800 text-zinc-300">
                            {item.category}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 max-w-xs">
                          <p className="font-bold text-zinc-100">{item.name}</p>
                          <p className="text-[10px] text-zinc-400 mt-0.5 leading-relaxed">{item.notes}</p>
                        </td>
                        <td className="px-4 py-3.5 text-zinc-300 font-semibold">${matCost.toLocaleString()}</td>
                        <td className="px-4 py-3.5 text-zinc-300 font-semibold">${labCost.toLocaleString()}</td>
                        <td className="px-4 py-3.5 text-right font-extrabold text-emerald-400">
                          ${item.cost.toLocaleString()}
                        </td>
                        <td className="px-4 py-3.5 text-zinc-300 text-[11px]">
                          {item.assignedContractor || "Unassigned"}
                        </td>
                        <td className="px-4 py-3.5">
                          <button
                            type="button"
                            onClick={() => handleToggleItemStatus(realIndex)}
                            className={`px-2 py-0.5 rounded-md text-[9px] font-extrabold uppercase tracking-wider border cursor-pointer transition ${
                              status === "completed"
                                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                                : status === "in_progress"
                                ? "bg-sky-500/10 text-sky-400 border-sky-500/30"
                                : status === "contracted"
                                ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/30"
                                : "bg-zinc-950 text-zinc-400 border-zinc-800"
                            }`}
                            title="Click to cycle status"
                          >
                            {status === "completed"
                              ? "✓ Passed"
                              : status === "in_progress"
                              ? "In Progress"
                              : status === "contracted"
                              ? "Contracted"
                              : "Estimated"}
                          </button>
                        </td>
                        <td className="px-3 py-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem(realIndex)}
                            className="p-1 text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 rounded transition cursor-pointer"
                            title="Delete Line Item"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Sub-Tab 2: Change Orders Management */}
      {activeSubTab === "change_orders" && (
        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800">
            <div>
              <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                Unforeseen Site Defect & Change Order Ledger
              </h4>
              <p className="text-[10px] text-zinc-400 mt-0.5">
                Log contractor change requests, track cost impacts, and approve variations before invoice disbursement.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsAddChangeOrderModalOpen(true)}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-sm"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Log Change Order</span>
            </button>
          </div>

          {changeOrders.length === 0 ? (
            <div className="py-10 text-center flex flex-col items-center justify-center border border-dashed border-zinc-800 rounded-xl">
              <FileText className="h-8 w-8 text-zinc-600 mb-2" />
              <p className="text-xs font-bold text-zinc-300">No Change Orders Logged</p>
              <p className="text-[10px] text-zinc-500 mt-1 max-w-sm">
                If structural or electrical surprises arise during construction, click "Log Change Order" to update your financial budget and MAO model.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-zinc-800 text-xs text-zinc-300">
                <thead className="bg-zinc-950/60 text-[10px] font-bold text-zinc-500 uppercase tracking-wider text-left">
                  <tr>
                    <th className="px-4 py-3">Order #</th>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Description & Discovery</th>
                    <th className="px-4 py-3">Contractor / Trade</th>
                    <th className="px-4 py-3 text-right">Cost Impact</th>
                    <th className="px-4 py-3">Approval Status</th>
                    <th className="px-3 py-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {changeOrders.map((co) => (
                    <tr key={co.id} className="hover:bg-zinc-950/40">
                      <td className="px-4 py-3.5 font-bold text-zinc-200">{co.orderNumber}</td>
                      <td className="px-4 py-3.5 text-zinc-400">{co.date}</td>
                      <td className="px-4 py-3.5 max-w-xs">
                        <p className="font-bold text-zinc-100">{co.description}</p>
                        <p className="text-[10px] text-zinc-400 mt-0.5">{co.reason}</p>
                      </td>
                      <td className="px-4 py-3.5 text-zinc-300">
                        <p className="font-medium">{co.contractorName}</p>
                        <span className="text-[9px] text-zinc-500">{co.trade}</span>
                      </td>
                      <td className="px-4 py-3.5 text-right font-extrabold text-amber-400">
                        +${co.costImpact.toLocaleString()}
                      </td>
                      <td className="px-4 py-3.5">
                        <button
                          type="button"
                          onClick={() => handleToggleChangeOrderStatus(co.id)}
                          className={`px-2.5 py-1 rounded-lg text-[9px] font-extrabold uppercase tracking-wider border cursor-pointer transition ${
                            co.status === "approved"
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                              : co.status === "pending"
                              ? "bg-amber-500/10 text-amber-400 border-amber-500/30"
                              : "bg-rose-500/10 text-rose-400 border-rose-500/30"
                          }`}
                        >
                          {co.status === "approved"
                            ? "✓ Approved"
                            : co.status === "pending"
                            ? "⏳ Pending Approval"
                            : "✗ Rejected"}
                        </button>
                      </td>
                      <td className="px-3 py-3.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleChangeOrderStatus(co.id)}
                          className="text-[10px] text-indigo-400 hover:text-indigo-300 font-bold underline cursor-pointer"
                        >
                          Toggle
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* 5. Sub-Tab 3: NC Regional Benchmarks Matrix */}
      {activeSubTab === "benchmarks" && (
        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800">
            <div>
              <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                North Carolina Construction Cost Benchmarks Matrix ($/SqFt)
              </h4>
              <p className="text-[10px] text-zinc-400 mt-0.5">
                Calibrated against active 2026 North Carolina residential permit costs and contractor labor indexes.
              </p>
            </div>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs font-bold text-zinc-200"
            >
              {NC_REGIONAL_BENCHMARKS.map((b) => (
                <option key={b.region} value={b.region}>
                  {b.region}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {NC_REGIONAL_BENCHMARKS.map((benchmark) => {
              const isCurrent = benchmark.region === selectedRegion;
              return (
                <div
                  key={benchmark.region}
                  onClick={() => setSelectedRegion(benchmark.region)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isCurrent
                      ? "bg-zinc-950 border-emerald-500/50 shadow-md ring-1 ring-emerald-500/20"
                      : "bg-zinc-950/40 border-zinc-850 hover:border-zinc-700"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <h5 className="font-extrabold text-xs text-zinc-100">{benchmark.region}</h5>
                    {isCurrent && (
                      <span className="px-1.5 py-0.5 rounded text-[8px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase">
                        Selected
                      </span>
                    )}
                  </div>
                  <p className="text-[9px] text-zinc-500 mt-0.5">{benchmark.desc}</p>
                  
                  <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-zinc-900 text-center">
                    <div>
                      <span className="text-[8px] text-zinc-500 uppercase font-bold block">Cosmetic</span>
                      <span className="text-xs font-bold text-zinc-300">${benchmark.low}/sqft</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-emerald-400 uppercase font-bold block">Average</span>
                      <span className="text-xs font-extrabold text-emerald-400">${benchmark.avg}/sqft</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-zinc-500 uppercase font-bold block">Full Gut</span>
                      <span className="text-xs font-bold text-zinc-300">${benchmark.high}/sqft</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Modal: Add Line Item */}
      {isAddItemModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-zinc-800">
              <h3 className="font-extrabold text-sm text-zinc-100 uppercase tracking-wide">
                Add Construction Line Item
              </h3>
              <button
                type="button"
                onClick={() => setIsAddItemModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300 text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddItemSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                  Trade Category
                </label>
                <select
                  value={newItemForm.category}
                  onChange={(e) => setNewItemForm({ ...newItemForm, category: e.target.value })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200 font-bold"
                >
                  {TRADE_CATEGORIES.filter((c) => c !== "All Categories").map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                  Scope Item Name / Specification
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Master Bath Walk-In Shower Tiling & Schluter Kerdi Pan"
                  value={newItemForm.name}
                  onChange={(e) => setNewItemForm({ ...newItemForm, name: e.target.value })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    Material Cost ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={newItemForm.materialCost}
                    onChange={(e) => setNewItemForm({ ...newItemForm, materialCost: Number(e.target.value) })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    Labor Cost ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={newItemForm.laborCost}
                    onChange={(e) => setNewItemForm({ ...newItemForm, laborCost: Number(e.target.value) })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                  Assigned Subcontractor
                </label>
                <input
                  type="text"
                  placeholder="e.g. Queen City Premier Contracting LLC"
                  value={newItemForm.assignedContractor}
                  onChange={(e) => setNewItemForm({ ...newItemForm, assignedContractor: e.target.value })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                  Notes & Code Compliance Constraints
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Requires NC Residential Code Chapter 7 waterproofing inspection sign-off."
                  value={newItemForm.notes}
                  onChange={(e) => setNewItemForm({ ...newItemForm, notes: e.target.value })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAddItemModalOpen(false)}
                  className="px-4 py-2 bg-zinc-800 hover:bg-zinc-750 text-zinc-300 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold cursor-pointer"
                >
                  Save Line Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Change Order */}
      {isAddChangeOrderModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-zinc-800">
              <h3 className="font-extrabold text-sm text-zinc-100 uppercase tracking-wide">
                Log Construction Change Order
              </h3>
              <button
                type="button"
                onClick={() => setIsAddChangeOrderModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300 text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddChangeOrderSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                  Change Description
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Subfloor Rot Replacement in Kitchen / Laundry Area"
                  value={newChangeOrderForm.description}
                  onChange={(e) => setNewChangeOrderForm({ ...newChangeOrderForm, description: e.target.value })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    Contractor Name
                  </label>
                  <input
                    type="text"
                    required
                    value={newChangeOrderForm.contractorName}
                    onChange={(e) => setNewChangeOrderForm({ ...newChangeOrderForm, contractorName: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    Trade
                  </label>
                  <input
                    type="text"
                    required
                    value={newChangeOrderForm.trade}
                    onChange={(e) => setNewChangeOrderForm({ ...newChangeOrderForm, trade: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                  Additional Cost Impact ($)
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={newChangeOrderForm.costImpact}
                  onChange={(e) => setNewChangeOrderForm({ ...newChangeOrderForm, costImpact: Number(e.target.value) })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200 font-bold"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                  Reason for Variance
                </label>
                <textarea
                  rows={2}
                  value={newChangeOrderForm.reason}
                  onChange={(e) => setNewChangeOrderForm({ ...newChangeOrderForm, reason: e.target.value })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAddChangeOrderModalOpen(false)}
                  className="px-4 py-2 bg-zinc-800 hover:bg-zinc-750 text-zinc-300 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold cursor-pointer"
                >
                  Save & Approve Change Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Export Scope of Work (Print / Copy) */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-zinc-800">
              <h3 className="font-extrabold text-sm text-zinc-100 uppercase tracking-wide">
                Construction Scope of Work & Budget Export
              </h3>
              <button
                type="button"
                onClick={() => setShowExportModal(false)}
                className="text-zinc-500 hover:text-zinc-300 text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl font-mono text-[11px] text-zinc-300 max-h-80 overflow-y-auto whitespace-pre-wrap leading-relaxed">
{`================================================================================
NORTH CAROLINA RESIDENTIAL CONSTRUCTION SCOPE OF WORK & BUDGET
Property: ${deal.address}, ${deal.city}, NC ${deal.zip}
Total Sqft: ${deal.sqft.toLocaleString()} sqft | Year Built: ${deal.yearBuilt}
Estimated Total Construction Budget: $${totalCalculatedRehab.toLocaleString()} ($${costPerSqft}/sqft)
================================================================================

1. ITEMIZED TRADE BREAKDOWN:
${rehabItems.map((item, idx) => `[#${idx + 1}] ${item.category.toUpperCase()} - ${item.name}
    Cost: $${item.cost.toLocaleString()} (Mat: $${(item.materialCost || Math.round(item.cost * 0.52)).toLocaleString()} | Lab: $${(item.laborCost || Math.round(item.cost * 0.48)).toLocaleString()})
    Contractor: ${item.assignedContractor || "Open Trade"}
    Status: ${(item.status || "estimated").toUpperCase()}
    Specs/Notes: ${item.notes}
`).join("\n")}

2. BUDGET CONTINGENCY & CHANGE ORDERS:
- Base Construction: $${rawBaseRehab.toLocaleString()}
- Contingency Reserve (${contingencyRate}%): $${contingencyAmount.toLocaleString()}
- Approved Change Orders (${changeOrders.length}): $${approvedChangeOrdersTotal.toLocaleString()}
--------------------------------------------------------------------------------
TOTAL PROJECTED REHABILITATION: $${totalCalculatedRehab.toLocaleString()}
================================================================================`}
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(
                    `SCOPE OF WORK: ${deal.address}, ${deal.city}, NC\nTotal Budget: $${totalCalculatedRehab.toLocaleString()}\n` +
                    rehabItems.map((it) => `- ${it.category}: ${it.name} ($${it.cost.toLocaleString()})`).join("\n")
                  );
                  alert("✓ Copied Scope of Work to clipboard!");
                  setShowExportModal(false);
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs cursor-pointer"
              >
                Copy to Clipboard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
