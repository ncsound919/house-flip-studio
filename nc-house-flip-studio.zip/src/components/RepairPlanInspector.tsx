/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PropertyDeal, RepairPlan, NCContractorDirectoryItem } from '../types';
import { NC_CONTRACTOR_DIRECTORY } from '../lib/contractorCatalog';
import { ContractorRFPModal } from './ContractorRFPModal';
import { 
  CheckCircle2, 
  Circle, 
  ShieldAlert, 
  Wrench, 
  Package, 
  FileText, 
  Users, 
  AlertTriangle, 
  Sparkles, 
  Clock, 
  DollarSign, 
  HardHat, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  Send, 
  Phone, 
  Mail, 
  Star, 
  ShieldCheck, 
  Plus, 
  Trash2,
  Download,
  Flame,
  Zap,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface RepairPlanInspectorProps {
  plan: RepairPlan;
  deal: PropertyDeal;
  onUpdatePlan: (updated: RepairPlan) => void;
  onDeletePlan: (planId: string) => void;
  onApplyToRehab: (plan: RepairPlan, contractorId?: string) => Promise<void>;
  onClose?: () => void;
}

export const RepairPlanInspector: React.FC<RepairPlanInspectorProps> = ({
  plan,
  deal,
  onUpdatePlan,
  onDeletePlan,
  onApplyToRehab,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'steps' | 'materials' | 'contractors' | 'safety'>('steps');
  const [selectedContractorForRFP, setSelectedContractorForRFP] = useState<NCContractorDirectoryItem | null>(null);
  const [isApplying, setIsApplying] = useState(false);
  const [applySuccessMessage, setApplySuccessMessage] = useState<string | null>(null);

  // Toggle step completion in execution phases
  const handleToggleStep = (phaseNumber: number, stepNumber: number) => {
    const updatedPhases = plan.executionPhases.map(phase => {
      if (phase.phaseNumber !== phaseNumber) return phase;
      return {
        ...phase,
        steps: phase.steps.map(step => {
          if (step.stepNumber !== stepNumber) return step;
          return { ...step, completed: !step.completed };
        })
      };
    });

    const totalSteps = updatedPhases.flatMap(p => p.steps).length;
    const completedSteps = updatedPhases.flatMap(p => p.steps).filter(s => s.completed).length;

    let newStatus = plan.status;
    if (completedSteps === totalSteps && totalSteps > 0) {
      newStatus = 'completed';
    } else if (completedSteps > 0) {
      newStatus = 'in_progress';
    }

    onUpdatePlan({
      ...plan,
      executionPhases: updatedPhases,
      status: newStatus
    });
  };

  // Assign contractor directly
  const handleAssignContractor = (contractor: NCContractorDirectoryItem) => {
    const updated: RepairPlan = {
      ...plan,
      assignedContractorId: contractor.id,
      assignedContractorName: contractor.name,
      assignedContractorPhone: contractor.phone,
      assignedContractorRate: `$${contractor.hourlyRate}/hr`,
      status: 'contracted'
    };
    onUpdatePlan(updated);
  };

  // Convert to deal rehab line item & milestone
  const handleApplyToDealRehab = async () => {
    setIsApplying(true);
    try {
      await onApplyToRehab(plan, plan.assignedContractorId);
      setApplySuccessMessage(`Successfully converted to Deal Rehab Budget with ${plan.assignedContractorName || 'assigned contractor'}!`);
      setTimeout(() => setApplySuccessMessage(null), 4000);
    } catch (err) {
      console.error('Failed to apply to rehab:', err);
    } finally {
      setIsApplying(false);
    }
  };

  // Find matched contractor objects
  const matchedContractors = (plan.matchedContractorIds || [])
    .map(id => NC_CONTRACTOR_DIRECTORY.find(c => c.id === id))
    .filter(Boolean) as NCContractorDirectoryItem[];

  // Total steps & progress
  const allSteps = plan.executionPhases.flatMap(p => p.steps);
  const completedCount = allSteps.filter(s => s.completed).length;
  const progressPercent = allSteps.length > 0 ? Math.round((completedCount / allSteps.length) * 100) : 0;

  return (
    <div className="bg-zinc-950/90 border border-zinc-800 rounded-3xl p-6 backdrop-blur-md shadow-2xl space-y-6 flex flex-col h-full overflow-hidden">
      {/* Header & Status Ribbon */}
      <div className="space-y-3 pb-4 border-b border-zinc-850">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                plan.severity === 'critical'
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  : plan.severity === 'high'
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {plan.severity} Severity
              </span>

              <span className="text-[10px] font-extrabold bg-zinc-900 text-zinc-300 px-2.5 py-0.5 rounded-full border border-zinc-800">
                {plan.trade}
              </span>

              <span className="text-[10px] font-extrabold bg-sky-500/20 text-sky-400 px-2.5 py-0.5 rounded-full border border-sky-500/30">
                {plan.roomZone}
              </span>

              <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${
                plan.diyFeasibility === 'Licensed Trade Required' || plan.diyFeasibility === 'NC GC Required'
                  ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                  : 'bg-teal-500/20 text-teal-400 border-teal-500/30'
              }`}>
                {plan.diyFeasibility}
              </span>
            </div>

            <h2 className="text-base font-extrabold text-zinc-100 mt-2">
              {plan.title}
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Target Property: <strong>{deal.address}, {deal.city} NC</strong> (Year Built {deal.yearBuilt || 1970})
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onDeletePlan(plan.id)}
              className="p-2 text-zinc-500 hover:text-rose-400 rounded-xl hover:bg-rose-500/10 transition cursor-pointer"
              title="Delete Repair Plan"
            >
              <Trash2 className="h-4 w-4" />
            </button>
            {onClose && (
              <button
                onClick={onClose}
                className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Close
              </button>
            )}
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
          <div className="bg-zinc-900/70 p-3 rounded-2xl border border-zinc-800">
            <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider flex items-center space-x-1">
              <DollarSign className="h-3 w-3 text-emerald-400" />
              <span>Total Est. Cost</span>
            </span>
            <p className="text-base font-black text-emerald-400 mt-0.5">
              ${plan.totalEstimatedCost.toLocaleString()}
            </p>
            <span className="text-[9px] text-zinc-500">
              Mat: ${plan.estimatedMaterialCost} • Lab: ${plan.estimatedLaborCost}
            </span>
          </div>

          <div className="bg-zinc-900/70 p-3 rounded-2xl border border-zinc-800">
            <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider flex items-center space-x-1">
              <Clock className="h-3 w-3 text-sky-400" />
              <span>Labor Hours</span>
            </span>
            <p className="text-base font-black text-zinc-100 mt-0.5">
              {plan.estimatedLaborHours} Hrs
            </p>
            <span className="text-[9px] text-zinc-500">
              ~{Math.ceil(plan.estimatedLaborHours / 8)} Work Days
            </span>
          </div>

          <div className="bg-zinc-900/70 p-3 rounded-2xl border border-zinc-800">
            <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider flex items-center space-x-1">
              <ShieldCheck className="h-3 w-3 text-amber-400" />
              <span>NC Permit Req.</span>
            </span>
            <p className="text-xs font-black text-zinc-200 mt-1 line-clamp-1">
              {plan.permitRequired ? 'Required' : 'Exempt / Minor'}
            </p>
            <span className="text-[9px] text-zinc-500 line-clamp-1">
              {plan.permitType}
            </span>
          </div>

          <div className="bg-zinc-900/70 p-3 rounded-2xl border border-zinc-800">
            <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider flex items-center space-x-1">
              <CheckCircle2 className="h-3 w-3 text-indigo-400" />
              <span>SOP Progress</span>
            </span>
            <p className="text-base font-black text-zinc-100 mt-0.5">
              {progressPercent}%
            </p>
            <span className="text-[9px] text-zinc-500">
              {completedCount} of {allSteps.length} Steps Done
            </span>
          </div>
        </div>

        {/* Assigned Contractor Strip */}
        <div className="bg-gradient-to-r from-emerald-950/40 via-zinc-900/80 to-zinc-900/80 border border-emerald-500/30 p-3 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded-xl">
              <HardHat className="h-4 w-4" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-400 block">
                Assigned NC Tradesman / GC:
              </span>
              <p className="text-xs font-bold text-zinc-100">
                {plan.assignedContractorName || 'No Contractor Assigned Yet'}
                {plan.assignedContractorRate && <span className="text-emerald-400 ml-1.5 font-mono">({plan.assignedContractorRate})</span>}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {plan.assignedContractorPhone && (
              <a
                href={`tel:${plan.assignedContractorPhone}`}
                className="flex items-center space-x-1 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-bold transition"
              >
                <Phone className="h-3.5 w-3.5 text-emerald-400" />
                <span>Call</span>
              </a>
            )}

            <button
              onClick={handleApplyToDealRehab}
              disabled={isApplying}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold transition shadow-md cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{isApplying ? 'Applying...' : 'Apply to Deal Budget'}</span>
            </button>
          </div>
        </div>

        {applySuccessMessage && (
          <div className="p-2.5 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 font-bold flex items-center space-x-2">
            <Check className="h-4 w-4 text-emerald-400" />
            <span>{applySuccessMessage}</span>
          </div>
        )}
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center space-x-2 border-b border-zinc-850 pb-2">
        <button
          onClick={() => setActiveTab('steps')}
          className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center space-x-1.5 ${
            activeTab === 'steps' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <CheckCircle2 className="h-3.5 w-3.5" />
          <span>Step-by-Step SOP ({allSteps.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('materials')}
          className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center space-x-1.5 ${
            activeTab === 'materials' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Package className="h-3.5 w-3.5" />
          <span>Materials & Tools ({plan.requiredMaterials.length + plan.requiredTools.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('contractors')}
          className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center space-x-1.5 ${
            activeTab === 'contractors' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Users className="h-3.5 w-3.5" />
          <span>Matched NC Contractors ({matchedContractors.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('safety')}
          className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center space-x-1.5 ${
            activeTab === 'safety' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <ShieldAlert className="h-3.5 w-3.5" />
          <span>NC Code & Safety</span>
        </button>
      </div>

      {/* Tab Contents */}
      <div className="overflow-y-auto pr-1 space-y-4 flex-1">
        {/* Tab 1: Execution Phases & Steps */}
        {activeTab === 'steps' && (
          <div className="space-y-4">
            <div className="p-3.5 bg-zinc-900/50 border border-zinc-850 rounded-2xl space-y-1">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-400 block">
                Diagnostic & Scope Analysis
              </span>
              <p className="text-xs text-zinc-300 leading-relaxed">
                {plan.problemDiagnosis}
              </p>
            </div>

            <div className="space-y-3">
              {plan.executionPhases.map((phase) => (
                <div key={phase.phaseNumber} className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                    <div>
                      <h4 className="text-xs font-extrabold text-zinc-100 uppercase tracking-tight">
                        Phase {phase.phaseNumber}: {phase.phaseName}
                      </h4>
                      <p className="text-[11px] text-zinc-400">{phase.description}</p>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-zinc-500 bg-zinc-950 px-2 py-0.5 rounded-md border border-zinc-850">
                      {phase.steps.filter(s => s.completed).length} / {phase.steps.length} Done
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {phase.steps.map((step) => (
                      <div
                        key={step.stepNumber}
                        onClick={() => handleToggleStep(phase.phaseNumber, step.stepNumber)}
                        className={`p-3.5 rounded-xl border transition cursor-pointer flex items-start space-x-3 ${
                          step.completed
                            ? 'bg-emerald-950/20 border-emerald-500/40 text-zinc-300'
                            : 'bg-zinc-950/70 border-zinc-850 hover:border-zinc-700 text-zinc-200'
                        }`}
                      >
                        <button
                          type="button"
                          className="mt-0.5 text-emerald-400 focus:outline-none"
                        >
                          {step.completed ? (
                            <CheckCircle2 className="h-4 w-4 fill-emerald-500/20 text-emerald-400" />
                          ) : (
                            <Circle className="h-4 w-4 text-zinc-600" />
                          )}
                        </button>

                        <div className="space-y-1 flex-1">
                          <div className="flex items-center justify-between">
                            <span className={`text-xs font-bold ${step.completed ? 'line-through text-zinc-400' : 'text-zinc-100'}`}>
                              Step {step.stepNumber}: {step.title}
                            </span>
                            {step.inspectionGate && (
                              <span className="text-[9px] font-extrabold bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full">
                                Inspection Gate
                              </span>
                            )}
                          </div>

                          <p className="text-[11px] text-zinc-400 leading-relaxed">
                            {step.instruction}
                          </p>

                          {step.toleranceMetric && (
                            <div className="text-[10px] font-mono text-emerald-400/90 pt-1">
                              <strong>Quality SOP:</strong> {step.toleranceMetric}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Materials & Tools */}
        {activeTab === 'materials' && (
          <div className="space-y-4">
            {/* Materials Manifest */}
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                <h4 className="text-xs font-extrabold text-zinc-100 uppercase tracking-tight flex items-center space-x-1.5">
                  <Package className="h-4 w-4 text-emerald-400" />
                  <span>Required Materials & Trade Hardware</span>
                </h4>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  Est. Total: ${plan.estimatedMaterialCost.toLocaleString()}
                </span>
              </div>

              <div className="space-y-2">
                {plan.requiredMaterials.map((mat, idx) => (
                  <div key={idx} className="p-3 bg-zinc-950/70 border border-zinc-850 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-zinc-200">{mat.name}</p>
                      <p className="text-[10px] text-zinc-400 font-mono">
                        Qty: {mat.quantity} • Spec: {mat.ncTradeSpec || 'NC Code Compliant'}
                      </p>
                    </div>
                    <div className="text-right font-mono">
                      <span className="font-extrabold text-emerald-400">${mat.totalCost.toLocaleString()}</span>
                      {mat.retailSku && <p className="text-[9px] text-zinc-500">SKU: {mat.retailSku}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tools Checklist */}
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 space-y-3">
              <h4 className="text-xs font-extrabold text-zinc-100 uppercase tracking-tight flex items-center space-x-1.5">
                <Wrench className="h-4 w-4 text-sky-400" />
                <span>Trade Tools & Equipment Manifest</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {plan.requiredTools.map((tool, idx) => (
                  <div key={idx} className="p-2.5 bg-zinc-950/70 border border-zinc-850 rounded-xl flex items-center justify-between text-xs">
                    <span className="font-bold text-zinc-300">{tool.name}</span>
                    <span className="text-[9px] font-extrabold text-zinc-500 uppercase bg-zinc-900 px-2 py-0.5 rounded-md border border-zinc-800">
                      {tool.category}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Matched NC Contractors */}
        {activeTab === 'contractors' && (
          <div className="space-y-3">
            <div className="p-3.5 bg-zinc-900/50 border border-zinc-850 rounded-2xl">
              <h4 className="text-xs font-extrabold text-zinc-100 uppercase tracking-tight">
                Top-Ranked NC Licensed Tradesmen for this Scope
              </h4>
              <p className="text-[11px] text-zinc-400">
                Matched based on trade specialization, active NC license verification, {deal.city} radius, and insurance status.
              </p>
            </div>

            <div className="space-y-2.5">
              {matchedContractors.map((contractor) => {
                const isAssigned = plan.assignedContractorId === contractor.id;

                return (
                  <div
                    key={contractor.id}
                    className={`p-4 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isAssigned
                        ? 'bg-emerald-950/30 border-emerald-500/60 ring-1 ring-emerald-500/40'
                        : 'bg-zinc-950/70 border-zinc-850 hover:border-zinc-700'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center space-x-2">
                        <h4 className="text-xs font-black text-zinc-100">{contractor.name}</h4>
                        {isAssigned && (
                          <span className="text-[9px] font-extrabold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                            Assigned to Scope
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-zinc-400">
                        {contractor.licenseNumber} ({contractor.licenseTier}) • {contractor.city}, NC • {contractor.phone}
                      </p>

                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {contractor.badgeHighlights.map((b, i) => (
                          <span key={i} className="text-[9px] bg-zinc-900 text-zinc-400 px-2 py-0.5 rounded-md border border-zinc-800">
                            ✓ {b}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 border-t sm:border-t-0 border-zinc-850 pt-2 sm:pt-0">
                      <span className="text-xs font-mono font-black text-emerald-400">
                        ${contractor.hourlyRate}/hr
                      </span>

                      <div className="flex items-center space-x-1.5">
                        <button
                          onClick={() => setSelectedContractorForRFP(contractor)}
                          className="px-2.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 text-[11px] font-bold border border-zinc-800 transition cursor-pointer"
                        >
                          View RFP
                        </button>

                        <button
                          onClick={() => handleAssignContractor(contractor)}
                          className={`px-3 py-1.5 rounded-xl text-[11px] font-extrabold transition cursor-pointer ${
                            isAssigned
                              ? 'bg-emerald-600 text-white'
                              : 'bg-emerald-950/60 hover:bg-emerald-900 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          {isAssigned ? 'Assigned' : 'Assign'}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 4: NC Code & Safety */}
        {activeTab === 'safety' && (
          <div className="space-y-4">
            {/* NC Code Box */}
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 space-y-2">
              <h4 className="text-xs font-extrabold text-zinc-100 uppercase tracking-tight flex items-center space-x-1.5">
                <FileText className="h-4 w-4 text-emerald-400" />
                <span>North Carolina Residential Code Reference</span>
              </h4>
              <p className="text-xs font-mono text-emerald-300/90 bg-zinc-950 p-3 rounded-xl border border-zinc-850">
                {plan.ncCodeCitation}
              </p>
              <p className="text-[11px] text-zinc-400">
                Permit Protocol: <strong>{plan.permitType}</strong>
              </p>
            </div>

            {/* Pitfalls */}
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 space-y-2.5">
              <h4 className="text-xs font-extrabold text-rose-400 uppercase tracking-tight flex items-center space-x-1.5">
                <AlertTriangle className="h-4 w-4" />
                <span>Critical Pitfalls & Red Flags to Avoid</span>
              </h4>
              <div className="space-y-1.5">
                {plan.criticalPitfalls.map((pitfall, idx) => (
                  <div key={idx} className="p-2.5 bg-rose-500/10 border border-rose-500/20 rounded-xl text-[11px] text-rose-300">
                    ⚠️ {pitfall}
                  </div>
                ))}
              </div>
            </div>

            {/* Pro Tips */}
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 space-y-2.5">
              <h4 className="text-xs font-extrabold text-sky-400 uppercase tracking-tight flex items-center space-x-1.5">
                <Sparkles className="h-4 w-4" />
                <span>NC Contractor Pro Tips</span>
              </h4>
              <div className="space-y-1.5">
                {plan.proTips.map((tip, idx) => (
                  <div key={idx} className="p-2.5 bg-sky-500/10 border border-sky-500/20 rounded-xl text-[11px] text-sky-300">
                    💡 {tip}
                  </div>
                ))}
              </div>
            </div>

            {/* PPE Required */}
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 space-y-2">
              <h4 className="text-xs font-extrabold text-zinc-100 uppercase tracking-tight flex items-center space-x-1.5">
                <HardHat className="h-4 w-4 text-amber-400" />
                <span>Required Safety PPE Package</span>
              </h4>
              <div className="flex flex-wrap gap-2">
                {plan.safetyPPE.map((ppe, idx) => (
                  <span key={idx} className="text-[11px] bg-zinc-950 text-zinc-300 px-3 py-1 rounded-xl border border-zinc-800">
                    🛡️ {ppe}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* RFP Modal */}
      {selectedContractorForRFP && (
        <ContractorRFPModal
          deal={deal}
          plan={plan}
          contractor={selectedContractorForRFP}
          onClose={() => setSelectedContractorForRFP(null)}
          onAssignContractor={() => handleAssignContractor(selectedContractorForRFP)}
        />
      )}
    </div>
  );
};
