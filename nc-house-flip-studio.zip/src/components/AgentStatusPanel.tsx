/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Bot, 
  Search, 
  TrendingUp, 
  Hammer, 
  ShieldCheck, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle,
  Activity,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { AgentType, AgentLog } from "../types";

interface AgentStatusPanelProps {
  activeAgent: AgentType | null;
  logs: AgentLog[];
}

interface AgentDetails {
  type: AgentType;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  bgColor: string;
  borderColor: string;
  executionMode: "Simple Rules" | "Smart AI" | "Super AI Agent";
}

const AGENTS: AgentDetails[] = [
  {
    type: "Supervisor",
    title: "Manager Agent",
    description: "The Coordinator: Directs all other helper agents",
    icon: Bot,
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/10",
    borderColor: "border-emerald-500/20",
    executionMode: "Super AI Agent"
  },
  {
    type: "Scout",
    title: "Scout Agent",
    description: "The Finder: Searches public county files for bargain houses",
    icon: Search,
    color: "text-teal-400",
    bgColor: "bg-teal-500/10",
    borderColor: "border-teal-500/20",
    executionMode: "Simple Rules"
  },
  {
    type: "ARV",
    title: "Price Expert Agent",
    description: "The Valuer: Figures out the finished house value",
    icon: TrendingUp,
    color: "text-sky-400",
    bgColor: "bg-sky-500/10",
    borderColor: "border-sky-500/20",
    executionMode: "Simple Rules"
  },
  {
    type: "Rehab",
    title: "Builder Agent",
    description: "The Estimator: Works out how much it costs to fix everything",
    icon: Hammer,
    color: "text-amber-400",
    bgColor: "bg-amber-500/10",
    borderColor: "border-amber-500/20",
    executionMode: "Simple Rules"
  },
  {
    type: "Compliance",
    title: "Law Checker Agent",
    description: "The Lawyer: Checks North Carolina house-buying rules",
    icon: ShieldCheck,
    color: "text-purple-400",
    bgColor: "bg-purple-500/10",
    borderColor: "border-purple-500/20",
    executionMode: "Simple Rules"
  },
  {
    type: "Project",
    title: "Planner Agent",
    description: "The Organizer: Lists project steps and suggests local crews",
    icon: Calendar,
    color: "text-pink-400",
    bgColor: "bg-pink-500/10",
    borderColor: "border-pink-500/20",
    executionMode: "Simple Rules"
  }
];

export default function AgentStatusPanel({ activeAgent, logs }: AgentStatusPanelProps) {
  const [isCollapsed, setIsCollapsed] = useState(true);

  // Take last 4 logs to show in panel
  const recentLogs = [...logs].reverse().slice(0, 4);

  // Automatically expand if there's an active agent currently running!
  useEffect(() => {
    if (activeAgent) {
      setIsCollapsed(false);
    }
  }, [activeAgent]);

  return (
    <div id="agent-status-panel" className="bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-5 shadow-md flex flex-col backdrop-blur-md transition-all duration-300">
      {/* Collapsible Header */}
      <div 
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="flex items-center justify-between pb-3 cursor-pointer select-none"
      >
        <div className="flex items-center space-x-2">
          <Activity className={`h-4 w-4 text-emerald-400 ${activeAgent ? "animate-pulse" : ""}`} />
          <div>
            <h2 className="text-xs font-extrabold text-zinc-100 uppercase tracking-wider flex items-center gap-1.5">
              <span>AI Agents System Monitor</span>
              <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase ${activeAgent ? "bg-emerald-500/15 text-emerald-400" : "bg-zinc-800 text-zinc-400"}`}>
                {activeAgent ? `${activeAgent} Working` : "Nominal State"}
              </span>
            </h2>
            <p className="text-[10px] text-zinc-500">6 specialized AI agents running 24/7 background analysis</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <div className="hidden sm:flex items-center space-x-1.5 text-[9px] font-black text-zinc-400 uppercase tracking-wider">
            {activeAgent ? (
              <span className="flex items-center space-x-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                <span>Agent processing live data...</span>
              </span>
            ) : (
              <span>All systems ready</span>
            )}
          </div>
          <button className="p-1 hover:bg-zinc-850 rounded-lg text-zinc-400 transition">
            {isCollapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
          </button>
        </div>
      </div>

      <AnimatePresence initial={false}>
        {!isCollapsed && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <div className="pt-3 border-t border-zinc-800/80 space-y-5">
              {/* Agents Row */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {AGENTS.map((agent) => {
                  const isCurrent = activeAgent === agent.type;
                  const Icon = agent.icon;
                  return (
                    <div
                      key={agent.type}
                      className={`relative flex flex-col items-center justify-center p-3 rounded-2xl border transition-all duration-300 ${
                        isCurrent 
                          ? `${agent.bgColor} ${agent.borderColor} shadow-lg scale-102 ring-1 ring-emerald-500/30` 
                          : 'bg-zinc-950/40 border-zinc-850 hover:bg-zinc-900/60 hover:border-zinc-700'
                      }`}
                    >
                      {isCurrent && (
                        <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
                        </span>
                      )}
                      <div className={`p-2 rounded-xl mb-1.5 ${isCurrent ? 'bg-zinc-950 shadow-inner' : 'bg-zinc-900/80'} ${agent.color}`}>
                        <Icon className="h-4.5 w-4.5" />
                      </div>
                      <span className="text-xs font-bold text-zinc-200 text-center">{agent.type}</span>
                      <span className="text-[9px] text-emerald-400 font-extrabold tracking-tight mt-0.5">{agent.executionMode}</span>
                      <span className="text-[8px] text-zinc-500 text-center line-clamp-1 mt-0.5">{agent.type === "Supervisor" ? "Orchestrator" : "Specialist"}</span>
                    </div>
                  );
                })}
              </div>

              {/* Live Activity Logs */}
              <div className="flex flex-col bg-zinc-950/40 border border-zinc-800/60 rounded-2xl p-4">
                <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-2.5">Agent Communication Feed</h3>
                {recentLogs.length === 0 ? (
                  <div className="flex flex-col items-center justify-center text-center p-6">
                    <Bot className="h-7 w-7 text-zinc-700 mb-1.5 animate-bounce" />
                    <p className="text-xs text-zinc-500">No active process log. Click "Go For Property" or ask the Supervisor to chat!</p>
                  </div>
                ) : (
                  <div className="space-y-2.5 text-xs max-h-[220px] overflow-y-auto pr-1">
                    {recentLogs.map((log) => {
                      const agentDetails = AGENTS.find((a) => a.type === log.agentName);
                      
                      return (
                        <motion.div
                          key={log.id}
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800/80 flex items-start space-x-2.5 shadow-xs"
                        >
                          <div className={`p-1.5 rounded-lg bg-zinc-950 border border-zinc-800 flex-shrink-0 ${agentDetails?.color || 'text-zinc-400'}`}>
                            {agentDetails ? <agentDetails.icon className="h-3.5 w-3.5" /> : <Bot className="h-3.5 w-3.5" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-zinc-200">{log.agentName} Agent</span>
                              <span className="text-[9px] text-zinc-500">
                                {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-zinc-300 mt-1 leading-relaxed text-[11px]">{log.message}</p>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
