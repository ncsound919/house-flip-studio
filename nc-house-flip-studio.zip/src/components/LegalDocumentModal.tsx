/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  FileText, 
  X, 
  Printer, 
  Copy, 
  CheckCircle2, 
  ShieldCheck, 
  Download, 
  Stamp, 
  Scale, 
  Landmark,
  Building,
  Calendar,
  Lock
} from "lucide-react";
import { PropertyDeal } from "../types";

interface LegalDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  deal: PropertyDeal;
  defaultDocType?: "lien_waiver" | "wholesale_assignment" | "proof_of_funds";
  contractorName?: string;
  drawAmount?: number;
  milestoneTitle?: string;
}

export default function LegalDocumentModal({
  isOpen,
  onClose,
  deal,
  defaultDocType = "lien_waiver",
  contractorName = "Plaza Midwood General Contractors LLC",
  drawAmount = 8500,
  milestoneTitle = "Framing & Structural Repairs"
}: LegalDocumentModalProps) {
  const [docType, setDocType] = useState<"lien_waiver" | "wholesale_assignment" | "proof_of_funds">(defaultDocType);
  const [docData, setDocData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [signedName, setSignedName] = useState("Managing Principal Operator");
  const [isSigned, setIsSigned] = useState(false);

  useEffect(() => {
    setDocType(defaultDocType);
  }, [defaultDocType]);

  useEffect(() => {
    if (!isOpen) return;

    const fetchDocument = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/generate-document", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            docType,
            dealId: deal.id,
            contractorName,
            drawAmount,
            milestoneTitle
          })
        });
        const json = await response.json();
        if (json.success) {
          setDocData(json.document);
        }
      } catch (err) {
        console.error("Failed to load document", err);
      } finally {
        setLoading(false);
      }
    };

    fetchDocument();
  }, [isOpen, docType, deal.id, contractorName, drawAmount, milestoneTitle]);

  if (!isOpen) return null;

  const handleCopy = () => {
    if (!docData) return;
    const fullText = `${docData.title}\nStatutory Authority: ${docData.statutoryReference}\nDocument ID: ${docData.documentId}\nProperty: ${docData.propertyAddress}\nDate: ${docData.effectiveDate}\n\n${docData.clauses?.join("\n\n")}\n\n[SIGNATURES]\n${JSON.stringify(docData.signatureBlock, null, 2)}`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    if (!docData) return;
    const fullText = `${docData.title}\nStatutory Authority: ${docData.statutoryReference}\nDocument ID: ${docData.documentId}\nProperty: ${docData.propertyAddress}\nDate: ${docData.effectiveDate}\n\n${docData.clauses?.join("\n\n")}\n\n[SIGNATURES]\n${JSON.stringify(docData.signatureBlock, null, 2)}`;
    const blob = new Blob([fullText], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${docData.documentId || "nc-legal-document"}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Top Bar */}
        <div className="p-5 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
              <Scale className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-zinc-100 uppercase tracking-wide">
                North Carolina Legal Compliance & Lien Waiver Suite
              </h3>
              <p className="text-[10px] text-zinc-400">
                Statutory real estate agreements & binding progress lien releases
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-850 text-zinc-300 text-xs font-bold rounded-xl border border-zinc-800 flex items-center space-x-1.5 transition cursor-pointer"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={handleDownload}
              className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-850 text-zinc-300 text-xs font-bold rounded-xl border border-zinc-800 flex items-center space-x-1.5 transition cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 bg-zinc-900 hover:bg-zinc-850 text-zinc-400 hover:text-zinc-200 rounded-xl border border-zinc-800 transition cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-zinc-800 bg-zinc-950/60 px-5 space-x-4 flex-shrink-0">
          <button
            onClick={() => setDocType("lien_waiver")}
            className={`py-3 text-xs font-extrabold uppercase tracking-wider border-b-2 transition cursor-pointer flex items-center space-x-2 ${
              docType === "lien_waiver"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <ShieldCheck className="h-4 w-4" />
            <span>Progress Lien Waiver (NC G.S. § 44A)</span>
          </button>
          <button
            onClick={() => setDocType("wholesale_assignment")}
            className={`py-3 text-xs font-extrabold uppercase tracking-wider border-b-2 transition cursor-pointer flex items-center space-x-2 ${
              docType === "wholesale_assignment"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <FileText className="h-4 w-4" />
            <span>NC HB 797 Assignment Agreement</span>
          </button>
          <button
            onClick={() => setDocType("proof_of_funds")}
            className={`py-3 text-xs font-extrabold uppercase tracking-wider border-b-2 transition cursor-pointer flex items-center space-x-2 ${
              docType === "proof_of_funds"
                ? "border-emerald-500 text-emerald-400"
                : "border-transparent text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <Landmark className="h-4 w-4" />
            <span>Escrow & Proof of Funds</span>
          </button>
        </div>

        {/* Document Body (Scrollable Paper Layout) */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-zinc-950/80">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 text-zinc-500 space-y-3">
              <div className="h-8 w-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-bold uppercase tracking-wider">Drafting Certified Legal Clauses...</p>
            </div>
          ) : docData ? (
            <div className="bg-zinc-900 border border-zinc-800/90 rounded-2xl p-8 shadow-inner space-y-6 text-zinc-300 font-serif leading-relaxed max-w-3xl mx-auto">
              {/* Official Seal Header */}
              <div className="text-center pb-6 border-b border-zinc-800/80 space-y-2">
                <div className="inline-flex items-center justify-center p-3 bg-zinc-950 rounded-full border border-zinc-800 text-emerald-400 mb-1">
                  <Stamp className="h-6 w-6" />
                </div>
                <h2 className="text-base font-extrabold font-sans text-zinc-100 uppercase tracking-tight">
                  {docData.title}
                </h2>
                <p className="text-[11px] font-sans text-emerald-400 font-bold">
                  {docData.statutoryReference}
                </p>
                <div className="flex items-center justify-center space-x-4 text-[10px] font-sans text-zinc-500 pt-1">
                  <span>Document ID: <strong className="text-zinc-400">{docData.documentId}</strong></span>
                  <span>•</span>
                  <span>Effective: <strong className="text-zinc-400">{docData.effectiveDate}</strong></span>
                </div>
              </div>

              {/* Property Summary Specs Block */}
              <div className="bg-zinc-950/60 p-4 rounded-xl border border-zinc-850 font-sans grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-[9px] uppercase font-bold text-zinc-500 block">Property</span>
                  <span className="font-bold text-zinc-200">{docData.propertyAddress}</span>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold text-zinc-500 block">Contractor / Assignee</span>
                  <span className="font-bold text-zinc-200">{docData.contractor || docData.assignee || docData.escrowAgent}</span>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold text-zinc-500 block">Disbursed Amount</span>
                  <span className="font-bold text-emerald-400">${(docData.drawAmount || docData.totalEscrowPool || 10000).toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold text-zinc-500 block">Scope Phase</span>
                  <span className="font-bold text-zinc-200">{docData.milestoneTitle || "Phase 1 Execution"}</span>
                </div>
              </div>

              {/* Clauses Body */}
              <div className="space-y-4 text-xs leading-relaxed text-zinc-300">
                {docData.clauses?.map((clause: string, i: number) => (
                  <p key={i} className="p-3.5 bg-zinc-950/30 rounded-xl border border-zinc-850/60">
                    {clause}
                  </p>
                ))}
              </div>

              {/* Legal Signatures Block */}
              <div className="mt-8 pt-6 border-t border-zinc-800 font-sans space-y-4">
                <h4 className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                  Digital Executions & Notarizations
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] uppercase font-bold text-zinc-500">Contractor / Assignor</span>
                      <span className="text-[9px] font-extrabold text-emerald-400 flex items-center">
                        <CheckCircle2 className="h-3 w-3 mr-1" /> VERIFIED
                      </span>
                    </div>
                    <p className="font-bold text-zinc-200">{docData.signatureBlock?.contractorSignature || docData.signatureBlock?.assignor || "Authorized Signatory"}</p>
                    <p className="text-[10px] text-zinc-500 font-mono">Timestamp: {docData.timestamp || "Electronic Signoff Verified"}</p>
                  </div>

                  <div className="p-4 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] uppercase font-bold text-zinc-500">Investor / Operator</span>
                      {isSigned ? (
                        <span className="text-[9px] font-extrabold text-emerald-400 flex items-center">
                          <CheckCircle2 className="h-3 w-3 mr-1" /> SIGNED
                        </span>
                      ) : (
                        <button
                          onClick={() => setIsSigned(true)}
                          className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[9px] font-bold transition cursor-pointer"
                        >
                          Sign Now
                        </button>
                      )}
                    </div>
                    {isSigned ? (
                      <p className="font-bold text-zinc-200">Signed Digitally by: {signedName}</p>
                    ) : (
                      <input
                        type="text"
                        value={signedName}
                        onChange={(e) => setSignedName(e.target.value)}
                        placeholder="Type legal name to sign..."
                        className="w-full bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-xs text-zinc-200 focus:outline-none focus:border-emerald-500"
                      />
                    )}
                    <p className="text-[10px] text-zinc-500 font-mono">NC e-Signature Act § 66-312</p>
                  </div>
                </div>

                <div className="p-3 bg-zinc-950/40 rounded-xl border border-zinc-850 text-[10px] text-zinc-500 flex items-center space-x-2">
                  <Lock className="h-3.5 w-3.5 text-zinc-600 flex-shrink-0" />
                  <span>
                    This legal record is cryptographically logged with local county compliance references and stored in the project audit repository.
                  </span>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* Modal Bottom Actions */}
        <div className="p-4 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between flex-shrink-0">
          <button
            onClick={handleCopy}
            className="px-3.5 py-2 bg-zinc-900 hover:bg-zinc-850 text-zinc-300 text-xs font-bold rounded-xl border border-zinc-800 flex items-center space-x-2 transition cursor-pointer"
          >
            {copied ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
            <span>{copied ? "Copied Full Text!" : "Copy Document Text"}</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
