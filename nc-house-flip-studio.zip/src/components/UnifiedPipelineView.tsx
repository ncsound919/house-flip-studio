/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  PropertyDeal, 
  DealStatus, 
  AgentType, 
  AgentLog 
} from '../types';
import { 
  Building, 
  TrendingUp, 
  Box, 
  Wrench, 
  Compass, 
  FileText, 
  Zap, 
  Search, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  ChevronRight, 
  Layers, 
  Plus, 
  Home, 
  DollarSign, 
  ShieldCheck, 
  HardHat, 
  Calendar, 
  MessageSquare, 
  CheckSquare, 
  Activity, 
  X,
  Sliders,
  Award,
  Clock,
  MapPin,
  ChevronDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Subcomponents
import PipelineBoard from './PipelineBoard';
import DealUnderwriter from './DealUnderwriter';
import { CADStudioView } from './CADStudioView';
import { RepairGuideView } from './RepairGuideView';
import PartnersOpsHub from './PartnersOpsHub';
import SupervisorChat from './SupervisorChat';
import ApprovalInbox from './ApprovalInbox';
import AgentStatusPanel from './AgentStatusPanel';
import LegalDocumentModal from './LegalDocumentModal';

export type PipelineStageId = 
  | 'sourcing' 
  | 'underwriting' 
  | 'cad-studio' 
  | 'repair-guide' 
  | 'walkthrough' 
  | 'contracts-draws';

interface UnifiedPipelineViewProps {
  deals: PropertyDeal[];
  selectedDealId: string | null;
  onSelectDeal: (id: string) => void;
  onUpdateDeal: (updatedDeal: PropertyDeal) => void;
  onAddDealTrigger: (status?: DealStatus) => void;
  onDeleteDeal: (dealId: string, e: React.MouseEvent) => void;
  onLaunchAutonomousPipeline: (deal: PropertyDeal) => void;
  // Sourcing handlers
  scoutingCity: string;
  setScoutingCity: (city: string) => void;
  isScouting: boolean;
  onAutoScout: () => void;
  liveSearchQuery: string;
  setLiveSearchQuery: (query: string) => void;
  isLookingUp: boolean;
  onLookupRealProperty: (address?: string) => void;
  sourcingMode: 'auto' | 'lookup';
  setSourcingMode: (mode: 'auto' | 'lookup') => void;
  scoutMessage: string | null;
  // Approvals & Assistant
  approvals: any[];
  onApprovalAction: (approvalId: string, action: 'approve' | 'reject', notes?: string) => void;
  isApprovalLoading: boolean;
  activeAgent: AgentType | null;
  isAnalyzing: boolean;
  onRunUnderwrite: () => void;
  onUpdateStatus: (status: string) => void;
}

export const PIPELINE_STAGES: {
  id: PipelineStageId;
  stepNumber: number;
  label: string;
  shortLabel: string;
  tagline: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  badgeColor: string;
  activeColor: string;
}[] = [
  {
    id: 'sourcing',
    stepNumber: 1,
    label: 'Lead Ingest & Sourcing',
    shortLabel: '1. Sourcing',
    tagline: 'MLS & County GIS Records',
    icon: Building,
    color: 'text-sky-400',
    badgeColor: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
    activeColor: 'border-sky-500 bg-sky-950/30 text-sky-300'
  },
  {
    id: 'underwriting',
    stepNumber: 2,
    label: 'Desktop Underwriting & Comps',
    shortLabel: '2. Underwriting',
    tagline: '70% MAO, Comps & Capital Stack',
    icon: TrendingUp,
    color: 'text-emerald-400',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    activeColor: 'border-emerald-500 bg-emerald-950/30 text-emerald-300'
  },
  {
    id: 'cad-studio',
    stepNumber: 3,
    label: '3D Spatial CAD Fix Studio',
    shortLabel: '3. 3D CAD',
    tagline: 'Interactive 3D Defect Modeling',
    icon: Box,
    color: 'text-indigo-400',
    badgeColor: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
    activeColor: 'border-indigo-500 bg-indigo-950/30 text-indigo-300'
  },
  {
    id: 'repair-guide',
    stepNumber: 4,
    label: 'NC Code SOPs & Contractors',
    shortLabel: '4. Code & Trades',
    tagline: '2024 NCRC SOPs & Subcontractor RFPs',
    icon: Wrench,
    color: 'text-amber-400',
    badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    activeColor: 'border-amber-500 bg-amber-950/30 text-amber-300'
  },
  {
    id: 'walkthrough',
    stepNumber: 5,
    label: 'On-Site Walkthrough & Punchout',
    shortLabel: '5. Field Punch',
    tagline: 'Mobile Checklist & Field Photos',
    icon: Compass,
    color: 'text-teal-400',
    badgeColor: 'bg-teal-500/10 text-teal-400 border-teal-500/20',
    activeColor: 'border-teal-500 bg-teal-950/30 text-teal-300'
  },
  {
    id: 'contracts-draws',
    stepNumber: 6,
    label: 'Contracts, Draws & Escrow',
    shortLabel: '6. Close & Draws',
    tagline: 'NC Lien Waivers, LOI & Bank Draws',
    icon: FileText,
    color: 'text-purple-400',
    badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    activeColor: 'border-purple-500 bg-purple-950/30 text-purple-300'
  }
];

export default function UnifiedPipelineView({
  deals,
  selectedDealId,
  onSelectDeal,
  onUpdateDeal,
  onAddDealTrigger,
  onDeleteDeal,
  onLaunchAutonomousPipeline,
  scoutingCity,
  setScoutingCity,
  isScouting,
  onAutoScout,
  liveSearchQuery,
  setLiveSearchQuery,
  isLookingUp,
  onLookupRealProperty,
  sourcingMode,
  setSourcingMode,
  scoutMessage,
  approvals,
  onApprovalAction,
  isApprovalLoading,
  activeAgent,
  isAnalyzing,
  onRunUnderwrite,
  onUpdateStatus
}: UnifiedPipelineViewProps) {
  const [pipelineMode, setPipelineMode] = useState<'stage-flow' | 'kanban'>('stage-flow');
  const [currentStage, setCurrentStage] = useState<PipelineStageId>('underwriting');
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [isApprovalDrawerOpen, setIsApprovalDrawerOpen] = useState(false);

  // Active Selected Deal
  const activeDeal = deals.find((d) => d.id === selectedDealId) || deals[0] || null;

  // Sync active deal stage mapping
  useEffect(() => {
    if (!activeDeal) return;
    // Map deal status to appropriate initial stage if in stage-flow mode
    if (activeDeal.status === 'Lead Ingest' || activeDeal.status === 'Property Enrichment') {
      // Keep or let user navigate freely
    }
  }, [activeDeal?.id]);

  const currentStageIndex = PIPELINE_STAGES.findIndex((s) => s.id === currentStage);
  const currentStageMeta = PIPELINE_STAGES[currentStageIndex] || PIPELINE_STAGES[0];

  const handleNextStage = () => {
    if (currentStageIndex < PIPELINE_STAGES.length - 1) {
      setCurrentStage(PIPELINE_STAGES[currentStageIndex + 1].id);
    }
  };

  const handlePrevStage = () => {
    if (currentStageIndex > 0) {
      setCurrentStage(PIPELINE_STAGES[currentStageIndex - 1].id);
    }
  };

  // Helper to calculate stage completion metrics
  const getStageCompletion = (stageId: PipelineStageId, deal: PropertyDeal | null) => {
    if (!deal) return { isComplete: false, label: 'Pending' };
    switch (stageId) {
      case 'sourcing':
        return { isComplete: true, label: 'GIS & MLS Verified' };
      case 'underwriting':
        return { 
          isComplete: (deal.underwriting?.arv ?? 0) > 0, 
          label: (deal.underwriting?.arv ?? 0) > 0 ? `$${deal.underwriting?.arv.toLocaleString()} ARV` : 'Pending' 
        };
      case 'cad-studio':
        return { 
          isComplete: !!deal.cadLayout, 
          label: deal.cadLayout ? `${deal.cadLayout.fixProtocols.length} Spatial Nodes` : 'Ready to Model' 
        };
      case 'repair-guide':
        return { 
          isComplete: (deal.repairPlans?.length ?? 0) > 0, 
          label: (deal.repairPlans?.length ?? 0) > 0 ? `${deal.repairPlans?.length} NC SOPs` : 'Plan Available' 
        };
      case 'walkthrough':
        const checkedCount = deal.completionChecklist?.filter((c) => c.checkedByPartner).length ?? 0;
        const totalCount = deal.completionChecklist?.length ?? 12;
        return { 
          isComplete: checkedCount > 0, 
          label: `${checkedCount}/${totalCount} Checked` 
        };
      case 'contracts-draws':
        const drawCount = deal.fundingDetails?.bankDrawsSubmitted?.length ?? 0;
        return { 
          isComplete: drawCount > 0 || (deal.milestones?.length ?? 0) > 0, 
          label: `${drawCount} Bank Draws` 
        };
    }
  };

  return (
    <div id="unified-pipeline-workspace" className="space-y-5">
      {/* 1. TOP PIPELINE COMMAND BAR */}
      <div className="bg-zinc-900/70 border border-zinc-800/90 rounded-3xl p-4 lg:p-5 shadow-xl backdrop-blur-md">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Left: Property Selector & Active Property Title */}
          <div className="flex items-center space-x-3.5 flex-1 min-w-0">
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/25 rounded-2xl flex-shrink-0 text-emerald-400 shadow-inner">
              <Building className="h-6 w-6" />
            </div>
            
            <div className="min-w-0 flex-1">
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 uppercase tracking-wider">
                  Unified Pipeline
                </span>
                <span className="text-[10px] text-zinc-500 font-bold flex items-center">
                  <MapPin className="h-2.5 w-2.5 mr-0.5 text-zinc-400" />
                  {activeDeal?.city || 'NC'}, North Carolina
                </span>
              </div>

              {/* Property Switcher Dropdown */}
              <div className="flex items-center space-x-2 mt-1">
                <select
                  value={selectedDealId || ''}
                  onChange={(e) => onSelectDeal(e.target.value)}
                  className="bg-zinc-950/80 border border-zinc-800 rounded-xl px-3 py-1.5 text-sm font-extrabold text-zinc-100 hover:border-zinc-700 transition cursor-pointer max-w-sm truncate focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                >
                  {deals.map((deal) => (
                    <option key={deal.id} value={deal.id}>
                      {deal.address} ({deal.city}) — ${deal.askingPrice.toLocaleString()}
                    </option>
                  ))}
                </select>

                <button
                  onClick={() => onAddDealTrigger('Lead Ingest')}
                  className="p-1.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-750 text-zinc-300 hover:text-white border border-zinc-700 transition cursor-pointer flex-shrink-0"
                  title="Add New Property Lead"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Center: Financial Deal Scorecard */}
          {activeDeal && (
            <div className="hidden xl:flex items-center space-x-4 bg-zinc-950/70 border border-zinc-800/80 rounded-2xl px-4 py-2 text-xs">
              <div>
                <span className="text-[9px] text-zinc-500 font-extrabold uppercase tracking-wider block">Asking</span>
                <span className="font-bold text-zinc-200">${activeDeal.askingPrice.toLocaleString()}</span>
              </div>
              <div className="h-6 w-[1px] bg-zinc-800" />
              <div>
                <span className="text-[9px] text-zinc-500 font-extrabold uppercase tracking-wider block">ARV Value</span>
                <span className="font-bold text-emerald-400">${activeDeal.underwriting?.arv?.toLocaleString() || '—'}</span>
              </div>
              <div className="h-6 w-[1px] bg-zinc-800" />
              <div>
                <span className="text-[9px] text-zinc-500 font-extrabold uppercase tracking-wider block">Est. Rehab</span>
                <span className="font-bold text-amber-400">${activeDeal.underwriting?.rehabCost?.toLocaleString() || '—'}</span>
              </div>
              <div className="h-6 w-[1px] bg-zinc-800" />
              <div>
                <span className="text-[9px] text-zinc-500 font-extrabold uppercase tracking-wider block">Net Profit</span>
                <span className="font-bold text-teal-400">${activeDeal.underwriting?.projectedProfit?.toLocaleString() || '—'}</span>
              </div>
              <div className="h-6 w-[1px] bg-zinc-800" />
              <div>
                <span className="text-[9px] text-zinc-500 font-extrabold uppercase tracking-wider block">Target ROI</span>
                <span className="font-bold text-emerald-300">{activeDeal.underwriting?.roi ? `${activeDeal.underwriting.roi}%` : '—'}</span>
              </div>
            </div>
          )}

          {/* Right: Mode Switcher & Autonomous 1-Click Trigger */}
          <div className="flex items-center space-x-2.5 flex-shrink-0">
            {/* View Mode Toggle: Stage Flow vs. Kanban Board */}
            <div className="flex rounded-xl bg-zinc-950 p-1 border border-zinc-800">
              <button
                onClick={() => setPipelineMode('stage-flow')}
                className={`px-3 py-1.5 text-[10px] font-extrabold rounded-lg transition uppercase tracking-wider cursor-pointer flex items-center space-x-1.5 ${
                  pipelineMode === 'stage-flow'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
                title="Step-by-step pipeline execution flow"
              >
                <Layers className="h-3.5 w-3.5" />
                <span>Stage Flow</span>
              </button>

              <button
                onClick={() => setPipelineMode('kanban')}
                className={`px-3 py-1.5 text-[10px] font-extrabold rounded-lg transition uppercase tracking-wider cursor-pointer flex items-center space-x-1.5 ${
                  pipelineMode === 'kanban'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
                title="Full Kanban Board overview"
              >
                <Sliders className="h-3.5 w-3.5" />
                <span>Kanban Board</span>
              </button>
            </div>

            {/* Autonomous 1-Click Pipeline Runner */}
            {activeDeal && (
              <button
                onClick={() => onLaunchAutonomousPipeline(activeDeal)}
                className="px-3.5 py-1.5 bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs rounded-xl shadow-md transition flex items-center space-x-1.5 cursor-pointer flex-shrink-0"
                title="Run all 5 agents automatically from Sourcing to Closing"
              >
                <Zap className="h-3.5 w-3.5 animate-pulse text-amber-300" />
                <span className="hidden sm:inline">Auto-Run Pipeline</span>
              </button>
            )}

            {/* AI Supervisor Toggle */}
            <button
              onClick={() => setIsCopilotOpen(!isCopilotOpen)}
              className={`p-2 rounded-xl border transition cursor-pointer flex items-center space-x-1 ${
                isCopilotOpen
                  ? 'bg-indigo-600 text-white border-indigo-500'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
              title="Toggle AI Supervisor Copilot"
            >
              <MessageSquare className="h-4 w-4" />
            </button>

            {/* Approvals Inbox Toggle */}
            {approvals.length > 0 && (
              <button
                onClick={() => setIsApprovalDrawerOpen(!isApprovalDrawerOpen)}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 font-extrabold text-xs transition cursor-pointer flex items-center space-x-1"
                title="Pending Human Decisions"
              >
                <CheckSquare className="h-3.5 w-3.5" />
                <span>{approvals.filter((a) => a.status === 'pending').length} Gates</span>
              </button>
            )}
          </div>
        </div>

        {/* 2. UNIFIED 6-STAGE PIPELINE STEPPER (Visible when in stage-flow mode) */}
        {pipelineMode === 'stage-flow' && (
          <div className="mt-4 pt-4 border-t border-zinc-800/80">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
              {PIPELINE_STAGES.map((stage, idx) => {
                const isActive = currentStage === stage.id;
                const isPassed = idx < currentStageIndex;
                const StageIcon = stage.icon;
                const completion = getStageCompletion(stage.id, activeDeal);

                return (
                  <button
                    key={stage.id}
                    onClick={() => setCurrentStage(stage.id)}
                    className={`relative p-3 rounded-2xl text-left border transition cursor-pointer flex flex-col justify-between overflow-hidden ${
                      isActive
                        ? `${stage.activeColor} shadow-md ring-1 ring-emerald-500/40`
                        : isPassed
                        ? 'bg-zinc-950/60 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                        : 'bg-zinc-950/30 border-zinc-900 text-zinc-500 hover:border-zinc-800'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <div className="flex items-center space-x-1.5">
                        <StageIcon className={`h-3.5 w-3.5 ${isActive ? stage.color : isPassed ? 'text-emerald-400' : 'text-zinc-500'}`} />
                        <span className={`text-[10px] font-extrabold uppercase tracking-wider ${isActive ? 'text-zinc-100' : 'text-zinc-400'}`}>
                          {stage.shortLabel}
                        </span>
                      </div>

                      {completion.isComplete ? (
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 flex-shrink-0" />
                      ) : (
                        <span className="text-[9px] font-bold text-zinc-600">Step {stage.stepNumber}</span>
                      )}
                    </div>

                    <div className="mt-1">
                      <p className={`text-xs font-bold truncate ${isActive ? 'text-zinc-100' : 'text-zinc-300'}`}>
                        {stage.label}
                      </p>
                      <p className="text-[9px] text-zinc-500 truncate mt-0.5">
                        {completion.label}
                      </p>
                    </div>

                    {/* Active Accent Bar */}
                    {isActive && (
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-500 rounded-b-full" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Stepper Navigation Controls */}
            <div className="flex items-center justify-between mt-3 text-xs">
              <button
                onClick={handlePrevStage}
                disabled={currentStageIndex === 0}
                className="px-3 py-1.5 rounded-xl bg-zinc-950 hover:bg-zinc-900 disabled:opacity-40 disabled:hover:bg-zinc-950 border border-zinc-800 text-zinc-300 font-bold transition flex items-center space-x-1 cursor-pointer"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                <span>Previous Stage</span>
              </button>

              <div className="flex items-center space-x-2 text-zinc-400 font-medium text-[11px]">
                <span>Stage {currentStageIndex + 1} of {PIPELINE_STAGES.length}:</span>
                <span className="font-extrabold text-zinc-200">{currentStageMeta.label}</span>
              </div>

              <button
                onClick={handleNextStage}
                disabled={currentStageIndex === PIPELINE_STAGES.length - 1}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white font-bold transition flex items-center space-x-1 cursor-pointer shadow-xs"
              >
                <span>Next Stage</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. COPILOT & APPROVALS SLIDEOVER DRAWERS (When Opened) */}
      <AnimatePresence>
        {isCopilotOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-zinc-900/90 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl backdrop-blur-md relative"
          >
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-zinc-800">
              <div className="flex items-center space-x-2">
                <Sparkles className="h-4 w-4 text-indigo-400" />
                <h3 className="font-extrabold text-sm text-zinc-100">AI Supervisor Copilot</h3>
                <span className="text-[10px] text-zinc-400">Grounded in NC real estate statutes & active deal context</span>
              </div>
              <button
                onClick={() => setIsCopilotOpen(false)}
                className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <SupervisorChat dealContext={activeDeal} />
          </motion.div>
        )}

        {isApprovalDrawerOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-zinc-900/90 border border-amber-500/30 rounded-3xl p-5 shadow-2xl backdrop-blur-md relative"
          >
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-zinc-800">
              <div className="flex items-center space-x-2">
                <CheckSquare className="h-4 w-4 text-amber-400" />
                <h3 className="font-extrabold text-sm text-zinc-100">Human-in-the-Loop Approval Inbox</h3>
                <span className="text-[10px] text-zinc-400">Review and authorize sensitive capital decisions and offers</span>
              </div>
              <button
                onClick={() => setIsApprovalDrawerOpen(false)}
                className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <ApprovalInbox
              approvals={approvals}
              onAction={onApprovalAction}
              isLoading={isApprovalLoading}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* 4. MAIN PIPELINE VIEW BODY */}
      {pipelineMode === 'kanban' ? (
        /* KANBAN BOARD VIEW */
        <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-6 shadow-md backdrop-blur-md">
          <PipelineBoard
            deals={deals}
            selectedDealId={selectedDealId}
            onSelectDeal={(id) => {
              onSelectDeal(id);
              setPipelineMode('stage-flow');
            }}
            onAddDeal={onAddDealTrigger}
            onDeleteDeal={onDeleteDeal}
            onLaunchAutonomousPipeline={onLaunchAutonomousPipeline}
          />
        </div>
      ) : (
        /* STAGE FLOW VIEW (Deep Dive into Current Stage) */
        <div className="space-y-6">
          {currentStage === 'sourcing' && (
            /* STAGE 1: SOURCING & INGEST */
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                {/* Sourcing Panel */}
                <div className="lg:col-span-6 bg-zinc-900/60 border border-zinc-800/90 rounded-3xl p-6 shadow-md flex flex-col justify-between backdrop-blur-md">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Building className="h-4 w-4 text-sky-400" />
                        <h3 className="font-bold text-xs text-zinc-400 uppercase tracking-wider">NC House Finder</h3>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[9px] font-extrabold bg-sky-500/10 text-sky-400 border border-sky-500/20">
                        Public GIS & MLS Rolls
                      </span>
                    </div>
                    <h2 className="text-lg font-extrabold text-zinc-100">Find & Ingest Distressed Leads</h2>
                    <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                      Search for cheap, run-down houses across North Carolina's main cities or lookup any real address to start underwriting.
                    </p>

                    {/* Mode Selector */}
                    <div className="flex rounded-xl bg-zinc-950 p-1 mt-3 border border-zinc-800">
                      <button
                        onClick={() => setSourcingMode('auto')}
                        className={`flex-1 py-1.5 text-[10px] font-extrabold rounded-lg transition uppercase tracking-wider cursor-pointer ${
                          sourcingMode === 'auto'
                            ? 'bg-sky-600 text-white shadow-xs'
                            : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        Quick Cities List
                      </button>
                      <button
                        onClick={() => setSourcingMode('lookup')}
                        className={`flex-1 py-1.5 text-[10px] font-extrabold rounded-lg transition uppercase tracking-wider cursor-pointer ${
                          sourcingMode === 'lookup'
                            ? 'bg-sky-600 text-white shadow-xs'
                            : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        Search Any Address
                      </button>
                    </div>
                  </div>

                  {/* Sourcing Input Controls */}
                  <div className="mt-4 pt-4 border-t border-zinc-800 space-y-3">
                    {sourcingMode === 'auto' ? (
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase font-bold text-zinc-400">Select North Carolina Town</label>
                        <div className="flex space-x-2">
                          <select
                            value={scoutingCity}
                            onChange={(e) => setScoutingCity(e.target.value)}
                            disabled={isScouting}
                            className="flex-1 px-3 py-2 bg-zinc-950/60 border border-zinc-800 rounded-xl text-zinc-200 font-semibold text-xs shadow-inner focus:ring-1 focus:ring-sky-500/50 focus:outline-hidden"
                          >
                            <option value="Charlotte">Charlotte (Canopy MLS / Meck GIS)</option>
                            <option value="Durham">Durham (Triangle MLS / Durham GIS)</option>
                            <option value="Greensboro">Greensboro (Triad MLS / Guilford)</option>
                            <option value="Raleigh">Raleigh (Triangle MLS / Wake iMAPS)</option>
                            <option value="Wilmington">Wilmington (Cape Fear MLS / New Hanover)</option>
                            <option value="Asheville">Asheville (Canopy MLS / Buncombe GIS)</option>
                          </select>
                          <button
                            onClick={onAutoScout}
                            disabled={isScouting}
                            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:bg-zinc-800 disabled:text-zinc-600 text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center space-x-1 flex-shrink-0 cursor-pointer"
                          >
                            <Search className={`h-3.5 w-3.5 ${isScouting ? 'animate-pulse' : ''}`} />
                            <span>{isScouting ? 'Searching...' : 'Find Houses'}</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        <label className="text-[10px] uppercase font-bold text-zinc-400">Type Any Real NC Address</label>
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            onLookupRealProperty();
                          }}
                          className="flex space-x-2"
                        >
                          <input
                            type="text"
                            value={liveSearchQuery}
                            onChange={(e) => setLiveSearchQuery(e.target.value)}
                            placeholder="e.g. 1823 Seigle Ave, Charlotte"
                            disabled={isLookingUp}
                            className="flex-1 px-3 py-2 bg-zinc-950/60 border border-zinc-800 rounded-xl text-zinc-200 placeholder-zinc-500 font-medium text-xs shadow-inner focus:ring-1 focus:ring-sky-500/50 focus:outline-hidden"
                          />
                          <button
                            type="submit"
                            disabled={isLookingUp || !liveSearchQuery.trim()}
                            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:bg-zinc-800 disabled:text-zinc-600 text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center space-x-1 flex-shrink-0 cursor-pointer"
                          >
                            <Search className={`h-3.5 w-3.5 ${isLookingUp ? 'animate-spin' : ''}`} />
                            <span>{isLookingUp ? 'Searching...' : 'Search'}</span>
                          </button>
                        </form>

                        {/* Quick Verified Properties */}
                        <div>
                          <span className="text-[9px] uppercase tracking-wider text-zinc-500 font-bold">Quick Verified Properties:</span>
                          <div className="flex flex-wrap gap-1.5 mt-1.5">
                            {[
                              { label: 'Seigle Ave (CLT)', address: '1823 Seigle Ave, Charlotte, NC' },
                              { label: 'Chapin St (DUR)', address: '2404 Chapin St, Durham, NC' },
                              { label: 'S Fisher (RAL)', address: '102 S Fisher St, Raleigh, NC' },
                              { label: 'Benbow Rd (GSO)', address: '2111 S Benbow Rd, Greensboro, NC' },
                              { label: 'Pearson Dr (AVL)', address: '323 Pearson Dr, Asheville, NC' },
                              { label: '12th St (ILM)', address: '207 N 12th St, Wilmington, NC' }
                            ].map((chip) => (
                              <button
                                key={chip.label}
                                type="button"
                                onClick={() => onLookupRealProperty(chip.address)}
                                disabled={isLookingUp}
                                className="px-2 py-0.5 rounded-md bg-zinc-950 text-[10px] text-zinc-400 hover:text-sky-400 hover:border-sky-500/40 border border-zinc-800 transition cursor-pointer"
                              >
                                {chip.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {scoutMessage && (
                      <div className="p-3 bg-sky-500/10 border border-sky-500/20 rounded-xl flex items-start space-x-2">
                        <Sparkles className="h-3.5 w-3.5 text-sky-400 flex-shrink-0 mt-0.5" />
                        <p className="text-[10px] font-medium text-sky-300 leading-normal">{scoutMessage}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sourced Leads Inventory */}
                <div className="lg:col-span-6 bg-zinc-900/60 border border-zinc-800/90 rounded-3xl p-6 shadow-md flex flex-col justify-between backdrop-blur-md">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <Layers className="h-4 w-4 text-emerald-400" />
                        <h3 className="font-bold text-xs text-zinc-400 uppercase tracking-wider">Active Deal Inventory ({deals.length})</h3>
                      </div>
                      <button
                        onClick={() => onAddDealTrigger('Lead Ingest')}
                        className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs rounded-lg transition flex items-center space-x-1 cursor-pointer"
                      >
                        <Plus className="h-3 w-3" />
                        <span>Manual Add</span>
                      </button>
                    </div>

                    <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                      {deals.map((deal) => {
                        const isSelected = deal.id === selectedDealId;
                        return (
                          <div
                            key={deal.id}
                            onClick={() => onSelectDeal(deal.id)}
                            className={`p-3 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                              isSelected
                                ? 'bg-sky-950/40 border-sky-500 text-zinc-100 shadow-xs'
                                : 'bg-zinc-950/50 border-zinc-800/80 text-zinc-300 hover:border-zinc-700'
                            }`}
                          >
                            <div className="min-w-0 flex-1 mr-2">
                              <div className="flex items-center space-x-2">
                                <span className="font-extrabold text-xs truncate">{deal.address}</span>
                                <span className="text-[10px] text-zinc-500">{deal.city}</span>
                              </div>
                              <div className="flex items-center space-x-3 text-[10px] text-zinc-400 mt-1">
                                <span>Asking: <strong className="text-zinc-200">${deal.askingPrice.toLocaleString()}</strong></span>
                                <span>ARV: <strong className="text-emerald-400">${deal.underwriting?.arv?.toLocaleString() || '—'}</strong></span>
                                <span>Rehab: <strong className="text-amber-400">${deal.underwriting?.rehabCost?.toLocaleString() || '—'}</strong></span>
                              </div>
                            </div>

                            <div className="flex items-center space-x-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelectDeal(deal.id);
                                  setCurrentStage('underwriting');
                                }}
                                className="px-2.5 py-1 bg-sky-600/20 hover:bg-sky-600 text-sky-400 hover:text-white border border-sky-500/30 rounded-lg text-[10px] font-extrabold transition cursor-pointer flex items-center space-x-1"
                              >
                                <span>Underwrite</span>
                                <ChevronRight className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
                    <span>Selected: <strong className="text-zinc-200">{activeDeal?.address}</strong></span>
                    <button
                      onClick={() => setCurrentStage('underwriting')}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition flex items-center space-x-1 cursor-pointer"
                    >
                      <span>Proceed to Underwriting</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStage === 'underwriting' && (
            /* STAGE 2: DESKTOP UNDERWRITING & COMPS */
            <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-6 shadow-md backdrop-blur-md">
              {activeDeal ? (
                <DealUnderwriter
                  deal={activeDeal}
                  onRunAnalysis={onRunUnderwrite}
                  onUpdateStatus={onUpdateStatus}
                  onUpdateDeal={onUpdateDeal}
                  isAnalyzing={isAnalyzing}
                  activeAgent={activeAgent}
                  onLaunchAutonomousPipeline={() => onLaunchAutonomousPipeline(activeDeal)}
                />
              ) : (
                <div className="py-20 text-center flex flex-col items-center justify-center">
                  <Building className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
                  <h3 className="font-bold text-zinc-300 text-sm">No Property Selected</h3>
                  <p className="text-xs text-zinc-500 mt-1">Please select or scout a deal in Stage 1 to begin underwriting.</p>
                </div>
              )}
            </div>
          )}

          {currentStage === 'cad-studio' && (
            /* STAGE 3: 3D SPATIAL CAD FIX STUDIO */
            <div>
              {activeDeal ? (
                <CADStudioView deal={activeDeal} onUpdateDeal={onUpdateDeal} />
              ) : (
                <div className="py-20 text-center flex flex-col items-center justify-center bg-zinc-900/40 border border-zinc-800/80 rounded-3xl p-6">
                  <Box className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
                  <h3 className="font-bold text-zinc-300 text-sm uppercase tracking-wider">Please Choose a House First!</h3>
                  <p className="text-xs text-zinc-500 mt-1.5 max-w-sm leading-relaxed">
                    Select a house from the top dropdown to explore the interactive 3D CAD model and repair fix protocols!
                  </p>
                </div>
              )}
            </div>
          )}

          {currentStage === 'repair-guide' && (
            /* STAGE 4: NC CODE SOPS & CONTRACTORS */
            <div>
              {activeDeal ? (
                <RepairGuideView
                  deals={deals}
                  activeDeal={activeDeal}
                  onSelectDeal={(deal) => onSelectDeal(deal.id)}
                  onUpdateDeal={onUpdateDeal}
                />
              ) : (
                <div className="py-20 text-center flex flex-col items-center justify-center bg-zinc-900/40 border border-zinc-800/80 rounded-3xl p-6">
                  <Wrench className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
                  <h3 className="font-bold text-zinc-300 text-sm uppercase tracking-wider">Please Choose a House First!</h3>
                  <p className="text-xs text-zinc-500 mt-1.5 max-w-sm leading-relaxed">
                    Select a house to generate code-grounded step-by-step repair guides and match verified local NC contractors!
                  </p>
                </div>
              )}
            </div>
          )}

          {currentStage === 'walkthrough' && (
            /* STAGE 5: ON-SITE WALKTHROUGH & FIELD PUNCHOUT */
            <div>
              {activeDeal ? (
                <PartnersOpsHub deal={activeDeal} onUpdateDeal={async (d) => onUpdateDeal(d)} />
              ) : (
                <div className="py-20 text-center flex flex-col items-center justify-center bg-zinc-900/40 border border-zinc-800/80 rounded-3xl p-6">
                  <Compass className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
                  <h3 className="font-bold text-zinc-300 text-sm uppercase tracking-wider">Please Choose a House First!</h3>
                  <p className="text-xs text-zinc-500 mt-1.5 max-w-sm leading-relaxed">
                    Select a house to access on-site walkthrough checklists, builder specs, and draw schedules!
                  </p>
                </div>
              )}
            </div>
          )}

          {currentStage === 'contracts-draws' && (
            /* STAGE 6: CONTRACTS, DRAWS & ESCROW */
            <div className="space-y-6">
              {activeDeal ? (
                <StageContractsAndDraws deal={activeDeal} onUpdateDeal={onUpdateDeal} />
              ) : (
                <div className="py-20 text-center flex flex-col items-center justify-center bg-zinc-900/40 border border-zinc-800/80 rounded-3xl p-6">
                  <FileText className="h-12 w-12 text-zinc-700 mb-3 animate-pulse" />
                  <h3 className="font-bold text-zinc-300 text-sm uppercase tracking-wider">Please Choose a House First!</h3>
                  <p className="text-xs text-zinc-500 mt-1.5 max-w-sm leading-relaxed">
                    Select a house to generate NC lien waivers, wholesale assignments, proof of funds, and bank draws!
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 5. ACTIVE AGENT STATUS BAR (Footer) */}
      <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-4 backdrop-blur-md">
        <AgentStatusPanel
          activeAgent={activeAgent}
          logs={activeDeal ? activeDeal.logs : []}
        />
      </div>
    </div>
  );
}

/**
 * Stage 6: Legal Contracts, Bank Draws & Escrow Sub-Module
 */
function StageContractsAndDraws({
  deal,
  onUpdateDeal
}: {
  deal: PropertyDeal;
  onUpdateDeal: (deal: PropertyDeal) => void;
}) {
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [docType, setDocType] = useState<'lien_waiver' | 'wholesale_assignment' | 'proof_of_funds'>('lien_waiver');
  const [selectedMilestone, setSelectedMilestone] = useState<any>(null);

  const openDoc = (type: 'lien_waiver' | 'wholesale_assignment' | 'proof_of_funds', milestone?: any) => {
    setDocType(type);
    setSelectedMilestone(milestone || null);
    setIsDocModalOpen(true);
  };

  const handleToggleLienWaiver = (milestoneId: string) => {
    const updatedMilestones = (deal.milestones || []).map((m) => {
      if (m.id === milestoneId) {
        return { ...m, lienWaiverSigned: !m.lienWaiverSigned };
      }
      return m;
    });
    onUpdateDeal({ ...deal, milestones: updatedMilestones });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-zinc-900/60 border border-zinc-800/90 rounded-3xl p-6 shadow-md backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded text-[9px] font-extrabold bg-purple-500/10 text-purple-400 border border-purple-500/20 uppercase tracking-wider">
                Stage 6: Legal & Capital Release
              </span>
              <span className="text-[10px] text-zinc-400 font-bold">North Carolina Escrow & Bank Draws</span>
            </div>
            <h2 className="text-xl font-extrabold text-zinc-100 mt-1">Contracts, Draws & Lien Waivers</h2>
            <p className="text-xs text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Generate statutory NC Wholesale Assignment Contracts, manage NC Interim & Final Lien Waivers (NC G.S. § 44A), and track lender construction draws for <strong>{deal.address}</strong>.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => openDoc('wholesale_assignment')}
              className="px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center space-x-1.5 cursor-pointer"
            >
              <FileText className="h-3.5 w-3.5" />
              <span>NC Wholesale Contract</span>
            </button>
            <button
              onClick={() => openDoc('lien_waiver')}
              className="px-3.5 py-2 bg-zinc-800 hover:bg-zinc-750 text-zinc-200 font-extrabold text-xs rounded-xl border border-zinc-700 transition flex items-center space-x-1.5 cursor-pointer"
            >
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
              <span>Generate NC Lien Waiver</span>
            </button>
            <button
              onClick={() => openDoc('proof_of_funds')}
              className="px-3.5 py-2 bg-zinc-800 hover:bg-zinc-750 text-zinc-200 font-extrabold text-xs rounded-xl border border-zinc-700 transition flex items-center space-x-1.5 cursor-pointer"
            >
              <DollarSign className="h-3.5 w-3.5 text-amber-400" />
              <span>Proof of Funds Letter</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Lender Draws & Milestones */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Rehab Draw Milestones */}
        <div className="lg:col-span-7 bg-zinc-900/60 border border-zinc-800/90 rounded-3xl p-6 shadow-md backdrop-blur-md">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <HardHat className="h-4 w-4 text-amber-400" />
              <h3 className="font-extrabold text-sm text-zinc-100">Lender Construction Draw Milestones</h3>
            </div>
            <span className="text-[10px] text-zinc-500 font-bold">
              Total Budget: ${(deal.underwriting?.rehabCost || 0).toLocaleString()}
            </span>
          </div>

          <div className="space-y-3">
            {(deal.milestones || [
              { id: 'm1', title: 'Phase 1: Demolition & Framing Inspection', cost: 12500, status: 'completed', dueDate: '2026-09-10', lienWaiverSigned: true },
              { id: 'm2', title: 'Phase 2: Rough Mechanical, Electrical & Plumbing (MEP)', cost: 18000, status: 'in_progress', dueDate: '2026-09-25', lienWaiverSigned: false },
              { id: 'm3', title: 'Phase 3: Drywall, Insulation & Subflooring', cost: 9500, status: 'pending', dueDate: '2026-10-10', lienWaiverSigned: false },
              { id: 'm4', title: 'Phase 4: Kitchen Cabinets, Quartz Countertops & Bath Tile', cost: 14000, status: 'pending', dueDate: '2026-10-25', lienWaiverSigned: false },
              { id: 'm5', title: 'Phase 5: Punchout, Final Inspection & Certificate of Occupancy', cost: 6000, status: 'pending', dueDate: '2026-11-05', lienWaiverSigned: false }
            ]).map((milestone) => (
              <div
                key={milestone.id}
                className="p-4 rounded-2xl bg-zinc-950/60 border border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-extrabold text-xs text-zinc-200">{milestone.title}</span>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                      milestone.status === 'completed'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : milestone.status === 'in_progress'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                    }`}>
                      {milestone.status}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-[10px] text-zinc-400 mt-1">
                    <span>Draw Amount: <strong className="text-zinc-200">${milestone.cost.toLocaleString()}</strong></span>
                    <span>Target Date: {milestone.dueDate}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleToggleLienWaiver(milestone.id)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold transition cursor-pointer flex items-center space-x-1 ${
                      milestone.lienWaiverSigned
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/25'
                        : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
                    }`}
                  >
                    <ShieldCheck className="h-3 w-3" />
                    <span>{milestone.lienWaiverSigned ? 'Lien Waiver Signed' : 'Sign Lien Waiver'}</span>
                  </button>

                  <button
                    onClick={() => openDoc('lien_waiver', milestone)}
                    className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-[10px] font-bold transition cursor-pointer"
                  >
                    View Doc
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Legal & NC Compliance Check */}
        <div className="lg:col-span-5 bg-zinc-900/60 border border-zinc-800/90 rounded-3xl p-6 shadow-md backdrop-blur-md flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <h3 className="font-extrabold text-sm text-zinc-100">NC Legal & Closing Checklist</h3>
            </div>

            <div className="space-y-2.5 text-xs">
              {[
                { title: 'NC Real Estate Commission Disclosure Verified', ok: true, note: 'Exempt under NC G.S. § 47E wholesale disclosure' },
                { title: 'NC General Contractors Licensing Verified ($40k+ limit)', ok: true, note: 'Contractor board license active' },
                { title: 'Mechanics Lien Agent (MLA) Designated via LiensNC', ok: true, note: 'Filings logged on liensnc.com' },
                { title: 'Deed Tax & County Transfer Stamps Calculated', ok: true, note: '$2.00 per $1,000 consideration' },
                { title: 'Escrow Title Search & Clear Title Commitment', ok: true, note: 'First American Title / NC bar certified attorney' }
              ].map((item, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-zinc-950/40 border border-zinc-800/80 flex items-start space-x-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-zinc-200">{item.title}</p>
                    <p className="text-[10px] text-zinc-500 mt-0.5">{item.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-zinc-800 text-[10px] text-zinc-500">
            North Carolina closing requires a licensed NC real estate attorney to handle title, settlement statement (ALTA/CD), and deed recording.
          </div>
        </div>
      </div>

      {/* Legal Document Suite Modal */}
      {isDocModalOpen && (
        <LegalDocumentModal
          isOpen={isDocModalOpen}
          onClose={() => setIsDocModalOpen(false)}
          deal={deal}
          defaultDocType={docType}
          contractorName={deal.contractors?.[0]?.name || 'Carolina Pro Builders LLC'}
          drawAmount={selectedMilestone?.cost || 12500}
          milestoneTitle={selectedMilestone?.title || 'Phase 1: Framing & Structural'}
        />
      )}
    </div>
  );
}
