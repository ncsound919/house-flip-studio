/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from 'react';
import { 
  PropertyDeal, 
  HouseCADLayout, 
  FixProtocolNode, 
  CADTradeType, 
  CADRoom 
} from '../types';
import { 
  X, 
  Download, 
  Printer, 
  HardHat, 
  Layers, 
  CheckSquare, 
  QrCode, 
  FileSpreadsheet, 
  FileText, 
  ShieldCheck, 
  Sparkles, 
  ChevronRight, 
  Box, 
  DollarSign, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Compass, 
  Share2, 
  Copy, 
  Check, 
  Eye, 
  Grid,
  Info,
  Wrench,
  Hammer
} from 'lucide-react';

interface ContractorVisualExportModalProps {
  deal: PropertyDeal;
  cadLayout: HouseCADLayout;
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'blueprints' | 'work-orders' | 'stud-badges' | 'bom-schedule' | 'cad-data';
}

interface MaterialBOMItem {
  id: string;
  trade: CADTradeType;
  description: string;
  specGrade: string;
  quantity: number;
  unit: string;
  unitCost: number;
  totalCost: number;
  sku: string;
  vendor: string;
}

export const ContractorVisualExportModal: React.FC<ContractorVisualExportModalProps> = ({
  deal,
  cadLayout,
  isOpen,
  onClose,
  defaultTab = 'blueprints'
}) => {
  const [activeTab, setActiveTab] = useState<'blueprints' | 'work-orders' | 'stud-badges' | 'bom-schedule' | 'cad-data'>(defaultTab);
  const [selectedTrade, setSelectedTrade] = useState<CADTradeType | 'ALL'>('ALL');
  const [blueprintTradeFilter, setBlueprintTradeFilter] = useState<CADTradeType | 'ALL'>('ALL');
  const [blueprintLayer, setBlueprintLayer] = useState<'all' | 'foundation' | 'level1' | 'level2' | 'roof'>('level1');
  const [showDimensions, setShowDimensions] = useState(true);
  const [showBeacons, setShowBeacons] = useState(true);
  const [showMEPPaths, setShowMEPPaths] = useState(true);
  const [copiedStatus, setCopiedStatus] = useState<string | null>(null);

  const blueprintRef = useRef<HTMLDivElement>(null);

  // Derive distinct trades in the CAD layout
  const availableTrades = useMemo(() => {
    const trades = new Set<CADTradeType>();
    cadLayout.fixProtocols.forEach(p => trades.add(p.trade));
    return Array.from(trades);
  }, [cadLayout.fixProtocols]);

  // Generate comprehensive Bill of Materials (BOM) Takeoff from Fix Protocols
  const masterBOM: MaterialBOMItem[] = useMemo(() => {
    const items: MaterialBOMItem[] = [];

    cadLayout.fixProtocols.forEach((protocol, idx) => {
      const trade = protocol.trade;
      const baseCost = protocol.materialCost || Math.round(protocol.estimatedCost * 0.45);

      if (trade === 'MEP - Electrical') {
        items.push({
          id: `bom-${protocol.id}-1`,
          trade,
          description: '200A 30-Space Main Breaker Indoor Load Center',
          specGrade: 'NEMA 1 / Copper Bus / UL Listed',
          quantity: 1,
          unit: 'EA',
          unitCost: 285,
          totalCost: 285,
          sku: 'HOM3060M200PC',
          vendor: 'Lowe’s Pro / Home Depot Pro'
        });
        items.push({
          id: `bom-${protocol.id}-2`,
          trade,
          description: 'Dual-Function AFCI/GFCI 20-Amp 1-Pole Breakers',
          specGrade: '10kA Interrupt / Class A GFCI',
          quantity: 8,
          unit: 'EA',
          unitCost: 58,
          totalCost: 464,
          sku: 'HOM120DFI',
          vendor: 'Lowe’s Pro'
        });
        items.push({
          id: `bom-${protocol.id}-3`,
          trade,
          description: '12/2 NM-B Romex Non-Metallic Sheathed Copper Cable',
          specGrade: '250 ft Reel / 600V / Solid CU',
          quantity: 2,
          unit: 'ROLL',
          unitCost: 145,
          totalCost: 290,
          sku: 'ROMEX-122-250',
          vendor: 'Home Depot Pro'
        });
      } else if (trade === 'Structural Framing') {
        items.push({
          id: `bom-${protocol.id}-1`,
          trade,
          description: '2x10 x 16 ft #2 Southern Yellow Pine (SYP) Joists',
          specGrade: 'Structural Select / Kiln-Dried #2',
          quantity: 14,
          unit: 'PCS',
          unitCost: 32,
          totalCost: 448,
          sku: '21016SYP',
          vendor: '84 Lumber / Lowe’s Pro'
        });
        items.push({
          id: `bom-${protocol.id}-2`,
          trade,
          description: 'Simpson Strong-Tie LUS210 Joist Hangers (ZMAX Galvanized)',
          specGrade: 'Double-shear 18ga Galvanized',
          quantity: 28,
          unit: 'EA',
          unitCost: 2.85,
          totalCost: 79.8,
          sku: 'LUS210-Z',
          vendor: 'Home Depot Pro'
        });
        items.push({
          id: `bom-${protocol.id}-3`,
          trade,
          description: '3/4" x 4x8 T&G OSB Subfloor Sheathing Panels (Sturd-I-Floor)',
          specGrade: 'APA Rated / Exposure 1 Sealed Edge',
          quantity: 12,
          unit: 'SHT',
          unitCost: 38.5,
          totalCost: 462,
          sku: 'OSB-34-TG',
          vendor: 'Lowe’s Pro'
        });
        items.push({
          id: `bom-${protocol.id}-4`,
          trade,
          description: '10d Structural Ring-Shank HDG Framing Nails (3" x 0.148")',
          specGrade: 'ASTM F1667 Code Compliant',
          quantity: 2,
          unit: 'BOX',
          unitCost: 65,
          totalCost: 130,
          sku: 'NAIL-10D-HDG',
          vendor: 'Fastenal / Lowe’s'
        });
      } else if (trade === 'Foundation & Crawlspace') {
        items.push({
          id: `bom-${protocol.id}-1`,
          trade,
          description: '12-Mil Reinforced Polyethylene Vapor Retarder (VaporBarrier)',
          specGrade: 'ASTM E1745 Class A / 1,200 sqft Roll',
          quantity: 2,
          unit: 'ROLL',
          unitCost: 310,
          totalCost: 620,
          sku: 'CRAWL-12MIL-1200',
          vendor: 'Crawlspace Depot / Home Depot'
        });
        items.push({
          id: `bom-${protocol.id}-2`,
          trade,
          description: 'Energy Star 70-Pint Crawlspace Commercial Dehumidifier with Condensate Pump',
          specGrade: 'AHAM Rated / Built-in Digital Humidistat',
          quantity: 1,
          unit: 'EA',
          unitCost: 980,
          totalCost: 980,
          sku: 'DEHUM-70P-PUMP',
          vendor: 'SupplyHouse / Lowe’s Pro'
        });
        items.push({
          id: `bom-${protocol.id}-3`,
          trade,
          description: '4" Waterproof Seam Sealing Tape (White Polyken)',
          specGrade: 'Double-thick Butyl Synthetic',
          quantity: 4,
          unit: 'ROLL',
          unitCost: 34,
          totalCost: 136,
          sku: 'TAPE-CRAWL-4IN',
          vendor: 'Home Depot Pro'
        });
      } else if (trade === 'MEP - Plumbing') {
        items.push({
          id: `bom-${protocol.id}-1`,
          trade,
          description: '3/4" x 100 ft PEX-A Barrier Tubing (Red/Blue Bundles)',
          specGrade: 'ASTM F876/F877 Expansion Spec',
          quantity: 2,
          unit: 'COIL',
          unitCost: 95,
          totalCost: 190,
          sku: 'PEXA-34-100',
          vendor: 'Ferguson / Lowe’s Pro'
        });
        items.push({
          id: `bom-${protocol.id}-2`,
          trade,
          description: '3" Schedule 40 Solid Core PVC DWV Pipe (10 ft lengths)',
          specGrade: 'ASTM D2665 Drain Waste Vent',
          quantity: 6,
          unit: 'LGT',
          unitCost: 28,
          totalCost: 168,
          sku: 'PVC-DWV-3IN',
          vendor: 'Lowe’s Pro'
        });
        items.push({
          id: `bom-${protocol.id}-3`,
          trade,
          description: 'Uponor ProPEX Lead-Free Brass Manifold System',
          specGrade: 'Multi-Port Flow-Through 3/4" Inlet',
          quantity: 2,
          unit: 'EA',
          unitCost: 145,
          totalCost: 290,
          sku: 'MANIFOLD-PEX-LF',
          vendor: 'SupplyHouse'
        });
      } else if (trade === 'Roofing & Attic') {
        items.push({
          id: `bom-${protocol.id}-1`,
          trade,
          description: 'Architectural High-Wind 130MPH Lifetime Shingles (33.3 sqft/bdl)',
          specGrade: 'Class A Fire / ASTM D3462',
          quantity: 36,
          unit: 'BDL',
          unitCost: 42,
          totalCost: 1512,
          sku: 'SHINGLE-ARCH-30',
          vendor: 'ABC Supply / Home Depot Pro'
        });
        items.push({
          id: `bom-${protocol.id}-2`,
          trade,
          description: 'Synthetic High-Traction Roof Underlayment (1000 sqft roll)',
          specGrade: 'ASTM D226 Type II Compliant',
          quantity: 2,
          unit: 'ROLL',
          unitCost: 88,
          totalCost: 176,
          sku: 'SYNTH-ROOF-1000',
          vendor: 'Lowe’s Pro'
        });
        items.push({
          id: `bom-${protocol.id}-3`,
          trade,
          description: 'Aluminum Drip Edge & Starter Shingle Strip Bundles',
          specGrade: 'F5 Aluminum 10ft / White Finish',
          quantity: 14,
          unit: 'PCS',
          unitCost: 14.5,
          totalCost: 203,
          sku: 'DRIP-EDGE-AL-10',
          vendor: 'ABC Supply'
        });
      } else {
        items.push({
          id: `bom-${protocol.id}-gen`,
          trade,
          description: `${protocol.title} Code-Approved Materials Package`,
          specGrade: 'NC 2024 Residential Code Spec',
          quantity: 1,
          unit: 'LOT',
          unitCost: baseCost,
          totalCost: baseCost,
          sku: `NC-LOT-${trade.slice(0, 3).toUpperCase()}`,
          vendor: 'Lowe’s Pro Contractor Desk'
        });
      }
    });

    return items;
  }, [cadLayout.fixProtocols]);

  // Aggregate totals
  const totalBOMCost = useMemo(() => {
    return masterBOM.reduce((sum, item) => sum + item.totalCost, 0);
  }, [masterBOM]);

  const totalLaborHours = useMemo(() => {
    return cadLayout.fixProtocols.reduce((sum, p) => sum + (p.laborHours || 0), 0);
  }, [cadLayout.fixProtocols]);

  const filteredProtocolsByTrade = useMemo(() => {
    if (selectedTrade === 'ALL') return cadLayout.fixProtocols;
    return cadLayout.fixProtocols.filter(p => p.trade === selectedTrade);
  }, [cadLayout.fixProtocols, selectedTrade]);

  // Export CSV Handler
  const handleExportBOMCSV = () => {
    const headers = ['Trade', 'Item Description', 'Specification Grade', 'Quantity', 'Unit', 'Unit Cost ($)', 'Total Cost ($)', 'SKU Reference', 'Preferred Supplier'];
    const rows = masterBOM.map(item => [
      `"${item.trade}"`,
      `"${item.description}"`,
      `"${item.specGrade}"`,
      item.quantity,
      `"${item.unit}"`,
      item.unitCost.toFixed(2),
      item.totalCost.toFixed(2),
      `"${item.sku}"`,
      `"${item.vendor}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Rehab_BOM_Takeoff_${deal.address.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Copy JSON Data Handler
  const handleCopyCADData = () => {
    const exportPayload = {
      project: {
        address: deal.address,
        city: deal.city,
        state: 'NC',
        parcelId: deal.taxParcelId || 'NC-GIS-P4901',
        exportDate: new Date().toISOString(),
        buildingCodeVersion: '2024 North Carolina Residential Code (NCRC)'
      },
      cadLayout: {
        style: cadLayout.styleName,
        totalSqft: cadLayout.totalSqft,
        foundationType: cadLayout.foundationType,
        roofType: cadLayout.roofType,
        lotDimensions: { width: cadLayout.lotWidth || 70, depth: cadLayout.lotDepth || 140 },
        rooms: cadLayout.rooms,
        fixProtocols: cadLayout.fixProtocols
      },
      materialsBOM: masterBOM
    };

    navigator.clipboard.writeText(JSON.stringify(exportPayload, null, 2));
    setCopiedStatus('cad-json');
    setTimeout(() => setCopiedStatus(null), 2500);
  };

  // Quick Print Action
  const handleTriggerPrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        
        {/* Header Ribbon */}
        <div className="p-5 border-b border-zinc-800 bg-zinc-900/90 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-3.5">
            <div className="p-3 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-2xl">
              <HardHat className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base sm:text-lg font-black text-zinc-100 uppercase tracking-tight">
                  Contractor Visual Export & Plan Studio
                </h2>
                <span className="text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  NCRC 2024 Verified
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Printable visual blueprints, trade work order packets, job-site QR stud badges, and material BOM takeoffs for <strong>{deal.address}, {deal.city} NC</strong>.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleTriggerPrint}
              className="flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold rounded-xl shadow-lg transition cursor-pointer"
              title="Print current sheet"
            >
              <Printer className="h-4 w-4" />
              <span>Print Sheet</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 p-3 bg-zinc-900/50 border-b border-zinc-800/80 px-5 overflow-x-auto">
          <button
            onClick={() => setActiveTab('blueprints')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer whitespace-nowrap ${
              activeTab === 'blueprints'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <Layers className="h-4 w-4" />
            <span>2D Blueprint & Dimension Plan</span>
          </button>

          <button
            onClick={() => setActiveTab('work-orders')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer whitespace-nowrap ${
              activeTab === 'work-orders'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <FileText className="h-4 w-4" />
            <span>Trade Scope Packets ({availableTrades.length} Trades)</span>
          </button>

          <button
            onClick={() => setActiveTab('stud-badges')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer whitespace-nowrap ${
              activeTab === 'stud-badges'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <QrCode className="h-4 w-4" />
            <span>On-Site QR Stud Badges</span>
          </button>

          <button
            onClick={() => setActiveTab('bom-schedule')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer whitespace-nowrap ${
              activeTab === 'bom-schedule'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <FileSpreadsheet className="h-4 w-4" />
            <span>Materials Takeoff (BOM)</span>
          </button>

          <button
            onClick={() => setActiveTab('cad-data')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer whitespace-nowrap ${
              activeTab === 'cad-data'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <Box className="h-4 w-4" />
            <span>CAD JSON / DXF Exchange</span>
          </button>
        </div>

        {/* Tab Body Area */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">

          {/* ========================================================================= */}
          {/* TAB 1: 2D ARCHITECTURAL BLUEPRINT & DIMENSION SCHEMATIC                   */}
          {/* ========================================================================= */}
          {activeTab === 'blueprints' && (
            <div className="space-y-4">
              {/* Blueprint Ribbon Controls */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-zinc-900/60 border border-zinc-800 p-3 rounded-2xl">
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500">Floor Level:</span>
                  <div className="flex bg-zinc-950 p-1 rounded-xl border border-zinc-800">
                    <button
                      onClick={() => setBlueprintLayer('foundation')}
                      className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition cursor-pointer ${
                        blueprintLayer === 'foundation' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      Crawlspace / Foundation
                    </button>
                    <button
                      onClick={() => setBlueprintLayer('level1')}
                      className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition cursor-pointer ${
                        blueprintLayer === 'level1' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      Level 1 Main Plan
                    </button>
                    {cadLayout.rooms.some(r => r.floorLevel === 2) && (
                      <button
                        onClick={() => setBlueprintLayer('level2')}
                        className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition cursor-pointer ${
                          blueprintLayer === 'level2' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        Level 2 Story
                      </button>
                    )}
                    <button
                      onClick={() => setBlueprintLayer('roof')}
                      className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition cursor-pointer ${
                        blueprintLayer === 'roof' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      Roof Framing & Trusses
                    </button>
                  </div>
                </div>

                {/* Overlays Toggle */}
                <div className="flex items-center space-x-3 text-xs font-bold text-zinc-300">
                  <label className="flex items-center space-x-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showDimensions}
                      onChange={(e) => setShowDimensions(e.target.checked)}
                      className="rounded bg-zinc-900 border-zinc-700 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-[11px]">Dimensions (Feet)</span>
                  </label>

                  <label className="flex items-center space-x-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showBeacons}
                      onChange={(e) => setShowBeacons(e.target.checked)}
                      className="rounded bg-zinc-900 border-zinc-700 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-[11px]">Defect Callout Pins</span>
                  </label>

                  <label className="flex items-center space-x-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showMEPPaths}
                      onChange={(e) => setShowMEPPaths(e.target.checked)}
                      className="rounded bg-zinc-900 border-zinc-700 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-[11px]">MEP Utility Conduits</span>
                  </label>
                </div>
              </div>

              {/* Blueprint Sheet Canvas (Print-styled architectural drawing) */}
              <div 
                ref={blueprintRef}
                className="bg-[#0b192c] border-2 border-[#1e3a8a] rounded-2xl p-6 shadow-2xl relative text-white font-mono overflow-hidden"
              >
                {/* Architectural Blueprint Grid Pattern Overlay */}
                <div 
                  className="absolute inset-0 opacity-20 pointer-events-none" 
                  style={{
                    backgroundImage: 'linear-gradient(to right, #38bdf8 1px, transparent 1px), linear-gradient(to bottom, #38bdf8 1px, transparent 1px)',
                    backgroundSize: '24px 24px'
                  }}
                />

                {/* Blueprint Title Block (Architectural Standard Title Block) */}
                <div className="relative z-10 border-b-2 border-sky-500/40 pb-4 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center space-x-2 text-sky-400">
                      <Compass className="h-4 w-4 animate-spin-slow" />
                      <span className="text-[10px] font-black uppercase tracking-widest">
                        ARCHITECTURAL SCHEMATIC DRAWING • SHEET A-101
                      </span>
                    </div>
                    <h3 className="text-base font-black text-sky-100 tracking-wider">
                      {deal.address}, {deal.city}, NC
                    </h3>
                    <p className="text-[10px] text-sky-300">
                      STYLE: {cadLayout.styleName.toUpperCase()} • TOTAL HEATED SQFT: {cadLayout.totalSqft} • FOUNDATION: {cadLayout.foundationType.toUpperCase()}
                    </p>
                  </div>

                  <div className="bg-sky-950/80 border border-sky-400/50 p-2.5 rounded-xl text-right text-[10px] space-y-0.5">
                    <div><strong className="text-sky-300">SCALE:</strong> 1/4" = 1'-0" (NOT TO RESCALE)</div>
                    <div><strong className="text-sky-300">CODE:</strong> NCRC 2024 / IRC COMPLIANT</div>
                    <div><strong className="text-sky-300">STAMP:</strong> CAROLINA FLIP OS VERIFIED</div>
                  </div>
                </div>

                {/* 2D Vector Floorplan SVG Rendering */}
                <div className="relative z-10 w-full overflow-x-auto flex justify-center py-4">
                  <svg 
                    viewBox="-35 -30 70 60" 
                    className="w-full max-w-3xl h-[420px] bg-[#071322]/90 border border-sky-800/60 rounded-xl shadow-inner select-none"
                  >
                    {/* Background Grid Lines */}
                    <defs>
                      <pattern id="cadGrid" width="5" height="5" patternUnits="userSpaceOnUse">
                        <path d="M 5 0 L 0 0 0 5" fill="none" stroke="#1e3a8a" strokeWidth="0.1" />
                      </pattern>
                      <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse">
                        <path d="M 0 0 L 10 5 L 0 10 z" fill="#38bdf8" />
                      </marker>
                    </defs>

                    <rect x="-35" y="-30" width="70" height="60" fill="url(#cadGrid)" />

                    {/* North Arrow */}
                    <g transform="translate(28, -22)">
                      <circle cx="0" cy="0" r="4" fill="#0c2340" stroke="#38bdf8" strokeWidth="0.3" />
                      <path d="M 0 -3 L 2 2 L 0 0 L -2 2 Z" fill="#38bdf8" />
                      <text x="0" y="3.5" fontSize="1.8" fill="#38bdf8" textAnchor="middle" fontWeight="bold">N</text>
                    </g>

                    {/* Exterior Foundation / Building Outline */}
                    <rect 
                      x={-cadLayout.lotWidth / 4} 
                      y={-cadLayout.lotDepth / 6} 
                      width={cadLayout.lotWidth / 2} 
                      height={cadLayout.lotDepth / 3} 
                      fill="none" 
                      stroke="#0284c7" 
                      strokeWidth="0.25" 
                      strokeDasharray="1,1" 
                    />

                    {/* Render Rooms for Selected Layer */}
                    {cadLayout.rooms
                      .filter(room => {
                        if (blueprintLayer === 'foundation') return room.floorLevel === 0;
                        if (blueprintLayer === 'level1') return room.floorLevel === 1;
                        if (blueprintLayer === 'level2') return room.floorLevel === 2;
                        if (blueprintLayer === 'roof') return room.floorLevel === 3 || room.zoneType === 'roof';
                        return true;
                      })
                      .map((room) => {
                        const rx = room.x;
                        const rz = room.z;
                        const rw = room.width;
                        const rl = room.length;
                        const halfW = rw / 2;
                        const halfL = rl / 2;

                        let roomFill = '#0f2744';
                        if (room.zoneType === 'kitchen') roomFill = '#133554';
                        if (room.zoneType === 'bath') roomFill = '#16425b';
                        if (room.zoneType === 'crawlspace') roomFill = '#081726';

                        return (
                          <g key={room.id} className="cursor-pointer group">
                            {/* Room Slab */}
                            <rect
                              x={rx - halfW}
                              y={rz - halfL}
                              width={rw}
                              height={rl}
                              fill={roomFill}
                              stroke="#38bdf8"
                              strokeWidth="0.4"
                              rx="0.3"
                            />

                            {/* Interior Wall Hatching Lines */}
                            <line 
                              x1={rx - halfW} 
                              y1={rz - halfL} 
                              x2={rx + halfW} 
                              y2={rz - halfL} 
                              stroke="#7dd3fc" 
                              strokeWidth="0.6" 
                            />
                            <line 
                              x1={rx - halfW} 
                              y1={rz + halfL} 
                              x2={rx + halfW} 
                              y2={rz + halfL} 
                              stroke="#7dd3fc" 
                              strokeWidth="0.6" 
                            />
                            <line 
                              x1={rx - halfW} 
                              y1={rz - halfL} 
                              x2={rx - halfW} 
                              y2={rz + halfL} 
                              stroke="#7dd3fc" 
                              strokeWidth="0.6" 
                            />
                            <line 
                              x1={rx + halfW} 
                              y1={rz - halfL} 
                              x2={rx + halfW} 
                              y2={rz + halfL} 
                              stroke="#7dd3fc" 
                              strokeWidth="0.6" 
                            />

                            {/* Room Label & Area */}
                            <text
                              x={rx}
                              y={rz - 0.5}
                              fontSize="1.6"
                              fill="#f0f9ff"
                              textAnchor="middle"
                              fontWeight="bold"
                            >
                              {room.name.toUpperCase()}
                            </text>
                            <text
                              x={rx}
                              y={rz + 1.6}
                              fontSize="1.1"
                              fill="#93c5fd"
                              textAnchor="middle"
                            >
                              {Math.round(rw * rl)} SQFT ({rw}' × {rl}')
                            </text>

                            {/* Dimension Callout Lines if enabled */}
                            {showDimensions && (
                              <g opacity="0.8">
                                {/* Width Dimension at Top */}
                                <line 
                                  x1={rx - halfW} 
                                  y1={rz - halfL - 1.2} 
                                  x2={rx + halfW} 
                                  y2={rz - halfL - 1.2} 
                                  stroke="#38bdf8" 
                                  strokeWidth="0.15" 
                                />
                                <text 
                                  x={rx} 
                                  y={rz - halfL - 1.6} 
                                  fontSize="1" 
                                  fill="#38bdf8" 
                                  textAnchor="middle"
                                >
                                  {rw}' - 0"
                                </text>

                                {/* Length Dimension at Side */}
                                <line 
                                  x1={rx + halfW + 1.2} 
                                  y1={rz - halfL} 
                                  x2={rx + halfW + 1.2} 
                                  y2={rz + halfL} 
                                  stroke="#38bdf8" 
                                  strokeWidth="0.15" 
                                />
                                <text 
                                  x={rx + halfW + 2.5} 
                                  y={rz + 0.4} 
                                  fontSize="1" 
                                  fill="#38bdf8" 
                                  textAnchor="middle"
                                >
                                  {rl}' - 0"
                                </text>
                              </g>
                            )}
                          </g>
                        );
                      })}

                    {/* MEP Path Overlays if enabled */}
                    {showMEPPaths && (
                      <g opacity="0.85">
                        {/* Electrical Main Home-Run Line (Yellow) */}
                        <path 
                          d="M -12 -8 L -12 6 L 8 6 L 8 -4" 
                          fill="none" 
                          stroke="#eab308" 
                          strokeWidth="0.35" 
                          strokeDasharray="1, 0.5" 
                        />
                        <text x="-12" y="-9" fontSize="0.9" fill="#facc15" fontWeight="bold">200A SERVICE FEED</text>

                        {/* Plumbing Main Supply Line (Cyan) */}
                        <path 
                          d="M 6 -12 L 6 10 L -6 10" 
                          fill="none" 
                          stroke="#06b6d4" 
                          strokeWidth="0.35" 
                        />
                        <text x="6" y="-12.8" fontSize="0.9" fill="#22d3ee" fontWeight="bold">3/4" PEX-A MAIN</text>

                        {/* HVAC Trunk Duct (Magenta) */}
                        <path 
                          d="M 0 -10 L 0 10" 
                          fill="none" 
                          stroke="#ec4899" 
                          strokeWidth="0.7" 
                          strokeDasharray="2, 1" 
                        />
                        <text x="1.5" y="0" fontSize="0.9" fill="#f472b6" fontWeight="bold">R-8 DUCT TRUNK</text>
                      </g>
                    )}

                    {/* Defect Fix Protocol Beacons on 2D Plan */}
                    {showBeacons && cadLayout.fixProtocols.map((protocol, idx) => {
                      const px = protocol.position.x;
                      const pz = protocol.position.z;
                      const isCrit = protocol.severity === 'critical';

                      return (
                        <g key={protocol.id} transform={`translate(${px}, ${pz})`} className="cursor-pointer">
                          <circle 
                            cx="0" 
                            cy="0" 
                            r="1.8" 
                            fill={isCrit ? '#ef4444' : '#f59e0b'} 
                            stroke="#ffffff" 
                            strokeWidth="0.3" 
                            className="animate-pulse"
                          />
                          <text 
                            x="0" 
                            y="0.6" 
                            fontSize="1.1" 
                            fill="#ffffff" 
                            textAnchor="middle" 
                            fontWeight="900"
                          >
                            #{idx + 1}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>

                {/* Blueprint Callout Index Table */}
                <div className="mt-4 pt-4 border-t-2 border-sky-500/40 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-[10px]">
                  {cadLayout.fixProtocols.map((protocol, idx) => (
                    <div key={protocol.id} className="p-2 bg-sky-950/60 border border-sky-800/60 rounded-lg flex items-start space-x-2">
                      <span className={`px-1.5 py-0.5 rounded font-black text-[9px] ${
                        protocol.severity === 'critical' ? 'bg-red-500 text-white' : 'bg-amber-500 text-black'
                      }`}>
                        #{idx + 1}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sky-100 truncate">{protocol.title}</div>
                        <div className="text-sky-300 text-[9px] truncate">{protocol.ncCodeReference}</div>
                        <div className="text-sky-400 font-mono mt-0.5 font-bold">${protocol.estimatedCost.toLocaleString()} • {protocol.trade}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 2: TRADE-BY-TRADE SUBCONTRACTOR WORK ORDER PACKETS                    */}
          {/* ========================================================================= */}
          {activeTab === 'work-orders' && (
            <div className="space-y-5">
              {/* Trade Selector Pills */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setSelectedTrade('ALL')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                    selectedTrade === 'ALL'
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  All Trades ({cadLayout.fixProtocols.length} Scopes)
                </button>
                {availableTrades.map(trade => (
                  <button
                    key={trade}
                    onClick={() => setSelectedTrade(trade)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                      selectedTrade === trade
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {trade}
                  </button>
                ))}
              </div>

              {/* Work Order Cards */}
              <div className="space-y-6">
                {filteredProtocolsByTrade.map((protocol, idx) => {
                  const targetRoom = cadLayout.rooms.find(r => r.id === protocol.targetRoomId);

                  return (
                    <div 
                      key={protocol.id} 
                      className="bg-zinc-900/80 border-2 border-zinc-800 rounded-2xl p-5 sm:p-6 space-y-4 shadow-xl print:border-black print:text-black print:bg-white"
                    >
                      {/* Work Order Header */}
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-zinc-800 pb-4">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg text-xs font-extrabold">
                              WORK ORDER #{idx + 101}
                            </span>
                            <span className="text-xs text-zinc-400 font-mono">
                              ZONE: {targetRoom?.name.toUpperCase() || 'GENERAL FACILITY'}
                            </span>
                          </div>
                          <h3 className="text-base font-black text-zinc-100 mt-1.5">
                            {protocol.title}
                          </h3>
                        </div>

                        <div className="text-right">
                          <span className="text-lg font-black text-emerald-400 font-mono">
                            ${protocol.estimatedCost.toLocaleString()}
                          </span>
                          <p className="text-[10px] text-zinc-500 font-mono">
                            {protocol.laborHours} Est. Labor Hours
                          </p>
                        </div>
                      </div>

                      {/* Code Compliance Reference Banner */}
                      <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-850 flex items-center justify-between text-xs">
                        <div className="flex items-center space-x-2">
                          <ShieldCheck className="h-4 w-4 text-emerald-400" />
                          <span className="font-bold text-zinc-200">
                            NC Code Compliance Standard:
                          </span>
                          <span className="text-zinc-400 font-mono text-[11px]">
                            {protocol.ncCodeReference}
                          </span>
                        </div>
                        <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-400 text-[10px] font-bold">
                          Trade: {protocol.trade}
                        </span>
                      </div>

                      {/* Tooling & Safety PPE Badges */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="p-3 bg-zinc-950/60 rounded-xl border border-zinc-850">
                          <span className="text-[10px] font-extrabold uppercase text-amber-400 flex items-center space-x-1">
                            <AlertTriangle className="h-3.5 w-3.5" />
                            <span>Mandatory Safety PPE:</span>
                          </span>
                          <div className="flex flex-wrap gap-1.5 mt-1.5">
                            {protocol.safetyPPE?.map((ppe, i) => (
                              <span key={i} className="px-2 py-0.5 bg-amber-500/10 text-amber-300 rounded text-[10px] font-semibold border border-amber-500/20">
                                {ppe}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="p-3 bg-zinc-950/60 rounded-xl border border-zinc-850">
                          <span className="text-[10px] font-extrabold uppercase text-sky-400 flex items-center space-x-1">
                            <Wrench className="h-3.5 w-3.5" />
                            <span>Required Tools & Gear:</span>
                          </span>
                          <div className="flex flex-wrap gap-1.5 mt-1.5">
                            {protocol.requiredTools?.map((tool, i) => (
                              <span key={i} className="px-2 py-0.5 bg-sky-500/10 text-sky-300 rounded text-[10px] font-semibold border border-sky-500/20">
                                {tool}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Step by Step Execution SOP */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-extrabold uppercase tracking-wider text-zinc-400">
                          Step-by-Step Trade SOP & Quality Checkpoints:
                        </h4>
                        <div className="space-y-2">
                          {protocol.executionSteps.map(step => (
                            <div 
                              key={step.stepNumber} 
                              className="p-3 bg-zinc-950 rounded-xl border border-zinc-850 space-y-1.5"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-zinc-200">
                                  Step {step.stepNumber}: {step.title}
                                </span>
                                {step.inspectionGate && (
                                  <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded text-[9px] font-black uppercase">
                                    NC Inspection Hold Gate
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-zinc-400 leading-relaxed">
                                {step.detail}
                              </p>
                              {step.qualityCheckSOP && (
                                <div className="text-[10px] font-mono text-emerald-400 bg-emerald-950/30 px-2 py-1 rounded border border-emerald-500/20 flex items-center space-x-1.5">
                                  <CheckCircle2 className="h-3 w-3 flex-shrink-0" />
                                  <span>QA Test: {step.qualityCheckSOP}</span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Contractor & Inspector Sign-Off Block */}
                      <div className="pt-4 border-t border-zinc-800 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                        <div className="p-3 bg-zinc-950/40 rounded-xl border border-dashed border-zinc-800 space-y-2">
                          <div className="text-[10px] uppercase font-bold text-zinc-500">Subcontractor Sign-Off:</div>
                          <div className="h-8 border-b border-zinc-700"></div>
                          <div className="flex justify-between text-[9px] text-zinc-400">
                            <span>Licensed Trade Signature</span>
                            <span>Date: ___/___/2026</span>
                          </div>
                        </div>

                        <div className="p-3 bg-zinc-950/40 rounded-xl border border-dashed border-zinc-800 space-y-2">
                          <div className="text-[10px] uppercase font-bold text-zinc-500">NC County Building Inspector:</div>
                          <div className="h-8 border-b border-zinc-700"></div>
                          <div className="flex justify-between text-[9px] text-zinc-400">
                            <span>County Permit Green Tag #</span>
                            <span>Sign: __________________</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 3: ON-SITE QR STUD BADGES & ROOM PUNCHOUT CARDS                      */}
          {/* ========================================================================= */}
          {activeTab === 'stud-badges' && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <QrCode className="h-6 w-6 text-emerald-400" />
                  <div>
                    <h4 className="text-xs font-bold text-emerald-300">
                      Printable 4x6 Job-Site Framing Stud Cards
                    </h4>
                    <p className="text-[11px] text-zinc-400">
                      Staple these weatherproof cards directly to the 2x4 framing studs in each room so trades and inspectors can scan for instant CAD specs and checklists.
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleTriggerPrint}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  Print Badges
                </button>
              </div>

              {/* Grid of Stud Badges */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cadLayout.rooms.map((room) => {
                  const roomFixes = cadLayout.fixProtocols.filter(p => p.targetRoomId === room.id);
                  const roomBudget = roomFixes.reduce((s, f) => s + f.estimatedCost, 0);

                  return (
                    <div 
                      key={room.id}
                      className="bg-zinc-950 border-2 border-zinc-700 rounded-2xl p-5 space-y-4 shadow-xl relative overflow-hidden print:border-black print:text-black"
                    >
                      {/* Top Warning Stripe */}
                      <div className="h-2 bg-gradient-to-r from-amber-500 via-emerald-500 to-sky-500 -mt-5 -mx-5 mb-3" />

                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-400">
                            JOB-SITE STUDBOARD CARD • LEVEL {room.floorLevel}
                          </span>
                          <h3 className="text-base font-black text-zinc-100 uppercase tracking-tight">
                            {room.name}
                          </h3>
                          <p className="text-[10px] text-zinc-400 font-mono">
                            {deal.address} • {Math.round(room.width * room.length)} SQFT ({room.width}' × {room.length}')
                          </p>
                        </div>

                        {/* Simulated QR Code Canvas */}
                        <div className="p-2 bg-white rounded-xl shadow-md flex flex-col items-center">
                          <div className="w-14 h-14 bg-zinc-950 p-1 flex items-center justify-center rounded">
                            <QrCode className="h-12 w-12 text-white" />
                          </div>
                          <span className="text-[8px] font-mono text-zinc-900 font-black mt-1">SCAN SOP</span>
                        </div>
                      </div>

                      {/* Designated Trade Scopes */}
                      <div className="space-y-1.5">
                        <span className="text-[10px] font-extrabold uppercase text-zinc-400 tracking-wider">
                          Assigned Scopes in this Zone:
                        </span>
                        {roomFixes.length > 0 ? (
                          <div className="space-y-1">
                            {roomFixes.map(fix => (
                              <div key={fix.id} className="p-2 bg-zinc-900 rounded-lg border border-zinc-800 flex items-center justify-between text-[11px]">
                                <span className="font-bold text-zinc-200">{fix.title}</span>
                                <span className="font-mono text-emerald-400 font-bold">${fix.estimatedCost.toLocaleString()}</span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="p-2 bg-zinc-900/50 rounded-lg text-zinc-500 text-[10px] italic">
                            Standard paint & trim finish scope only.
                          </div>
                        )}
                      </div>

                      {/* Field Punchout Checklist */}
                      <div className="p-3 bg-zinc-900 rounded-xl border border-zinc-800 space-y-1.5 text-[10px] font-mono">
                        <div className="font-bold text-zinc-300 uppercase">Field Quality Verification:</div>
                        <div className="flex items-center space-x-2 text-zinc-400">
                          <div className="w-3.5 h-3.5 border border-zinc-600 rounded"></div>
                          <span>Rough Framing / Blocking plumb and level</span>
                        </div>
                        <div className="flex items-center space-x-2 text-zinc-400">
                          <div className="w-3.5 h-3.5 border border-zinc-600 rounded"></div>
                          <span>MEP rough-in nail plates installed</span>
                        </div>
                        <div className="flex items-center space-x-2 text-zinc-400">
                          <div className="w-3.5 h-3.5 border border-zinc-600 rounded"></div>
                          <span>Passes NC County Inspection Gate</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 4: MATERIALS TAKEOFF SCHEDULE (BOM)                                   */}
          {/* ========================================================================= */}
          {activeTab === 'bom-schedule' && (
            <div className="space-y-5">
              {/* Aggregate BOM Metric Ribbon */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl">
                  <span className="text-[10px] font-extrabold uppercase text-zinc-500 flex items-center space-x-1.5">
                    <DollarSign className="h-4 w-4 text-emerald-400" />
                    <span>Estimated Materials Cost</span>
                  </span>
                  <p className="text-xl font-black text-emerald-400 mt-1">
                    ${totalBOMCost.toLocaleString()}
                  </p>
                </div>

                <div className="bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl">
                  <span className="text-[10px] font-extrabold uppercase text-zinc-500 flex items-center space-x-1.5">
                    <Layers className="h-4 w-4 text-sky-400" />
                    <span>Total Line Items</span>
                  </span>
                  <p className="text-xl font-black text-zinc-100 mt-1">
                    {masterBOM.length} Master SKUs
                  </p>
                </div>

                <div className="bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-zinc-500">Data Actions:</span>
                    <p className="text-xs text-zinc-400 mt-0.5">Download for Contractor Desks</p>
                  </div>
                  <button
                    onClick={handleExportBOMCSV}
                    className="flex items-center space-x-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold rounded-xl transition shadow-lg cursor-pointer"
                  >
                    <Download className="h-4 w-4" />
                    <span>Export CSV</span>
                  </button>
                </div>
              </div>

              {/* Master BOM Table */}
              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-zinc-950 text-zinc-400 uppercase text-[10px] font-extrabold border-b border-zinc-800">
                      <tr>
                        <th className="py-3 px-4">Trade</th>
                        <th className="py-3 px-4">Material Description</th>
                        <th className="py-3 px-4">Specification Grade</th>
                        <th className="py-3 px-4 text-center">Qty / Unit</th>
                        <th className="py-3 px-4 text-right">Unit Price</th>
                        <th className="py-3 px-4 text-right">Total</th>
                        <th className="py-3 px-4">Supplier SKU</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-850">
                      {masterBOM.map((item) => (
                        <tr key={item.id} className="hover:bg-zinc-850/50 transition">
                          <td className="py-3 px-4 font-bold text-sky-400">{item.trade}</td>
                          <td className="py-3 px-4 text-zinc-100 font-sans font-medium">{item.description}</td>
                          <td className="py-3 px-4 text-zinc-400 text-[11px]">{item.specGrade}</td>
                          <td className="py-3 px-4 text-center text-zinc-200 font-bold">{item.quantity} {item.unit}</td>
                          <td className="py-3 px-4 text-right text-zinc-300">${item.unitCost.toFixed(2)}</td>
                          <td className="py-3 px-4 text-right font-black text-emerald-400">${item.totalCost.toLocaleString()}</td>
                          <td className="py-3 px-4 text-[10px] text-zinc-500">{item.sku}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 5: DIGITAL CAD DATA (JSON / DXF EXCHANGE)                             */}
          {/* ========================================================================= */}
          {activeTab === 'cad-data' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl">
                <div>
                  <h4 className="text-xs font-bold text-zinc-100">
                    Interoperable Spatial CAD JSON Schema
                  </h4>
                  <p className="text-[11px] text-zinc-400">
                    Standard coordinate payload for Chief Architect, AutoCAD, Revit, and Matterport spatial engines.
                  </p>
                </div>

                <button
                  onClick={handleCopyCADData}
                  className="flex items-center space-x-1.5 px-3.5 py-2 bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-200 text-xs font-extrabold rounded-xl transition cursor-pointer"
                >
                  {copiedStatus === 'cad-json' ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                  <span>{copiedStatus === 'cad-json' ? 'Copied to Clipboard' : 'Copy JSON'}</span>
                </button>
              </div>

              {/* JSON Code Viewer */}
              <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-850 font-mono text-[11px] text-emerald-300 max-h-[400px] overflow-y-auto">
                <pre>{JSON.stringify({
                  metadata: {
                    project: deal.address,
                    city: deal.city,
                    jurisdiction: 'North Carolina',
                    buildingCode: 'NCRC 2024'
                  },
                  cadLayout: {
                    architecturalStyle: cadLayout.styleName,
                    heatedSqft: cadLayout.totalSqft,
                    roomsCount: cadLayout.rooms.length,
                    rooms: cadLayout.rooms,
                    repairBeaconsCount: cadLayout.fixProtocols.length,
                    protocols: cadLayout.fixProtocols
                  }
                }, null, 2)}</pre>
              </div>
            </div>
          )}

        </div>

        {/* Footer Bar */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-900/90 flex items-center justify-between text-xs text-zinc-400">
          <div className="flex items-center space-x-2 font-mono text-[11px]">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <span>NCRC 2024 Code Compliance Engine • All Trades Protected</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold rounded-xl transition cursor-pointer"
          >
            Close Studio
          </button>
        </div>

      </div>
    </div>
  );
};
