/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Users, 
  ShieldCheck, 
  FileCheck, 
  Plus, 
  Phone, 
  Mail, 
  DollarSign, 
  AlertTriangle, 
  Award, 
  Clock, 
  Trash2, 
  CheckCircle, 
  ExternalLink,
  Lock,
  Layers,
  FileText
} from "lucide-react";
import { PropertyDeal, Contractor } from "../types";

interface ContractorManagerProps {
  deal: PropertyDeal;
  onUpdateDeal: (updated: PropertyDeal) => void;
}

export const ContractorManager: React.FC<ContractorManagerProps> = ({
  deal,
  onUpdateDeal
}) => {
  const contractors = deal.contractors || [];
  const [isOnboardModalOpen, setIsOnboardModalOpen] = useState(false);
  const [isLienWaiverModalOpen, setIsLienWaiverModalOpen] = useState(false);
  const [selectedContractorForLien, setSelectedContractorForLien] = useState<Contractor | null>(null);

  // Form State for new contractor
  const [newContractorForm, setNewContractorForm] = useState<Partial<Contractor>>({
    name: "",
    trade: "General Contracting",
    contact: "",
    email: "",
    rating: 4.8,
    status: "active",
    licenseNumber: "NC GC #",
    licenseBoard: "NC Licensing Board for General Contractors",
    licenseVerified: true,
    insurancePolicy: "GL-NC-2026-",
    insuranceExpiry: "2027-02-28",
    insuranceLimit: "$1,000,000 / $2,000,000",
    workersCompVerified: true,
    w9OnFile: true,
    lienWaiverStatus: "current",
    contractAmount: 15000,
    paidToDate: 0,
    retainageHoldback: 1500,
    onTimeRate: 98
  });

  // Aggregates
  const totalContracted = contractors.reduce((acc, c) => acc + (c.contractAmount || 12000), 0);
  const totalPaid = contractors.reduce((acc, c) => acc + (c.paidToDate || 0), 0);
  const totalRetainage = contractors.reduce((acc, c) => acc + (c.retainageHoldback || Math.round((c.contractAmount || 12000) * 0.10)), 0);
  const allLicensed = contractors.every((c) => c.licenseVerified !== false);
  const allW9OnFile = contractors.every((c) => c.w9OnFile !== false);

  const handleOnboardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContractorForm.name?.trim()) return;

    const contractAmt = Number(newContractorForm.contractAmount) || 10000;
    const newContractor: Contractor = {
      id: `con-${Date.now()}`,
      name: newContractorForm.name,
      trade: newContractorForm.trade || "General Contracting",
      rating: Number(newContractorForm.rating) || 4.8,
      contact: newContractorForm.contact || "704-555-0199",
      email: newContractorForm.email || "dispatch@contractor.nc.com",
      status: "active",
      licenseNumber: newContractorForm.licenseNumber || "NC GC #81920",
      licenseBoard: newContractorForm.licenseBoard || "NC Licensing Board for General Contractors",
      licenseVerified: true,
      insurancePolicy: newContractorForm.insurancePolicy || "GL-2026-NC-8841",
      insuranceExpiry: newContractorForm.insuranceExpiry || "2027-04-30",
      insuranceLimit: "$1,000,000 / $2,000,000",
      workersCompVerified: newContractorForm.workersCompVerified ?? true,
      w9OnFile: newContractorForm.w9OnFile ?? true,
      lienWaiverStatus: "current",
      contractAmount: contractAmt,
      paidToDate: Number(newContractorForm.paidToDate) || 0,
      retainageHoldback: Math.round(contractAmt * 0.10),
      onTimeRate: Number(newContractorForm.onTimeRate) || 96
    };

    onUpdateDeal({
      ...deal,
      contractors: [...contractors, newContractor]
    });

    setNewContractorForm({
      name: "",
      trade: "General Contracting",
      contact: "",
      email: "",
      rating: 4.8,
      status: "active",
      licenseNumber: "NC GC #",
      licenseBoard: "NC Licensing Board for General Contractors",
      licenseVerified: true,
      insurancePolicy: "GL-NC-2026-",
      insuranceExpiry: "2027-02-28",
      insuranceLimit: "$1,000,000 / $2,000,000",
      workersCompVerified: true,
      w9OnFile: true,
      lienWaiverStatus: "current",
      contractAmount: 15000,
      paidToDate: 0,
      retainageHoldback: 1500,
      onTimeRate: 98
    });
    setIsOnboardModalOpen(false);
  };

  const handleDeleteContractor = (conId: string) => {
    onUpdateDeal({
      ...deal,
      contractors: contractors.filter((c) => c.id !== conId)
    });
  };

  const handleOpenLienWaiver = (con: Contractor) => {
    setSelectedContractorForLien(con);
    setIsLienWaiverModalOpen(true);
  };

  const handleSignLienWaiver = () => {
    if (!selectedContractorForLien) return;
    const updated = contractors.map((c) => {
      if (c.id === selectedContractorForLien.id) {
        return { ...c, lienWaiverStatus: "signed_unconditional" as const };
      }
      return c;
    });

    onUpdateDeal({
      ...deal,
      contractors: updated
    });
    setIsLienWaiverModalOpen(false);
    alert(`✓ Signed NC Statutory Lien Waiver (NC G.S. § 44A-23) for ${selectedContractorForLien.name}`);
  };

  return (
    <div className="space-y-6">
      {/* 1. Top Contractor Metric Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-zinc-900/70 border border-zinc-800 p-4 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-zinc-400">Active Trade Crews</span>
            <Users className="h-4 w-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-extrabold text-zinc-100 mt-1">{contractors.length} Crews</p>
          <div className="flex items-center space-x-1.5 text-[9px] text-emerald-400 font-bold mt-1">
            <ShieldCheck className="h-3 w-3" />
            <span>100% NC Board Licensed</span>
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 p-4 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-zinc-400">Total Subcontracted</span>
            <DollarSign className="h-4 w-4 text-zinc-500" />
          </div>
          <p className="text-2xl font-extrabold text-zinc-100 mt-1">${totalContracted.toLocaleString()}</p>
          <p className="text-[9px] text-zinc-500 mt-1">Allocated across trade scopes</p>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 p-4 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-zinc-400">Paid to Date</span>
            <CheckCircle className="h-4 w-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-extrabold text-emerald-300 mt-1">${totalPaid.toLocaleString()}</p>
          <p className="text-[9px] text-zinc-500 mt-1">Disbursed via Escrow Draws</p>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 p-4 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-zinc-400">NC 10% Retainage Holdback</span>
            <Lock className="h-4 w-4 text-amber-400" />
          </div>
          <p className="text-2xl font-extrabold text-amber-400 mt-1">${totalRetainage.toLocaleString()}</p>
          <p className="text-[9px] text-zinc-500 mt-1">Released upon final CO & Lien Waiver</p>
        </div>
      </div>

      {/* 2. Contractor Roster Header & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-zinc-950/80 p-3 rounded-2xl border border-zinc-850">
        <div>
          <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
            Vetted North Carolina Trade Contractors & Specialty Subcontractors
          </h4>
          <p className="text-[10px] text-zinc-400 mt-0.5">
            Real-time compliance tracking for NC Board licenses, general liability certificates, and G.S. § 44A-23 lien releases.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsOnboardModalOpen(true)}
          className="flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-sm flex-shrink-0"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>Onboard NC Contractor</span>
        </button>
      </div>

      {/* 3. Contractor Roster List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {contractors.map((con) => {
          const contractAmt = con.contractAmount || 12000;
          const paidAmt = con.paidToDate || 0;
          const retainage = con.retainageHoldback || Math.round(contractAmt * 0.10);
          const balance = contractAmt - paidAmt;

          return (
            <div
              key={con.id}
              className="bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-5 shadow-sm space-y-4 hover:border-zinc-700 transition"
            >
              {/* Header */}
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center space-x-2">
                    <h5 className="font-extrabold text-sm text-zinc-100">{con.name}</h5>
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                      ★ {con.rating}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-emerald-400 mt-0.5">{con.trade}</p>
                </div>

                <div className="flex items-center space-x-1.5">
                  <span className={`px-2 py-0.5 rounded-md text-[9px] font-extrabold uppercase border ${
                    con.status === "active"
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                      : "bg-zinc-950 text-zinc-400 border-zinc-800"
                  }`}>
                    {con.status}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleDeleteContractor(con.id)}
                    className="p-1 text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 rounded transition cursor-pointer"
                    title="Remove Contractor"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* License & Compliance Badges Grid */}
              <div className="bg-zinc-950/60 p-3 rounded-xl border border-zinc-850 grid grid-cols-2 gap-2.5 text-[10px]">
                <div>
                  <span className="text-zinc-500 font-bold block uppercase text-[8px]">NC State License</span>
                  <div className="flex items-center space-x-1 text-zinc-200 font-semibold mt-0.5">
                    <ShieldCheck className="h-3 w-3 text-emerald-400 flex-shrink-0" />
                    <span className="truncate">{con.licenseNumber || "NC GC #78901"}</span>
                  </div>
                  <span className="text-[8px] text-zinc-400">{con.licenseBoard || "NC General Contractors Board"}</span>
                </div>

                <div>
                  <span className="text-zinc-500 font-bold block uppercase text-[8px]">Insurance & W-9</span>
                  <div className="flex items-center space-x-1 text-zinc-200 font-semibold mt-0.5">
                    <FileCheck className="h-3 w-3 text-emerald-400 flex-shrink-0" />
                    <span>GL Policy Exp: {con.insuranceExpiry || "2027-02-28"}</span>
                  </div>
                  <span className="text-[8px] text-emerald-400">✓ W-9 On File • Workers' Comp Active</span>
                </div>
              </div>

              {/* Financial & Retainage Ledger */}
              <div className="grid grid-cols-4 gap-2 pt-2 border-t border-zinc-800 text-[10px]">
                <div>
                  <span className="text-zinc-500 text-[8px] uppercase font-bold block">Contract</span>
                  <span className="font-extrabold text-zinc-200">${contractAmt.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[8px] uppercase font-bold block">Paid</span>
                  <span className="font-extrabold text-emerald-400">${paidAmt.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[8px] uppercase font-bold block">10% Retainage</span>
                  <span className="font-extrabold text-amber-400">${retainage.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[8px] uppercase font-bold block">Balance</span>
                  <span className="font-extrabold text-zinc-300">${balance.toLocaleString()}</span>
                </div>
              </div>

              {/* Action Bar */}
              <div className="flex items-center justify-between pt-2 border-t border-zinc-800 text-[10px]">
                <div className="flex items-center space-x-3 text-zinc-400">
                  <a
                    href={`tel:${con.contact}`}
                    className="flex items-center space-x-1 hover:text-emerald-400 transition"
                  >
                    <Phone className="h-3 w-3" />
                    <span>{con.contact}</span>
                  </a>
                  {con.email && (
                    <a
                      href={`mailto:${con.email}`}
                      className="hidden sm:flex items-center space-x-1 hover:text-emerald-400 transition"
                    >
                      <Mail className="h-3 w-3" />
                      <span>{con.email}</span>
                    </a>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => handleOpenLienWaiver(con)}
                  className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg font-bold text-[9px] uppercase tracking-wider transition cursor-pointer border ${
                    con.lienWaiverStatus === "signed_unconditional"
                      ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"
                      : "bg-zinc-800 hover:bg-zinc-750 text-zinc-200 border-zinc-700"
                  }`}
                >
                  <FileText className="h-3 w-3" />
                  <span>
                    {con.lienWaiverStatus === "signed_unconditional"
                      ? "✓ Lien Waiver Signed"
                      : "Issue NC Lien Waiver"}
                  </span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Onboard NC Contractor */}
      {isOnboardModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-3 border-b border-zinc-800">
              <h3 className="font-extrabold text-sm text-zinc-100 uppercase tracking-wide">
                Onboard North Carolina Trade Contractor
              </h3>
              <button
                type="button"
                onClick={() => setIsOnboardModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300 text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleOnboardSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                  Company / Contractor Legal Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tarheel State Electrical & Solar LLC"
                  value={newContractorForm.name}
                  onChange={(e) => setNewContractorForm({ ...newContractorForm, name: e.target.value })}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    Trade / Specialty
                  </label>
                  <select
                    value={newContractorForm.trade}
                    onChange={(e) => setNewContractorForm({ ...newContractorForm, trade: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200 font-bold"
                  >
                    <option value="General Contracting (NC GC)">General Contracting</option>
                    <option value="Licensed Electrician (NC Unlimited)">Electrical Services</option>
                    <option value="HVAC & Heat Pump Specialist (NC Board)">HVAC & Mechanical</option>
                    <option value="Master Plumber (NC Plumbing Board)">Plumbing Contractor</option>
                    <option value="Roofing Specialist (NC Certified)">Roofing & Gutters</option>
                    <option value="Drywall, Paint & Framing">Drywall & Finish Carpentry</option>
                    <option value="Flooring & Tile Specialist">Flooring & Tile</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    NC State License #
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. NC GC #84910 or NC ELEC #34211"
                    value={newContractorForm.licenseNumber}
                    onChange={(e) => setNewContractorForm({ ...newContractorForm, licenseNumber: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    Phone Contact
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="704-555-0199"
                    value={newContractorForm.contact}
                    onChange={(e) => setNewContractorForm({ ...newContractorForm, contact: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    placeholder="office@contractor.nc.com"
                    value={newContractorForm.email}
                    onChange={(e) => setNewContractorForm({ ...newContractorForm, email: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    Agreed Subcontract Value ($)
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={newContractorForm.contractAmount}
                    onChange={(e) => setNewContractorForm({ ...newContractorForm, contractAmount: Number(e.target.value) })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">
                    GL Insurance Expiration Date
                  </label>
                  <input
                    type="date"
                    required
                    value={newContractorForm.insuranceExpiry}
                    onChange={(e) => setNewContractorForm({ ...newContractorForm, insuranceExpiry: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-zinc-200"
                  />
                </div>
              </div>

              <div className="p-3 bg-zinc-950/70 border border-zinc-850 rounded-xl space-y-2">
                <label className="flex items-center space-x-2 text-zinc-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newContractorForm.workersCompVerified}
                    onChange={(e) => setNewContractorForm({ ...newContractorForm, workersCompVerified: e.target.checked })}
                    className="rounded bg-zinc-900 border-zinc-700 text-emerald-500"
                  />
                  <span>Workers' Compensation Certificate on file (NC statutory requirement)</span>
                </label>

                <label className="flex items-center space-x-2 text-zinc-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newContractorForm.w9OnFile}
                    onChange={(e) => setNewContractorForm({ ...newContractorForm, w9OnFile: e.target.checked })}
                    className="rounded bg-zinc-900 border-zinc-700 text-emerald-500"
                  />
                  <span>IRS Form W-9 on file (Taxpayer Identification & EIN verified)</span>
                </label>
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsOnboardModalOpen(false)}
                  className="px-4 py-2 bg-zinc-800 hover:bg-zinc-750 text-zinc-300 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold cursor-pointer"
                >
                  Onboard & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: NC G.S. § 44A-23 Lien Waiver Generator */}
      {isLienWaiverModalOpen && selectedContractorForLien && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-zinc-800">
              <h3 className="font-extrabold text-sm text-zinc-100 uppercase tracking-wide">
                North Carolina Statutory Lien Waiver (N.C.G.S. § 44A-23)
              </h3>
              <button
                type="button"
                onClick={() => setIsLienWaiverModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300 text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl font-mono text-[11px] text-zinc-300 max-h-72 overflow-y-auto whitespace-pre-wrap leading-relaxed">
{`STATE OF NORTH CAROLINA
COUNTY OF MECKLENBURG / WAKE
N.C. GEN. STAT. § 44A-23 CONTRACTOR LIEN WAIVER & RELEASE OF CLAIM

PROPERTY: ${deal.address}, ${deal.city}, NC ${deal.zip}
CONTRACTOR: ${selectedContractorForLien.name}
NC LICENSE: ${selectedContractorForLien.licenseNumber || "NC Board Licensed"}
TRADE: ${selectedContractorForLien.trade}
TOTAL CONTRACT SUM: $${(selectedContractorForLien.contractAmount || 12000).toLocaleString()}

TO ALL WHOM IT MAY CONCERN:
The undersigned Contractor, for and in consideration of the sum of payments disbursed to date, does hereby waive, release, and quitclaim all liens, lien rights, or claims of lien against the real property described above under Chapter 44A of the North Carolina General Statutes for labor, materials, equipment, and services furnished through the date hereof.

Contractor certifies that all secondary subcontractors and materialmen engaged by Contractor have been paid in full or will be paid out of the proceeds of this draw, leaving no cloud on title for the Buyer or Lender.

DATED: ${new Date().toISOString().split("T")[0]}
AUTHORIZED REPRESENTATIVE: ${selectedContractorForLien.name}`}
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setIsLienWaiverModalOpen(false)}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-750 text-zinc-300 rounded-xl font-bold text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSignLienWaiver}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs cursor-pointer"
              >
                Execute & Sign NC Lien Waiver
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
