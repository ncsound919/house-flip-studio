import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BookOpen, 
  HelpCircle, 
  X, 
  MapPin, 
  ShieldAlert, 
  Sparkles, 
  DollarSign, 
  ArrowRight, 
  Clipboard, 
  Check, 
  Info,
  Scale,
  Bot,
  Compass,
  FileCheck2,
  ListTodo
} from "lucide-react";

interface UserManualProps {
  isOpen: boolean;
  onClose: () => void;
  onStartInteractiveTour: () => void;
}

export default function UserManual({ isOpen, onClose, onStartInteractiveTour }: UserManualProps) {
  const [activeTab, setActiveTab] = useState<"onboarding" | "agents" | "mls-gis" | "nc-law">("onboarding");
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-4xl max-h-[85vh] bg-zinc-900 border border-zinc-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-zinc-300 font-sans"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 bg-zinc-900/80 border-b border-zinc-800/80">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-md font-extrabold text-zinc-100 uppercase tracking-wider">NC House Flip Studio — Simple Guide</h2>
                <p className="text-[10px] text-emerald-400 font-extrabold tracking-wider uppercase">Learn the steps, check out your AI helpers, and see NC house rules</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="p-1.5 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-zinc-350 transition cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Sub Navigation */}
          <div className="flex px-6 py-2 bg-zinc-950/40 border-b border-zinc-800/60 overflow-x-auto gap-2">
            {[
              { id: "onboarding", label: "Quick Start Guide", icon: Sparkles },
              { id: "agents", label: "Our AI Helpers", icon: Bot },
              { id: "mls-gis", label: "How We Find Houses", icon: Compass },
              { id: "nc-law", label: "North Carolina Rules", icon: Scale },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider whitespace-nowrap transition cursor-pointer ${
                    activeTab === tab.id
                      ? "bg-emerald-600/10 text-emerald-400 border border-emerald-500/30"
                      : "text-zinc-400 hover:text-zinc-250 border border-transparent"
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Content Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {activeTab === "onboarding" && (
              <div className="space-y-6">
                {/* Intro Explainer banner */}
                <div className="bg-emerald-600/5 border border-emerald-500/20 rounded-2xl p-5 flex items-start space-x-4">
                  <div className="p-2 bg-emerald-500/15 rounded-xl text-emerald-400 flex-shrink-0">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-zinc-200 text-sm">Welcome to House Flipping!</h3>
                    <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                      This studio is a fun game and tool that helps you practice house flipping in North Carolina, even if you are brand new to real estate! 
                      Our smart AI helpers do all the boring research (like digging up home records, estimating repair costs, and looking up state laws) so you can focus on the fun parts: walking through virtual houses, checking for problems, and deciding on the best deal.
                    </p>
                  </div>
                </div>

                {/* Tour Trigger Box */}
                <div className="bg-zinc-950/40 border border-zinc-850 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="space-y-1 text-center sm:text-left">
                    <h4 className="font-extrabold text-xs text-zinc-200 uppercase tracking-wider">Take a Guided Screen Tour</h4>
                    <p className="text-xs text-zinc-400">Launch a simple step-by-step visual tour pointing out key sections of the screen in real-time.</p>
                  </div>
                  <button
                    onClick={() => {
                      onClose();
                      onStartInteractiveTour();
                    }}
                    className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-md transition flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <span>Start Simple Walkthrough</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>

                {/* Step-by-Step Playbook */}
                <div className="space-y-3">
                  <h3 className="font-extrabold text-xs text-zinc-400 uppercase tracking-widest flex items-center space-x-2">
                    <ListTodo className="h-4 w-4 text-emerald-400" />
                    <span>The Simple 4 Steps to Flip a House</span>
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-zinc-950/20 border border-zinc-850 rounded-2xl space-y-2">
                      <div className="flex items-center space-x-2">
                        <span className="h-6 w-6 rounded-lg bg-zinc-900 border border-zinc-800 text-[10px] font-black text-emerald-400 flex items-center justify-center">01</span>
                        <h4 className="font-bold text-zinc-200 text-xs font-black uppercase tracking-wider">Find a House</h4>
                      </div>
                      <p className="text-[11px] text-zinc-400 leading-relaxed">
                        Go to the **Command Center** and select a town like Charlotte or Raleigh. Or, type in a real address! Our AI Scout will immediately pull up all the details about the house, like when it was built and how large the yard is.
                      </p>
                    </div>

                    <div className="p-4 bg-zinc-950/20 border border-zinc-850 rounded-2xl space-y-2">
                      <div className="flex items-center space-x-2">
                        <span className="h-6 w-6 rounded-lg bg-zinc-900 border border-zinc-800 text-[10px] font-black text-emerald-400 flex items-center justify-center">02</span>
                        <h4 className="font-bold text-zinc-200 text-xs font-black uppercase tracking-wider">Let the AI do the Math</h4>
                      </div>
                      <p className="text-[11px] text-zinc-400 leading-relaxed">
                        Once you have a house loaded, click **"Go For Property (Auto Pipeline)"**. Watch your AI helpers run calculations instantly! They will find out what similar houses nearby sold for and write up a list of estimated repair costs.
                      </p>
                    </div>

                    <div className="p-4 bg-zinc-950/20 border border-zinc-850 rounded-2xl space-y-2">
                      <div className="flex items-center space-x-2">
                        <span className="h-6 w-6 rounded-lg bg-zinc-900 border border-zinc-800 text-[10px] font-black text-emerald-400 flex items-center justify-center">03</span>
                        <h4 className="font-bold text-zinc-200 text-xs font-black uppercase tracking-wider">Virtual House Walkthrough</h4>
                      </div>
                      <p className="text-[11px] text-zinc-400 leading-relaxed">
                        Switch to the **Partners' Oversight** tab to simulate a walking tour of the house. You can check off issues like mold or a bad roof. When you click *Calibrate Rehab Budget*, your repair lists will automatically update with new costs!
                      </p>
                    </div>

                    <div className="p-4 bg-zinc-950/20 border border-zinc-850 rounded-2xl space-y-2">
                      <div className="flex items-center space-x-2">
                        <span className="h-6 w-6 rounded-lg bg-zinc-900 border border-zinc-800 text-[10px] font-black text-emerald-400 flex items-center justify-center">04</span>
                        <h4 className="font-bold text-zinc-200 text-xs font-black uppercase tracking-wider">Plan Your Profit & Close</h4>
                      </div>
                      <p className="text-[11px] text-zinc-400 leading-relaxed">
                        Keep track of the money you borrowed, double-check your contractor checklist, and click the final approval buttons to complete your flip and lock in your practice profit!
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "agents" && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <h3 className="font-extrabold text-sm text-zinc-100">Meet Your 6 AI Helpers</h3>
                  <p className="text-xs text-zinc-400">Think of these helpers as your personal, automated real estate team who do the hard work for you.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    {
                      name: "The Coach (Supervisor)",
                      desc: "The leader of the group. He coordinates the other helpers, alerts you if something is risky or illegal, and answers all your questions in the live chat.",
                      tasks: ["Coordinates specialist helpers", "Chats with you live and explains concepts", "Helps you make the final decisions"]
                    },
                    {
                      name: "The House Finder (Scout)",
                      desc: "Searches public databases and real estate listings to grab details like the build year, land size, and tax records.",
                      tasks: ["Finds cheap or run-down houses", "Reads home details", "Flags old houses that need work"]
                    },
                    {
                      name: "The Value Guesser (ARV)",
                      desc: "Looks at recent sales of similar homes in the same neighborhood to figure out what your flipped house will be worth once fixed up.",
                      tasks: ["Looks up neighborhood house sales", "Tells you the perfect flip value", "Helps you avoid overpaying"]
                    },
                    {
                      name: "The Repair Estimator",
                      desc: "Creates a list of repair costs based on how run-down the house is, and updates prices instantly if you find problems during your virtual walk-through.",
                      tasks: ["Lists wood, paint, and labor costs", "Updates prices for mold or damage", "Calculates contractor prices"]
                    },
                    {
                      name: "The Legal Safeguard",
                      desc: "Checks North Carolina state laws to make sure you have all the right permits and aren't breaking any rules.",
                      tasks: ["Checks North Carolina builder rules", "Ensures correct paperwork", "Prevents legal trouble"]
                    },
                    {
                      name: "The Bank Helper",
                      desc: "Helps you calculate how much money to borrow, tracks your budget, and makes sure you don't run out of cash before the flip is done.",
                      tasks: ["Calculates interest and loans", "Tracks your total budget", "Prepares final profit statements"]
                    }
                  ].map((agent, index) => (
                    <div key={index} className="p-4 bg-zinc-950/40 border border-zinc-800 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-extrabold text-xs text-zinc-100 uppercase tracking-wider flex items-center space-x-1.5">
                          <Bot className="h-4 w-4 text-emerald-400" />
                          <span>{agent.name}</span>
                        </h4>
                        <span className="text-[8px] font-bold text-zinc-500 uppercase tracking-wider bg-zinc-900 border border-zinc-800 px-1.5 py-0.5 rounded">AI Bot</span>
                      </div>
                      <p className="text-xs text-zinc-400 leading-relaxed">{agent.desc}</p>
                      <div className="pt-2 border-t border-zinc-850">
                        <h5 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5">What this helper does:</h5>
                        <ul className="space-y-1">
                          {agent.tasks.map((task, tIdx) => (
                            <li key={tIdx} className="text-[10px] text-zinc-300 flex items-center space-x-1.5">
                              <span className="h-1 w-1 rounded-full bg-emerald-400"></span>
                              <span>{task}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "mls-gis" && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <h3 className="font-extrabold text-sm text-zinc-100">Where the House Data Comes From</h3>
                  <p className="text-xs text-zinc-400">Our helpers look at real North Carolina public records to find accurate data for your practice flips.</p>
                </div>

                <div className="space-y-4">
                  <div className="p-5 bg-zinc-950/40 border border-zinc-800 rounded-2xl space-y-3">
                    <h4 className="font-bold text-xs text-zinc-200 uppercase tracking-wider flex items-center space-x-2">
                      <Compass className="h-4 w-4 text-emerald-400" />
                      <span>Real North Carolina Cities Covered</span>
                    </h4>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      Depending on the city you select, our AI searches through different real-world regional networks:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                      <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-850">
                        <span className="text-[10px] font-black text-emerald-400 uppercase">Charlotte & Asheville</span>
                        <p className="text-[10px] text-zinc-400 mt-1">Pulls local county tax cards and public property lines from real databases.</p>
                      </div>
                      <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-850">
                        <span className="text-[10px] font-black text-emerald-400 uppercase">Raleigh & Durham</span>
                        <p className="text-[10px] text-zinc-400 mt-1">Pulls public property records from central Raleigh & Durham registers.</p>
                      </div>
                      <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-850">
                        <span className="text-[10px] font-black text-emerald-400 uppercase">Greensboro & Wilmington</span>
                        <p className="text-[10px] text-zinc-400 mt-1">Scrapes tax history, acreage, and year-built records automatically.</p>
                      </div>
                    </div>
                  </div>

                  <div className="p-5 bg-zinc-950/40 border border-zinc-800 rounded-2xl space-y-3">
                    <h4 className="font-bold text-xs text-zinc-200 uppercase tracking-wider flex items-center space-x-2">
                      <Info className="h-4 w-4 text-emerald-400" />
                      <span>The 4 Things the AI Checks</span>
                    </h4>
                    <p className="text-xs text-zinc-400">The AI automatically reads these 4 details about every property:</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center text-[10px] text-zinc-300 font-extrabold uppercase">
                      <div className="p-2.5 bg-zinc-900/40 border border-zinc-850 rounded-xl">City Identification ID</div>
                      <div className="p-2.5 bg-zinc-900/40 border border-zinc-850 rounded-xl">County Tax Value</div>
                      <div className="p-2.5 bg-zinc-900/40 border border-zinc-850 rounded-xl">The Year Built</div>
                      <div className="p-2.5 bg-zinc-900/40 border border-zinc-850 rounded-xl">The Yard Size</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "nc-law" && (
              <div className="space-y-6">
                <div className="space-y-1 bg-amber-500/5 border border-amber-500/25 rounded-2xl p-4 flex items-start space-x-3">
                  <ShieldAlert className="h-5 w-5 text-amber-500 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-sm text-zinc-200">North Carolina Rules & Laws</h3>
                    <p className="text-xs text-zinc-400 mt-0.5 leading-relaxed">
                      Flipping houses in North Carolina is highly regulated to keep buyers and contractors safe. Our app has built-in smart checks to make sure you follow these 2 big rules:
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  {/* HB 797 */}
                  <div className="p-4 bg-zinc-950/40 border border-zinc-800 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-extrabold text-xs text-zinc-100 uppercase tracking-wider flex items-center space-x-1.5">
                        <Scale className="h-4 w-4 text-emerald-400" />
                        <span>Rule 1: Honest Disclosures (HB 797)</span>
                      </h4>
                      <span className="px-1.5 py-0.5 text-[8px] font-black text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded uppercase">State Rule</span>
                    </div>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      If you are transferring a contract to someone else (called wholesaling), North Carolina says you must be 100% honest that you do not own the house yet, only the purchase contract. We have a button to copy this official disclosure text instantly!
                    </p>
                    <div className="pt-2">
                      <button
                        onClick={() => handleCopy("Under NC law (HB 797), real estate wholesaling requires strict assignment declarations. We confirm that this transaction represents an assignment of equitable contract interest, not an unauthorized brokerage transaction. The assignor discloses that they hold no legal title, only equitable interest under a purchase agreement.", "hb797")}
                        className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-[10px] font-bold text-zinc-300 rounded-lg transition flex items-center space-x-1.5 cursor-pointer"
                      >
                        {copiedText === "hb797" ? <Check className="h-3 w-3 text-emerald-400" /> : <Clipboard className="h-3 w-3 text-zinc-400" />}
                        <span>Copy Legal Disclosure Text</span>
                      </button>
                    </div>
                  </div>

                  {/* GC Licensing */}
                  <div className="p-4 bg-zinc-950/40 border border-zinc-800 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-extrabold text-xs text-zinc-100 uppercase tracking-wider flex items-center space-x-1.5">
                        <FileCheck2 className="h-4 w-4 text-emerald-400" />
                        <span>Rule 2: The $40,000 Contractor Limit (NCGS § 87-1)</span>
                      </h4>
                      <span className="px-1.5 py-0.5 text-[8px] font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded uppercase">Builder Law</span>
                    </div>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      In North Carolina, if repair costs go over **$40,000**, you are legally required to hire a licensed General Contractor to do the work. If you try to do it without a licensed builder, it's illegal.
                    </p>
                    <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-850 text-[10px] text-zinc-400">
                      <strong>AI Helper Note:</strong> If your estimated repair costs go over $40,000, our system automatically adds a critical compliance reminder to verify that your selected contractor possesses an active NC General Contractor License so you stay 100% legal!
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer controls */}
          <div className="p-6 bg-zinc-950 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">NC House Flip Studio — Made Easy For Everyone</span>
            <div className="flex items-center space-x-3 w-full sm:w-auto">
              <button
                onClick={() => {
                  onClose();
                  onStartInteractiveTour();
                }}
                className="flex-1 sm:flex-initial px-4 py-2 hover:bg-zinc-900 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-300 transition cursor-pointer"
              >
                Start Screen Tour
              </button>
              <button
                onClick={onClose}
                className="flex-1 sm:flex-initial px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer"
              >
                Got It!
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
