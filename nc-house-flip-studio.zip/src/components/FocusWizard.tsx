/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Compass, 
  MapPin, 
  TrendingUp, 
  Hammer, 
  ShieldCheck, 
  Calendar, 
  Play, 
  Check, 
  Loader2, 
  ArrowRight, 
  ArrowLeft,
  DollarSign,
  AlertTriangle,
  UserCheck
} from "lucide-react";
import { PropertyDeal, DealStatus } from "../types";

interface FocusWizardProps {
  deal: PropertyDeal;
  onRunStepAnalysis: (step: string) => Promise<void>;
  onGateApprove: (gateKey: string) => void;
  isAnalyzing: boolean;
  activeAgent: string | null;
  gates: {
    compsApproved: boolean;
    rehabApproved: boolean;
    complianceApproved: boolean;
  };
}

export default function FocusWizard({ 
  deal, 
  onRunStepAnalysis, 
  onGateApprove, 
  isAnalyzing, 
  activeAgent,
  gates
}: FocusWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [stepLoading, setStepLoading] = useState(false);

  const steps = [
    {
      id: "ingest",
      title: "Step 1: House Info Details",
      description: "Extract county details, tax values, year built, and basic size numbers.",
      icon: Compass,
      color: "text-emerald-400",
      bgColor: "bg-emerald-500/10",
      borderColor: "border-emerald-500/20",
      architectureMode: "Simple Rules"
    },
    {
      id: "comps",
      title: "Step 2: Checking Selling Prices",
      description: "Compare with other nearby houses that recently sold to find the perfect value.",
      icon: TrendingUp,
      color: "text-sky-400",
      bgColor: "bg-sky-500/10",
      borderColor: "border-sky-500/20",
      architectureMode: "Smart AI"
    },
    {
      id: "rehab",
      title: "Step 3: Calculating Repair Costs",
      description: "Work out exactly what needs fixing and how much materials and labor will cost.",
      icon: Hammer,
      color: "text-amber-400",
      bgColor: "bg-amber-500/10",
      borderColor: "border-amber-500/20",
      architectureMode: "Smart AI"
    },
    {
      id: "compliance",
      title: "Step 4: Making Sure It's Legal",
      description: "Double-check local rules, tax laws, and assignment laws so we stay safe.",
      icon: ShieldCheck,
      color: "text-purple-400",
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-500/20",
      architectureMode: "Simple Rules"
    },
    {
      id: "underwrite",
      title: "Step 5: Final Money Report",
      description: "Review final profit, plan the repair timeline, and match local contractor crews.",
      icon: Calendar,
      color: "text-pink-400",
      bgColor: "bg-pink-500/10",
      borderColor: "border-pink-500/20",
      architectureMode: "Super AI Agent"
    }
  ];

  const handleTriggerAnalysis = async () => {
    setStepLoading(true);
    try {
      await onRunStepAnalysis(steps[currentStep].id);
    } catch (err) {
      console.error(err);
    } finally {
      setStepLoading(false);
    }
  };

  const isStepCompleted = (idx: number) => {
    const hasCalculations = deal.underwriting && deal.underwriting.arv > 0;
    if (idx === 0) return true; // basic info is always present
    if (idx === 1) return hasCalculations && deal.comps.length > 0;
    if (idx === 2) return hasCalculations && deal.rehabItems.length > 0;
    if (idx === 3) return hasCalculations && deal.complianceChecks.length > 2;
    if (idx === 4) return hasCalculations && deal.milestones.length > 0;
    return false;
  };

  const isStepGated = (idx: number) => {
    if (idx === 1) return !gates.compsApproved;
    if (idx === 2) return !gates.rehabApproved;
    if (idx === 3) return !gates.complianceApproved;
    return false;
  };

  const getStepGateKey = (idx: number) => {
    if (idx === 1) return "compsApproved";
    if (idx === 2) return "rehabApproved";
    if (idx === 3) return "complianceApproved";
    return "";
  };

  const ActiveStepIcon = steps[currentStep].icon;

  return (
    <div className="space-y-5 text-xs">
      {/* Wizard Step Progress Tracker */}
      <div className="flex justify-between items-center bg-zinc-950/40 border border-zinc-850 p-4 rounded-2xl">
        {steps.map((step, idx) => {
          const isActive = idx === currentStep;
          const isDone = isStepCompleted(idx);
          const isGated = isStepGated(idx);
          const Icon = step.icon;

          return (
            <React.Fragment key={step.id}>
              <button
                onClick={() => setCurrentStep(idx)}
                className={`flex flex-col items-center space-y-1 focus:outline-hidden group relative cursor-pointer`}
              >
                <div className={`p-2.5 rounded-xl border transition-all duration-300 ${
                  isActive 
                    ? `${step.bgColor} ${step.borderColor} ring-1 ring-emerald-500/20 shadow-md`
                    : isDone
                    ? "bg-zinc-900 border-zinc-800 text-emerald-400"
                    : "bg-zinc-950 border-zinc-850 text-zinc-600 group-hover:text-zinc-400"
                }`}>
                  {isDone && !isActive ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <Icon className="h-4 w-4" />
                  )}
                  {isGated && isDone && (
                    <span className="absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full bg-amber-500 border-2 border-zinc-900 flex items-center justify-center text-[8px] font-bold text-zinc-950">!</span>
                  )}
                </div>
                <span className={`text-[10px] font-bold hidden md:inline transition ${
                  isActive ? "text-zinc-200" : "text-zinc-500 group-hover:text-zinc-400"
                }`}>
                  {step.title.split(" ")[0]}
                </span>
              </button>
              {idx < steps.length - 1 && (
                <div className={`flex-1 h-[1px] mx-1 md:mx-3 transition duration-500 ${
                  isStepCompleted(idx + 1) ? "bg-emerald-500/40" : "bg-zinc-800"
                }`} />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Step Visual Board */}
      <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-5 relative overflow-hidden min-h-[280px] flex flex-col justify-between">
        {/* Decorative Grid background */}
        <div className="absolute inset-0 bg-radial-at-t from-zinc-800/10 via-transparent to-transparent opacity-50 pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className={`p-2.5 rounded-xl ${steps[currentStep].bgColor} ${steps[currentStep].borderColor} border text-lg`}>
                <ActiveStepIcon className={`h-5 w-5 ${steps[currentStep].color}`} />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] uppercase font-extrabold tracking-wider text-emerald-400">Step {currentStep + 1} of 5</span>
                  <span className="text-[9px] font-bold bg-zinc-955 text-emerald-300 border border-emerald-500/20 px-1.5 py-0.5 rounded uppercase tracking-wider">
                    {steps[currentStep].architectureMode}
                  </span>
                </div>
                <h3 className="text-sm font-extrabold text-zinc-100 mt-1">{steps[currentStep].title}</h3>
              </div>
            </div>

            {/* Run Button for Step */}
            {!isStepCompleted(currentStep) && (
              <button
                onClick={handleTriggerAnalysis}
                disabled={isAnalyzing || stepLoading}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center space-x-1.5 transition shadow-xs cursor-pointer"
              >
                {isAnalyzing || stepLoading ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Play className="h-3.5 w-3.5" />
                )}
                <span>{isAnalyzing || stepLoading ? "Running AI..." : "Run AI Analysis"}</span>
              </button>
            )}
          </div>

          <p className="text-zinc-400 leading-relaxed text-[11px] max-w-2xl bg-zinc-950/20 p-2.5 rounded-xl border border-zinc-850/40">
            {steps[currentStep].description}
          </p>

          {/* Render Step-Specific Data if available, otherwise prompt Job Enqueue */}
          <div className="pt-2">
            {!isStepCompleted(currentStep) ? (
              <div className="py-6 text-center bg-zinc-950/40 border border-zinc-850 border-dashed rounded-xl flex flex-col items-center justify-center">
                <Loader2 className={`h-8 w-8 text-zinc-700 mb-2 ${isAnalyzing || stepLoading ? 'animate-spin' : ''}`} />
                <h4 className="font-bold text-zinc-400 text-xs uppercase tracking-wider">AI Helper is Ready to Work</h4>
                <p className="text-[10px] text-zinc-500 max-w-sm mt-1 mb-3">
                  This step has no information yet. Click the button below to have your AI helper find and analyze everything for this step!
                </p>
                <button
                  onClick={handleTriggerAnalysis}
                  disabled={isAnalyzing || stepLoading}
                  className="px-4 py-2 bg-zinc-900 border border-zinc-800 hover:bg-zinc-850 text-zinc-300 font-extrabold text-[10px] uppercase tracking-wider rounded-xl transition cursor-pointer"
                >
                  Run AI Helper on This Step
                </button>
              </div>
            ) : (
              <motion.div 
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-3"
              >
                {/* Step 1 Content: Ingest details */}
                {currentStep === 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-zinc-950/60 p-3 rounded-xl border border-zinc-850">
                      <span className="text-[9px] text-zinc-500 font-extrabold uppercase">District</span>
                      <p className="font-bold text-zinc-300 mt-1">{deal.yearBuilt < 1945 ? "Historic Overlay" : "Standard Residential"}</p>
                    </div>
                    <div className="bg-zinc-950/60 p-3 rounded-xl border border-zinc-850">
                      <span className="text-[9px] text-zinc-500 font-extrabold uppercase">GIS Acres</span>
                      <p className="font-bold text-zinc-300 mt-1">{deal.lotSize} Acres</p>
                    </div>
                    <div className="bg-zinc-950/60 p-3 rounded-xl border border-zinc-850">
                      <span className="text-[9px] text-zinc-500 font-extrabold uppercase">County PIN</span>
                      <p className="font-mono font-bold text-zinc-300 mt-1">Meck-{deal.zip}-{Math.round(deal.yearBuilt * 5.3)}</p>
                    </div>
                    <div className="bg-zinc-950/60 p-3 rounded-xl border border-zinc-850">
                      <span className="text-[9px] text-zinc-500 font-extrabold uppercase">Built</span>
                      <p className="font-bold text-zinc-300 mt-1">{deal.yearBuilt}</p>
                    </div>
                  </div>
                )}

                {/* Step 2 Content: Comps */}
                {currentStep === 1 && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center bg-zinc-950/60 p-3 rounded-xl border border-zinc-850">
                      <div>
                        <span className="text-[9px] text-zinc-500 font-extrabold uppercase">Estimated After Repair Value (ARV)</span>
                        <p className="text-md font-extrabold text-sky-400 mt-0.5">${deal.underwriting.arv.toLocaleString()}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-zinc-500 font-extrabold uppercase">ARV Confidence</span>
                        <p className="text-xs font-bold text-zinc-300 mt-0.5">{deal.underwriting.arvConfidence} Confidence</p>
                      </div>
                    </div>
                    <div className="max-h-[120px] overflow-y-auto space-y-1.5 pr-1">
                      {deal.comps.map((comp, idx) => (
                        <div key={idx} className="p-2 bg-zinc-950/40 border border-zinc-850 rounded-xl flex justify-between text-[10px]">
                          <span className="font-bold text-zinc-300">{comp.address}</span>
                          <span className="font-bold text-sky-400">${comp.price.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                    {isStepGated(currentStep) && (
                      <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-xl flex items-center justify-between text-amber-300">
                        <div className="flex items-center space-x-2">
                          <AlertTriangle className="h-4 w-4" />
                          <span>Double-Check Needed: Please review these sales details and click to approve!</span>
                        </div>
                        <button
                          onClick={() => onGateApprove(getStepGateKey(currentStep))}
                          className="px-3 py-1 bg-amber-500 text-zinc-950 font-extrabold uppercase tracking-wider text-[9px] rounded-lg cursor-pointer hover:bg-amber-400 animate-pulse"
                        >
                          Looks Good, Approve Prices!
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Step 3 Content: Rehab */}
                {currentStep === 2 && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center bg-zinc-950/60 p-3 rounded-xl border border-zinc-850">
                      <div>
                        <span className="text-[9px] text-zinc-500 font-extrabold uppercase">Compiled Rehab Budget</span>
                        <p className="text-md font-extrabold text-amber-400 mt-0.5">${deal.underwriting.rehabCost.toLocaleString()}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-zinc-500 font-extrabold uppercase">NC Material Index</span>
                        <p className="text-xs font-bold text-zinc-300 mt-0.5">Mecklenburg-1.02x</p>
                      </div>
                    </div>
                    <div className="max-h-[120px] overflow-y-auto space-y-1.5 pr-1">
                      {deal.rehabItems.map((item, idx) => (
                        <div key={idx} className="p-2 bg-zinc-950/40 border border-zinc-850 rounded-xl flex justify-between text-[10px]">
                          <div>
                            <span className="px-1.5 py-0.5 rounded-md bg-zinc-950 text-zinc-400 font-extrabold mr-1.5">{item.category}</span>
                            <span className="font-bold text-zinc-300">{item.name}</span>
                          </div>
                          <span className="font-bold text-amber-400">${item.cost.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                    {isStepGated(currentStep) && (
                      <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-xl flex items-center justify-between text-amber-300">
                        <div className="flex items-center space-x-2">
                          <AlertTriangle className="h-4 w-4" />
                          <span>Double-Check Needed: Please lock the fix-up budget so your builders can start!</span>
                        </div>
                        <button
                          onClick={() => onGateApprove(getStepGateKey(currentStep))}
                          className="px-3 py-1 bg-amber-500 text-zinc-950 font-extrabold uppercase tracking-wider text-[9px] rounded-lg cursor-pointer hover:bg-amber-400 animate-pulse"
                        >
                          Looks Good, Approve Repair Costs!
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Step 4 Content: Compliance */}
                {currentStep === 3 && (
                  <div className="space-y-3">
                    <div className="max-h-[150px] overflow-y-auto space-y-1.5 pr-1">
                      {deal.complianceChecks.map((chk, idx) => (
                        <div key={idx} className="p-2.5 bg-zinc-950/40 border border-zinc-850 rounded-xl flex items-center justify-between text-[10px]">
                          <div className="flex items-center space-x-2">
                            <span className="px-1.5 py-0.5 rounded bg-zinc-900 text-zinc-400 font-extrabold text-[8px]">{chk.category}</span>
                            <span className="font-bold text-zinc-300">{chk.label}</span>
                          </div>
                          <span className={`px-1.5 py-0.5 rounded-full font-bold text-[9px] ${
                            chk.status === "passed" ? "bg-emerald-500/15 text-emerald-400" : "bg-amber-500/15 text-amber-400"
                          }`}>
                            {chk.status}
                          </span>
                        </div>
                      ))}
                    </div>
                    {isStepGated(currentStep) && (
                      <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-xl flex items-center justify-between text-amber-300">
                        <div className="flex items-center space-x-2">
                          <AlertTriangle className="h-4 w-4" />
                          <span>Double-Check Needed: Please confirm all rules have been checked!</span>
                        </div>
                        <button
                          onClick={() => onGateApprove(getStepGateKey(currentStep))}
                          className="px-3 py-1 bg-amber-500 text-zinc-950 font-extrabold uppercase tracking-wider text-[9px] rounded-lg cursor-pointer hover:bg-amber-400 animate-pulse"
                        >
                          Looks Good, Approve Legal Rules!
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Step 5 Content: Summary & Commit */}
                {currentStep === 4 && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-zinc-950/60 p-4 rounded-xl border border-zinc-850">
                    <div>
                      <span className="text-[9px] text-zinc-500 font-extrabold uppercase">Projected Profit</span>
                      <p className="text-sm font-extrabold text-emerald-400 mt-1">${deal.underwriting.projectedProfit.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="text-[9px] text-zinc-500 font-extrabold uppercase">Projected ROI</span>
                      <p className="text-sm font-extrabold text-zinc-200 mt-1">{deal.underwriting.roi}%</p>
                    </div>
                    <div>
                      <span className="text-[9px] text-zinc-500 font-extrabold uppercase">Cash-On-Cash</span>
                      <p className="text-sm font-extrabold text-zinc-200 mt-1">{deal.underwriting.cashOnCash}%</p>
                    </div>
                    <div>
                      <span className="text-[9px] text-zinc-500 font-extrabold uppercase">Recommended Offer</span>
                      <p className="text-sm font-extrabold text-emerald-400 mt-1">${deal.underwriting.purchasePrice.toLocaleString()}</p>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </div>
        </div>

        {/* Wizard Footer controls */}
        <div className="relative z-10 flex justify-between items-center pt-3 border-t border-zinc-800/80 mt-4">
          <button
            disabled={currentStep === 0}
            onClick={() => setCurrentStep((prev) => prev - 1)}
            className="px-3.5 py-1.5 bg-zinc-950 border border-zinc-850 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-zinc-200 disabled:opacity-30 disabled:pointer-events-none transition flex items-center space-x-1 font-bold cursor-pointer"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Previous</span>
          </button>

          <div className="flex items-center space-x-2 text-[10px] text-zinc-500 font-semibold">
            <span>Sourcing Status:</span>
            <span className="px-2 py-0.5 rounded-lg bg-zinc-950 text-zinc-300 border border-zinc-850 font-bold">{deal.status}</span>
          </div>

          <button
            disabled={currentStep === steps.length - 1}
            onClick={() => setCurrentStep((prev) => prev + 1)}
            className="px-3.5 py-1.5 bg-zinc-950 border border-zinc-850 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-zinc-200 disabled:opacity-30 disabled:pointer-events-none transition flex items-center space-x-1 font-bold cursor-pointer"
          >
            <span>Next</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
