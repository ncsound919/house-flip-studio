import React, { useState } from "react";
import { 
  Sparkles, 
  TrendingUp, 
  Check, 
  X, 
  DollarSign, 
  ShieldCheck, 
  Zap, 
  Eye, 
  Server, 
  Layers, 
  ChevronDown, 
  HelpCircle,
  Percent
} from "lucide-react";
import { motion } from "motion/react";

interface Competitor {
  name: string;
  price: string;
  dealAnalysis: boolean;
  projMgmt: boolean;
  budgetTrack: boolean;
  crm: boolean;
  propData: boolean;
  autonomousSourcing: boolean;
  photoAnalysis: boolean;
  complianceNC: boolean;
  financingEngine: boolean;
  countyData: boolean;
  agentic: boolean;
  autonomous247: boolean;
}

export default function CompetitiveEdge() {
  const [activeMoat, setActiveMoat] = useState<number | null>(null);
  
  // Stacking calculator state
  const [selectedStack, setSelectedStack] = useState({
    propStream: true,
    flipperForce: true,
    resimpli: true,
    dealCheck: true
  });

  const stackTools = [
    { id: "propStream", name: "PropStream", price: 99, purpose: "Property data & lists" },
    { id: "flipperForce", name: "FlipperForce", price: 79, purpose: "Project & rehab tracker" },
    { id: "resimpli", name: "REsimpli", price: 199, purpose: "CRM & pipeline list" },
    { id: "dealCheck", name: "DealCheck", price: 29, purpose: "Deal quick analysis" }
  ];

  const currentStackCost = Object.entries(selectedStack).reduce((sum, [key, active]) => {
    if (!active) return sum;
    const tool = stackTools.find(t => t.id === key);
    return sum + (tool ? tool.price : 0);
  }, 0);

  const savings = Math.max(0, currentStackCost - 199);
  const annualSavings = savings * 12;

  const competitors: Competitor[] = [
    {
      name: "Our AI Studio App",
      price: "$199/mo",
      dealAnalysis: true,
      projMgmt: true,
      budgetTrack: true,
      crm: true,
      propData: true,
      autonomousSourcing: true,
      photoAnalysis: true,
      complianceNC: true,
      financingEngine: true,
      countyData: true,
      agentic: true,
      autonomous247: true
    },
    {
      name: "FlipperForce",
      price: "$79/mo",
      dealAnalysis: true,
      projMgmt: true,
      budgetTrack: true,
      crm: false,
      propData: false,
      autonomousSourcing: false,
      photoAnalysis: false,
      complianceNC: false,
      financingEngine: false,
      countyData: false,
      agentic: false,
      autonomous247: false
    },
    {
      name: "DealCheck",
      price: "$14/mo",
      dealAnalysis: true,
      projMgmt: false,
      budgetTrack: false,
      crm: false,
      propData: true,
      autonomousSourcing: false,
      photoAnalysis: false,
      complianceNC: false,
      financingEngine: false,
      countyData: false,
      agentic: false,
      autonomous247: false
    },
    {
      name: "REsimpli",
      price: "$199/mo",
      dealAnalysis: false,
      projMgmt: false,
      budgetTrack: false,
      crm: true,
      propData: false,
      autonomousSourcing: false,
      photoAnalysis: false,
      complianceNC: false,
      financingEngine: false,
      countyData: false,
      agentic: false,
      autonomous247: false
    },
    {
      name: "PropStream",
      price: "$99/mo",
      dealAnalysis: false,
      projMgmt: false,
      budgetTrack: false,
      crm: false,
      propData: true,
      autonomousSourcing: false,
      photoAnalysis: false,
      complianceNC: false,
      financingEngine: false,
      countyData: false,
      agentic: false,
      autonomous247: false
    },
    {
      name: "FlipLogic",
      price: "$79/mo",
      dealAnalysis: true,
      projMgmt: true,
      budgetTrack: true,
      crm: true,
      propData: false,
      autonomousSourcing: false,
      photoAnalysis: false,
      complianceNC: false,
      financingEngine: false,
      countyData: false,
      agentic: false,
      autonomous247: false
    }
  ];

  const moats = [
    {
      id: 1,
      title: "1. Autonomous Deal Sourcing (Speed Moat)",
      icon: Zap,
      desc: "Our event-driven county data pipeline works while you sleep. While other platforms require manual list building, our system pulls tax delinquents and pre-foreclosures daily, running them through deterministic evaluations so only premium deals hit your dashboard.",
      weaknessRef: "Competitor PropStream ($99/mo) has manual list-building and unreliable skip tracing."
    },
    {
      id: 2,
      title: "2. AI Property Photo Analysis (Intelligence Moat)",
      icon: Eye,
      desc: "No competitor uses computer vision to inspect property photos. Our built-in scanner detects roof condition, kitchen finish tier, and structural cracks directly from listings, turning raw visual data into immediate line-item repair costs in seconds.",
      weaknessRef: "Competitors only offer manual calculators or simple document receipt analyzers."
    },
    {
      id: 3,
      title: "3. Compliance Engine (Regulatory Moat)",
      icon: ShieldCheck,
      desc: "Enforces strict North Carolina compliance deterministically. Automatically flags wholesaling broker requirements (NC HB 797), state usury limits, deed of trust details, and local tax appraisal structures so you stay completely safe from regulatory action.",
      weaknessRef: "No competitor has state-specific legal or broker assignment compliance gates."
    },
    {
      id: 4,
      title: "4. Financing Strategy Engine (Decision Moat)",
      icon: TrendingUp,
      desc: "Evaluates 8 different financing paths (FHA, Hard Money, HELOC, Partners) instantly based on your credit score and liquid cash. It ranks them and tells you exactly what down payment you need and your total risk level.",
      weaknessRef: "Competitors only show flat cost calculators, leaving you to guess which loan fits you."
    },
    {
      id: 5,
      title: "5. Proprietary Historical Intelligence (Data Moat)",
      icon: Server,
      desc: "Every deal evaluated, comp pulled, and budget locked is recorded in your secure private database. Over time, your neighborhood history compounds, giving you a massive pricing advantage that competitors cannot buy.",
      weaknessRef: "PropTech market analysis confirms proprietary data and speed are the ultimate keys to growth."
    },
    {
      id: 6,
      title: "6. Agentic Workflow (Architecture Moat)",
      icon: Layers,
      desc: "Built on multi-agent collaboration with human-in-the-loop gates. Instead of manual data entry, specialized AI helpers cooperate to fetch data, estimate repairs, check rules, and await your one-click approval.",
      weaknessRef: "Competitors are entirely manual systems that require you to enter every field yourself."
    },
    {
      id: 7,
      title: "7. Integrated Ecosystem (Stack Moat)",
      icon: Sparkles,
      desc: "Connects your whole property stack automatically. Integrates Google Cloud compute, county database rules, and automated financing analysis into one clean visual environment.",
      weaknessRef: "Other systems require copying and pasting data across 4 or 5 different websites."
    }
  ];

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-6 backdrop-blur-md">
        <span className="text-[10px] font-extrabold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-lg uppercase tracking-wider">
          Competitive Intelligence Mode
        </span>
        <h2 className="text-xl font-extrabold text-zinc-100 mt-2">Why Our Studio Wins Every Time</h2>
        <p className="text-xs text-zinc-400 mt-1.5 leading-relaxed">
          Traditional real estate tools are just passive, manual spreadsheets. Our platform is a 24/7 autonomous employee that sources deals, analyzes photos, checks NC law compliance, and pairs financing routes instantly.
        </p>
      </div>

      {/* Grid: Moats & Cost Stacking */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Col: 7 Moats */}
        <div className="lg:col-span-7 bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-6 backdrop-blur-md space-y-4">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <h3 className="font-extrabold text-sm text-zinc-200 uppercase tracking-wider">The Seven Moats of Superiority</h3>
          </div>
          <p className="text-[11px] text-zinc-500 leading-relaxed">
            These compounding advantages are structurally impossible for traditional software platforms to copy. Click each to learn why:
          </p>

          <div className="space-y-2 pt-2">
            {moats.map((moat, i) => {
              const IconComp = moat.icon;
              const isOpen = activeMoat === i;
              return (
                <div 
                  key={moat.id}
                  className={`border rounded-2xl transition-all duration-200 overflow-hidden ${
                    isOpen ? "bg-zinc-950 border-emerald-500/30 shadow-lg" : "bg-zinc-950/30 border-zinc-850 hover:bg-zinc-950/60"
                  }`}
                >
                  <button
                    onClick={() => setActiveMoat(isOpen ? null : i)}
                    className="w-full p-4 flex items-center justify-between text-left focus:outline-hidden"
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`p-1.5 rounded-lg ${isOpen ? "bg-emerald-600 text-zinc-950" : "bg-zinc-900 text-zinc-400"}`}>
                        <IconComp className="h-4 w-4" />
                      </div>
                      <span className={`text-xs font-bold ${isOpen ? "text-emerald-400" : "text-zinc-300"}`}>{moat.title}</span>
                    </div>
                    <ChevronDown className={`h-4 w-4 text-zinc-500 transition-transform ${isOpen ? "rotate-180 text-emerald-400" : ""}`} />
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 pt-1 border-t border-zinc-850/50 text-[11px] text-zinc-300 leading-relaxed space-y-2">
                      <p>{moat.desc}</p>
                      <div className="bg-amber-500/5 border border-amber-500/10 p-2.5 rounded-xl text-[10px] text-amber-300 flex items-start space-x-1.5">
                        <span className="font-bold flex-shrink-0">⚠️ Competitor Pitfall:</span>
                        <span>{moat.weaknessRef}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Cost Saving Stack Calculator */}
        <div className="lg:col-span-5 bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-6 backdrop-blur-md space-y-4 flex flex-col justify-between h-full">
          <div>
            <div className="flex items-center space-x-2 mb-2">
              <DollarSign className="h-4 w-4 text-emerald-400" />
              <h3 className="font-extrabold text-sm text-zinc-200 uppercase tracking-wider">Software Cost Calculator</h3>
            </div>
            <p className="text-[11px] text-zinc-500 leading-relaxed">
              Flippers usually need to buy a messy, manual stack of multiple tools to do what we do. Check the tools you currently use to see your total cost vs. our flat price:
            </p>

            <div className="space-y-2 pt-4">
              {stackTools.map((tool) => {
                const isActive = (selectedStack as any)[tool.id];
                return (
                  <label
                    key={tool.id}
                    className={`flex items-center justify-between p-3 border rounded-xl cursor-pointer transition ${
                      isActive ? "bg-zinc-950/80 border-emerald-500/20 text-zinc-200" : "bg-zinc-950/20 border-zinc-900 text-zinc-500"
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        checked={isActive}
                        onChange={() => setSelectedStack({
                          ...selectedStack,
                          [tool.id]: !isActive
                        })}
                        className="rounded-md accent-emerald-500 bg-zinc-900 border-zinc-800 h-4 w-4 cursor-pointer"
                      />
                      <div>
                        <span className="text-xs font-bold block">{tool.name}</span>
                        <span className="text-[9px] text-zinc-500 block">{tool.purpose}</span>
                      </div>
                    </div>
                    <span className="text-xs font-extrabold">${tool.price}/mo</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="bg-zinc-950 p-4 border border-zinc-850 rounded-2xl space-y-3.5 mt-4">
            <div className="flex justify-between items-center text-xs">
              <span className="text-zinc-500">Traditional Stack Cost</span>
              <span className="font-extrabold text-zinc-300 line-through">${currentStackCost}/mo</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-zinc-400 font-bold">Our Flat Studio Price</span>
              <span className="font-extrabold text-emerald-400">$199/mo</span>
            </div>

            <div className="border-t border-zinc-900 pt-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase font-bold">Your Extra Cash Savings</span>
                <span className="text-xl font-extrabold text-emerald-400 block">${savings}/mo</span>
              </div>
              <div className="text-right">
                <span className="text-[9px] text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-lg border border-emerald-500/20 font-bold block">
                  Saves ${annualSavings.toLocaleString()}/year!
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Comparison Grid Table */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-6 backdrop-blur-md overflow-hidden">
        <div className="flex items-center space-x-2 mb-4">
          <Layers className="h-4 w-4 text-emerald-400" />
          <h3 className="font-extrabold text-sm text-zinc-200 uppercase tracking-wider">Studio Feature Matrix Comparison</h3>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-zinc-850">
          <table className="min-w-full divide-y divide-zinc-850 text-xs text-zinc-400">
            <thead className="bg-zinc-950 text-[10px] font-bold text-zinc-500 uppercase tracking-wider text-left">
              <tr>
                <th className="px-4 py-3">Key Feature</th>
                <th className="px-4 py-3 bg-emerald-600/10 border-x border-emerald-500/10 text-emerald-400 font-extrabold">Our Tool</th>
                <th className="px-4 py-3">FlipperForce</th>
                <th className="px-4 py-3">DealCheck</th>
                <th className="px-4 py-3">REsimpli</th>
                <th className="px-4 py-3">PropStream</th>
                <th className="px-4 py-3">FlipLogic</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900 font-semibold text-zinc-300 bg-zinc-950/20">
              <tr>
                <td className="px-4 py-3 text-zinc-400">Deal Analysis</td>
                <td className="px-4 py-3 bg-emerald-600/10 border-x border-emerald-500/10 text-emerald-400"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-zinc-400">Project Management</td>
                <td className="px-4 py-3 bg-emerald-600/10 border-x border-emerald-500/10 text-emerald-400"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-zinc-400">Budget Tracking</td>
                <td className="px-4 py-3 bg-emerald-600/10 border-x border-emerald-500/10 text-emerald-400"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-zinc-400">CRM / Pipeline Board</td>
                <td className="px-4 py-3 bg-emerald-600/10 border-x border-emerald-500/10 text-emerald-400"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-zinc-400">Property Data</td>
                <td className="px-4 py-3 bg-emerald-600/10 border-x border-emerald-500/10 text-emerald-400"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-500"><Check className="h-4 w-4" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
              </tr>
              {/* Premium Moats */}
              <tr className="bg-zinc-950/40">
                <td className="px-4 py-3 text-emerald-400 font-bold">★ Autonomous Deal Sourcing</td>
                <td className="px-4 py-3 bg-emerald-600/20 border-x border-emerald-500/20 text-emerald-400"><Sparkles className="h-4 w-4 text-emerald-400" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
              </tr>
              <tr className="bg-zinc-950/40">
                <td className="px-4 py-3 text-emerald-400 font-bold">★ AI Property Photo Analysis</td>
                <td className="px-4 py-3 bg-emerald-600/20 border-x border-emerald-500/20 text-emerald-400"><Sparkles className="h-4 w-4 text-emerald-400" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
              </tr>
              <tr className="bg-zinc-950/40">
                <td className="px-4 py-3 text-emerald-400 font-bold">★ Compliance Engine (NC)</td>
                <td className="px-4 py-3 bg-emerald-600/20 border-x border-emerald-500/20 text-emerald-400"><Sparkles className="h-4 w-4 text-emerald-400" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
              </tr>
              <tr className="bg-zinc-950/40">
                <td className="px-4 py-3 text-emerald-400 font-bold">★ Financing Strategy Engine</td>
                <td className="px-4 py-3 bg-emerald-600/20 border-x border-emerald-500/20 text-emerald-400"><Sparkles className="h-4 w-4 text-emerald-400" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
              </tr>
              <tr className="bg-zinc-950/40">
                <td className="px-4 py-3 text-emerald-400 font-bold">★ Event-Driven County Data</td>
                <td className="px-4 py-3 bg-emerald-600/20 border-x border-emerald-500/20 text-emerald-400"><Sparkles className="h-4 w-4 text-emerald-400" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
              </tr>
              <tr className="bg-zinc-950/40">
                <td className="px-4 py-3 text-emerald-400 font-bold">★ Agentic 24/7 Workflow</td>
                <td className="px-4 py-3 bg-emerald-600/20 border-x border-emerald-500/20 text-emerald-400"><Sparkles className="h-4 w-4 text-emerald-400" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
                <td className="px-4 py-3 text-zinc-600"><X className="h-4 w-4 text-zinc-700" /></td>
              </tr>
              {/* Cost Rows */}
              <tr className="border-t border-zinc-800">
                <td className="px-4 py-3 text-zinc-400">Starting Cost</td>
                <td className="px-4 py-3 bg-emerald-600/10 border-x border-emerald-500/10 font-bold text-emerald-400">$199/mo</td>
                <td className="px-4 py-3">$79/mo</td>
                <td className="px-4 py-3">$14/mo</td>
                <td className="px-4 py-3">$199/mo</td>
                <td className="px-4 py-3">$99/mo</td>
                <td className="px-4 py-3">$79/mo</td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-zinc-400">Autonomous (24/7)</td>
                <td className="px-4 py-3 bg-emerald-600/10 border-x border-emerald-500/10 font-extrabold text-emerald-400">YES</td>
                <td className="px-4 py-3 text-zinc-500">NO</td>
                <td className="px-4 py-3 text-zinc-500">NO</td>
                <td className="px-4 py-3 text-zinc-500">NO</td>
                <td className="px-4 py-3 text-zinc-500">NO</td>
                <td className="px-4 py-3 text-zinc-500">NO</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Strict Guidance Notice (What NOT to Compete On) */}
      <div className="p-5 bg-zinc-950/60 border border-zinc-850 rounded-2xl flex items-start space-x-3 text-[11px] text-zinc-500">
        <HelpCircle className="h-4 w-4 text-zinc-600 flex-shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold text-zinc-400 uppercase tracking-wide">Developer & Strategist Note</h4>
          <p className="mt-1 leading-normal">
            To keep our application lean and focused, we purposely avoid competing on brute-force data coverage or manual pricing. We integrate standard APIs (e.g., PropStream's property lists) rather than re-creating them, maintaining our edge purely on the <strong>7 proprietary moats</strong>.
          </p>
        </div>
      </div>
    </div>
  );
}
