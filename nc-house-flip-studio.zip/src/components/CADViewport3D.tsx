/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { 
  CADRoom, 
  FixProtocolNode, 
  CADTradeType, 
  HouseCADLayout 
} from '../types';
import { 
  Eye, 
  Layers, 
  Maximize2, 
  Minimize2, 
  RotateCcw, 
  Compass, 
  Box, 
  Activity, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle,
  ZoomIn,
  ZoomOut,
  Grid,
  Info,
  Camera,
  Ruler,
  Check,
  Download,
  Share2
} from 'lucide-react';

// Memory cleanup utility to prevent WebGL GPU memory leaks
function disposeHierarchy(obj: THREE.Object3D) {
  obj.traverse((child) => {
    if ((child as any).geometry) {
      (child as any).geometry.dispose();
    }
    if ((child as any).material) {
      const mat = (child as any).material;
      if (Array.isArray(mat)) {
        mat.forEach((m) => m.dispose && m.dispose());
      } else if (mat.dispose) {
        mat.dispose();
      }
    }
  });
}

interface CADViewport3DProps {
  cadLayout: HouseCADLayout;
  selectedProtocolId: string | null;
  onSelectProtocol: (protocolId: string | null) => void;
  selectedRoomId: string | null;
  onSelectRoom: (roomId: string | null) => void;
  filterTrade: CADTradeType | 'ALL';
  activeLayer: 'all' | 'foundation' | 'level1' | 'level2' | 'roof';
  renderMode: 'solid' | 'xray' | 'wireframe' | 'trade-mep';
  isAddingFixNode?: boolean;
  onPlaceFixNode?: (coords: { x: number; y: number; z: number }, roomId: string) => void;
  onOpenExportModal?: () => void;
}

export const CADViewport3D: React.FC<CADViewport3DProps> = ({
  cadLayout,
  selectedProtocolId,
  onSelectProtocol,
  selectedRoomId,
  onSelectRoom,
  filterTrade,
  activeLayer,
  renderMode,
  isAddingFixNode = false,
  onPlaceFixNode,
  onOpenExportModal
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const beaconMeshesRef = useRef<Map<string, THREE.Group>>(new Map());
  const roomMeshesRef = useRef<Map<string, THREE.Group>>(new Map());
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2());

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [hoveredProtocol, setHoveredProtocol] = useState<FixProtocolNode | null>(null);
  const [hoveredRoom, setHoveredRoom] = useState<CADRoom | null>(null);
  const [cursorCoords, setCursorCoords] = useState<{ x: number; y: number; z: number }>({ x: 0, y: 0, z: 0 });
  const [isSnapshotting, setIsSnapshotting] = useState(false);
  const [snapshotSuccess, setSnapshotSuccess] = useState(false);

  // Interactive Measurement Ruler State
  const [isMeasuring, setIsMeasuring] = useState(false);
  const [measurePointA, setMeasurePointA] = useState<THREE.Vector3 | null>(null);
  const [measurePointB, setMeasurePointB] = useState<THREE.Vector3 | null>(null);
  const [measureDistanceFt, setMeasureDistanceFt] = useState<number | null>(null);
  const measureLineMeshRef = useRef<THREE.Line | null>(null);

  // Filter fix protocols based on trade and layer
  const visibleProtocols = useMemo(() => {
    return cadLayout.fixProtocols.filter(p => {
      if (filterTrade !== 'ALL' && p.trade !== filterTrade) return false;
      const targetRoom = cadLayout.rooms.find(r => r.id === p.targetRoomId);
      if (!targetRoom) return true;
      if (activeLayer === 'foundation' && targetRoom.floorLevel !== 0) return false;
      if (activeLayer === 'level1' && targetRoom.floorLevel !== 1) return false;
      if (activeLayer === 'level2' && targetRoom.floorLevel !== 2) return false;
      if (activeLayer === 'roof' && targetRoom.floorLevel !== 3 && targetRoom.zoneType !== 'roof') return false;
      return true;
    });
  }, [cadLayout.fixProtocols, cadLayout.rooms, filterTrade, activeLayer]);

  // Setup Three.js Scene
  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x09090b); // Tailwind zinc-950
    scene.fog = new THREE.FogExp2(0x09090b, 0.012);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 1000);
    camera.position.set(45, 35, 55);
    cameraRef.current = camera;

    // 3. Renderer with preserveDrawingBuffer enabled for high-res exports
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.replaceChildren(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 + 0.1; // Allow slight crawlspace view angle
    controls.minDistance = 5;
    controls.maxDistance = 180;
    controls.target.set(0, 5, 0);
    controlsRef.current = controls;

    // 5. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(30, 50, 40);
    dirLight1.castShadow = true;
    dirLight1.shadow.mapSize.width = 2048;
    dirLight1.shadow.mapSize.height = 2048;
    dirLight1.shadow.camera.near = 0.5;
    dirLight1.shadow.camera.far = 200;
    const d = 50;
    dirLight1.shadow.camera.left = -d;
    dirLight1.shadow.camera.right = d;
    dirLight1.shadow.camera.top = d;
    dirLight1.shadow.camera.bottom = -d;
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.4); // Subtle cyan fill
    dirLight2.position.set(-30, 20, -30);
    scene.add(dirLight2);

    const groundLight = new THREE.DirectionalLight(0x10b981, 0.25); // Emerald bounce
    groundLight.position.set(0, -30, 0);
    scene.add(groundLight);

    // 6. Ground & Architectural Lot Grid
    const lotWidth = cadLayout.lotWidth || 70;
    const lotDepth = cadLayout.lotDepth || 140;

    // Lot terrain plane
    const lotGeo = new THREE.PlaneGeometry(lotWidth, lotDepth);
    const lotMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.9,
      metalness: 0.1
    });
    const lotMesh = new THREE.Mesh(lotGeo, lotMat);
    lotMesh.rotation.x = -Math.PI / 2;
    lotMesh.position.y = -2.5;
    lotMesh.receiveShadow = true;
    scene.add(lotMesh);

    // CAD Grid
    const gridHelper = new THREE.GridHelper(Math.max(lotWidth, lotDepth), 40, 0x27272a, 0x1f1f23);
    gridHelper.position.y = -2.48;
    scene.add(gridHelper);

    // Property Boundary Border
    const boundaryGeo = new THREE.BufferGeometry();
    const halfW = lotWidth / 2;
    const halfD = lotDepth / 2;
    const boundaryPoints = [
      new THREE.Vector3(-halfW, -2.4, -halfD),
      new THREE.Vector3(halfW, -2.4, -halfD),
      new THREE.Vector3(halfW, -2.4, halfD),
      new THREE.Vector3(-halfW, -2.4, halfD),
      new THREE.Vector3(-halfW, -2.4, -halfD)
    ];
    boundaryGeo.setFromPoints(boundaryPoints);
    const boundaryMat = new THREE.LineDashedMaterial({
      color: 0x10b981,
      dashSize: 2,
      gapSize: 1.5,
      linewidth: 2
    });
    const boundaryLine = new THREE.Line(boundaryGeo, boundaryMat);
    boundaryLine.computeLineDistances();
    scene.add(boundaryLine);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Animate Beacon Rings and Pulses
      beaconMeshesRef.current.forEach((group, id) => {
        const ring = group.getObjectByName('pulseRing');
        if (ring) {
          const scale = 1 + Math.sin(elapsedTime * 4 + Number(id.replace(/\D/g, '')) * 0.5) * 0.25;
          ring.scale.set(scale, scale, scale);
        }
        const pin = group.getObjectByName('pinHead');
        if (pin) {
          pin.position.y = 1.2 + Math.sin(elapsedTime * 2.5) * 0.2;
        }
      });

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    // Resize handling with ResizeObserver
    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        const { width: newW, height: newH } = entry.contentRect;
        if (newW > 0 && newH > 0) {
          camera.aspect = newW / newH;
          camera.updateProjectionMatrix();
          renderer.setSize(newW, newH);
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      if (sceneRef.current) {
        disposeHierarchy(sceneRef.current);
      }
      renderer.dispose();
      if (renderer.domElement && renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
    };
  }, [cadLayout.lotWidth, cadLayout.lotDepth]);

  // Re-build 3D Room Geometries & Walls whenever layout, layer, or renderMode changes
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Clear and dispose old room meshes
    roomMeshesRef.current.forEach((group) => {
      scene.remove(group);
      disposeHierarchy(group);
    });
    roomMeshesRef.current.clear();

    const isWireframe = renderMode === 'wireframe';
    const isXray = renderMode === 'xray';
    const isMep = renderMode === 'trade-mep';

    cadLayout.rooms.forEach((room) => {
      // Layer Visibility Filter
      if (activeLayer === 'foundation' && room.floorLevel !== 0) return;
      if (activeLayer === 'level1' && room.floorLevel !== 1) return;
      if (activeLayer === 'level2' && room.floorLevel !== 2) return;
      if (activeLayer === 'roof' && room.floorLevel !== 3 && room.zoneType !== 'roof') return;

      const roomGroup = new THREE.Group();
      roomGroup.name = `room-${room.id}`;
      (roomGroup as any).userData = { roomId: room.id, roomData: room };

      const baseElevation = room.floorLevel === 0 ? -2.2 : (room.floorLevel - 1) * 9.5;
      const wallH = room.height || 9;
      const w = room.width;
      const l = room.length;

      // 1. Floor Slab Mesh
      const floorGeo = new THREE.BoxGeometry(w, 0.4, l);
      let floorColor = 0x27272a;
      if (room.zoneType === 'kitchen') floorColor = 0x3f3f46;
      if (room.zoneType === 'bath') floorColor = 0x475569;
      if (room.zoneType === 'crawlspace') floorColor = 0x18181b;
      if (room.zoneType === 'roof') floorColor = 0x1c1917;

      const floorMat = new THREE.MeshStandardMaterial({
        color: floorColor,
        roughness: 0.7,
        metalness: 0.2,
        transparent: isXray,
        opacity: isXray ? 0.35 : 1
      });
      const floorMesh = new THREE.Mesh(floorGeo, floorMat);
      floorMesh.position.set(room.x, baseElevation + 0.2, room.z);
      floorMesh.receiveShadow = true;
      roomGroup.add(floorMesh);

      // Floor Edge Outline
      const floorEdges = new THREE.EdgesGeometry(floorGeo);
      const floorEdgeMat = new THREE.LineBasicMaterial({
        color: room.id === selectedRoomId ? 0x10b981 : 0x52525b,
        linewidth: room.id === selectedRoomId ? 2 : 1
      });
      const floorEdgeLines = new THREE.LineSegments(floorEdges, floorEdgeMat);
      floorEdgeLines.position.copy(floorMesh.position);
      roomGroup.add(floorEdgeLines);

      // 2. Perimeter Walls
      if (room.zoneType !== 'roof') {
        const wallMat = new THREE.MeshStandardMaterial({
          color: isMep ? 0x18181b : (room.id === selectedRoomId ? 0x064e3b : 0x3f3f46),
          roughness: 0.6,
          wireframe: isWireframe,
          transparent: isXray || isMep,
          opacity: isXray ? 0.25 : (isMep ? 0.15 : 0.85)
        });

        // 4 Wall Slabs with cutaway heights to let users look inside
        const wallThickness = 0.5;
        const visibleWallHeight = (isXray || isMep) ? wallH : wallH * 0.75; // cutaway 3D view

        // North Wall
        const wallNGeo = new THREE.BoxGeometry(w, visibleWallHeight, wallThickness);
        const wallN = new THREE.Mesh(wallNGeo, wallMat);
        wallN.position.set(room.x, baseElevation + visibleWallHeight / 2 + 0.4, room.z - l / 2 + wallThickness / 2);
        wallN.castShadow = true;
        wallN.receiveShadow = true;
        roomGroup.add(wallN);

        // South Wall
        const wallSGeo = new THREE.BoxGeometry(w, visibleWallHeight, wallThickness);
        const wallS = new THREE.Mesh(wallSGeo, wallMat);
        wallS.position.set(room.x, baseElevation + visibleWallHeight / 2 + 0.4, room.z + l / 2 - wallThickness / 2);
        wallS.castShadow = true;
        wallS.receiveShadow = true;
        roomGroup.add(wallS);

        // East Wall
        const wallEGeo = new THREE.BoxGeometry(wallThickness, visibleWallHeight, l - wallThickness * 2);
        const wallE = new THREE.Mesh(wallEGeo, wallMat);
        wallE.position.set(room.x + w / 2 - wallThickness / 2, baseElevation + visibleWallHeight / 2 + 0.4, room.z);
        wallE.castShadow = true;
        wallE.receiveShadow = true;
        roomGroup.add(wallE);

        // West Wall
        const wallWGeo = new THREE.BoxGeometry(wallThickness, visibleWallHeight, l - wallThickness * 2);
        const wallW = new THREE.Mesh(wallWGeo, wallMat);
        wallW.position.set(room.x - w / 2 + wallThickness / 2, baseElevation + visibleWallHeight / 2 + 0.4, room.z);
        wallW.castShadow = true;
        wallW.receiveShadow = true;
        roomGroup.add(wallW);
      } else {
        // Roof Pitch Geometry (A-Frame architectural trusses)
        const roofHeight = 7;
        const roofGeo = new THREE.ConeGeometry(Math.max(w, l) * 0.7, roofHeight, 4);
        roofGeo.rotateY(Math.PI / 4);
        const roofMat = new THREE.MeshStandardMaterial({
          color: 0x27272a,
          roughness: 0.8,
          wireframe: isWireframe,
          transparent: true,
          opacity: isXray ? 0.2 : 0.65
        });
        const roofMesh = new THREE.Mesh(roofGeo, roofMat);
        roofMesh.position.set(room.x, baseElevation + roofHeight / 2 + 0.4, room.z);
        roofMesh.castShadow = true;
        roomGroup.add(roofMesh);

        // Truss framing wireframe lines
        const trussEdges = new THREE.EdgesGeometry(roofGeo);
        const trussLine = new THREE.LineSegments(trussEdges, new THREE.LineBasicMaterial({ color: 0xf59e0b, linewidth: 2 }));
        trussLine.position.copy(roofMesh.position);
        roomGroup.add(trussLine);
      }

      // 3. Trade / MEP 3D Visual Conduits & Pipes (Rendered when in 'trade-mep' or 'xray' mode)
      if (isMep || isXray) {
        // Electrical Conduit (Orange line running across studs)
        const elecCurve = new THREE.LineCurve3(
          new THREE.Vector3(room.x - w / 2 + 1, baseElevation + 4, room.z - l / 2 + 1),
          new THREE.Vector3(room.x + w / 2 - 1, baseElevation + 4, room.z + l / 2 - 1)
        );
        const elecGeo = new THREE.TubeGeometry(elecCurve, 10, 0.12, 6, false);
        const elecMat = new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0xf97316, emissiveIntensity: 0.6 });
        const elecMesh = new THREE.Mesh(elecGeo, elecMat);
        roomGroup.add(elecMesh);

        // Plumbing Water Line (Blue PEX tube)
        if (room.zoneType === 'kitchen' || room.zoneType === 'bath' || room.zoneType === 'crawlspace') {
          const pexCurve = new THREE.LineCurve3(
            new THREE.Vector3(room.x - w / 3, baseElevation + 0.8, room.z - l / 3),
            new THREE.Vector3(room.x + w / 3, baseElevation + 2.5, room.z + l / 3)
          );
          const pexGeo = new THREE.TubeGeometry(pexCurve, 10, 0.15, 6, false);
          const pexMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x38bdf8, emissiveIntensity: 0.7 });
          const pexMesh = new THREE.Mesh(pexGeo, pexMat);
          roomGroup.add(pexMesh);
        }

        // HVAC Supply Trunk (Cyan metallic rectangular duct)
        if (room.zoneType === 'living' || room.zoneType === 'kitchen' || room.zoneType === 'roof') {
          const ductGeo = new THREE.BoxGeometry(w * 0.8, 0.8, 1.4);
          const ductMat = new THREE.MeshStandardMaterial({ color: 0x06b6d4, metalness: 0.8, roughness: 0.2 });
          const ductMesh = new THREE.Mesh(ductGeo, ductMat);
          ductMesh.position.set(room.x, baseElevation + wallH - 0.6, room.z);
          roomGroup.add(ductMesh);
        }
      }

      scene.add(roomGroup);
      roomMeshesRef.current.set(room.id, roomGroup);
    });
  }, [cadLayout.rooms, activeLayer, renderMode, selectedRoomId]);

  // Re-build 3D Fix Protocol Beacon Pins
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Clear and dispose old beacon groups
    beaconMeshesRef.current.forEach((group) => {
      scene.remove(group);
      disposeHierarchy(group);
    });
    beaconMeshesRef.current.clear();

    visibleProtocols.forEach((protocol) => {
      const isSelected = protocol.id === selectedProtocolId;
      const beaconGroup = new THREE.Group();
      beaconGroup.name = `beacon-${protocol.id}`;
      (beaconGroup as any).userData = { protocolId: protocol.id, protocolData: protocol };

      // Pin Color according to Severity and Trade
      let beaconColor = 0xf59e0b; // Amber Moderate
      if (protocol.severity === 'critical') beaconColor = 0xef4444; // Red Critical
      if (protocol.status === 'completed') beaconColor = 0x10b981; // Green Done
      if (isSelected) beaconColor = 0x38bdf8; // Cyan Selected

      // 1. Vertical Anchor Line
      const lineGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.5, 8);
      const lineMat = new THREE.MeshBasicMaterial({ color: beaconColor, transparent: true, opacity: 0.8 });
      const lineMesh = new THREE.Mesh(lineGeo, lineMat);
      lineMesh.position.y = 1.25;
      beaconGroup.add(lineMesh);

      // 2. Glowing Pin Head Sphere
      const sphereGeo = new THREE.SphereGeometry(0.65, 16, 16);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: beaconColor,
        emissive: beaconColor,
        emissiveIntensity: isSelected ? 0.9 : 0.6,
        roughness: 0.2,
        metalness: 0.5
      });
      const pinHead = new THREE.Mesh(sphereGeo, sphereMat);
      pinHead.name = 'pinHead';
      pinHead.position.y = 2.5;
      beaconGroup.add(pinHead);

      // 3. Pulsing Horizontal Ring
      const ringGeo = new THREE.RingGeometry(0.7, 1.1, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: beaconColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.65
      });
      const pulseRing = new THREE.Mesh(ringGeo, ringMat);
      pulseRing.name = 'pulseRing';
      pulseRing.rotation.x = Math.PI / 2;
      pulseRing.position.y = 0.1;
      beaconGroup.add(pulseRing);

      // Position beacon in 3D world space
      beaconGroup.position.set(protocol.position.x, protocol.position.y, protocol.position.z);
      scene.add(beaconGroup);
      beaconMeshesRef.current.set(protocol.id, beaconGroup);
    });
  }, [visibleProtocols, selectedProtocolId]);

  // Smooth camera pan to selected protocol
  useEffect(() => {
    if (!selectedProtocolId || !controlsRef.current || !cameraRef.current) return;
    const selected = cadLayout.fixProtocols.find(p => p.id === selectedProtocolId);
    if (!selected) return;

    const targetPos = new THREE.Vector3(selected.position.x, selected.position.y, selected.position.z);
    controlsRef.current.target.copy(targetPos);
  }, [selectedProtocolId, cadLayout.fixProtocols]);

  // Update 3D Measurement Ruler Line in scene
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (measureLineMeshRef.current) {
      scene.remove(measureLineMeshRef.current);
      disposeHierarchy(measureLineMeshRef.current);
      measureLineMeshRef.current = null;
    }

    if (measurePointA && measurePointB) {
      const lineGeo = new THREE.BufferGeometry().setFromPoints([measurePointA, measurePointB]);
      const lineMat = new THREE.LineBasicMaterial({
        color: 0x10b981,
        linewidth: 3,
        transparent: true,
        opacity: 0.9
      });
      const line = new THREE.Line(lineGeo, lineMat);
      scene.add(line);
      measureLineMeshRef.current = line;
    }
  }, [measurePointA, measurePointB]);

  // Raycasting Click & Hover Handler
  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;
    const rect = mountRef.current.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    raycasterRef.current.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    // If in Measurement Ruler mode, handle Point A and Point B placement
    if (isMeasuring) {
      const intersects = raycasterRef.current.intersectObjects(sceneRef.current.children, true);
      const hit = intersects.find(i => i.point.y > -2.5 && i.point.y < 35);
      if (hit) {
        const pt = new THREE.Vector3(
          Math.round(hit.point.x * 10) / 10,
          Math.round(hit.point.y * 10) / 10,
          Math.round(hit.point.z * 10) / 10
        );

        if (!measurePointA) {
          setMeasurePointA(pt);
          setMeasurePointB(null);
          setMeasureDistanceFt(null);
        } else {
          setMeasurePointB(pt);
          const dist = measurePointA.distanceTo(pt);
          setMeasureDistanceFt(Math.round(dist * 10) / 10);
        }
        return;
      }
    }

    // If in "Add Fix Node" mode, raycast against floor slabs and report placement
    if (isAddingFixNode && onPlaceFixNode) {
      const intersects = raycasterRef.current.intersectObjects(sceneRef.current.children, true);
      const hit = intersects.find(i => i.point.y > -2.5 && i.point.y < 35);
      if (hit) {
        // Find which room was clicked
        let targetRoomId = cadLayout.rooms[0].id;
        for (const room of cadLayout.rooms) {
          const rx = room.x;
          const rz = room.z;
          const halfW = room.width / 2;
          const halfL = room.length / 2;
          if (hit.point.x >= rx - halfW && hit.point.x <= rx + halfW && hit.point.z >= rz - halfL && hit.point.z <= rz + halfL) {
            targetRoomId = room.id;
            break;
          }
        }
        onPlaceFixNode({ x: Math.round(hit.point.x), y: Math.round(hit.point.y), z: Math.round(hit.point.z) }, targetRoomId);
        return;
      }
    }

    // Check if clicked a Beacon Pin
    const beaconObjects: THREE.Object3D[] = [];
    beaconMeshesRef.current.forEach(group => {
      group.traverse(child => {
        if (child instanceof THREE.Mesh) beaconObjects.push(child);
      });
    });

    const beaconHits = raycasterRef.current.intersectObjects(beaconObjects, false);
    if (beaconHits.length > 0) {
      let current: THREE.Object3D | null = beaconHits[0].object;
      while (current && !(current as any).userData?.protocolId) {
        current = current.parent;
      }
      if (current && (current as any).userData?.protocolId) {
        const pId = (current as any).userData.protocolId;
        onSelectProtocol(pId);
        return;
      }
    }

    // Check if clicked a Room Floor / Wall
    const roomObjects: THREE.Object3D[] = [];
    roomMeshesRef.current.forEach(group => {
      group.traverse(child => {
        if (child instanceof THREE.Mesh) roomObjects.push(child);
      });
    });

    const roomHits = raycasterRef.current.intersectObjects(roomObjects, false);
    if (roomHits.length > 0) {
      let current: THREE.Object3D | null = roomHits[0].object;
      while (current && !(current as any).userData?.roomId) {
        current = current.parent;
      }
      if (current && (current as any).userData?.roomId) {
        const rId = (current as any).userData.roomId;
        onSelectRoom(rId);
      }
    } else {
      // Clicked background, clear selection
      onSelectProtocol(null);
      onSelectRoom(null);
    }
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;
    const rect = mountRef.current.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    mouseRef.current.set(x, y);

    raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);

    // Compute live 3D coordinates on ground or floor plane
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const targetPoint = new THREE.Vector3();
    raycasterRef.current.ray.intersectPlane(plane, targetPoint);
    if (targetPoint) {
      setCursorCoords({
        x: Math.round(targetPoint.x * 10) / 10,
        y: Math.round(targetPoint.y * 10) / 10,
        z: Math.round(targetPoint.z * 10) / 10
      });
    }

    // Hover detection on beacons
    const beaconObjects: THREE.Object3D[] = [];
    beaconMeshesRef.current.forEach(group => {
      group.traverse(child => {
        if (child instanceof THREE.Mesh) beaconObjects.push(child);
      });
    });

    const beaconHits = raycasterRef.current.intersectObjects(beaconObjects, false);
    if (beaconHits.length > 0) {
      let current: THREE.Object3D | null = beaconHits[0].object;
      while (current && !(current as any).userData?.protocolData) {
        current = current.parent;
      }
      if (current && (current as any).userData?.protocolData) {
        setHoveredProtocol((current as any).userData.protocolData);
        return;
      }
    } else {
      setHoveredProtocol(null);
    }
  };

  // Capture High-Resolution 3D Snapshot with Architectural Title Block
  const handleCaptureSnapshot = () => {
    if (!rendererRef.current || !sceneRef.current || !cameraRef.current) return;
    setIsSnapshotting(true);

    try {
      rendererRef.current.render(sceneRef.current, cameraRef.current);
      const dataURL = rendererRef.current.domElement.toDataURL('image/png');

      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setIsSnapshotting(false);
          return;
        }

        // Draw original 3D render
        ctx.drawImage(img, 0, 0);

        // Draw architectural bottom banner
        const barH = 70;
        ctx.fillStyle = 'rgba(9, 9, 11, 0.9)';
        ctx.fillRect(0, canvas.height - barH, canvas.width, barH);

        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(0, canvas.height - barH);
        ctx.lineTo(canvas.width, canvas.height - barH);
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 16px monospace';
        ctx.fillText(`${cadLayout.styleName.toUpperCase()} • 3D SPATIAL CAD SNAPSHOT`, 20, canvas.height - barH + 28);

        ctx.fillStyle = '#a1a1aa';
        ctx.font = '12px monospace';
        ctx.fillText(`TOTAL SQFT: ${cadLayout.totalSqft} • ZONES: ${cadLayout.rooms.length} • FIX PROTOCOLS: ${visibleProtocols.length} • NCRC 2024`, 20, canvas.height - barH + 50);

        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 12px monospace';
        ctx.fillText(`DATE: ${new Date().toLocaleDateString()}`, canvas.width - 200, canvas.height - barH + 38);

        // Trigger Download
        const link = document.createElement('a');
        link.download = `3D_CAD_Snapshot_${Date.now()}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();

        setSnapshotSuccess(true);
        setIsSnapshotting(false);
        setTimeout(() => setSnapshotSuccess(false), 2500);
      };
      img.src = dataURL;
    } catch (err) {
      console.error('Failed to capture snapshot', err);
      setIsSnapshotting(false);
    }
  };

  // Camera Presets
  const setCameraPreset = (preset: 'iso' | 'top' | 'front' | 'crawlspace') => {
    if (!cameraRef.current || !controlsRef.current) return;
    const cam = cameraRef.current;
    const ctrl = controlsRef.current;

    if (preset === 'iso') {
      cam.position.set(45, 35, 55);
      ctrl.target.set(0, 5, 0);
    } else if (preset === 'top') {
      cam.position.set(0, 85, 0.1);
      ctrl.target.set(0, 0, 0);
    } else if (preset === 'front') {
      cam.position.set(0, 10, 60);
      ctrl.target.set(0, 6, 0);
    } else if (preset === 'crawlspace') {
      cam.position.set(25, -1, 30);
      ctrl.target.set(0, -2, 0);
    }
  };

  return (
    <div className={`relative w-full rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-950 flex flex-col ${isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen' : 'h-[520px] lg:h-[580px]'}`}>
      {/* 3D WebGL Canvas Container */}
      <div 
        ref={mountRef} 
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        className={`w-full h-full cursor-grab active:cursor-grabbing ${isAddingFixNode || isMeasuring ? 'cursor-crosshair' : ''}`}
      />

      {/* Top Floating Heads-Up Display (HUD) */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10 gap-2">
        {/* Spatial Coordinate Beacon & Model Info */}
        <div className="flex items-center space-x-2 bg-zinc-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-zinc-800 pointer-events-auto shadow-lg">
          <Box className="h-4 w-4 text-emerald-400" />
          <span className="text-xs font-extrabold text-zinc-100 uppercase tracking-wide">
            {cadLayout.styleName}
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">
            {cadLayout.totalSqft} SQFT • {cadLayout.rooms.length} ZONES
          </span>
        </div>

        {/* Camera Viewport Angles & Tools */}
        <div className="flex items-center space-x-1.5 bg-zinc-900/80 backdrop-blur-md p-1 rounded-xl border border-zinc-800 pointer-events-auto shadow-lg">
          <button
            onClick={() => setCameraPreset('iso')}
            className="px-2.5 py-1 rounded-lg text-[10px] font-bold text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
            title="Isometric 3D Perspective"
          >
            3D Iso
          </button>
          <button
            onClick={() => setCameraPreset('top')}
            className="px-2.5 py-1 rounded-lg text-[10px] font-bold text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
            title="Top-Down 2D CAD Blueprint Plan"
          >
            2D Plan
          </button>
          <button
            onClick={() => setCameraPreset('front')}
            className="px-2.5 py-1 rounded-lg text-[10px] font-bold text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
            title="Front Elevation Cam"
          >
            Elevation
          </button>
          <button
            onClick={() => setCameraPreset('crawlspace')}
            className="px-2.5 py-1 rounded-lg text-[10px] font-bold text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
            title="Foundation & Crawlspace Inspector"
          >
            Crawlspace
          </button>

          <div className="w-[1px] h-4 bg-zinc-800 mx-0.5" />

          {/* Measure Tool (Ruler) */}
          <button
            onClick={() => {
              setIsMeasuring(!isMeasuring);
              setMeasurePointA(null);
              setMeasurePointB(null);
              setMeasureDistanceFt(null);
            }}
            className={`p-1.5 rounded-lg text-[10px] font-bold transition cursor-pointer flex items-center space-x-1 ${
              isMeasuring 
                ? 'bg-emerald-600 text-white' 
                : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800'
            }`}
            title="Interactive Measurement Ruler (Click 2 points in 3D space)"
          >
            <Ruler className="h-3.5 w-3.5" />
          </button>

          {/* Snapshot Camera */}
          <button
            onClick={handleCaptureSnapshot}
            disabled={isSnapshotting}
            className={`p-1.5 rounded-lg text-[10px] font-bold transition cursor-pointer flex items-center space-x-1 ${
              snapshotSuccess 
                ? 'bg-emerald-600 text-white' 
                : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800'
            }`}
            title="Capture High-Resolution 3D Snapshot with Title Block"
          >
            {snapshotSuccess ? <Check className="h-3.5 w-3.5" /> : <Camera className="h-3.5 w-3.5" />}
          </button>

          {/* Open Contractor Visual Export Studio */}
          {onOpenExportModal && (
            <button
              onClick={onOpenExportModal}
              className="px-2 py-1 bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 rounded-lg text-[10px] font-extrabold transition cursor-pointer flex items-center space-x-1"
              title="Open Contractor Blueprint & Work Order Export Studio"
            >
              <Download className="h-3 w-3" />
              <span>Exports</span>
            </button>
          )}

          <div className="w-[1px] h-4 bg-zinc-800 mx-0.5" />

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-lg transition cursor-pointer"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen 3D CAD Studio'}
          >
            {isFullscreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
          </button>
        </div>
      </div>

      {/* Measurement HUD Overlay */}
      {isMeasuring && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 bg-zinc-900/90 text-zinc-100 px-4 py-2 rounded-xl text-xs font-mono border border-emerald-500/40 shadow-2xl flex items-center space-x-3 pointer-events-auto z-20">
          <Ruler className="h-4 w-4 text-emerald-400" />
          <span>
            {!measurePointA 
              ? 'Click Point A on any wall/slab' 
              : !measurePointB 
                ? 'Click Point B to complete span measurement' 
                : `Span Distance: ${measureDistanceFt} ft (${Math.floor(measureDistanceFt!)}' ${Math.round((measureDistanceFt! % 1) * 12)}")`}
          </span>
          {measurePointA && (
            <button
              onClick={() => {
                setMeasurePointA(null);
                setMeasurePointB(null);
                setMeasureDistanceFt(null);
              }}
              className="px-2 py-0.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[10px] font-bold"
            >
              Reset
            </button>
          )}
        </div>
      )}

      {/* Adding Fix Node Prompt Banner */}
      {isAddingFixNode && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 bg-emerald-600/90 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-xl border border-emerald-400/40 flex items-center space-x-2 animate-bounce pointer-events-none z-20">
          <Sparkles className="h-4 w-4" />
          <span>Click anywhere in the 3D house model to place the new repair node</span>
        </div>
      )}

      {/* Hover Protocol Tooltip HUD */}
      {hoveredProtocol && (
        <div className="absolute bottom-12 left-4 bg-zinc-900/95 backdrop-blur-md p-3 rounded-xl border border-zinc-700 shadow-2xl pointer-events-none z-20 max-w-xs space-y-1">
          <div className="flex items-center space-x-2">
            <span className={`w-2 h-2 rounded-full ${hoveredProtocol.severity === 'critical' ? 'bg-red-400 animate-ping' : 'bg-amber-400'}`} />
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-400">
              {hoveredProtocol.trade}
            </span>
          </div>
          <p className="text-xs font-bold text-zinc-100">{hoveredProtocol.title}</p>
          <p className="text-[10px] text-zinc-400 font-mono">
            Est: ${hoveredProtocol.estimatedCost.toLocaleString()} • {hoveredProtocol.executionSteps.length} Protocol Steps
          </p>
        </div>
      )}

      {/* Bottom Live CAD Spatial Grid Status Bar */}
      <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between pointer-events-none text-[10px] font-mono text-zinc-500">
        <div className="flex items-center space-x-3 bg-zinc-950/80 px-2.5 py-1 rounded-lg border border-zinc-850 pointer-events-auto">
          <span>X: {cursorCoords.x}'</span>
          <span>Y: {cursorCoords.y}'</span>
          <span>Z: {cursorCoords.z}'</span>
          <span className="text-zinc-600">|</span>
          <span className="text-emerald-500 font-bold">{visibleProtocols.length} Active Spatial Fix Beacons</span>
        </div>
        <div className="hidden sm:flex items-center space-x-2 bg-zinc-950/80 px-2.5 py-1 rounded-lg border border-zinc-850 pointer-events-auto">
          <span>Left-Drag: Orbit</span>
          <span>•</span>
          <span>Right-Drag: Pan</span>
          <span>•</span>
          <span>Scroll: Zoom</span>
        </div>
      </div>
    </div>
  );
};
