/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HouseCADLayout, PropertyDeal, CADRoom, CADZoneType } from '../types';
import { 
  Building, 
  Layers, 
  Sparkles, 
  Upload, 
  FileCode, 
  Check, 
  X, 
  ArrowRight, 
  Home, 
  Maximize2,
  Box
} from 'lucide-react';
import { generateCADLayoutForDeal } from '../lib/cadLayoutGenerator';

interface CADLayoutIngestModalProps {
  deal: PropertyDeal;
  currentLayout: HouseCADLayout;
  onSaveLayout: (newLayout: HouseCADLayout) => void;
  onClose: () => void;
}

const NC_ARCHITECTURAL_PRESETS = [
  {
    id: 'charlotte-ranch',
    name: 'Charlotte 1950s Brick Ranch',
    description: 'Classic 1-story open ranch with brick foundation, central crawlspace, and 3 bedrooms.',
    sqft: 1546,
    foundation: 'crawlspace' as const,
    stories: 1,
    roomsCount: 5
  },
  {
    id: 'raleigh-colonial',
    name: 'Raleigh 2-Story Center-Hall Colonial',
    description: 'Traditional 2-story layout with primary suite downstairs, 2 guest suites up, and attic truss system.',
    sqft: 2450,
    foundation: 'crawlspace' as const,
    stories: 2,
    roomsCount: 7
  },
  {
    id: 'durham-craftsman',
    name: 'Durham Historic Craftsman Bungalow',
    description: 'Distinctive open porch, heavy timber roof pitch, heart pine flooring, and high ceilings.',
    sqft: 1820,
    foundation: 'crawlspace' as const,
    stories: 1,
    roomsCount: 6
  },
  {
    id: 'greensboro-farmhouse',
    name: 'Greensboro Modern Farmhouse',
    description: 'Contemporary wide-span great room, cathedral ceiling, slab foundation, and dual en-suites.',
    sqft: 2150,
    foundation: 'slab' as const,
    stories: 1,
    roomsCount: 6
  },
  {
    id: 'asheville-split',
    name: 'Asheville Mountain Split-Level / Basement',
    description: 'Sloped lot walkout basement, upper living deck, steep 8/12 roof pitch, and structural retaining walls.',
    sqft: 2280,
    foundation: 'basement' as const,
    stories: 2,
    roomsCount: 7
  }
];

export const CADLayoutIngestModal: React.FC<CADLayoutIngestModalProps> = ({
  deal,
  currentLayout,
  onSaveLayout,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'preset' | 'dimensions' | 'blueprint-ai'>('preset');
  const [selectedPresetId, setSelectedPresetId] = useState('charlotte-ranch');
  
  // Custom Dimension Ingest state
  const [customSqft, setCustomSqft] = useState(deal.sqft || 1600);
  const [customLotWidth, setCustomLotWidth] = useState(currentLayout.lotWidth || 65);
  const [customLotDepth, setCustomLotDepth] = useState(currentLayout.lotDepth || 140);
  const [customFoundation, setCustomFoundation] = useState<'crawlspace' | 'slab' | 'basement'>('crawlspace');
  const [customStories, setCustomStories] = useState(deal.sqft > 2000 ? 2 : 1);
  const [customPrompt, setCustomPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Ingest preset
  const handleApplyPreset = (presetId: string) => {
    const preset = NC_ARCHITECTURAL_PRESETS.find(p => p.id === presetId);
    if (!preset) return;

    const mockDeal: PropertyDeal = {
      ...deal,
      sqft: preset.sqft,
      propertyType: preset.name
    };

    const newLayout = generateCADLayoutForDeal(mockDeal);
    newLayout.styleName = preset.name;
    newLayout.foundationType = preset.foundation;
    onSaveLayout(newLayout);
    onClose();
  };

  // Ingest custom dimensions
  const handleApplyCustomDimensions = () => {
    const mockDeal: PropertyDeal = {
      ...deal,
      sqft: customSqft,
      propertyType: `${deal.city} Custom Layout (${customStories}-Story)`
    };

    const newLayout = generateCADLayoutForDeal(mockDeal);
    newLayout.lotWidth = customLotWidth;
    newLayout.lotDepth = customLotDepth;
    newLayout.foundationType = customFoundation;
    onSaveLayout(newLayout);
    onClose();
  };

  // Ingest via AI blueprint prompt / room schedule text
  const handleIngestAIBlueprint = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const mockDeal: PropertyDeal = {
        ...deal,
        sqft: customSqft,
        propertyType: customPrompt ? `Custom Blueprint: ${customPrompt.slice(0, 30)}...` : deal.propertyType
      };

      const newLayout = generateCADLayoutForDeal(mockDeal);
      newLayout.lotWidth = customLotWidth;
      newLayout.lotDepth = customLotDepth;
      newLayout.foundationType = customFoundation;
      onSaveLayout(newLayout);
      setIsProcessing(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl animate-fadeIn">
        {/* Modal Header */}
        <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-2xl">
              <Box className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-zinc-100 uppercase tracking-tight">
                Ingest House Layout & 3D Geometry
              </h2>
              <p className="text-xs text-zinc-400">
                Load architectural blueprints, select NC regional housing styles, or customize room dimensions.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Ingest Method Tabs */}
        <div className="flex border-b border-zinc-800 px-6 bg-zinc-950/40">
          <button
            onClick={() => setActiveTab('preset')}
            className={`py-3 px-4 text-xs font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'preset'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            NC Architectural Presets
          </button>
          <button
            onClick={() => setActiveTab('dimensions')}
            className={`py-3 px-4 text-xs font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'dimensions'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Custom Dimension Modeler
          </button>
          <button
            onClick={() => setActiveTab('blueprint-ai')}
            className={`py-3 px-4 text-xs font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'blueprint-ai'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            AI Blueprint / Schedule Ingest
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'preset' && (
            <div className="space-y-3">
              <p className="text-xs text-zinc-400">
                Select an authentic North Carolina construction style matching <strong>{deal.address}</strong>:
              </p>

              <div className="space-y-2.5">
                {NC_ARCHITECTURAL_PRESETS.map((preset) => {
                  const isSelected = selectedPresetId === preset.id;
                  return (
                    <div
                      key={preset.id}
                      onClick={() => setSelectedPresetId(preset.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-emerald-950/30 border-emerald-500/50 shadow-md shadow-emerald-500/5'
                          : 'bg-zinc-950/40 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <Home className={`h-4 w-4 ${isSelected ? 'text-emerald-400' : 'text-zinc-500'}`} />
                          <h3 className="text-xs font-extrabold text-zinc-100">{preset.name}</h3>
                          <span className="text-[10px] font-mono text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded-full border border-zinc-800">
                            {preset.sqft} SQFT
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-400">{preset.description}</p>
                      </div>

                      <div className="flex items-center space-x-3 shrink-0 ml-4">
                        <div className="text-right text-[10px] text-zinc-500 font-mono hidden sm:block">
                          <div>{preset.stories} Stories</div>
                          <div className="capitalize">{preset.foundation}</div>
                        </div>
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                          isSelected ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-zinc-700'
                        }`}>
                          {isSelected && <Check className="h-3 w-3" />}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'dimensions' && (
            <div className="space-y-4">
              <p className="text-xs text-zinc-400">
                Configure primary building envelope parameters and structural boundary limits:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-300">Total Finished SqFt</label>
                  <input
                    type="number"
                    value={customSqft}
                    onChange={(e) => setCustomSqft(Number(e.target.value))}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-300">Number of Stories</label>
                  <select
                    value={customStories}
                    onChange={(e) => setCustomStories(Number(e.target.value))}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-100 focus:outline-none focus:border-emerald-500"
                  >
                    <option value={1}>1-Story Ranch / Bungalow</option>
                    <option value={2}>2-Story Multi-Level</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-300">Foundation Substructure</label>
                  <select
                    value={customFoundation}
                    onChange={(e) => setCustomFoundation(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-100 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="crawlspace">Crawlspace with Masonry Piers</option>
                    <option value="slab">Monolithic Concrete Slab</option>
                    <option value="basement">Full Poured Basement</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-300">Lot Frontage & Depth (ft)</label>
                  <div className="flex space-x-2">
                    <input
                      type="number"
                      value={customLotWidth}
                      onChange={(e) => setCustomLotWidth(Number(e.target.value))}
                      placeholder="Width"
                      className="w-1/2 bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-100 focus:outline-none focus:border-emerald-500"
                    />
                    <input
                      type="number"
                      value={customLotDepth}
                      onChange={(e) => setCustomLotDepth(Number(e.target.value))}
                      placeholder="Depth"
                      className="w-1/2 bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-100 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'blueprint-ai' && (
            <div className="space-y-3">
              <p className="text-xs text-zinc-400">
                Paste an architect room schedule, appraiser floor sketch description, or contractor layout notes:
              </p>
              <textarea
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                placeholder="Example: Main level open kitchen 14x16 with central quartz island, great room 20x18 with fireplace, primary bed 16x14 with walk-in closet and en-suite tile shower, crawlspace foundation with 12-mil vapor barrier..."
                rows={5}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 text-xs text-zinc-200 focus:outline-none focus:border-emerald-500"
              />
              <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-xl text-xs text-emerald-400 flex items-center space-x-2">
                <Sparkles className="h-4 w-4 shrink-0" />
                <span>AI Layout Engine will automatically map rooms and spatial fix nodes into 3D CAD space.</span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-6 border-t border-zinc-800 flex items-center justify-between bg-zinc-950/40">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-zinc-400 hover:text-zinc-200 transition cursor-pointer"
          >
            Cancel
          </button>

          {activeTab === 'preset' && (
            <button
              onClick={() => handleApplyPreset(selectedPresetId)}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold shadow-lg transition flex items-center space-x-1.5 cursor-pointer"
            >
              <span>Ingest Selected Preset Layout</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          )}

          {activeTab === 'dimensions' && (
            <button
              onClick={handleApplyCustomDimensions}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold shadow-lg transition flex items-center space-x-1.5 cursor-pointer"
            >
              <span>Generate 3D CAD Geometry</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          )}

          {activeTab === 'blueprint-ai' && (
            <button
              onClick={handleIngestAIBlueprint}
              disabled={isProcessing}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold shadow-lg transition flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
            >
              <Sparkles className={`h-4 w-4 ${isProcessing ? 'animate-spin' : ''}`} />
              <span>{isProcessing ? 'Synthesizing 3D Model...' : 'Generate 3D Model from Notes'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
