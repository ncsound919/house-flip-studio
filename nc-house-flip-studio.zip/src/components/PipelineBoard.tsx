/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";
import { 
  Plus, 
  MapPin, 
  Home, 
  TrendingUp, 
  DollarSign, 
  Trash2,
  Calendar,
  AlertTriangle,
  Zap
} from "lucide-react";
import { PropertyDeal, DealStatus } from "../types";

interface PipelineBoardProps {
  deals: PropertyDeal[];
  selectedDealId: string | null;
  onSelectDeal: (dealId: string) => void;
  onAddDeal: (status: DealStatus) => void;
  onDeleteDeal: (dealId: string, e: React.MouseEvent) => void;
  onLaunchAutonomousPipeline?: (deal: PropertyDeal) => void;
}

const COLUMNS: { status: DealStatus; label: string; color: string; bgColor: string }[] = [
  { status: "Lead Ingest", label: "1. Just Found", color: "border-t-sky-500 text-sky-400", bgColor: "bg-zinc-950/40" },
  { status: "Property Enrichment", label: "2. Info Found", color: "border-t-teal-500 text-teal-400", bgColor: "bg-zinc-950/40" },
  { status: "ARV & Comps", label: "3. Price Comps", color: "border-t-emerald-500 text-emerald-400", bgColor: "bg-zinc-950/40" },
  { status: "Rehab & Estimating", label: "4. Fix-up Costs", color: "border-t-amber-500 text-amber-400", bgColor: "bg-zinc-950/40" },
  { status: "Underwriting", label: "5. Money Math", color: "border-t-indigo-500 text-indigo-400", bgColor: "bg-zinc-950/40" },
  { status: "Compliance & Offer", label: "6. Check Laws", color: "border-t-purple-500 text-purple-400", bgColor: "bg-zinc-950/40" },
  { status: "Renovation", label: "7. Doing Repairs", color: "border-t-pink-500 text-pink-400", bgColor: "bg-zinc-950/40" },
  { status: "Listed", label: "8. For Sale", color: "border-t-orange-500 text-orange-400", bgColor: "bg-zinc-950/40" },
  { status: "Completed", label: "9. All Done!", color: "border-t-zinc-500 text-zinc-400", bgColor: "bg-zinc-950/40" }
];

export default function PipelineBoard({
  deals,
  selectedDealId,
  onSelectDeal,
  onAddDeal,
  onDeleteDeal,
  onLaunchAutonomousPipeline
}: PipelineBoardProps) {
  return (
    <div id="pipeline-board-container" className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-extrabold text-zinc-100 uppercase tracking-wider">My House Pipeline</h2>
          <p className="text-xs text-zinc-500 mt-0.5">See all your house opportunities and their status from start to finish.</p>
        </div>
        <div className="flex space-x-2">
          <button 
            id="scout-trigger-btn"
            onClick={() => onAddDeal("Lead Ingest")}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-zinc-800 border border-zinc-700 hover:bg-zinc-750 text-zinc-200 font-semibold rounded-xl text-xs shadow-xs transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Add a House</span>
          </button>
        </div>
      </div>

      {/* Horizontal Scroll Area */}
      <div className="flex-1 overflow-x-auto pb-4 flex space-x-4 pr-4">
        {COLUMNS.map((col) => {
          const columnDeals = deals.filter((d) => d.status === col.status);
          return (
            <div
              key={col.status}
              className={`flex-shrink-0 w-80 rounded-2xl border border-zinc-800/80 ${col.bgColor} flex flex-col p-4 shadow-sm`}
            >
              {/* Header */}
              <div className={`flex items-center justify-between pb-2.5 mb-3 border-t-2 ${col.color}`}>
                <div className="flex items-center space-x-1.5 mt-2.5">
                  <span className="font-extrabold text-xs text-zinc-200 uppercase tracking-wide">{col.label}</span>
                  <span className="px-2 py-0.5 text-[10px] font-extrabold bg-zinc-900 text-zinc-400 rounded-full border border-zinc-800">
                    {columnDeals.length}
                  </span>
                </div>
                <button
                  onClick={() => onAddDeal(col.status)}
                  className="p-1 hover:bg-zinc-800 hover:text-zinc-200 rounded-lg text-zinc-500 transition mt-2.5 cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              {/* Cards Container */}
              <div className="flex-1 overflow-y-auto space-y-3 min-h-[300px] max-h-[500px] pr-1">
                {columnDeals.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center p-6 border border-dashed border-zinc-800 rounded-xl text-zinc-500 text-center">
                    <Home className="h-8 w-8 text-zinc-700 mb-1.5" />
                    <span className="text-[11px] font-medium">No active deals here.</span>
                  </div>
                ) : (
                  columnDeals.map((deal) => {
                    const isSelected = selectedDealId === deal.id;
                    const hasAnalyseData = deal.underwriting.arv > 0;
                    
                    return (
                      <motion.div
                        key={deal.id}
                        layoutId={deal.id}
                        onClick={() => onSelectDeal(deal.id)}
                        className={`group bg-zinc-900 rounded-2xl border p-4 shadow-sm cursor-pointer hover:bg-zinc-850/80 transition-all duration-300 relative overflow-hidden ${
                          isSelected 
                            ? 'border-emerald-500 ring-2 ring-emerald-500/20 scale-102' 
                            : 'border-zinc-800/80 hover:border-zinc-700'
                        }`}
                      >
                        {deal.imageUrl && (
                          <div className="w-full h-24 rounded-xl overflow-hidden mb-3 relative bg-zinc-950">
                            <img 
                              src={deal.imageUrl} 
                              alt={deal.address} 
                              className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute top-2 right-2 bg-zinc-950/90 backdrop-blur-xs px-2 py-0.5 rounded text-[10px] text-zinc-200 font-extrabold border border-zinc-850">
                              {deal.yearBuilt}
                            </div>
                          </div>
                        )}

                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-1.5 mb-1">
                              <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                {deal.mlsNumber || "MLS Verified"}
                              </span>
                              {deal.parcelId && (
                                <span className="px-1.5 py-0.5 rounded text-[9px] font-medium bg-zinc-950 text-zinc-400 border border-zinc-800">
                                  {deal.parcelId}
                                </span>
                              )}
                            </div>
                            <h3 className="font-bold text-zinc-100 text-xs leading-snug group-hover:text-emerald-400 transition-colors">
                              {deal.address}
                            </h3>
                            <div className="flex items-center text-[10px] text-zinc-400 mt-0.5">
                              <MapPin className="h-3 w-3 text-zinc-500 mr-0.5 flex-shrink-0" />
                              <span>{deal.city}, NC {deal.zip}</span>
                            </div>
                            {deal.neighborhood && (
                              <div className="text-[9px] text-zinc-500 mt-0.5 font-medium">
                                {deal.neighborhood}
                              </div>
                            )}
                          </div>
                          
                          <button
                            onClick={(e) => onDeleteDeal(deal.id, e)}
                            className="p-1 text-zinc-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition opacity-0 group-hover:opacity-100 flex-shrink-0 cursor-pointer"
                            title="Delete Lead"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>

                        {/* Specs */}
                        <div className="grid grid-cols-3 gap-1 mt-2.5 pt-2.5 border-t border-zinc-800 text-[10px] font-medium text-zinc-400">
                          <div>Bed: <span className="font-bold text-zinc-200">{deal.bed}</span></div>
                          <div>Bath: <span className="font-bold text-zinc-200">{deal.bath}</span></div>
                          <div>Sqft: <span className="font-bold text-zinc-200">{deal.sqft.toLocaleString()}</span></div>
                        </div>

                        {/* Finance Highlights */}
                        <div className="mt-3 pt-2.5 border-t border-zinc-800 flex items-center justify-between">
                          <div className="flex flex-col">
                            <span className="text-[9px] uppercase tracking-wider text-zinc-500 font-semibold">Seller's Price</span>
                            <span className="text-xs font-bold text-zinc-200">${deal.askingPrice.toLocaleString()}</span>
                          </div>

                          {hasAnalyseData ? (
                            <div className="flex flex-col items-end">
                              <span className="text-[9px] uppercase tracking-wider text-emerald-400 font-semibold flex items-center">
                                <TrendingUp className="h-2.5 w-2.5 mr-0.5" /> Leftover Profit
                              </span>
                              <span className="text-xs font-extrabold text-emerald-400">
                                ${deal.underwriting.projectedProfit.toLocaleString()}
                              </span>
                            </div>
                          ) : (
                            <div className="flex items-center space-x-1.5 bg-zinc-950/60 px-2 py-0.5 rounded-lg border border-zinc-800">
                              <AlertTriangle className="h-2.5 w-2.5 text-amber-500 animate-pulse" />
                              <span className="text-[9px] text-zinc-400 font-medium">Not Checked Yet</span>
                            </div>
                          )}
                        </div>

                        {/* 1-Click Autonomous Pipeline Launch Button */}
                        {onLaunchAutonomousPipeline && (
                          <div className="mt-2.5 pt-2 border-t border-zinc-800/60">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onLaunchAutonomousPipeline(deal);
                              }}
                              className="w-full flex items-center justify-center space-x-1.5 py-1.5 px-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-600 text-emerald-400 hover:text-white border border-emerald-500/20 text-[10px] font-extrabold transition shadow-xs cursor-pointer group/btn"
                            >
                              <Zap className="h-3 w-3 text-emerald-400 group-hover/btn:text-white" />
                              <span>Go For This Property (Auto Pipeline)</span>
                            </button>
                          </div>
                        )}
                      </motion.div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
