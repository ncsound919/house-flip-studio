import React from "react";
import { motion } from "motion/react";
import { 
  Sparkles, 
  ArrowRight, 
  BookOpen, 
  Bot, 
  Compass, 
  Scale, 
  ShieldCheck, 
  Zap, 
  Building, 
  Coins 
} from "lucide-react";

interface WelcomeHeroProps {
  onStartTour: () => void;
  onEnterApp: () => void;
  onOpenManual: () => void;
}

export default function WelcomeHero({ onStartTour, onEnterApp, onOpenManual }: WelcomeHeroProps) {
  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-12">
      {/* Premium Hero Title and Visual Branding */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center space-x-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full text-[10px] font-black uppercase tracking-wider"
        >
          <Sparkles className="h-3.5 w-3.5 animate-pulse" />
          <span>North Carolina House Flip Studio — Made for Beginners!</span>
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-3xl sm:text-4xl lg:text-5xl font-black text-zinc-100 tracking-tight leading-tight"
        >
          Learn How to Flip Houses in North Carolina — Step by Step!
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-sm sm:text-base text-zinc-400 max-w-2xl mx-auto leading-relaxed"
        >
          Never flipped a house before? No problem! Our friendly team of AI helpers does all the hard research for you. They instantly find houses, check nearby sales to see how much they are worth, estimate what repairs will cost, and make sure everything is 100% legal. You just click, learn, and make decisions!
        </motion.p>
      </div>

      {/* Grid of Interactive CTAs */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="flex flex-col sm:flex-row justify-center items-center gap-4 max-w-md mx-auto"
      >
        <button
          onClick={onStartTour}
          className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg hover:shadow-emerald-900/20 transition flex items-center justify-center space-x-2 border border-emerald-400/20 cursor-pointer"
        >
          <span>Start Simple Walkthrough</span>
          <ArrowRight className="h-4 w-4" />
        </button>

        <button
          onClick={onEnterApp}
          className="w-full sm:w-auto px-6 py-3.5 bg-zinc-900 hover:bg-zinc-850 text-zinc-200 hover:text-zinc-100 font-extrabold text-xs uppercase tracking-wider rounded-xl border border-zinc-850 hover:border-zinc-700 transition flex items-center justify-center space-x-2 cursor-pointer"
        >
          <span>Go to Command Center</span>
        </button>
      </motion.div>

      {/* Visual Agent Specialized Panel Cards */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.45 }}
        className="space-y-6 pt-6"
      >
        <div className="text-center space-y-1">
          <h2 className="text-xs font-black text-zinc-500 uppercase tracking-widest">Your 3 Main AI Helpers</h2>
          <p className="text-xs text-zinc-400">These 3 automated helpers handle the tricky calculations and paperwork for you</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              title: "1. Finding Houses (Scout)",
              desc: "The Scout automatically searches public listings and city registers to find houses that are run-down or selling for cheap.",
              icon: Building,
              color: "text-blue-400",
              bgColor: "bg-blue-500/5",
              borderColor: "border-blue-500/10"
            },
            {
              title: "2. House Value Estimator (ARV)",
              desc: "ARV stands for 'After-Repair Value'. This helper looks at other houses sold nearby to tell you what your house will be worth once fixed up.",
              icon: Coins,
              color: "text-amber-400",
              bgColor: "bg-amber-500/5",
              borderColor: "border-amber-500/10"
            },
            {
              title: "3. Legal Safe-Check (Compliance)",
              desc: "Ensures you are following North Carolina state laws, like reminding you to hire a licensed builder if repairs cost more than $40,000.",
              icon: Scale,
              color: "text-purple-400",
              bgColor: "bg-purple-500/5",
              borderColor: "border-purple-500/10"
            }
          ].map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div 
                key={idx}
                className={`p-5 rounded-2xl bg-zinc-900/40 border ${feature.borderColor} space-y-3 flex flex-col justify-between`}
              >
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <div className={`p-2 rounded-lg bg-zinc-950 ${feature.color}`}>
                      <Icon className="h-4.5 w-4.5" />
                    </div>
                    <h3 className="font-bold text-xs text-zinc-200 uppercase tracking-wider">{feature.title}</h3>
                  </div>
                  <p className="text-xs text-zinc-400 leading-relaxed">{feature.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>

      {/* Bottom Manual Callout */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        className="max-w-2xl mx-auto p-4 bg-zinc-950/40 border border-zinc-850 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left"
      >
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-emerald-500/5 border border-emerald-500/10 rounded-xl text-emerald-400 hidden sm:block">
            <BookOpen className="h-4 w-4" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-zinc-200 uppercase tracking-wider">New to House Flipping? We've Got You Covered!</h4>
            <p className="text-[11px] text-zinc-500">Read our super simple, jargon-free guide that explains all the rules and steps from start to finish.</p>
          </div>
        </div>
        <button
          onClick={onOpenManual}
          className="w-full sm:w-auto px-4 py-2 hover:bg-zinc-900 border border-zinc-800 hover:border-zinc-700 rounded-xl text-xs font-bold text-zinc-300 transition cursor-pointer"
        >
          Open Beginner Guide
        </button>
      </motion.div>
    </div>
  );
}
