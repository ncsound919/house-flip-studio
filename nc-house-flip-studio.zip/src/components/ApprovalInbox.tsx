/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Inbox, 
  ShieldAlert, 
  TrendingUp, 
  Hammer, 
  FileText,
  UserCheck,
  ChevronRight
} from "lucide-react";

export interface ApprovalRequest {
  id: string;
  dealId: string;
  dealAddress: string;
  type: "action_gate" | "draft_approval" | "two_person_rule";
  title: string;
  description: string;
  proposedValue?: string;
  category: "comps" | "rehab" | "compliance" | "offer";
  status: "pending" | "approved" | "rejected";
  createdAt: string;
  data?: any;
}

interface ApprovalInboxProps {
  approvals: ApprovalRequest[];
  onAction: (id: string, action: "approve" | "reject", notes?: string) => void;
  isLoading?: boolean;
}

export default function ApprovalInbox({ approvals, onAction, isLoading }: ApprovalInboxProps) {
  const [activeApprovalId, setActiveApprovalId] = useState<string | null>(null);
  const [feedbackNotes, setFeedbackNotes] = useState("");

  const pendingApprovals = approvals.filter((a) => a.status === "pending");
  const historyApprovals = approvals.filter((a) => a.status !== "pending").slice(0, 4);

  const activeApproval = approvals.find((a) => a.id === activeApprovalId) || pendingApprovals[0] || null;

  const getCategoryFriendlyName = (category: string) => {
    switch (category) {
      case "comps": return "similar houses";
      case "rehab": return "repair budgets";
      case "compliance": return "laws check";
      case "offer": return "making an offer";
      default: return category;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "comps": return <TrendingUp className="h-4 w-4 text-sky-400" />;
      case "rehab": return <Hammer className="h-4 w-4 text-amber-400" />;
      case "compliance": return <ShieldAlert className="h-4 w-4 text-purple-400" />;
      case "offer": return <FileText className="h-4 w-4 text-emerald-400" />;
      default: return <UserCheck className="h-4 w-4 text-zinc-400" />;
    }
  };

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case "comps": return "bg-sky-500/10 text-sky-400 border border-sky-500/20";
      case "rehab": return "bg-amber-500/10 text-amber-400 border border-amber-500/20";
      case "compliance": return "bg-purple-500/10 text-purple-400 border border-purple-500/20";
      case "offer": return "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
      default: return "bg-zinc-800 text-zinc-400";
    }
  };

  return (
    <div id="approval-inbox-panel" className="bg-zinc-900/50 border border-zinc-800/80 rounded-3xl p-5 shadow-md flex flex-col h-full backdrop-blur-md">
      {/* Header */}
      <div className="flex items-center justify-between pb-3.5 border-b border-zinc-800/80 mb-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
            <Inbox className="h-4 w-4" />
          </div>
          <div>
            <h3 className="font-extrabold text-xs text-zinc-200 uppercase tracking-wider">Simple Double-Check Box</h3>
            <p className="text-[10px] text-zinc-500">Double-check your AI's decisions before they happen!</p>
          </div>
        </div>
        {pendingApprovals.length > 0 && (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/10 border border-amber-500/20 text-amber-400 animate-pulse">
            {pendingApprovals.length} Left to Check
          </span>
        )}
      </div>

      {pendingApprovals.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center py-10 text-center">
          <CheckCircle2 className="h-10 w-10 text-zinc-700 mb-2.5" />
          <h4 className="font-extrabold text-zinc-300 text-xs uppercase tracking-wider">All Clear!</h4>
          <p className="text-[10px] text-zinc-500 max-w-xs mt-1 leading-relaxed">
            Hooray! No decisions left to double-check. Your AI helpers are working happily on their own.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 flex-1 min-h-0">
          {/* List of pending approvals */}
          <div className="md:col-span-5 space-y-2 overflow-y-auto max-h-[300px] pr-1">
            {pendingApprovals.map((appr) => {
              const isActive = activeApproval?.id === appr.id;
              return (
                <button
                  key={appr.id}
                  onClick={() => {
                    setActiveApprovalId(appr.id);
                    setFeedbackNotes("");
                  }}
                  className={`w-full text-left p-3 rounded-2xl border transition text-xs flex items-start space-x-2.5 cursor-pointer ${
                    isActive
                      ? "bg-zinc-800 border-emerald-500/40 shadow-sm"
                      : "bg-zinc-950/40 border-zinc-850 hover:bg-zinc-900/60 hover:border-zinc-800"
                  }`}
                >
                  <div className={`p-1.5 rounded-lg bg-zinc-950 border border-zinc-800 flex-shrink-0 mt-0.5`}>
                    {getCategoryIcon(appr.category)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-0.5 rounded-lg text-[8px] font-extrabold uppercase ${getCategoryBadge(appr.category)}`}>
                        {getCategoryFriendlyName(appr.category)}
                      </span>
                      <span className="text-[8px] text-zinc-500 flex items-center">
                        <Clock className="h-2.5 w-2.5 mr-0.5" /> Just now
                      </span>
                    </div>
                    <h5 className="font-bold text-zinc-200 mt-1.5 truncate leading-tight">{appr.title}</h5>
                    <p className="text-[10px] text-zinc-500 truncate mt-0.5">{appr.dealAddress}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-zinc-600 self-center" />
                </button>
              );
            })}
          </div>

          {/* Active Approval Details Card */}
          <div className="md:col-span-7 bg-zinc-950/40 border border-zinc-800 rounded-2xl p-4 flex flex-col justify-between text-xs">
            {activeApproval && (
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeApproval.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="space-y-3.5 flex-1 flex flex-col justify-between"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className={`px-2.5 py-0.5 rounded-lg text-[9px] font-extrabold uppercase ${getCategoryBadge(activeApproval.category)}`}>
                        {getCategoryFriendlyName(activeApproval.category)}
                      </span>
                      <span className="text-[10px] font-semibold text-zinc-400">
                        {activeApproval.dealAddress}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-extrabold text-sm text-zinc-100 leading-snug">{activeApproval.title}</h4>
                      <p className="text-zinc-400 mt-1.5 leading-relaxed text-[11px]">
                        {activeApproval.description}
                      </p>
                    </div>

                    {activeApproval.proposedValue && (
                      <div className="bg-zinc-900 border border-zinc-850 rounded-xl p-3">
                        <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider block mb-1">
                          The Plan Details
                        </span>
                        <p className="font-mono text-zinc-200 text-[11px] leading-relaxed break-all whitespace-pre-wrap">
                          {activeApproval.proposedValue}
                        </p>
                      </div>
                    )}

                    {/* Feedback Notes Input */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-zinc-500 uppercase tracking-wider mb-1">
                        Notes on what to change (Optional)
                      </label>
                      <input
                        type="text"
                        value={feedbackNotes}
                        onChange={(e) => setFeedbackNotes(e.target.value)}
                        placeholder="e.g. Lower the repair cost a bit..."
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2 focus:ring-1 focus:ring-emerald-500/40 text-[11px] focus:outline-hidden text-zinc-200 placeholder-zinc-600 font-medium"
                      />
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-zinc-800/80 mt-2">
                    <button
                      onClick={() => onAction(activeApproval.id, "reject", feedbackNotes)}
                      disabled={isLoading}
                      className="px-3.5 py-2 bg-zinc-900 hover:bg-red-950/20 text-zinc-400 hover:text-red-400 border border-zinc-800 hover:border-red-900/50 rounded-xl font-bold flex items-center justify-center space-x-1.5 transition cursor-pointer"
                    >
                      <XCircle className="h-4 w-4" />
                      <span>Wait, Fix This</span>
                    </button>
                    <button
                      onClick={() => onAction(activeApproval.id, "approve", feedbackNotes)}
                      disabled={isLoading}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-extrabold shadow-sm flex items-center justify-center space-x-1.5 transition cursor-pointer"
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      <span>Looks Good, Do It!</span>
                    </button>
                  </div>
                </motion.div>
              </AnimatePresence>
            )}
          </div>
        </div>
      )}

      {/* History log block */}
      {historyApprovals.length > 0 && (
        <div className="mt-4 pt-3 border-t border-zinc-800/80">
          <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider block mb-2">
            Decisions You Already Made
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px]">
            {historyApprovals.map((hist) => (
              <div key={hist.id} className="p-2 bg-zinc-950/30 border border-zinc-850 rounded-xl flex items-center justify-between">
                <div className="flex items-center space-x-2 min-w-0">
                  <div className="p-1 rounded bg-zinc-900 border border-zinc-800">
                    {hist.status === "approved" ? (
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                    ) : (
                      <XCircle className="h-3.5 w-3.5 text-red-400" />
                    )}
                  </div>
                  <div className="truncate min-w-0">
                    <p className="font-bold text-zinc-300 truncate">{hist.title}</p>
                    <p className="text-[8px] text-zinc-500 truncate">{hist.dealAddress}</p>
                  </div>
                </div>
                <span className={`px-1.5 py-0.5 rounded-md text-[8px] font-extrabold uppercase ${
                  hist.status === "approved"
                    ? "bg-emerald-500/10 text-emerald-400"
                    : "bg-red-500/10 text-red-400"
                }`}>
                  {hist.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
