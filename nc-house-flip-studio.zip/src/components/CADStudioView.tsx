/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  PropertyDeal, 
  HouseCADLayout, 
  FixProtocolNode, 
  CADTradeType, 
  CADRoom 
} from '../types';
import { CADViewport3D } from './CADViewport3D';
import { FixProtocolInspector } from './FixProtocolInspector';
import { CADLayoutIngestModal } from './CADLayoutIngestModal';
import { ContractorVisualExportModal } from './ContractorVisualExportModal';
import { generateCADLayoutForDeal, generateFixProtocolSteps, NC_CODE_CATALOG } from '../lib/cadLayoutGenerator';
import { 
  Box, 
  Layers, 
  Sparkles, 
  Plus, 
  RefreshCw, 
  Filter, 
  Download, 
  FileText, 
  Wrench, 
  HardHat, 
  ShieldCheck, 
  ChevronRight, 
  Search, 
  SlidersHorizontal,
  Home,
  CheckCircle2,
  AlertCircle,
  Eye,
  Zap,
  DollarSign,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CADStudioViewProps {
  deal: PropertyDeal;
  onUpdateDeal: (updated: PropertyDeal) => void;
}

export const CADStudioView: React.FC<CADStudioViewProps> = ({ deal, onUpdateDeal }) => {
  // Initialize CAD Layout state from deal or auto-generate
  const [cadLayout, setCadLayout] = useState<HouseCADLayout>(() => {
    return deal.cadLayout || generateCADLayoutForDeal(deal);
  });

  const [selectedProtocolId, setSelectedProtocolId] = useState<string | null>(null);
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [filterTrade, setFilterTrade] = useState<CADTradeType | 'ALL'>('ALL');
  const [activeLayer, setActiveLayer] = useState<'all' | 'foundation' | 'level1' | 'level2' | 'roof'>('all');
  const [renderMode, setRenderMode] = useState<'solid' | 'xray' | 'wireframe' | 'trade-mep'>('solid');
  
  const [isIngestModalOpen, setIsIngestModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isAddingFixNode, setIsAddingFixNode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewTab, setViewTab] = useState<'protocols' | 'rooms' | 'contractor-packet'>('protocols');

  // Keep local CAD Layout synced with deal if deal changes
  useEffect(() => {
    if (deal.cadLayout) {
      setCadLayout(deal.cadLayout);
    } else {
      const generated = generateCADLayoutForDeal(deal);
      setCadLayout(generated);
    }
  }, [deal.id]);

  // Persist updated CAD layout to deal
  const handleSaveLayout = (newLayout: HouseCADLayout) => {
    setCadLayout(newLayout);
    onUpdateDeal({
      ...deal,
      cadLayout: newLayout
    });
  };

  // Update specific fix protocol
  const handleUpdateProtocol = (updated: FixProtocolNode) => {
    const updatedProtocols = cadLayout.fixProtocols.map(p => p.id === updated.id ? updated : p);
    const newLayout: HouseCADLayout = {
      ...cadLayout,
      fixProtocols: updatedProtocols,
      lastModified: new Date().toISOString()
    };
    handleSaveLayout(newLayout);
  };

  // Delete fix protocol
  const handleDeleteProtocol = (id: string) => {
    const updatedProtocols = cadLayout.fixProtocols.filter(p => p.id !== id);
    const newLayout: HouseCADLayout = {
      ...cadLayout,
      fixProtocols: updatedProtocols,
      lastModified: new Date().toISOString()
    };
    handleSaveLayout(newLayout);
    if (selectedProtocolId === id) setSelectedProtocolId(null);
  };

  // Ingest / Sync all Deal Rehab Items into 3D Fix Protocols
  const handleSyncRehabItems = () => {
    const freshLayout = generateCADLayoutForDeal(deal);
    handleSaveLayout(freshLayout);
    setSelectedProtocolId(null);
  };

  // Place newly clicked fix node in 3D Space
  const handlePlaceFixNode = (coords: { x: number; y: number; z: number }, roomId: string) => {
    const targetRoom = cadLayout.rooms.find(r => r.id === roomId) || cadLayout.rooms[0];
    const newId = `fix-${deal.id}-${Date.now()}`;
    const codeInfo = NC_CODE_CATALOG['Subfloor & Joist Sistering'];
    const steps = generateFixProtocolSteps('New Spatial Repair Fix', 'Structural Framing');

    const newNode: FixProtocolNode = {
      id: newId,
      dealId: deal.id,
      title: `Repair Node @ ${targetRoom.name}`,
      trade: 'Structural Framing',
      severity: 'moderate',
      status: 'scoped',
      position: coords,
      targetRoomId: targetRoom.id,
      ncCodeReference: codeInfo.code,
      estimatedCost: 3200,
      laborHours: 24,
      materialCost: 1400,
      laborCost: 1800,
      requiredTools: ['Laser Level', 'Impact Driver', 'PPE Package'],
      requiredMaterials: ['NC Approved Fasteners', 'Framing Lumber'],
      safetyPPE: ['Safety Glasses', 'Steel Toe Boots', 'Gloves'],
      executionSteps: steps
    };

    const newLayout: HouseCADLayout = {
      ...cadLayout,
      fixProtocols: [...cadLayout.fixProtocols, newNode],
      lastModified: new Date().toISOString()
    };

    handleSaveLayout(newLayout);
    setIsAddingFixNode(false);
    setSelectedProtocolId(newId);
  };

  // Selected protocol object
  const activeProtocol = useMemo(() => {
    return cadLayout.fixProtocols.find(p => p.id === selectedProtocolId) || null;
  }, [cadLayout.fixProtocols, selectedProtocolId]);

  // Filtered protocols list for ledger
  const filteredProtocols = useMemo(() => {
    return cadLayout.fixProtocols.filter(p => {
      if (filterTrade !== 'ALL' && p.trade !== filterTrade) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return p.title.toLowerCase().includes(q) || p.ncCodeReference.toLowerCase().includes(q) || p.trade.toLowerCase().includes(q);
      }
      return true;
    });
  }, [cadLayout.fixProtocols, filterTrade, searchQuery]);

  // Aggregate Metrics
  const totalCost = useMemo(() => {
    return cadLayout.fixProtocols.reduce((sum, p) => sum + (p.estimatedCost || 0), 0);
  }, [cadLayout.fixProtocols]);

  const totalLaborHours = useMemo(() => {
    return cadLayout.fixProtocols.reduce((sum, p) => sum + (p.laborHours || 0), 0);
  }, [cadLayout.fixProtocols]);

  const completedProtocolsCount = useMemo(() => {
    return cadLayout.fixProtocols.filter(p => p.status === 'completed').length;
  }, [cadLayout.fixProtocols]);

  const allTrades: Array<CADTradeType | 'ALL'> = [
    'ALL',
    'Structural Framing',
    'MEP - Electrical',
    'MEP - Plumbing',
    'MEP - HVAC',
    'Roofing & Attic',
    'Foundation & Crawlspace',
    'Kitchen & Cabinetry',
    'Bath & Tile',
    'Drywall & Insulation',
    'Flooring & Finishes'
  ];

  return (
    <div className="space-y-5 animate-fadeIn">
      {/* Top Banner & Quick Controls */}
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-5 backdrop-blur-md shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3.5">
          <div className="p-3 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-2xl">
            <Box className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-extrabold text-zinc-100 uppercase tracking-tight">
                3D CAD & Repair Fix Studio
              </h1>
              <span className="text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                Spatial NC Code Engine
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Interactive 3D building model for <strong>{deal.address}, {deal.city} NC</strong> with spatial repair placement and trade SOP protocols.
            </p>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsIngestModalOpen(true)}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-200 text-xs font-extrabold transition shadow-sm cursor-pointer"
            title="Load blueprints or architectural styles"
          >
            <Layers className="h-4 w-4 text-emerald-400" />
            <span>Ingest Layout</span>
          </button>

          <button
            onClick={() => setIsAddingFixNode(!isAddingFixNode)}
            className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-extrabold transition shadow-sm cursor-pointer ${
              isAddingFixNode 
                ? 'bg-emerald-600 text-white border border-emerald-400' 
                : 'bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-200'
            }`}
            title="Place a new repair beacon pin in 3D CAD space"
          >
            <Plus className="h-4 w-4 text-emerald-400" />
            <span>{isAddingFixNode ? 'Click Model to Place' : 'Add 3D Fix Node'}</span>
          </button>

          <button
            onClick={() => setIsExportModalOpen(true)}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-zinc-950 border border-emerald-500/40 hover:bg-zinc-900 text-emerald-300 hover:text-white text-xs font-extrabold shadow-sm transition cursor-pointer"
            title="Open 2D Blueprints, BOM Takeoffs, QR Stud Badges & Contractor Packets"
          >
            <Download className="h-4 w-4 text-emerald-400" />
            <span>Contractor Exports</span>
          </button>

          <button
            onClick={handleSyncRehabItems}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-extrabold shadow-sm transition border border-emerald-400/30 cursor-pointer"
            title="Sync with deal rehab estimating list"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Sync Rehab List</span>
          </button>
        </div>
      </div>

      {/* Control Ribbon (Layers, Render Modes, Trade Filters) */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-zinc-950/70 border border-zinc-850 p-3 rounded-2xl">
        {/* Floor Level Layer Switcher */}
        <div className="flex items-center space-x-1 bg-zinc-900/90 p-1 rounded-xl border border-zinc-800">
          <span className="text-[10px] font-extrabold text-zinc-500 px-2 uppercase tracking-wider hidden sm:inline">
            Floor Level:
          </span>
          <button
            onClick={() => setActiveLayer('all')}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              activeLayer === 'all' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            All Floors
          </button>
          <button
            onClick={() => setActiveLayer('foundation')}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              activeLayer === 'foundation' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Crawlspace
          </button>
          <button
            onClick={() => setActiveLayer('level1')}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              activeLayer === 'level1' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Main Floor
          </button>
          {cadLayout.rooms.some(r => r.floorLevel === 2) && (
            <button
              onClick={() => setActiveLayer('level2')}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                activeLayer === 'level2' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              2nd Story
            </button>
          )}
          <button
            onClick={() => setActiveLayer('roof')}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              activeLayer === 'roof' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Roof & Trusses
          </button>
        </div>

        {/* 3D Rendering Shading Modes */}
        <div className="flex items-center space-x-1 bg-zinc-900/90 p-1 rounded-xl border border-zinc-800">
          <span className="text-[10px] font-extrabold text-zinc-500 px-2 uppercase tracking-wider hidden sm:inline">
            Rendering:
          </span>
          <button
            onClick={() => setRenderMode('solid')}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              renderMode === 'solid' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="Architectural Solid Shaded"
          >
            Solid CAD
          </button>
          <button
            onClick={() => setRenderMode('trade-mep')}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              renderMode === 'trade-mep' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="MEP Trade Routing & Conduits"
          >
            MEP Layers
          </button>
          <button
            onClick={() => setRenderMode('xray')}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              renderMode === 'xray' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="Transparent X-Ray Inspection"
          >
            X-Ray
          </button>
          <button
            onClick={() => setRenderMode('wireframe')}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              renderMode === 'wireframe' ? 'bg-zinc-800 text-emerald-400' : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="Framing Wireframe"
          >
            Wireframe
          </button>
        </div>

        {/* Trade Filter Dropdown */}
        <div className="flex items-center space-x-2">
          <Filter className="h-3.5 w-3.5 text-zinc-500" />
          <select
            value={filterTrade}
            onChange={(e) => setFilterTrade(e.target.value as any)}
            className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1 text-xs text-zinc-200 focus:outline-none focus:border-emerald-500 font-bold"
          >
            {allTrades.map(trade => (
              <option key={trade} value={trade}>
                {trade === 'ALL' ? 'All Trades (Full House)' : trade}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Split Grid: 3D CAD Viewport + Fix Protocol Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column: 3D Three.js CAD Viewport */}
        <div className={activeProtocol ? 'lg:col-span-7' : 'lg:col-span-12'}>
          <CADViewport3D
            cadLayout={cadLayout}
            selectedProtocolId={selectedProtocolId}
            onSelectProtocol={(id) => setSelectedProtocolId(id)}
            selectedRoomId={selectedRoomId}
            onSelectRoom={(id) => setSelectedRoomId(id)}
            filterTrade={filterTrade}
            activeLayer={activeLayer}
            renderMode={renderMode}
            isAddingFixNode={isAddingFixNode}
            onPlaceFixNode={handlePlaceFixNode}
            onOpenExportModal={() => setIsExportModalOpen(true)}
          />
        </div>

        {/* Right Column: Fix Protocol SOP Inspector (When Node Selected) */}
        {activeProtocol && (
          <div className="lg:col-span-5 h-[520px] lg:h-[580px]">
            <FixProtocolInspector
              protocol={activeProtocol}
              deal={deal}
              onUpdateProtocol={handleUpdateProtocol}
              onDeleteProtocol={handleDeleteProtocol}
              onClose={() => setSelectedProtocolId(null)}
            />
          </div>
        )}
      </div>

      {/* Bottom Structural Section: Protocol Ledger & Trade Overview */}
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-6 backdrop-blur-md shadow-xl space-y-5">
        {/* Metric Summary Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-zinc-950/60 border border-zinc-850 p-3.5 rounded-2xl">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 flex items-center space-x-1.5">
              <DollarSign className="h-3.5 w-3.5 text-emerald-400" />
              <span>Total CAD Repair Scope</span>
            </span>
            <p className="text-lg font-black text-zinc-100 mt-1">
              ${totalCost.toLocaleString()}
            </p>
          </div>

          <div className="bg-zinc-950/60 border border-zinc-850 p-3.5 rounded-2xl">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 flex items-center space-x-1.5">
              <Clock className="h-3.5 w-3.5 text-sky-400" />
              <span>Total Labor Hours</span>
            </span>
            <p className="text-lg font-black text-zinc-100 mt-1">
              {totalLaborHours} Hours
            </p>
          </div>

          <div className="bg-zinc-950/60 border border-zinc-850 p-3.5 rounded-2xl">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 flex items-center space-x-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-amber-400" />
              <span>Inspection Passed</span>
            </span>
            <p className="text-lg font-black text-zinc-100 mt-1">
              {completedProtocolsCount} / {cadLayout.fixProtocols.length} Fixes
            </p>
          </div>

          <div className="bg-zinc-950/60 border border-zinc-850 p-3.5 rounded-2xl">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 flex items-center space-x-1.5">
              <Box className="h-3.5 w-3.5 text-indigo-400" />
              <span>Active Zones</span>
            </span>
            <p className="text-lg font-black text-zinc-100 mt-1">
              {cadLayout.rooms.length} Structural Rooms
            </p>
          </div>
        </div>

        {/* Ledger Navigation Tabs */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
          <div className="flex space-x-2">
            <button
              onClick={() => setViewTab('protocols')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                viewTab === 'protocols'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-zinc-950 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
              }`}
            >
              Structured Fix Protocols ({filteredProtocols.length})
            </button>
            <button
              onClick={() => setViewTab('rooms')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                viewTab === 'rooms'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-zinc-950 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
              }`}
            >
              House Zones & Rooms ({cadLayout.rooms.length})
            </button>
            <button
              onClick={() => setViewTab('contractor-packet')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                viewTab === 'contractor-packet'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-zinc-950 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
              }`}
            >
              Contractor Work Order Packet
            </button>
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-zinc-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search trade, code, or repair..."
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-zinc-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Tab 1: Fix Protocol Ledger */}
        {viewTab === 'protocols' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredProtocols.map((protocol) => {
                const isSelected = protocol.id === selectedProtocolId;
                const targetRoom = cadLayout.rooms.find(r => r.id === protocol.targetRoomId);

                return (
                  <div
                    key={protocol.id}
                    onClick={() => setSelectedProtocolId(protocol.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                      isSelected
                        ? 'bg-emerald-950/30 border-emerald-500 shadow-md shadow-emerald-500/10 ring-1 ring-emerald-500'
                        : 'bg-zinc-950/60 border-zinc-850 hover:border-zinc-700'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          protocol.severity === 'critical'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}>
                          {protocol.severity}
                        </span>

                        <span className="text-[10px] font-mono text-emerald-400 font-extrabold">
                          ${protocol.estimatedCost.toLocaleString()}
                        </span>
                      </div>

                      <h3 className="text-xs font-bold text-zinc-100 line-clamp-1">
                        {protocol.title}
                      </h3>

                      <p className="text-[11px] text-zinc-400 line-clamp-2">
                        {protocol.ncCodeReference}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-zinc-850 flex items-center justify-between text-[10px] text-zinc-500 font-mono">
                      <span>{targetRoom?.name || 'General Zone'}</span>
                      <span className="text-zinc-400 font-bold">{protocol.executionSteps.length} SOP Steps</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 2: Rooms & Zones List */}
        {viewTab === 'rooms' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {cadLayout.rooms.map((room) => {
              const roomFixes = cadLayout.fixProtocols.filter(p => p.targetRoomId === room.id);
              const roomTotalCost = roomFixes.reduce((s, f) => s + f.estimatedCost, 0);

              return (
                <div
                  key={room.id}
                  onClick={() => setSelectedRoomId(room.id)}
                  className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-2xl space-y-2.5 hover:border-zinc-700 transition"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Home className="h-4 w-4 text-emerald-400" />
                      <h4 className="text-xs font-extrabold text-zinc-100">{room.name}</h4>
                    </div>
                    <span className="text-[10px] font-mono text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded-md border border-zinc-800">
                      Level {room.floorLevel}
                    </span>
                  </div>

                  <p className="text-[11px] text-zinc-400">
                    Dimensions: {room.width}' × {room.length}' ({Math.round(room.width * room.length)} sqft) • Wall Height: {room.height}'
                  </p>

                  <div className="pt-2 border-t border-zinc-850 flex items-center justify-between text-[10px]">
                    <span className="text-zinc-500 font-mono">
                      {roomFixes.length} Spatial Fixes
                    </span>
                    <span className="text-emerald-400 font-extrabold">
                      ${roomTotalCost.toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 3: Contractor Work Order Packet */}
        {viewTab === 'contractor-packet' && (
          <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-850 space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <div>
                <h3 className="text-sm font-extrabold text-zinc-100 uppercase tracking-tight">
                  Official North Carolina Contractor Work Order Packet
                </h3>
                <p className="text-xs text-zinc-400">
                  Project: {deal.address}, {deal.city}, NC • Generated: {new Date().toLocaleDateString()}
                </p>
              </div>
              <button
                onClick={() => setIsExportModalOpen(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer shadow-lg"
              >
                <Download className="h-4 w-4" />
                <span>Open Contractor Visual Export Studio</span>
              </button>
            </div>

            <div className="space-y-4">
              {cadLayout.fixProtocols.map((protocol, idx) => (
                <div key={protocol.id} className="p-4 bg-zinc-900/70 border border-zinc-800 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-zinc-100">
                      Scope #{idx + 1}: {protocol.title} ({protocol.trade})
                    </h4>
                    <span className="text-xs font-mono font-bold text-emerald-400">
                      Est. Budget: ${protocol.estimatedCost.toLocaleString()}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400 font-mono">
                    Code Citation: {protocol.ncCodeReference}
                  </p>
                  <div className="space-y-1.5 pl-2 border-l-2 border-emerald-500/40">
                    {protocol.executionSteps.map((s) => (
                      <div key={s.stepNumber} className="text-[11px] text-zinc-300">
                        <strong>Step {s.stepNumber}: {s.title}</strong> — {s.detail}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Ingest Modal */}
      {isIngestModalOpen && (
        <CADLayoutIngestModal
          deal={deal}
          currentLayout={cadLayout}
          onSaveLayout={handleSaveLayout}
          onClose={() => setIsIngestModalOpen(false)}
        />
      )}

      {/* Contractor Visual Export Studio Modal */}
      <ContractorVisualExportModal
        deal={deal}
        cadLayout={cadLayout}
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />
    </div>
  );
};
