import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, 
  ArrowLeft, 
  ArrowRight, 
  Sparkles, 
  Compass, 
  Bot, 
  CheckCircle2, 
  HelpCircle,
  Activity,
  UserCheck
} from "lucide-react";

interface TourStep {
  title: string;
  description: string;
  selector: string;
  icon: React.ComponentType<any>;
  tip: string;
  position: "bottom" | "top" | "center";
}

interface InteractiveTourProps {
  isActive: boolean;
  onClose: () => void;
  onComplete: () => void;
}

const TOUR_STEPS: TourStep[] = [
  {
    title: "1. The Simple Menu",
    description: "This is your main dashboard. You can switch between 'Welcome Home', 'Go to Command Center' to search and play with properties, 'Partners' Oversight' to plan physical construction work, and 'Pricing Moats' to see your savings.",
    selector: "#header-navigation",
    icon: Compass,
    tip: "Tip: Switch to the other tabs above to explore different parts of the studio!",
    position: "bottom"
  },
  {
    title: "2. Finding Houses",
    description: "This is where you find real properties to practice house flipping on. Choose a city like Raleigh, Charlotte, or Asheville, or type an address to let our AI search city files and listings automatically.",
    selector: "#sourcing-section",
    icon: Compass,
    tip: "Tip: Sourcing automatically fetches legal land size and construction year records!",
    position: "bottom"
  },
  {
    title: "3. Inbox Approvals",
    description: "The AI assistants never make big decisions without your permission. If they find a run-down house, list recommended home sales nearby, or flag a warning, they will ask for your thumbs-up here first.",
    selector: "#approval-inbox",
    icon: UserCheck,
    tip: "Tip: Clicking 'Approve' lets the simulation proceed to the next step!",
    position: "bottom"
  },
  {
    title: "4. AI Assistants Monitor",
    description: "Think of this as a live screen showing what your 6 specialized AI helpers are doing in the background. You can open it to see them 'talk' and process files live.",
    selector: "#agent-status-panel",
    icon: Bot,
    tip: "Tip: It blinks green whenever a helper starts working on a house.",
    position: "top"
  },
  {
    title: "5. House Calculations Sheet",
    description: "Once you choose a property, all the details show up here! You can check what the house is worth fixed up (ARV), look at local home comparisons (comps), customize repair budgets, and play with mortgage/profit sliders.",
    selector: "#deal-underwriter",
    icon: CheckCircle2,
    tip: "Tip: Click 'Go For Property (Auto Pipeline)' to let the AI automatically fill in all these calculations!",
    position: "top"
  }
];

export default function InteractiveTour({ isActive, onClose, onComplete }: InteractiveTourProps) {
  const [currentStep, setCurrentStep] = React.useState(0);

  React.useEffect(() => {
    if (isActive) {
      setCurrentStep(0);
      // Attempt to scroll to the active selector
      scrollToSelector(TOUR_STEPS[0].selector);
    }
  }, [isActive]);

  const scrollToSelector = (selector: string) => {
    try {
      const element = document.querySelector(selector);
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "center" });
        // Add a temporary highlight border
        element.classList.add("ring-2", "ring-emerald-500", "ring-offset-2", "ring-offset-zinc-950", "transition-all", "duration-500");
        setTimeout(() => {
          element.classList.remove("ring-2", "ring-emerald-500", "ring-offset-2", "ring-offset-zinc-950");
        }, 4000);
      }
    } catch (e) {
      console.warn("Failed to scroll to selector", selector, e);
    }
  };

  const handleNext = () => {
    if (currentStep < TOUR_STEPS.length - 1) {
      const nextIdx = currentStep + 1;
      setCurrentStep(nextIdx);
      scrollToSelector(TOUR_STEPS[nextIdx].selector);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      const prevIdx = currentStep - 1;
      setCurrentStep(prevIdx);
      scrollToSelector(TOUR_STEPS[prevIdx].selector);
    }
  };

  if (!isActive) return null;

  const step = TOUR_STEPS[currentStep];
  const Icon = step.icon;

  return (
    <AnimatePresence>
      <div className="fixed inset-x-4 bottom-6 sm:right-6 sm:left-auto z-50 max-w-sm font-sans">
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          className="bg-zinc-900 border border-emerald-500/40 rounded-3xl p-5 shadow-2xl flex flex-col space-y-4 backdrop-blur-md relative overflow-hidden"
        >
          {/* Subtle green aesthetic pulse */}
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl -z-10"></div>

          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="p-1.5 bg-emerald-600/10 border border-emerald-500/20 text-emerald-400 rounded-xl">
                <Sparkles className="h-4 w-4" />
              </span>
              <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Interactive Studio Tour</span>
            </div>
            <button 
              onClick={onClose}
              className="p-1 hover:bg-zinc-800 rounded text-zinc-500 hover:text-zinc-350 transition cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Guide Content */}
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Icon className="h-5 w-5 text-emerald-400 flex-shrink-0" />
              <h4 className="font-extrabold text-sm text-zinc-100">{step.title}</h4>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              {step.description}
            </p>
          </div>

          {/* On-screen tip */}
          <div className="p-2.5 bg-zinc-950/60 border border-zinc-850 rounded-xl text-[10px] text-zinc-500 flex items-start space-x-1.5">
            <HelpCircle className="h-3.5 w-3.5 text-emerald-500/60 flex-shrink-0 mt-0.5" />
            <span>{step.tip}</span>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-2 border-t border-zinc-850">
            {/* Step Counter */}
            <span className="text-[10px] font-black text-zinc-500 uppercase">
              Step {currentStep + 1} of {TOUR_STEPS.length}
            </span>

            <div className="flex items-center space-x-2">
              <button
                onClick={handlePrev}
                disabled={currentStep === 0}
                className="p-1.5 bg-zinc-950 hover:bg-zinc-850 disabled:opacity-30 border border-zinc-800 rounded-lg text-zinc-400 transition cursor-pointer"
                title="Previous step"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={handleNext}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider rounded-xl transition flex items-center space-x-1 cursor-pointer"
              >
                <span>{currentStep === TOUR_STEPS.length - 1 ? "Finish" : "Next"}</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
