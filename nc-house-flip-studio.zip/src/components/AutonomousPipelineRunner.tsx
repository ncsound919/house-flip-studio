/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Zap,
  CheckCircle,
  AlertTriangle,
  Play,
  ShieldCheck,
  Building,
  DollarSign,
  Hammer,
  Scale,
  FileText,
  Users,
  ChevronRight,
  TrendingUp,
  X,
  Sparkles,
  MapPin,
  Clock,
  ArrowRight,
  Download
} from "lucide-react";
import { PropertyDeal, AgentLog } from "../types";

interface AutonomousPipelineRunnerProps {
  deal: PropertyDeal;
  isOpen: boolean;
  onClose: () => void;
  onComplete: (updatedDeal: PropertyDeal) => void;
  onViewDoc?: (docType: string) => void;
}

interface PipelineStep {
  id: string;
  number: number;
  agent: "Scout" | "ARV" | "Rehab" | "Supervisor" | "Compliance" | "Project";
  title: string;
  description: string;
  metricLabel?: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  badgeColor: string;
}

const PIPELINE_STEPS: PipelineStep[] = [
  {
    id: "step-ingest",
    number: 1,
    agent: "Scout",
    title: "Public Record & GIS Verification",
    description: "Ingest county tax parcel PIN, deed registry, and zoning ordinances",
    metricLabel: "Parcel GIS Verified",
    icon: Building,
    color: "text-sky-400",
    badgeColor: "bg-sky-500/10 text-sky-400 border-sky-500/20"
  },
  {
    id: "step-arv",
    number: 2,
    agent: "ARV",
    title: "MLS Comps & Calibrated ARV",
    description: "Analyze 0.5-mile recent closed sales and compute weighted $/sqft",
    metricLabel: "Calibrated ARV",
    icon: TrendingUp,
    color: "text-emerald-400",
    badgeColor: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
  },
  {
    id: "step-rehab",
    number: 3,
    agent: "Rehab",
    title: "Defect Scope & Trade Cost Matrix",
    description: "Generate 6-trade itemized repair line items with 15% contingency buffer",
    metricLabel: "Total Rehab Budget",
    icon: Hammer,
    color: "text-amber-400",
    badgeColor: "bg-amber-500/10 text-amber-400 border-amber-500/20"
  },
  {
    id: "step-underwrite",
    number: 4,
    agent: "Supervisor",
    title: "70% Rule MAO & Financial Engine",
    description: "Calculate Max Allowable Offer, debt service, holding costs, and ROI%",
    metricLabel: "Max Allowable Offer",
    icon: DollarSign,
    color: "text-indigo-400",
    badgeColor: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
  },
  {
    id: "step-compliance",
    number: 5,
    agent: "Compliance",
    title: "NC HB 797 & Legal/Tax Audit",
    description: "Audit NC SOS Single-Member LLC entity shield & wholesaling broker statute",
    metricLabel: "NC Statutory Clear",
    icon: Scale,
    color: "text-purple-400",
    badgeColor: "bg-purple-500/10 text-purple-400 border-purple-500/20"
  },
  {
    id: "step-contractors",
    number: 6,
    agent: "Project",
    title: "Contractor Vetting & Escrow Schedule",
    description: "Assign 4 licensed NC trade contractors and 6-phase draw schedule",
    metricLabel: "6-Phase Escrow Draw",
    icon: Users,
    color: "text-teal-400",
    badgeColor: "bg-teal-500/10 text-teal-400 border-teal-500/20"
  },
  {
    id: "step-legal-docs",
    number: 7,
    agent: "Supervisor",
    title: "NC Form 2-T & Closing Packet Ready",
    description: "Auto-generate NC Standard Form 2-T Offer Contract, Lien Waivers & Escrow Certificate",
    metricLabel: "Contract Package Ready",
    icon: FileText,
    color: "text-emerald-400",
    badgeColor: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
  }
];

export default function AutonomousPipelineRunner({
  deal,
  isOpen,
  onClose,
  onComplete,
  onViewDoc
}: AutonomousPipelineRunnerProps) {
  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const [isExecuting, setIsExecuting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [liveLogs, setLiveLogs] = useState<{ id: string; agent: string; text: string; time: string }[]>([]);
  const [updatedDealResult, setUpdatedDealResult] = useState<PropertyDeal | null>(null);
  const [executionSpeed, setExecutionSpeed] = useState<"normal" | "turbo">("normal");
  const isMountedRef = React.useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  // Reset or run pipeline
  useEffect(() => {
    if (isOpen) {
      setActiveStepIndex(0);
      setIsCompleted(false);
      setUpdatedDealResult(null);
      setLiveLogs([
        {
          id: "log-init",
          agent: "Supervisor",
          text: `⚡ Autonomous Pipeline Runner initialized for ${deal.address}, ${deal.city}, NC. Ready to execute full 7-step sequence.`,
          time: new Date().toLocaleTimeString()
        }
      ]);
    }
  }, [isOpen, deal.id]);

  const handleStartPipeline = async () => {
    setIsExecuting(true);
    setIsCompleted(false);

    try {
      // Step 1: Ingest
      if (!isMountedRef.current) return;
      setActiveStepIndex(0);
      addLiveLog("Scout", `Ingesting county parcel records (${deal.parcelId || "County GIS PIN"}). Verifying zoning classification.`);
      await delay(executionSpeed === "turbo" ? 300 : 700);

      // Step 2: ARV & Comps
      if (!isMountedRef.current) return;
      setActiveStepIndex(1);
      addLiveLog("ARV", `Scanning MLS comps within 0.5 miles. Calculating $/sqft baseline for ${deal.city} sub-market.`);
      await delay(executionSpeed === "turbo" ? 300 : 800);

      // Step 3: Rehab
      if (!isMountedRef.current) return;
      setActiveStepIndex(2);
      addLiveLog("Rehab", `Analyzing property physical scope: Roofing, Kitchen/Bath, HVAC, Flooring. Applying 15% contingency reserve.`);
      await delay(executionSpeed === "turbo" ? 300 : 800);

      // Step 4: Underwriting & 70% Rule
      if (!isMountedRef.current) return;
      setActiveStepIndex(3);
      addLiveLog("Supervisor", `Computing 70% Rule MAO formula. Running debt-service financing and cash-on-cash return simulations.`);
      await delay(executionSpeed === "turbo" ? 300 : 800);

      // Step 5: Compliance
      if (!isMountedRef.current) return;
      setActiveStepIndex(4);
      addLiveLog("Compliance", `Verifying NC Secretary of State LLC entity status, Deed of Trust usury limits, and NC HB 797 Wholesaling Broker mandates.`);
      await delay(executionSpeed === "turbo" ? 300 : 700);

      // Step 6: Contractors & Escrow
      if (!isMountedRef.current) return;
      setActiveStepIndex(5);
      addLiveLog("Project", `Matching vetted local NC licensed contractors (GC, Electrician, HVAC, Roofer) and establishing 6-phase Escrow Draw milestones.`);
      await delay(executionSpeed === "turbo" ? 300 : 700);

      // Step 7: Legal Documents & Server Commit
      if (!isMountedRef.current) return;
      setActiveStepIndex(6);
      addLiveLog("Supervisor", `Auto-generating NC Standard Form 2-T Purchase Contract, Construction Escrow Deposit Certificate, and Lien Waivers.`);

      // Call server to persist deterministic results
      const res = await fetch("/api/execute-autonomous-pipeline", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dealId: deal.id,
          targetStatus: "Underwriting"
        })
      });

      if (!res.ok) {
        throw new Error("Failed to execute autonomous pipeline on server");
      }

      const data = await res.json();
      if (!isMountedRef.current) return;
      setUpdatedDealResult(data.deal);
      addLiveLog("Supervisor", `🎯 AUTONOMOUS PIPELINE COMPLETE! All 7 stages executed. Deal is now fully underwritten and offer-ready.`);

      setIsCompleted(true);
      setActiveStepIndex(7); // all done
      onComplete(data.deal);
    } catch (err) {
      console.error("Pipeline execution failed:", err);
      if (isMountedRef.current) {
        addLiveLog("Supervisor", `⚠️ Pipeline error: ${String(err)}`);
      }
    } finally {
      if (isMountedRef.current) {
        setIsExecuting(false);
      }
    }
  };

  const addLiveLog = (agent: string, text: string) => {
    setLiveLogs((prev) => [
      ...prev,
      {
        id: `log-${Date.now()}-${Math.random()}`,
        agent,
        text,
        time: new Date().toLocaleTimeString()
      }
    ]);
  };

  const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

  if (!isOpen) return null;

  const currentDeal = updatedDealResult || deal;
  const isFinished = isCompleted || activeStepIndex >= 7;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-zinc-900 border border-zinc-700/80 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Modal Top Bar */}
        <div className="p-5 bg-zinc-950/80 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Zap className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-extrabold text-zinc-100 tracking-tight">
                  Autonomous Multi-Agent Deal Pipeline
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-wider">
                  1-Click Auto-Pilot
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Executing full end-to-end real estate acquisition sequence for <strong className="text-zinc-200">{deal.address}, {deal.city}, NC</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Speed toggle */}
            <div className="flex bg-zinc-900 border border-zinc-800 rounded-xl p-0.5 text-[10px] font-bold">
              <button
                type="button"
                onClick={() => setExecutionSpeed("normal")}
                className={`px-2.5 py-1 rounded-lg transition ${
                  executionSpeed === "normal" ? "bg-emerald-600 text-white" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                Standard
              </button>
              <button
                type="button"
                onClick={() => setExecutionSpeed("turbo")}
                className={`px-2.5 py-1 rounded-lg transition ${
                  executionSpeed === "turbo" ? "bg-emerald-600 text-white" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                ⚡ Turbo
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Modal Main Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Target Property Hero Strip */}
          <div className="p-4 bg-zinc-950/60 rounded-2xl border border-zinc-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-3.5">
              {deal.imageUrl && (
                <img
                  src={deal.imageUrl}
                  alt={deal.address}
                  className="w-16 h-16 rounded-xl object-cover border border-zinc-800 shadow-sm"
                />
              )}
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-extrabold text-emerald-400">{deal.mlsNumber || "MLS Verified"}</span>
                  {deal.parcelId && (
                    <span className="text-[10px] font-semibold text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                      {deal.parcelId}
                    </span>
                  )}
                </div>
                <h3 className="text-base font-extrabold text-zinc-100">{deal.address}</h3>
                <div className="flex items-center text-xs text-zinc-400 mt-0.5 space-x-3">
                  <span>{deal.city}, NC {deal.zip}</span>
                  <span>•</span>
                  <span>{deal.bed} Bed / {deal.bath} Bath</span>
                  <span>•</span>
                  <span>{deal.sqft.toLocaleString()} sqft</span>
                </div>
              </div>
            </div>

            {/* Current Asking vs Max Allowable Offer */}
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider block">List Asking Price</span>
                <span className="text-base font-extrabold text-zinc-200">${deal.askingPrice.toLocaleString()}</span>
              </div>
              <div className="h-8 w-px bg-zinc-800" />
              <div className="text-right">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">70% Rule MAO</span>
                <span className="text-lg font-black text-emerald-400">
                  ${(currentDeal.underwriting?.maxOffer70Rule || Math.round(deal.askingPrice * 0.75)).toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Action Trigger Banner if Not Started */}
          {!isExecuting && !isFinished && (
            <div className="p-5 bg-gradient-to-r from-emerald-950/40 via-zinc-900 to-zinc-900 border border-emerald-500/30 rounded-2xl flex items-center justify-between">
              <div>
                <h4 className="text-sm font-extrabold text-emerald-300">Ready to Launch Single Autonomous Pipeline</h4>
                <p className="text-xs text-zinc-400 mt-1">
                  All 7 subagents (Scout, ARV, Rehab, Underwriter, Compliance, Project, Legal) will execute deterministically in a coordinated chain.
                </p>
              </div>
              <button
                type="button"
                onClick={handleStartPipeline}
                className="flex items-center space-x-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-950/50 transition cursor-pointer flex-shrink-0"
              >
                <Play className="h-4 w-4 fill-white" />
                <span>Go For This Property Now</span>
              </button>
            </div>
          )}

          {/* 7-Step Pipeline Progress Rail */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">
                Autonomous Execution Sequence ({isFinished ? "7/7 Complete" : `${activeStepIndex}/7 in Progress`})
              </span>
              <span className="text-xs text-emerald-400 font-bold">
                {isFinished ? "✓ All Stages Verified" : isExecuting ? "Running Multi-Agent Orchestrator..." : "Standing By"}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-2.5">
              {PIPELINE_STEPS.map((step, idx) => {
                const isStepDone = isFinished || activeStepIndex > idx;
                const isStepActive = isExecuting && activeStepIndex === idx;
                const IconComponent = step.icon;

                return (
                  <div
                    key={step.id}
                    className={`p-3 rounded-2xl border transition-all duration-300 flex flex-col justify-between min-h-[140px] ${
                      isStepDone
                        ? "bg-emerald-950/20 border-emerald-500/30"
                        : isStepActive
                        ? "bg-zinc-850 border-emerald-400/80 shadow-md ring-1 ring-emerald-400/40"
                        : "bg-zinc-950/40 border-zinc-800/80 opacity-60"
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className={`p-1.5 rounded-xl border ${step.badgeColor}`}>
                          <IconComponent className="h-3.5 w-3.5" />
                        </span>
                        {isStepDone ? (
                          <CheckCircle className="h-4 w-4 text-emerald-400" />
                        ) : isStepActive ? (
                          <span className="flex h-2 w-2 relative">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-zinc-600">Step {step.number}</span>
                        )}
                      </div>

                      <div className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-400">
                        {step.agent} Agent
                      </div>
                      <h5 className="text-xs font-bold text-zinc-200 mt-0.5 leading-snug">
                        {step.title}
                      </h5>
                    </div>

                    <div className="mt-2 pt-2 border-t border-zinc-800/60">
                      <span className="text-[10px] font-semibold text-zinc-400 block truncate">
                        {isStepDone ? `✓ ${step.metricLabel}` : isStepActive ? "Calculating..." : "Queued"}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom Split: Live Telemetry Terminal & Scorecard */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Live Terminal Log Feed */}
            <div className="lg:col-span-7 bg-zinc-950 rounded-2xl border border-zinc-800 p-4 flex flex-col h-64 shadow-inner">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-850">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  </div>
                  <span className="text-xs font-mono font-bold text-zinc-400">agent-orchestrator.log</span>
                </div>
                <span className="text-[10px] font-mono text-zinc-500">Autonomous Telemetry</span>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2 font-mono text-[11px] pr-1">
                {liveLogs.map((log) => (
                  <div key={log.id} className="flex items-start space-x-2 leading-relaxed">
                    <span className="text-zinc-600 flex-shrink-0">{log.time}</span>
                    <span className="font-bold text-emerald-400 flex-shrink-0">[{log.agent}]</span>
                    <span className="text-zinc-300">{log.text}</span>
                  </div>
                ))}
                {isExecuting && (
                  <div className="flex items-center space-x-2 text-emerald-400 animate-pulse">
                    <span>›</span>
                    <span className="text-zinc-400">Processing next pipeline stage...</span>
                  </div>
                )}
              </div>
            </div>

            {/* Real-time Computed Scorecard */}
            <div className="lg:col-span-5 bg-zinc-900/60 rounded-2xl border border-zinc-800 p-4 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider mb-3">
                  Live Deal Underwriting Scorecard
                </h4>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800">
                    <span className="text-[10px] text-zinc-400 uppercase font-bold">Projected ARV</span>
                    <div className="text-sm font-black text-emerald-400 mt-0.5">
                      ${(currentDeal.underwriting?.arv || Math.round(deal.askingPrice * 1.55)).toLocaleString()}
                    </div>
                    <span className="text-[9px] text-zinc-500">MLS Comps Verified</span>
                  </div>

                  <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800">
                    <span className="text-[10px] text-zinc-400 uppercase font-bold">Rehab Budget</span>
                    <div className="text-sm font-black text-amber-400 mt-0.5">
                      ${(currentDeal.underwriting?.rehabCost || Math.round(deal.sqft * 48)).toLocaleString()}
                    </div>
                    <span className="text-[9px] text-zinc-500">6 Trades + 15% Buffer</span>
                  </div>

                  <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800">
                    <span className="text-[10px] text-zinc-400 uppercase font-bold">Max Offer (70%)</span>
                    <div className="text-sm font-black text-indigo-400 mt-0.5">
                      ${(currentDeal.underwriting?.maxOffer70Rule || Math.round(deal.askingPrice * 0.75)).toLocaleString()}
                    </div>
                    <span className="text-[9px] text-zinc-500">ARV × 0.70 - Rehab</span>
                  </div>

                  <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800">
                    <span className="text-[10px] text-zinc-400 uppercase font-bold">Projected Profit / ROI</span>
                    <div className="text-sm font-black text-emerald-400 mt-0.5">
                      ${(currentDeal.underwriting?.projectedProfit || 52000).toLocaleString()} ({currentDeal.underwriting?.roi || 18.5}%)
                    </div>
                    <span className="text-[9px] text-zinc-500">Leveraged CoC: {currentDeal.underwriting?.cashOnCash || 24.5}%</span>
                  </div>
                </div>
              </div>

              {/* Quick Legal Packet Links if Finished */}
              {isFinished && (
                <div className="mt-4 pt-3 border-t border-zinc-800 space-y-2">
                  <span className="text-[10px] uppercase font-bold text-zinc-400">Generated Closing Documents:</span>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => onViewDoc?.("purchase_contract")}
                      className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg text-[11px] font-bold transition cursor-pointer"
                    >
                      <FileText className="h-3 w-3" />
                      <span>NC Form 2-T Offer Contract</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onViewDoc?.("escrow_certificate")}
                      className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-750 text-zinc-200 border border-zinc-700 rounded-lg text-[11px] font-bold transition cursor-pointer"
                    >
                      <ShieldCheck className="h-3 w-3 text-emerald-400" />
                      <span>Escrow Draw Certificate</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-5 bg-zinc-950/80 border-t border-zinc-800 flex items-center justify-between">
          <div className="text-xs text-zinc-400">
            {isFinished ? (
              <span className="flex items-center text-emerald-400 font-bold space-x-1.5">
                <CheckCircle className="h-4 w-4" />
                <span>Pipeline Finished: Deal is fully underwritten and in active execution stage.</span>
              </span>
            ) : isExecuting ? (
              <span className="text-zinc-300">Agents are executing autonomous sequence...</span>
            ) : (
              <span>Click "Go For This Property" to execute all stages autonomously.</span>
            )}
          </div>

          <div className="flex items-center space-x-3">
            {!isExecuting && !isFinished ? (
              <button
                type="button"
                onClick={handleStartPipeline}
                className="flex items-center space-x-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-xs transition cursor-pointer"
              >
                <Zap className="h-4 w-4" />
                <span>Go For Property (Launch All Steps)</span>
              </button>
            ) : isFinished ? (
              <button
                type="button"
                onClick={onClose}
                className="flex items-center space-x-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-xs transition cursor-pointer"
              >
                <span>View Full Deal Underwriting</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                type="button"
                disabled
                className="flex items-center space-x-2 px-5 py-2.5 bg-zinc-800 text-zinc-500 font-extrabold text-xs rounded-xl cursor-not-allowed"
              >
                <div className="w-3.5 h-3.5 border-2 border-zinc-500 border-t-transparent rounded-full animate-spin" />
                <span>Executing Pipeline...</span>
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
