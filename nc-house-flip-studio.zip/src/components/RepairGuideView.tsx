/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { PropertyDeal, RepairPlan, NCContractorDirectoryItem } from '../types';
import { NC_CONTRACTOR_DIRECTORY } from '../lib/contractorCatalog';
import { COMMON_NC_REPAIR_PRESETS, RepairTemplatePreset } from '../lib/repairGuideEngine';
import { RepairPlanInspector } from './RepairPlanInspector';
import { ContractorRFPModal } from './ContractorRFPModal';
import { 
  Sparkles, 
  Wrench, 
  HardHat, 
  ShieldCheck, 
  DollarSign, 
  Clock, 
  Search, 
  Filter, 
  Plus, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Phone, 
  Mail, 
  MapPin, 
  Layers, 
  FileText, 
  RefreshCw,
  Home,
  Check,
  Award,
  Zap,
  Flame,
  Droplets,
  Hammer
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface RepairGuideViewProps {
  deals: PropertyDeal[];
  activeDeal: PropertyDeal;
  onSelectDeal: (deal: PropertyDeal) => void;
  onUpdateDeal: (deal: PropertyDeal) => void;
}

export const RepairGuideView: React.FC<RepairGuideViewProps> = ({
  deals,
  activeDeal,
  onSelectDeal,
  onUpdateDeal
}) => {
  // Navigation & Sub-views
  const [activeSubTab, setActiveSubTab] = useState<'generator' | 'ledger' | 'contractors'>('generator');
  
  // Selected repair plan for full-screen / deep inspection
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);

  // Generator form state
  const [customTaskTitle, setCustomTaskTitle] = useState('');
  const [customTrade, setCustomTrade] = useState('Foundation & Crawlspace');
  const [customZone, setCustomZone] = useState('Crawlspace');
  const [customSeverity, setCustomSeverity] = useState<'low' | 'moderate' | 'high' | 'critical'>('high');
  const [customPromptDetails, setCustomPromptDetails] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);

  // Contractor directory search & filter state
  const [contractorSearch, setContractorSearch] = useState('');
  const [contractorTradeFilter, setContractorTradeFilter] = useState('ALL');
  const [contractorCityFilter, setContractorCityFilter] = useState('ALL');
  const [contractorLicenseFilter, setContractorLicenseFilter] = useState('ALL');
  const [selectedContractorForRFP, setSelectedContractorForRFP] = useState<NCContractorDirectoryItem | null>(null);
  const [rfpTargetPlan, setRfpTargetPlan] = useState<RepairPlan | null>(null);

  // Ensure default plans exist for active deal if empty
  useEffect(() => {
    if (!activeDeal.repairPlans || activeDeal.repairPlans.length === 0) {
      // Auto-populate initial high-impact NC flip repair plans
      fetch(`/api/repair-guide/generate-plan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dealId: activeDeal.id,
          taskTitle: COMMON_NC_REPAIR_PRESETS[0].title,
          tradeCategory: COMMON_NC_REPAIR_PRESETS[0].trade,
          roomZone: COMMON_NC_REPAIR_PRESETS[0].roomZone,
          severity: COMMON_NC_REPAIR_PRESETS[0].severity
        })
      })
        .then(res => res.json())
        .then(data => {
          if (data.plan) {
            const updatedDeal = {
              ...activeDeal,
              repairPlans: [data.plan]
            };
            onUpdateDeal(updatedDeal);
          }
        })
        .catch(err => console.error('Error seeding initial repair plan:', err));
    }
  }, [activeDeal.id]);

  // Handle plan generation from preset or custom input
  const handleGeneratePlan = async (
    title: string,
    trade: string,
    zone: string,
    severity: 'low' | 'moderate' | 'high' | 'critical',
    promptNote?: string
  ) => {
    setIsGenerating(true);
    setGenerationError(null);

    try {
      const res = await fetch('/api/repair-guide/generate-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dealId: activeDeal.id,
          taskTitle: title,
          tradeCategory: trade,
          roomZone: zone,
          severity: severity,
          customPrompt: promptNote
        })
      });

      const data = await res.json();
      if (data.success && data.plan) {
        const existingPlans = activeDeal.repairPlans || [];
        const updatedPlans = [data.plan, ...existingPlans.filter(p => p.id !== data.plan.id)];
        
        // Save to backend deal
        await fetch(`/api/deals/${activeDeal.id}/repair-plans`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data.plan)
        });

        const updatedDeal = {
          ...activeDeal,
          repairPlans: updatedPlans
        };
        onUpdateDeal(updatedDeal);
        setSelectedPlanId(data.plan.id);
        setActiveSubTab('ledger');
        setCustomTaskTitle('');
        setCustomPromptDetails('');
      } else {
        setGenerationError('Failed to generate plan. Please try again.');
      }
    } catch (err: any) {
      console.error('Generation error:', err);
      setGenerationError(err.message || 'Error communicating with AI service');
    } finally {
      setIsGenerating(false);
    }
  };

  // Update existing plan in deal state & backend
  const handleUpdatePlan = async (updatedPlan: RepairPlan) => {
    const existingPlans = activeDeal.repairPlans || [];
    const newPlans = existingPlans.map(p => p.id === updatedPlan.id ? updatedPlan : p);
    
    const updatedDeal = {
      ...activeDeal,
      repairPlans: newPlans
    };
    onUpdateDeal(updatedDeal);

    await fetch(`/api/deals/${activeDeal.id}/repair-plans`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedPlan)
    });
  };

  // Delete plan from deal state & backend
  const handleDeletePlan = async (planId: string) => {
    const existingPlans = activeDeal.repairPlans || [];
    const newPlans = existingPlans.filter(p => p.id !== planId);
    
    const updatedDeal = {
      ...activeDeal,
      repairPlans: newPlans
    };
    onUpdateDeal(updatedDeal);
    if (selectedPlanId === planId) {
      setSelectedPlanId(null);
    }

    await fetch(`/api/deals/${activeDeal.id}/repair-plans/${planId}`, {
      method: 'DELETE'
    });
  };

  // Convert plan into Deal Rehab Item & Milestone
  const handleApplyToRehab = async (plan: RepairPlan, contractorId?: string) => {
    const res = await fetch(`/api/deals/${activeDeal.id}/apply-repair-plan-to-rehab`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ planId: plan.id, contractorId: contractorId || plan.assignedContractorId })
    });

    const data = await res.json();
    if (data.success && data.deal) {
      onUpdateDeal(data.deal);
    }
  };

  // Filtered contractors directory
  const filteredContractors = NC_CONTRACTOR_DIRECTORY.filter(c => {
    const matchSearch = !contractorSearch.trim() || 
      c.name.toLowerCase().includes(contractorSearch.toLowerCase()) ||
      c.trade.toLowerCase().includes(contractorSearch.toLowerCase()) ||
      c.city.toLowerCase().includes(contractorSearch.toLowerCase()) ||
      c.licenseNumber.toLowerCase().includes(contractorSearch.toLowerCase()) ||
      c.specialties.some(s => s.toLowerCase().includes(contractorSearch.toLowerCase()));

    const matchTrade = contractorTradeFilter === 'ALL' || c.trade.toLowerCase() === contractorTradeFilter.toLowerCase();
    const matchCity = contractorCityFilter === 'ALL' || c.city.toLowerCase() === contractorCityFilter.toLowerCase();
    const matchLicense = contractorLicenseFilter === 'ALL' || c.licenseTier === contractorLicenseFilter;

    return matchSearch && matchTrade && matchCity && matchLicense;
  });

  // Calculate totals
  const repairPlans = activeDeal.repairPlans || [];
  const totalRepairBudget = repairPlans.reduce((sum, p) => sum + (p.totalEstimatedCost || 0), 0);
  const totalLaborHours = repairPlans.reduce((sum, p) => sum + (p.estimatedLaborHours || 0), 0);
  const completedPlansCount = repairPlans.filter(p => p.status === 'completed').length;

  const currentSelectedPlan = repairPlans.find(p => p.id === selectedPlanId) || repairPlans[0];

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Top Header Bar */}
      <div className="p-5 border-b border-zinc-850 bg-zinc-900/60 backdrop-blur-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="p-2.5 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded-2xl shadow-lg">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-black tracking-tight text-zinc-100">
                  AI Step-by-Step Repair Guide & NC Contractor Engine
                </h1>
                <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  NC Code 2024 Verified
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Ground repair scopes in NC Residential Code, generate materials & SOPs, and instantly match verified local tradesmen.
              </p>
            </div>
          </div>
        </div>

        {/* Deal Selector Dropdown */}
        <div className="flex items-center space-x-3">
          <div className="text-right hidden sm:block">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 block">
              Active Project
            </span>
            <span className="text-xs font-black text-zinc-200">{activeDeal.address}, {activeDeal.city}</span>
          </div>

          <select
            value={activeDeal.id}
            onChange={(e) => {
              const selected = deals.find(d => d.id === e.target.value);
              if (selected) onSelectDeal(selected);
            }}
            className="px-3.5 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-200 hover:border-zinc-700 transition cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-500"
          >
            {deals.map(d => (
              <option key={d.id} value={d.id}>
                {d.address} ({d.city}) • Built {d.yearBuilt || '1970'}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Summary KPI Strip */}
      <div className="px-6 py-3.5 bg-zinc-900/40 border-b border-zinc-850 grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
            <DollarSign className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 block">
              Total Repair Est.
            </span>
            <span className="text-sm font-black text-emerald-400 font-mono">
              ${totalRepairBudget.toLocaleString()}
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="p-2 bg-sky-500/10 text-sky-400 rounded-xl border border-sky-500/20">
            <Clock className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 block">
              Total Labor Hours
            </span>
            <span className="text-sm font-black text-zinc-100 font-mono">
              {totalLaborHours} Hours (~{Math.ceil(totalLaborHours / 8)} Days)
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
            <Layers className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 block">
              Active Repair Plans
            </span>
            <span className="text-sm font-black text-zinc-100 font-mono">
              {repairPlans.length} ({completedPlansCount} Completed)
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
            <ShieldCheck className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 block">
              NC Verified Trades
            </span>
            <span className="text-sm font-black text-amber-400 font-mono">
              {NC_CONTRACTOR_DIRECTORY.length} Vetted Contractors
            </span>
          </div>
        </div>
      </div>

      {/* Main View Nav Tabs */}
      <div className="px-6 pt-4 pb-2 border-b border-zinc-850 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveSubTab('generator')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center space-x-2 ${
              activeSubTab === 'generator'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>AI Plan Generator</span>
          </button>

          <button
            onClick={() => setActiveSubTab('ledger')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center space-x-2 ${
              activeSubTab === 'ledger'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
            }`}
          >
            <FileText className="h-3.5 w-3.5" />
            <span>Active Repair Plans ({repairPlans.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('contractors')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center space-x-2 ${
              activeSubTab === 'contractors'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
            }`}
          >
            <HardHat className="h-3.5 w-3.5" />
            <span>NC Contractor Directory ({NC_CONTRACTOR_DIRECTORY.length})</span>
          </button>
        </div>

        {activeSubTab === 'ledger' && (
          <button
            onClick={() => setActiveSubTab('generator')}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-emerald-400 rounded-xl text-xs font-extrabold border border-emerald-500/30 transition cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>New Repair SOP</span>
          </button>
        )}
      </div>

      {/* Main SubTab Content Area */}
      <div className="flex-1 min-h-0 overflow-y-auto p-6">
        {/* SUBTAB 1: AI PLAN GENERATOR */}
        {activeSubTab === 'generator' && (
          <div className="max-w-6xl mx-auto space-y-8">
            {/* Custom Prompt Card */}
            <div className="bg-zinc-900/70 border border-zinc-800 rounded-3xl p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2.5 bg-emerald-600/20 text-emerald-400 rounded-2xl border border-emerald-500/30">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-extrabold text-zinc-100">
                      Generate Custom Code-Compliant Repair Plan
                    </h2>
                    <p className="text-xs text-zinc-400">
                      Enter any property defect or custom scope to generate materials takeoff, tools, SOP phases, and match local contractors.
                    </p>
                  </div>
                </div>

                <span className="text-[10px] font-mono font-extrabold text-zinc-500 bg-zinc-950 px-2.5 py-1 rounded-lg border border-zinc-850">
                  Target: {activeDeal.address} (Built {activeDeal.yearBuilt || 1970})
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div>
                  <label className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-400 block mb-1">
                    Trade Category
                  </label>
                  <select
                    value={customTrade}
                    onChange={(e) => setCustomTrade(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="Foundation & Crawlspace">Foundation & Crawlspace</option>
                    <option value="MEP - Electrical">MEP - Electrical</option>
                    <option value="MEP - Plumbing">MEP - Plumbing</option>
                    <option value="MEP - HVAC">MEP - HVAC</option>
                    <option value="Structural Framing">Structural Framing</option>
                    <option value="Roofing & Attic">Roofing & Attic</option>
                    <option value="Bath & Tile">Bath & Tile</option>
                    <option value="Drywall & Insulation">Drywall & Insulation</option>
                    <option value="Flooring & Finishes">Flooring & Finishes</option>
                    <option value="General Contracting">General Contracting</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-400 block mb-1">
                    Location Zone
                  </label>
                  <select
                    value={customZone}
                    onChange={(e) => setCustomZone(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="Crawlspace">Crawlspace</option>
                    <option value="Living Room">Living Room</option>
                    <option value="Kitchen">Kitchen</option>
                    <option value="Master Bath">Master Bath</option>
                    <option value="Hall Bath">Hall Bath</option>
                    <option value="Bedrooms">Bedrooms</option>
                    <option value="Utility Room">Utility Room / Electrical Panel</option>
                    <option value="Roof & Attic">Roof & Attic</option>
                    <option value="Exterior / Siding">Exterior / Siding</option>
                    <option value="Whole House">Whole House</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-400 block mb-1">
                    Severity Level
                  </label>
                  <select
                    value={customSeverity}
                    onChange={(e) => setCustomSeverity(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="critical">Critical (Immediate Structural / Life Safety / Code)</option>
                    <option value="high">High (Major Rehab / Trade Required)</option>
                    <option value="moderate">Moderate (Standard Renovation Upgrade)</option>
                    <option value="low">Low (Punchout / Cosmetic Touchup)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-400 block mb-1">
                  Repair Task Title / Specific Defect
                </label>
                <input
                  type="text"
                  placeholder="e.g., Water damage under dishwasher causing sagging subfloor and rotted 2x8 joist"
                  value={customTaskTitle}
                  onChange={(e) => setCustomTaskTitle(e.target.value)}
                  className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-400 block mb-1">
                  Additional Operator Context / Observations (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Add specific dimensions, brand preferences (e.g. Uponor PEX-A, Square D QO), or NC county inspection constraints..."
                  value={customPromptDetails}
                  onChange={(e) => setCustomPromptDetails(e.target.value)}
                  className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:ring-1 focus:ring-emerald-500 resize-none"
                />
              </div>

              {generationError && (
                <div className="p-3 bg-rose-500/20 border border-rose-500/40 rounded-xl text-xs text-rose-300 font-bold flex items-center space-x-2">
                  <AlertTriangle className="h-4 w-4" />
                  <span>{generationError}</span>
                </div>
              )}

              <div className="flex justify-end pt-1">
                <button
                  onClick={() => handleGeneratePlan(
                    customTaskTitle || `${customTrade} Rehabilitation`,
                    customTrade,
                    customZone,
                    customSeverity,
                    customPromptDetails
                  )}
                  disabled={isGenerating}
                  className="flex items-center space-x-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-xs font-black uppercase tracking-wider transition shadow-xl cursor-pointer disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      <span>Synthesizing NC Code SOP & Materials Takeoff...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      <span>Generate Step-by-Step SOP & Match Tradesmen</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Quick-Select NC Flip Repair Presets */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-extrabold text-zinc-100 uppercase tracking-tight">
                    Pre-Engineered North Carolina Flip Repair Presets
                  </h3>
                  <p className="text-xs text-zinc-400">
                    One-click launch standard high-impact repairs with full NCRC 2024 code grounding and pre-vetted trade requirements.
                  </p>
                </div>
                <span className="text-[10px] text-zinc-500 font-mono">
                  {COMMON_NC_REPAIR_PRESETS.length} Presets Available
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {COMMON_NC_REPAIR_PRESETS.map((preset, idx) => (
                  <div
                    key={idx}
                    className="bg-zinc-900/60 hover:bg-zinc-900 border border-zinc-800 hover:border-zinc-700 rounded-2xl p-4.5 space-y-3 transition flex flex-col justify-between"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          preset.severity === 'critical'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : preset.severity === 'high'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        }`}>
                          {preset.severity}
                        </span>

                        <span className="text-[10px] font-extrabold text-zinc-400 bg-zinc-950 px-2 py-0.5 rounded-md border border-zinc-850">
                          {preset.roomZone}
                        </span>
                      </div>

                      <h4 className="text-xs font-black text-zinc-100 line-clamp-2">
                        {preset.title}
                      </h4>

                      <p className="text-[11px] text-zinc-400 line-clamp-3 leading-relaxed">
                        {preset.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-zinc-850 flex items-center justify-between">
                      <div className="font-mono text-xs">
                        <span className="font-extrabold text-emerald-400">${preset.defaultCost.toLocaleString()}</span>
                        <span className="text-[10px] text-zinc-500 ml-1.5">• {preset.laborHours}h</span>
                      </div>

                      <button
                        onClick={() => handleGeneratePlan(preset.title, preset.trade, preset.roomZone, preset.severity)}
                        disabled={isGenerating}
                        className="flex items-center space-x-1 px-3 py-1.5 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold transition cursor-pointer"
                      >
                        <span>Generate</span>
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 2: ACTIVE REPAIR PLANS LEDGER & INSPECTOR */}
        {activeSubTab === 'ledger' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
            {/* Left Column: Plan Cards List */}
            <div className="lg:col-span-5 space-y-3 overflow-y-auto pr-1">
              <div className="flex items-center justify-between pb-1">
                <span className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
                  Property Repair Scopes ({repairPlans.length})
                </span>
                <span className="text-xs text-emerald-400 font-mono font-bold">
                  Total: ${totalRepairBudget.toLocaleString()}
                </span>
              </div>

              {repairPlans.length === 0 ? (
                <div className="p-8 text-center bg-zinc-900/40 border border-zinc-800 rounded-3xl space-y-3">
                  <p className="text-xs text-zinc-400">No repair plans created for this property yet.</p>
                  <button
                    onClick={() => setActiveSubTab('generator')}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition"
                  >
                    Create First Repair Plan
                  </button>
                </div>
              ) : (
                repairPlans.map((plan) => {
                  const isSelected = selectedPlanId === plan.id || (!selectedPlanId && currentSelectedPlan?.id === plan.id);
                  const totalSteps = plan.executionPhases.flatMap(p => p.steps).length;
                  const completedSteps = plan.executionPhases.flatMap(p => p.steps).filter(s => s.completed).length;

                  return (
                    <div
                      key={plan.id}
                      onClick={() => setSelectedPlanId(plan.id)}
                      className={`p-4 rounded-2xl border transition cursor-pointer space-y-2.5 ${
                        isSelected
                          ? 'bg-zinc-900/90 border-emerald-500/70 shadow-lg ring-1 ring-emerald-500/30'
                          : 'bg-zinc-900/40 border-zinc-850 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          plan.severity === 'critical'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : plan.severity === 'high'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        }`}>
                          {plan.severity}
                        </span>

                        <span className="text-[10px] font-mono text-zinc-400">
                          {plan.roomZone}
                        </span>
                      </div>

                      <h4 className="text-xs font-extrabold text-zinc-100 line-clamp-1">
                        {plan.title}
                      </h4>

                      <div className="flex items-center justify-between text-xs pt-1 border-t border-zinc-850 font-mono">
                        <span className="font-extrabold text-emerald-400">
                          ${plan.totalEstimatedCost.toLocaleString()}
                        </span>
                        <span className="text-zinc-400 text-[11px]">
                          {completedSteps}/{totalSteps} SOP Done
                        </span>
                      </div>

                      {plan.assignedContractorName && (
                        <div className="text-[10px] text-zinc-400 flex items-center space-x-1.5 pt-0.5">
                          <HardHat className="h-3 w-3 text-emerald-400" />
                          <span className="line-clamp-1">{plan.assignedContractorName}</span>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {/* Right Column: Deep-Dive Plan Inspector */}
            <div className="lg:col-span-7 h-full">
              {currentSelectedPlan ? (
                <RepairPlanInspector
                  plan={currentSelectedPlan}
                  deal={activeDeal}
                  onUpdatePlan={handleUpdatePlan}
                  onDeletePlan={handleDeletePlan}
                  onApplyToRehab={handleApplyToRehab}
                />
              ) : (
                <div className="p-12 text-center bg-zinc-900/40 border border-zinc-800 rounded-3xl space-y-2">
                  <p className="text-xs text-zinc-400">Select a repair plan on the left to inspect SOP phases, materials takeoff, and match contractors.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SUBTAB 3: NC CONTRACTOR & REPAIRMAN DIRECTORY */}
        {activeSubTab === 'contractors' && (
          <div className="space-y-6">
            {/* Search & Filter Bar */}
            <div className="bg-zinc-900/70 border border-zinc-800 rounded-3xl p-5 shadow-xl space-y-3">
              <div className="flex flex-col md:flex-row items-center gap-3">
                <div className="relative flex-1 w-full">
                  <Search className="absolute left-3.5 top-3 h-4 w-4 text-zinc-500" />
                  <input
                    type="text"
                    placeholder="Search by contractor name, specialty, license number, or phone..."
                    value={contractorSearch}
                    onChange={(e) => setContractorSearch(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                  <select
                    value={contractorTradeFilter}
                    onChange={(e) => setContractorTradeFilter(e.target.value)}
                    className="px-3 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="ALL">All Trades</option>
                    <option value="General Contracting">General Contracting</option>
                    <option value="MEP - Electrical">MEP - Electrical</option>
                    <option value="MEP - Plumbing">MEP - Plumbing</option>
                    <option value="MEP - HVAC">MEP - HVAC</option>
                    <option value="Foundation & Crawlspace">Foundation & Crawlspace</option>
                    <option value="Roofing & Attic">Roofing & Attic</option>
                    <option value="Bath & Tile">Bath & Tile</option>
                    <option value="Flooring & Finishes">Flooring & Punchout</option>
                    <option value="Drywall & Insulation">Drywall & Insulation</option>
                  </select>

                  <select
                    value={contractorCityFilter}
                    onChange={(e) => setContractorCityFilter(e.target.value)}
                    className="px-3 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="ALL">All NC Cities</option>
                    <option value="Charlotte">Charlotte / Mecklenburg</option>
                    <option value="Raleigh">Raleigh / Wake</option>
                    <option value="Durham">Durham / Triangle</option>
                    <option value="Greensboro">Greensboro / Triad</option>
                  </select>

                  <select
                    value={contractorLicenseFilter}
                    onChange={(e) => setContractorLicenseFilter(e.target.value)}
                    className="px-3 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="ALL">All License Tiers</option>
                    <option value="Unlimited GC">Unlimited GC</option>
                    <option value="Master Electrician">Master Electrician</option>
                    <option value="Master Plumber">Master Plumber</option>
                    <option value="HVAC Class I">HVAC Class I</option>
                    <option value="Specialty Trade">Specialty Trade</option>
                    <option value="Punchout Handyman">Punchout Handyman</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Contractors Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredContractors.map((contractor) => (
                <div
                  key={contractor.id}
                  className="bg-zinc-900/60 hover:bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700 rounded-3xl p-5 space-y-3.5 transition flex flex-col justify-between shadow-xl"
                >
                  <div className="space-y-2.5">
                    {/* Top Badges */}
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                        {contractor.licenseTier}
                      </span>
                      <span className="text-[10px] font-mono font-bold text-zinc-400 flex items-center space-x-1">
                        <MapPin className="h-3 w-3 text-zinc-500" />
                        <span>{contractor.city}, NC</span>
                      </span>
                    </div>

                    <div>
                      <h3 className="text-sm font-black text-zinc-100">{contractor.name}</h3>
                      <p className="text-[11px] text-zinc-400 font-mono mt-0.5">
                        {contractor.licenseNumber} • {contractor.phone}
                      </p>
                    </div>

                    {/* Verified Badges */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {contractor.badgeHighlights.map((badge, i) => (
                        <span key={i} className="text-[9px] bg-zinc-950 text-zinc-400 px-2 py-0.5 rounded-md border border-zinc-850">
                          ✓ {badge}
                        </span>
                      ))}
                    </div>

                    {/* Specialties */}
                    <div className="space-y-1 pt-1">
                      <span className="text-[9px] font-extrabold uppercase tracking-wider text-zinc-500 block">
                        Trade Specialties:
                      </span>
                      <p className="text-[11px] text-zinc-300 leading-snug">
                        {contractor.specialties.join(' • ')}
                      </p>
                    </div>
                  </div>

                  {/* Pricing & Actions */}
                  <div className="pt-3 border-t border-zinc-850 flex items-center justify-between">
                    <div>
                      <span className="text-sm font-mono font-black text-emerald-400">
                        ${contractor.hourlyRate}/hr
                      </span>
                      <span className="text-[9px] text-zinc-500 block">
                        {contractor.availability}
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <a
                        href={`tel:${contractor.phone}`}
                        className="p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl transition cursor-pointer"
                        title="Call Contractor"
                      >
                        <Phone className="h-3.5 w-3.5 text-emerald-400" />
                      </a>

                      <button
                        onClick={() => {
                          const target = repairPlans[0] || {
                            id: 'temp-plan',
                            dealId: activeDeal.id,
                            propertyAddress: activeDeal.address,
                            city: activeDeal.city,
                            title: `${contractor.trade} Rehabilitation`,
                            trade: contractor.trade,
                            roomZone: 'Whole House',
                            severity: 'high',
                            problemDiagnosis: `Scope of work for ${contractor.trade} at ${activeDeal.address}.`,
                            rootCauses: ['Deferred maintenance'],
                            riskFactors: ['Code compliance inspection delay'],
                            ncCodeCitation: '2024 NC Residential Building Code',
                            permitRequired: true,
                            permitType: 'Trade Permit',
                            diyFeasibility: 'Licensed Trade Required',
                            estimatedLaborHours: 24,
                            estimatedMaterialCost: 2000,
                            estimatedLaborCost: 2500,
                            totalEstimatedCost: 4500,
                            requiredTools: [],
                            requiredMaterials: [],
                            safetyPPE: ['Safety Glasses', 'Gloves'],
                            criticalPitfalls: [],
                            proTips: [],
                            executionPhases: [],
                            createdAt: new Date().toISOString(),
                            status: 'ready'
                          };
                          setRfpTargetPlan(target);
                          setSelectedContractorForRFP(contractor);
                        }}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-md cursor-pointer"
                      >
                        Request Bid / SOW
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Contractor RFP Modal */}
      {selectedContractorForRFP && rfpTargetPlan && (
        <ContractorRFPModal
          deal={activeDeal}
          plan={rfpTargetPlan}
          contractor={selectedContractorForRFP}
          onClose={() => {
            setSelectedContractorForRFP(null);
            setRfpTargetPlan(null);
          }}
          onAssignContractor={() => {
            if (rfpTargetPlan) {
              handleUpdatePlan({
                ...rfpTargetPlan,
                assignedContractorId: selectedContractorForRFP.id,
                assignedContractorName: selectedContractorForRFP.name,
                assignedContractorPhone: selectedContractorForRFP.phone,
                assignedContractorRate: `$${selectedContractorForRFP.hourlyRate}/hr`,
                status: 'contracted'
              });
            }
          }}
        />
      )}
    </div>
  );
};
