/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Compass, 
  MapPin, 
  TrendingUp, 
  Sparkles, 
  AlertCircle, 
  CheckCircle, 
  CheckCircle2, 
  HelpCircle, 
  Building, 
  Zap, 
  Hammer, 
  ShieldCheck, 
  Calendar, 
  DollarSign, 
  AlertTriangle, 
  UserCheck, 
  FileText, 
  Layers, 
  Clock, 
  ArrowRight, 
  Lock, 
  Unlock, 
  Printer, 
  Clipboard, 
  Plus, 
  Trash, 
  Upload,
  RefreshCw
} from "lucide-react";
import { PropertyDeal, SurveyNotes, FundingDetails, ContractorGuideline, CompletionChecklistItem, BankDraw, RehabLineItem, Milestone, WorkSession } from "../types";

interface PartnersOpsHubProps {
  deal: PropertyDeal;
  onUpdateDeal: (updatedDeal: PropertyDeal) => Promise<void>;
}

export default function PartnersOpsHub({ deal, onUpdateDeal }: PartnersOpsHubProps) {
  const [activeTab, setActiveTab] = useState<"survey" | "funding" | "guidelines" | "completion">("survey");
  const [isSaving, setIsSaving] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  // --- Initializing Hub States from deal prop ---
  const [survey, setSurvey] = useState<SurveyNotes>({
    structuralRating: 'good',
    foundationNotes: '',
    waterDamageFound: false,
    waterDamageNotes: '',
    roofNotes: '',
    electricalNotes: '',
    plumbingNotes: '',
    generalSurveyNotes: '',
    surveyDate: new Date().toISOString().split('T')[0],
    surveyedBy: 'John & Business Partner'
  });

  const [funding, setFunding] = useState<FundingDetails>({
    hardMoneySource: 'First National Hard Money LLC',
    hardMoneyAmount: 0,
    interestRate: 10.5,
    points: 2.0,
    partnerEquityAmount: 0,
    additionalCapitalNeeded: 0,
    ltcRatio: 0,
    ltvRatio: 0,
    debtServiceReserve: 15000,
    bankDrawsSubmitted: []
  });

  const [guidelines, setGuidelines] = useState<ContractorGuideline[]>([]);
  const [completion, setCompletion] = useState<CompletionChecklistItem[]>([]);

  // Local state for forms
  const [newGuideline, setNewGuideline] = useState({
    trade: "Electrical",
    guidelineText: "",
    qualityCheckSOP: "",
    safetyRequirement: ""
  });

  const [newDrawAmount, setNewDrawAmount] = useState<number>(0);
  const [newDrawNotes, setNewDrawNotes] = useState<string>("");
  const [selectedMilestoneForDraw, setSelectedMilestoneForDraw] = useState<string>("");

  const [newPunchTask, setNewPunchTask] = useState({
    category: "Interior" as const,
    taskName: ""
  });

  // --- Workspace Multi-Session State and Persistence ---
  const [sessions, setSessions] = useState<WorkSession[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>("");
  const [newSessionName, setNewSessionName] = useState("");
  const [isCreatingSession, setIsCreatingSession] = useState(false);
  const [sessionToDeleteId, setSessionToDeleteId] = useState<string | null>(null);

  // Sync internal state when deal changes and handle default session seeding
  useEffect(() => {
    if (deal) {
      let currentSessions = deal.sessions || [];
      if (currentSessions.length === 0) {
        // Seed default session with current values or defaults
        const defaultSess: WorkSession = {
          id: `sess-default-${deal.id}`,
          name: "Primary Appraisal Session",
          createdAt: new Date().toISOString(),
          lastUpdated: new Date().toISOString(),
          isActive: true,
          surveyNotes: deal.surveyNotes || {
            structuralRating: deal.yearBuilt < 1965 ? 'poor' : 'good',
            foundationNotes: deal.yearBuilt < 1965 ? 'Localized crawlspace joist sag observed under bathrooms. Recommending structural engineer survey.' : 'Solid crawlspace foundation, minor settling consistent with age.',
            waterDamageFound: deal.yearBuilt < 1965,
            waterDamageNotes: deal.yearBuilt < 1965 ? 'Minor mold/staining in utility room subfloor. Requires subfloor cutout.' : 'No active water leaks detected during walkthrough.',
            roofNotes: 'Architectural shingles appear original, showing granular loss near valleys.',
            electricalNotes: 'Older panels visible, requires 200-Amp service upgrade to comply with modern NC building code.',
            plumbingNotes: 'Mainly copper supply lines, drain lines transition to ABS. Normal condition.',
            generalSurveyNotes: 'Cosmetic bungalow located in established neighborhood. Structurally sound with solid wood frame but needs standard trade updates.',
            surveyDate: new Date().toISOString().split('T')[0],
            surveyedBy: 'John & Business Partner'
          },
          fundingDetails: deal.fundingDetails || {
            hardMoneySource: 'Blue Ridge Private Capital Pool',
            hardMoneyAmount: Math.round(((deal.underwriting.purchasePrice || deal.askingPrice * 0.85) + (deal.underwriting.rehabCost || 85000)) * 0.80),
            interestRate: 11.25,
            points: 1.5,
            partnerEquityAmount: Math.round(((deal.underwriting.purchasePrice || deal.askingPrice * 0.85) + (deal.underwriting.rehabCost || 85000) + 15000) - Math.round(((deal.underwriting.purchasePrice || deal.askingPrice * 0.85) + (deal.underwriting.rehabCost || 85000)) * 0.80)),
            additionalCapitalNeeded: 0,
            ltcRatio: 80,
            ltvRatio: Math.round((Math.round(((deal.underwriting.purchasePrice || deal.askingPrice * 0.85) + (deal.underwriting.rehabCost || 85000)) * 0.80) / deal.underwriting.arv) * 100) || 0,
            debtServiceReserve: 12000,
            bankDrawsSubmitted: [
              {
                id: 'draw-1',
                amount: 25000,
                submittedDate: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString().split('T')[0],
                status: 'approved',
                notes: 'First escrow reimbursement for Phase 1 Demo & Structural Joist reinforcement.'
              }
            ]
          },
          contractorGuidelines: (deal.contractorGuidelines && deal.contractorGuidelines.length > 0) ? deal.contractorGuidelines : [
            {
              id: 'sop-1',
              trade: 'Electrical',
              guidelineText: 'Service upgrade from existing obsolete panel to modern 200-Amp Siemens/Square D panel. Run dedicated 12/2 wiring for kitchen small appliance circuits. Re-wire bathrooms to individual 20-Amp GFCI circuits.',
              qualityCheckSOP: 'Check for proper grounding to water main and auxiliary ground rods. Test all GFCI outlets using mechanical GFCI receptacle tester under load.',
              safetyRequirement: 'All work must comply with NC Residential Code Section E3902. Tag and lock out main feed before panel tear-out.',
              isVerifiedByPartner: true
            },
            {
              id: 'sop-2',
              trade: 'Plumbing',
              guidelineText: 'Replace tub/shower valves with pressure-balancing valves (Delta R10000-UNBX). All toilet water connections must use steel braided lines. Run continuous 1/2in PEX with manifold system.',
              qualityCheckSOP: 'Pressure test lines under 100 PSI hydrostatic pressure for 2 hours. Leak check all Schluter waterproofing pans prior to tile setting.',
              safetyRequirement: 'Use flame guards when sweating copper connections near wood framing. Keep Class A fire extinguisher on site.',
              isVerifiedByPartner: false
            },
            {
              id: 'sop-3',
              trade: 'Finishes & Flooring',
              guidelineText: 'Install 20-mil commercial wear-layer waterproof luxury vinyl plank (LVP). Maintain a consistent 1/4 inch expansion spacing gap around all perimeter walls and door frames.',
              qualityCheckSOP: 'Subfloor must be leveled to within 3/16 inch deviation across a 10-foot radius. Sand down high joints and fill low spots with cementitious self-leveler.',
              safetyRequirement: 'Use organic vapor respirator masks when applying polyurethane adhesives or subfloor primers.',
              isVerifiedByPartner: false
            }
          ],
          completionChecklist: (deal.completionChecklist && deal.completionChecklist.length > 0) ? deal.completionChecklist : [
            { id: 'punch-1', category: 'Interior', taskName: 'Kitchen Calacatta Quartz seamless edge polishing & sink undermount silicone seal', checkedByPartner: true, checkedDate: new Date().toISOString().split('T')[0], verifiedPartnerName: 'John' },
            { id: 'punch-2', category: 'Interior', taskName: 'Install low-profile soft-close cabinet doors and level hardware', checkedByPartner: false },
            { id: 'punch-3', category: 'MEP', taskName: 'HVAC supply registers and air filter grille inspection', checkedByPartner: true, checkedDate: new Date().toISOString().split('T')[0], verifiedPartnerName: 'Business Partner' },
            { id: 'punch-4', category: 'MEP', taskName: 'GFCI circuit interrupter trip validation and outlet plate leveling', checkedByPartner: false },
            { id: 'punch-5', category: 'Exterior', taskName: 'Clean and pitch seamless aluminum gutters, clear downspouts', checkedByPartner: false },
            { id: 'punch-6', category: 'Exterior', taskName: 'Powerwash concrete driveway and scrape/paint soffit boards', checkedByPartner: false },
            { id: 'punch-7', category: 'Code/Inspections', taskName: 'Obtain Charlotte/Mecklenburg County final building certificate of occupancy', checkedByPartner: false },
            { id: 'punch-8', category: 'Marketing', taskName: 'Final interior deep-clean, remove construction dust, and set up staging', checkedByPartner: false }
          ],
          rehabItems: deal.rehabItems || [],
          underwriting: deal.underwriting
        };
        currentSessions = [defaultSess];
        const seededDeal = {
          ...deal,
          sessions: currentSessions,
          surveyNotes: defaultSess.surveyNotes,
          fundingDetails: defaultSess.fundingDetails,
          contractorGuidelines: defaultSess.contractorGuidelines,
          completionChecklist: defaultSess.completionChecklist
        };
        onUpdateDeal(seededDeal);
      }

      setSessions(currentSessions);
      const active = currentSessions.find(s => s.isActive) || currentSessions[0];
      if (active) {
        setSelectedSessionId(active.id);
        setSurvey(active.surveyNotes || {
          structuralRating: 'good',
          foundationNotes: '',
          waterDamageFound: false,
          waterDamageNotes: '',
          roofNotes: '',
          electricalNotes: '',
          plumbingNotes: '',
          generalSurveyNotes: '',
          surveyDate: new Date().toISOString().split('T')[0],
          surveyedBy: 'John & Business Partner'
        });
        setFunding(active.fundingDetails || {
          hardMoneySource: 'First National Hard Money LLC',
          hardMoneyAmount: 0,
          interestRate: 10.5,
          points: 2.0,
          partnerEquityAmount: 0,
          additionalCapitalNeeded: 0,
          ltcRatio: 0,
          ltvRatio: 0,
          debtServiceReserve: 15000,
          bankDrawsSubmitted: []
        });
        setGuidelines(active.contractorGuidelines || []);
        setCompletion(active.completionChecklist || []);
      }
    }
  }, [deal.id]);

  // Session selector handler
  const handleSwitchSession = async (sessionId: string) => {
    const updatedSessions = sessions.map(s => ({
      ...s,
      isActive: s.id === sessionId
    }));
    
    const targetSession = updatedSessions.find(s => s.id === sessionId);
    if (!targetSession) return;

    setSessions(updatedSessions);
    setSelectedSessionId(sessionId);
    setSurvey(targetSession.surveyNotes || {
      structuralRating: 'good',
      foundationNotes: '',
      waterDamageFound: false,
      waterDamageNotes: '',
      roofNotes: '',
      electricalNotes: '',
      plumbingNotes: '',
      generalSurveyNotes: '',
      surveyDate: new Date().toISOString().split('T')[0],
      surveyedBy: 'John & Business Partner'
    });
    setFunding(targetSession.fundingDetails || {
      hardMoneySource: 'First National Hard Money LLC',
      hardMoneyAmount: 0,
      interestRate: 10.5,
      points: 2.0,
      partnerEquityAmount: 0,
      additionalCapitalNeeded: 0,
      ltcRatio: 0,
      ltvRatio: 0,
      debtServiceReserve: 15000,
      bankDrawsSubmitted: []
    });
    setGuidelines(targetSession.contractorGuidelines || []);
    setCompletion(targetSession.completionChecklist || []);

    const updatedDeal: PropertyDeal = {
      ...deal,
      sessions: updatedSessions,
      surveyNotes: targetSession.surveyNotes,
      fundingDetails: targetSession.fundingDetails,
      contractorGuidelines: targetSession.contractorGuidelines,
      completionChecklist: targetSession.completionChecklist,
      rehabItems: targetSession.rehabItems || deal.rehabItems,
      underwriting: targetSession.underwriting || deal.underwriting
    };

    await onUpdateDeal(updatedDeal);
    setSyncMessage(`✓ Switched to workspace session: "${targetSession.name}"`);
    setTimeout(() => setSyncMessage(null), 3000);
  };

  // Create new scenario session
  const handleCreateSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSessionName.trim()) return;

    const newSessionId = `sess-${Date.now()}`;
    const newSession: WorkSession = {
      id: newSessionId,
      name: newSessionName.trim(),
      createdAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      isActive: true,
      surveyNotes: { ...survey },
      fundingDetails: { ...funding },
      contractorGuidelines: [...guidelines],
      completionChecklist: [...completion],
      rehabItems: [...deal.rehabItems],
      underwriting: { ...deal.underwriting }
    };

    const updatedSessions = sessions.map(s => ({ ...s, isActive: false })).concat(newSession);
    setSessions(updatedSessions);
    setSelectedSessionId(newSessionId);
    setNewSessionName("");
    setIsCreatingSession(false);

    const payload: PropertyDeal = {
      ...deal,
      sessions: updatedSessions,
      surveyNotes: newSession.surveyNotes,
      fundingDetails: newSession.fundingDetails,
      contractorGuidelines: newSession.contractorGuidelines,
      completionChecklist: newSession.completionChecklist,
      rehabItems: newSession.rehabItems,
      underwriting: newSession.underwriting
    };

    await onUpdateDeal(payload);
    setSyncMessage(`✓ Created scenario session: "${newSession.name}"`);
    setTimeout(() => setSyncMessage(null), 4000);
  };

  // Delete scenario session
  const handleDeleteSession = async (sessionId: string) => {
    if (sessions.length <= 1) return;
    const updatedSessions = sessions.filter(s => s.id !== sessionId);
    
    let nextSelectedId = selectedSessionId;
    if (selectedSessionId === sessionId) {
      const nextSession = updatedSessions[0];
      nextSession.isActive = true;
      nextSelectedId = nextSession.id;

      setSurvey(nextSession.surveyNotes || survey);
      setFunding(nextSession.fundingDetails || funding);
      setGuidelines(nextSession.contractorGuidelines || guidelines);
      setCompletion(nextSession.completionChecklist || completion);
    }

    setSessions(updatedSessions);
    setSelectedSessionId(nextSelectedId);
    setSessionToDeleteId(null);

    const activeSess = updatedSessions.find(s => s.id === nextSelectedId)!;
    const payload: PropertyDeal = {
      ...deal,
      sessions: updatedSessions,
      surveyNotes: activeSess.surveyNotes,
      fundingDetails: activeSess.fundingDetails,
      contractorGuidelines: activeSess.contractorGuidelines,
      completionChecklist: activeSess.completionChecklist,
      rehabItems: activeSess.rehabItems || deal.rehabItems,
      underwriting: activeSess.underwriting || deal.underwriting
    };

    await onUpdateDeal(payload);
    setSyncMessage("✓ Deleted scenario session workspace.");
    setTimeout(() => setSyncMessage(null), 3000);
  };

  // Recalculate parameters when local state changes
  const purchasePrice = deal?.underwriting?.purchasePrice || deal?.askingPrice * 0.85;
  const rehabCost = deal?.underwriting?.rehabCost || 85000;
  const arv = deal?.underwriting?.arv || 240000;

  // LTV & LTC Live Calculations
  const calculatedLTC = Math.round((funding.hardMoneyAmount / (purchasePrice + rehabCost)) * 100) || 0;
  const calculatedLTV = Math.round((funding.hardMoneyAmount / arv) * 100) || 0;
  const totalInvested = purchasePrice + rehabCost + funding.debtServiceReserve;
  const partnerEquityRequired = Math.max(0, totalInvested - funding.hardMoneyAmount);

  // --- SAVE ACTIONS ---
  const handleSaveHubData = async (updatedSurvey?: SurveyNotes, updatedFunding?: FundingDetails, updatedGuidelines?: ContractorGuideline[], updatedCompletion?: CompletionChecklistItem[]) => {
    setIsSaving(true);
    try {
      const finalSurvey = updatedSurvey || survey;
      const finalFunding = updatedFunding || funding;
      const finalGuidelines = updatedGuidelines || guidelines;
      const finalCompletion = updatedCompletion || completion;

      const updatedSessions = sessions.map(s => {
        if (s.id === selectedSessionId) {
          return {
            ...s,
            lastUpdated: new Date().toISOString(),
            surveyNotes: finalSurvey,
            fundingDetails: finalFunding,
            contractorGuidelines: finalGuidelines,
            completionChecklist: finalCompletion,
            rehabItems: deal.rehabItems,
            underwriting: deal.underwriting
          };
        }
        return s;
      });

      const payload: PropertyDeal = {
        ...deal,
        surveyNotes: finalSurvey,
        fundingDetails: finalFunding,
        contractorGuidelines: finalGuidelines,
        completionChecklist: finalCompletion,
        sessions: updatedSessions
      };
      
      await onUpdateDeal(payload);
      setSessions(updatedSessions);
      setSyncMessage("✓ Session workspace state synchronized to cloud database successfully.");
      setTimeout(() => setSyncMessage(null), 4000);
    } catch (err) {
      console.error("Error saving Partners Operations data:", err);
      setSyncMessage("⚠ Failed to sync operations data. Please try again.");
      setTimeout(() => setSyncMessage(null), 5000);
    } finally {
      setIsSaving(false);
    }
  };

  // --- SURVEY HANDLERS ---
  const handleSurveyChange = (field: keyof SurveyNotes, value: any) => {
    const updated = { ...survey, [field]: value };
    setSurvey(updated);
  };

  const handleSyncSurveyToBudget = () => {
    // Inject calibrated structural items to the rehab line items
    let customItems: RehabLineItem[] = [...deal.rehabItems];
    let logsAppend = [...deal.logs];

    if (survey.structuralRating === 'poor' && !customItems.some(item => item.category === 'Structural' && item.name.includes('Underpinning'))) {
      customItems.push({
        id: `rehab-human-struct-${Date.now()}`,
        category: "Structural",
        name: "Crawlspace Underpinning & Structural Piers (Helical Screw Install)",
        cost: 12500,
        laborCost: 7500,
        materialCost: 5000,
        unit: "lump_sum",
        quantity: 1,
        status: "estimated",
        notes: `Automatically injected based on Partner Physical Survey: ${survey.foundationNotes}`
      });
      logsAppend.push({
        id: `log-human-${Date.now()}`,
        timestamp: new Date().toISOString(),
        agentName: "Supervisor",
        message: "Human Survey Override: Added $12,500 Crawlspace Underpinning to rehab scope due to structural settling observations.",
        status: "warning"
      });
    }

    if (survey.waterDamageFound && !customItems.some(item => item.category === 'Structural' && item.name.includes('Mold Remediation'))) {
      customItems.push({
        id: `rehab-human-mold-${Date.now()}`,
        category: "Structural",
        name: "Professional Mold Remediation & Subfloor Dehumidification Dryout",
        cost: 4800,
        laborCost: 2800,
        materialCost: 2000,
        unit: "lump_sum",
        quantity: 1,
        status: "estimated",
        notes: `Automatically injected based on Partner Physical Survey: ${survey.waterDamageNotes}`
      });
      logsAppend.push({
        id: `log-human-${Date.now()}`,
        timestamp: new Date().toISOString(),
        agentName: "Rehab",
        message: "Human Survey Override: Added $4,800 Mold Remediation to rehab scope due to water damage findings.",
        status: "warning"
      });
    }

    // Recalculate underwriting
    const baseRehabTotal = customItems.reduce((acc, item) => acc + item.cost, 0);
    const updatedRehabCost = Math.round(baseRehabTotal * 1.15); // contingency
    const updatedPurchasePrice = Math.min(deal.askingPrice, Math.round((arv * 0.70) - updatedRehabCost));
    const projectedProfit = arv - updatedPurchasePrice - updatedRehabCost - 15000; // rough math
    const roi = Math.round((projectedProfit / (updatedPurchasePrice + updatedRehabCost + 15000)) * 100);

    const updatedDeal: PropertyDeal = {
      ...deal,
      rehabItems: customItems,
      logs: logsAppend,
      underwriting: {
        ...deal.underwriting,
        rehabCost: updatedRehabCost,
        purchasePrice: updatedPurchasePrice,
        projectedProfit: projectedProfit,
        roi: roi
      }
    };

    onUpdateDeal(updatedDeal);
    setSyncMessage("✓ Survey hazards translated! Added specific structural repair scope & adjusted calculations.");
    setTimeout(() => setSyncMessage(null), 5000);
  };

  // --- FUNDING HANDLERS ---
  const handleFundingChange = (field: keyof FundingDetails, value: any) => {
    const updated = { ...funding, [field]: value };
    // Live recalculations for LTC / LTV
    updated.ltcRatio = Math.round((updated.hardMoneyAmount / (purchasePrice + rehabCost)) * 100) || 0;
    updated.ltvRatio = Math.round((updated.hardMoneyAmount / arv) * 100) || 0;
    setFunding(updated);
  };

  const handleAddDrawRequest = () => {
    if (newDrawAmount <= 0) return;
    const newDraw: BankDraw = {
      id: `draw-${Date.now()}`,
      amount: newDrawAmount,
      submittedDate: new Date().toISOString().split('T')[0],
      status: 'pending',
      notes: newDrawNotes || `Draw request for completed Milestone: ${selectedMilestoneForDraw || 'General Renovation Reimbursement'}`
    };

    const updatedFunding = {
      ...funding,
      bankDrawsSubmitted: [newDraw, ...funding.bankDrawsSubmitted]
    };
    setFunding(updatedFunding);
    setNewDrawAmount(0);
    setNewDrawNotes("");
    setSelectedMilestoneForDraw("");

    handleSaveHubData(survey, updatedFunding, guidelines, completion);
  };

  const handleToggleDrawStatus = (drawId: string) => {
    const updatedDraws = funding.bankDrawsSubmitted.map(draw => {
      if (draw.id === drawId) {
        const nextStatus = draw.status === 'pending' ? 'approved' : draw.status === 'approved' ? 'rejected' : 'pending';
        return { ...draw, status: nextStatus };
      }
      return draw;
    });

    const updatedFunding = {
      ...funding,
      bankDrawsSubmitted: updatedDraws
    };
    setFunding(updatedFunding);
    handleSaveHubData(survey, updatedFunding, guidelines, completion);
  };

  // --- GUIDELINE HANDLERS ---
  const handleAddGuideline = () => {
    if (!newGuideline.guidelineText.trim()) return;
    const item: ContractorGuideline = {
      id: `sop-${Date.now()}`,
      trade: newGuideline.trade,
      guidelineText: newGuideline.guidelineText,
      qualityCheckSOP: newGuideline.qualityCheckSOP || 'Standard code compliance check.',
      safetyRequirement: newGuideline.safetyRequirement || 'Wear standard personal protective equipment (PPE).',
      isVerifiedByPartner: true
    };

    const updated = [...guidelines, item];
    setGuidelines(updated);
    setNewGuideline({
      trade: "Electrical",
      guidelineText: "",
      qualityCheckSOP: "",
      safetyRequirement: ""
    });

    handleSaveHubData(survey, funding, updated, completion);
  };

  const handleDeleteGuideline = (id: string) => {
    const updated = guidelines.filter(g => g.id !== id);
    setGuidelines(updated);
    handleSaveHubData(survey, funding, updated, completion);
  };

  const handleToggleGuidelineVerify = (id: string) => {
    const updated = guidelines.map(g => g.id === id ? { ...g, isVerifiedByPartner: !g.isVerifiedByPartner } : g);
    setGuidelines(updated);
    handleSaveHubData(survey, funding, updated, completion);
  };

  // --- COMPLETION HANDLERS ---
  const handleAddPunchTask = () => {
    if (!newPunchTask.taskName.trim()) return;
    const item: CompletionChecklistItem = {
      id: `punch-${Date.now()}`,
      category: newPunchTask.category,
      taskName: newPunchTask.taskName,
      checkedByPartner: false
    };

    const updated = [...completion, item];
    setCompletion(updated);
    setNewPunchTask({
      category: "Interior",
      taskName: ""
    });

    handleSaveHubData(survey, funding, guidelines, updated);
  };

  const handleTogglePunchTask = (id: string) => {
    const updated = completion.map(item => {
      if (item.id === id) {
        const isChecked = !item.checkedByPartner;
        return {
          ...item,
          checkedByPartner: isChecked,
          checkedDate: isChecked ? new Date().toISOString().split('T')[0] : undefined,
          verifiedPartnerName: isChecked ? 'John' : undefined
        };
      }
      return item;
    });

    setCompletion(updated);
    handleSaveHubData(survey, funding, guidelines, updated);
  };

  const handleDeletePunchTask = (id: string) => {
    const updated = completion.filter(item => item.id !== id);
    setCompletion(updated);
    handleSaveHubData(survey, funding, guidelines, updated);
  };

  // Quick stats
  const completedPunchCount = completion.filter(item => item.checkedByPartner).length;
  const progressPercent = Math.round((completedPunchCount / completion.length) * 100) || 0;

  return (
    <div className="bg-zinc-900/35 border border-zinc-800/80 rounded-3xl p-6 shadow-xl backdrop-blur-md space-y-6">
      
      {/* Ops Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <UserCheck className="h-5 w-5 text-emerald-400" />
            <h2 className="text-sm font-extrabold text-zinc-400 uppercase tracking-wider">Walkthrough & Checklist</h2>
          </div>
          <h1 className="text-xl font-extrabold text-zinc-100 mt-1">House Walkthrough & Checklist Hub</h1>
          <p className="text-xs text-zinc-400 mt-1 max-w-2xl leading-relaxed">
            Our AI helpers handle the hard computer work in the other tab. Use this hub to inspect the property, track loan money, write rules for your builders, and check off final tasks to complete your flip!
          </p>
        </div>

        {/* Sync Controls */}
        <div className="flex flex-col items-end space-y-2">
          <div className="flex items-center space-x-2">
            {syncMessage && (
              <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                {syncMessage}
              </span>
            )}
            <button
              onClick={() => handleSaveHubData()}
              disabled={isSaving}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-zinc-100 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer shadow"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isSaving ? "animate-spin" : ""}`} />
              <span>{isSaving ? "Syncing..." : "Sync Operations State"}</span>
            </button>
          </div>
          <span className="text-[10px] text-zinc-500">
            Active Property: <strong className="text-zinc-300">{deal.address}, {deal.city}</strong>
          </span>
        </div>
      </div>

      {/* Workspace Scenario Sessions Control Panel */}
      <div className="bg-zinc-950/60 border border-zinc-850 rounded-2xl p-4 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-850/60">
          <div className="flex items-center space-x-2">
            <Layers className="h-4.5 w-4.5 text-emerald-400" />
            <div>
              <h3 className="text-xs font-extrabold text-zinc-200 uppercase tracking-wider">Multi-Scenario Sessions</h3>
              <p className="text-[10px] text-zinc-400">Save, compare, and switch between multiple scoping walkthroughs, budgets, and loan structures.</p>
            </div>
          </div>
          
          {!isCreatingSession ? (
            <button
              onClick={() => setIsCreatingSession(true)}
              className="px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-zinc-300 rounded-xl text-[11px] font-bold transition flex items-center space-x-1 cursor-pointer self-start"
            >
              <Plus className="h-3 w-3" />
              <span>New Workspace Session</span>
            </button>
          ) : (
            <form onSubmit={handleCreateSession} className="flex items-center space-x-2 w-full sm:w-auto">
              <input
                type="text"
                value={newSessionName}
                onChange={(e) => setNewSessionName(e.target.value)}
                placeholder="Session name (e.g. FHA Budget, Premium Walkthrough)"
                maxLength={45}
                className="bg-zinc-950 border border-zinc-800 text-zinc-200 text-xs px-2.5 py-1.5 rounded-xl placeholder-zinc-500 focus:outline-none focus:border-emerald-500 w-full sm:w-64"
                required
              />
              <button
                type="submit"
                className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-zinc-100 rounded-xl text-[11px] font-bold transition whitespace-nowrap cursor-pointer"
              >
                Create
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsCreatingSession(false);
                  setNewSessionName("");
                }}
                className="px-2.5 py-1.5 bg-zinc-900 text-zinc-400 hover:text-zinc-300 rounded-xl text-[11px] font-bold transition cursor-pointer"
              >
                Cancel
              </button>
            </form>
          )}
        </div>

        {/* Inline Delete Confirmation Alert */}
        <AnimatePresence>
          {sessionToDeleteId && (
            <motion.div
              initial={{ opacity: 0, height: 0, scale: 0.95 }}
              animate={{ opacity: 1, height: "auto", scale: 1 }}
              exit={{ opacity: 0, height: 0, scale: 0.95 }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              className="bg-red-500/10 border border-red-500/20 p-3.5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 overflow-hidden"
            >
              <div className="flex items-start space-x-2">
                <AlertTriangle className="h-4 w-4 text-red-400 mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-red-300">Permanently delete this session workspace?</p>
                  <p className="text-[10px] text-zinc-400">
                    Are you sure you want to delete <strong className="text-zinc-300">"{sessions.find(s => s.id === sessionToDeleteId)?.name}"</strong>? All of its custom inspections, contractor rules, checklist answers, and local parameters will be lost.
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2 self-end sm:self-center">
                <button
                  onClick={() => handleDeleteSession(sessionToDeleteId)}
                  className="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-zinc-100 rounded-lg text-[10px] font-bold transition cursor-pointer"
                >
                  Yes, Delete Session
                </button>
                <button
                  onClick={() => setSessionToDeleteId(null)}
                  className="px-2.5 py-1 bg-zinc-900 text-zinc-400 hover:text-zinc-300 rounded-lg text-[10px] font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sessions Carousel List */}
        <div className="flex flex-wrap gap-2">
          <AnimatePresence initial={false}>
            {sessions.map((s) => {
              const isSelected = s.id === selectedSessionId;
              return (
                <motion.div
                  key={s.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: "spring", stiffness: 400, damping: 28 }}
                  className={`flex items-center space-x-2 pl-3 pr-2.5 py-1.5 rounded-xl border text-xs font-bold transition relative ${
                    isSelected
                      ? "bg-zinc-900 border-emerald-500/50 text-emerald-400 shadow-md shadow-emerald-500/10"
                      : "bg-zinc-950/40 border-zinc-850 text-zinc-400 hover:text-zinc-300 hover:bg-zinc-900/40 cursor-pointer"
                  }`}
                  onClick={() => !isSelected && handleSwitchSession(s.id)}
                >
                  <div className="flex items-center space-x-1.5">
                    <span className="relative flex h-2 w-2">
                      {isSelected && (
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      )}
                      <span className={`relative inline-flex rounded-full h-2 w-2 ${isSelected ? "bg-emerald-400" : "bg-zinc-600"}`}></span>
                    </span>
                    <span className="truncate max-w-[160px]">{s.name}</span>
                  </div>

                  <div className="flex items-center space-x-1 pl-1">
                    {/* Metadata display */}
                    <span className="text-[9px] font-medium text-zinc-500">
                      {new Date(s.lastUpdated).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </span>
                    
                    {/* Delete button (only show if there are more than 1 sessions) */}
                    {sessions.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSessionToDeleteId(s.id);
                        }}
                        className="p-1 hover:text-red-400 text-zinc-500 hover:bg-zinc-800 rounded-lg transition"
                        title="Delete Scenario Session Workspace"
                      >
                        <Trash className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>

      {/* Hub Tab Switcher */}
      <div className="flex flex-wrap items-center gap-1.5 bg-zinc-950 p-1 rounded-2xl border border-zinc-850 max-w-max">
        <button
          onClick={() => setActiveTab("survey")}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
            activeTab === "survey"
              ? "bg-zinc-900 text-emerald-400 border border-zinc-800 shadow"
              : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          🔍 Inspect the House
        </button>
        <button
          onClick={() => setActiveTab("funding")}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
            activeTab === "funding"
              ? "bg-zinc-900 text-emerald-400 border border-zinc-800 shadow"
              : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          💰 Money & Loans
        </button>
        <button
          onClick={() => setActiveTab("guidelines")}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
            activeTab === "guidelines"
              ? "bg-zinc-900 text-emerald-400 border border-zinc-800 shadow"
              : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          📋 Builder Rules
        </button>
        <button
          onClick={() => setActiveTab("completion")}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
            activeTab === "completion"
              ? "bg-zinc-900 text-emerald-400 border border-zinc-800 shadow"
              : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          ✓ Final Checklist
        </button>
      </div>

      <div className="relative mt-2">
        <AnimatePresence mode="wait">
          {/* --- TAB 1: SURVEYING (Boots-on-the-Ground) --- */}
          {activeTab === "survey" && (
            <motion.div
              key="survey"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-6"
            >
          {/* Context Banner */}
          <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-4 flex items-start space-x-3">
            <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-xs font-extrabold text-amber-300 uppercase tracking-wider">Walking Through the House</h4>
              <p className="text-[11px] text-zinc-400 leading-normal">
                Even though computers find home records, you have to look for real-life problems like mold, leaks, or roof damage! Use this panel to check off any issues you find. If you find heavy damage, our AI helper will automatically recalculate the repair budget for you.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Input Form Column */}
            <div className="lg:col-span-7 bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl space-y-4.5">
              <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">House Condition Checklist</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">Overall House Strength</label>
                  <div className="grid grid-cols-3 gap-1.5 bg-zinc-950 p-1 rounded-xl border border-zinc-850">
                    {(['good', 'fair', 'poor'] as const).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => handleSurveyChange('structuralRating', r)}
                        className={`py-1 rounded-lg text-[10px] font-bold capitalize transition ${
                          survey.structuralRating === r
                            ? r === 'good' ? 'bg-emerald-600 text-white' : r === 'fair' ? 'bg-amber-600 text-white' : 'bg-rose-600 text-white'
                            : 'text-zinc-500 hover:text-zinc-350'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">Active Water Damage & Mold</label>
                  <label className="flex items-center space-x-2 p-1.5 px-3 bg-zinc-950 rounded-xl border border-zinc-850 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={survey.waterDamageFound}
                      onChange={(e) => handleSurveyChange('waterDamageFound', e.target.checked)}
                      className="rounded border-zinc-800 text-emerald-600 focus:ring-emerald-600/30 h-4 w-4 bg-zinc-900"
                    />
                    <span className="text-[11px] font-bold text-zinc-300">Hazard Detected</span>
                  </label>
                </div>
              </div>

              <div className="space-y-3.5 pt-2">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Floor & Foundation Notes</label>
                  <textarea
                    rows={2}
                    value={survey.foundationNotes}
                    onChange={(e) => handleSurveyChange('foundationNotes', e.target.value)}
                    placeholder="Describe any issues with the crawlspace, cracking, or saggy floors..."
                    className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600/25"
                  />
                </div>

                {survey.waterDamageFound && (
                  <div>
                    <label className="block text-[10px] font-bold text-rose-400 uppercase tracking-wider mb-1">Water Damage & Mold Details</label>
                    <textarea
                      rows={2}
                      value={survey.waterDamageNotes}
                      onChange={(e) => handleSurveyChange('waterDamageNotes', e.target.value)}
                      placeholder="Where is the water leak or mold located, and how bad is it?..."
                      className="w-full text-xs bg-zinc-950 border border-rose-500/30 rounded-xl p-2.5 text-zinc-100 focus:border-rose-500 focus:ring-1 focus:ring-rose-500/25"
                    />
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Roofing Condition Notes</label>
                    <input
                      type="text"
                      value={survey.roofNotes}
                      onChange={(e) => handleSurveyChange('roofNotes', e.target.value)}
                      className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Electrical Panel Notes</label>
                    <input
                      type="text"
                      value={survey.electricalNotes}
                      onChange={(e) => handleSurveyChange('electricalNotes', e.target.value)}
                      className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">General Walkthrough Remarks</label>
                  <textarea
                    rows={2}
                    value={survey.generalSurveyNotes}
                    onChange={(e) => handleSurveyChange('generalSurveyNotes', e.target.value)}
                    className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Survey Date</label>
                    <input
                      type="date"
                      value={survey.surveyDate}
                      onChange={(e) => handleSurveyChange('surveyDate', e.target.value)}
                      className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Assigned Surveyor</label>
                    <input
                      type="text"
                      value={survey.surveyedBy}
                      onChange={(e) => handleSurveyChange('surveyedBy', e.target.value)}
                      className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Calculations Bridge Column */}
            <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
              <div className="bg-zinc-950/60 border border-zinc-850 p-5 rounded-2xl space-y-4">
                <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">AI Repair Cost Updates</h3>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Your walkthrough notes can instantly change your budget. Click the button below to automatically add special repair costs (like mold treatment or crawlspace repairs) into your total house budget.
                </p>

                <div className="space-y-2.5">
                  <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-900 flex justify-between items-center text-xs">
                    <span className="text-zinc-400">Foundation Rating:</span>
                    <span className={`font-bold px-2 py-0.5 rounded uppercase text-[10px] ${
                      survey.structuralRating === 'good' ? 'bg-emerald-500/10 text-emerald-400' :
                      survey.structuralRating === 'fair' ? 'bg-amber-500/10 text-amber-400' : 'bg-rose-500/10 text-rose-400 animate-pulse'
                    }`}>
                      {survey.structuralRating}
                    </span>
                  </div>

                  <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-900 flex justify-between items-center text-xs">
                    <span className="text-zinc-400">Active Water Leak:</span>
                    <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${
                      survey.waterDamageFound ? 'bg-rose-500/10 text-rose-400' : 'bg-zinc-900 text-zinc-500'
                    }`}>
                      {survey.waterDamageFound ? 'YES - ACTION NEEDED' : 'NONE DETECTED'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleSyncSurveyToBudget}
                  className="w-full py-3 bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center space-x-1.5"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>Update My House Budget & Value</span>
                </button>
              </div>

              {/* General Property Summary Box */}
              <div className="bg-zinc-950/20 border border-zinc-850 p-5 rounded-2xl space-y-2">
                <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider">Walkthrough Summary Record</span>
                <p className="text-xs text-zinc-300 italic font-medium">
                  "{survey.generalSurveyNotes || 'No custom remarks recorded yet.'}"
                </p>
                <div className="pt-2 text-[10px] text-zinc-500 flex justify-between">
                  <span>Logged: {survey.surveyDate}</span>
                  <span>Inspector: {survey.surveyedBy}</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

          {/* --- TAB 2: GETTING FUNDS (Capital & Draw Management) --- */}
          {activeTab === "funding" && (
            <motion.div
              key="funding"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-6"
            >
          {/* Quick Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-2xl">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Hard Money Loan</span>
              <span className="text-lg font-extrabold text-zinc-100 block mt-1">${funding.hardMoneyAmount.toLocaleString()}</span>
              <span className="text-[9px] text-zinc-500 mt-1 block">Lender: {funding.hardMoneySource}</span>
            </div>

            <div className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-2xl">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Partner Cash Equity</span>
              <span className="text-lg font-extrabold text-zinc-100 block mt-1">${partnerEquityRequired.toLocaleString()}</span>
              <span className="text-[9px] text-emerald-400 mt-1 block">✓ Fully Funded</span>
            </div>

            <div className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-2xl">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Loan-To-Cost Ratio</span>
              <span className="text-lg font-extrabold text-emerald-400 block mt-1">{calculatedLTC}%</span>
              <div className="w-full bg-zinc-900 h-1.5 rounded-full mt-1.5 overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${Math.min(100, calculatedLTC)}%` }}></div>
              </div>
            </div>

            <div className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-2xl">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Loan-To-Value Ratio</span>
              <span className="text-lg font-extrabold text-sky-400 block mt-1">{calculatedLTV}%</span>
              <div className="w-full bg-zinc-900 h-1.5 rounded-full mt-1.5 overflow-hidden">
                <div className="bg-sky-500 h-full rounded-full" style={{ width: `${Math.min(100, calculatedLTV)}%` }}></div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Funding Allocation Form */}
            <div className="lg:col-span-5 bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl space-y-4">
              <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">Where the Money Comes From</h3>
              
              <div className="space-y-3.5">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Hard Money Lender Name</label>
                  <input
                    type="text"
                    value={funding.hardMoneySource}
                    onChange={(e) => handleFundingChange('hardMoneySource', e.target.value)}
                    className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100 font-semibold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Loan Amount ($)</label>
                    <input
                      type="number"
                      value={funding.hardMoneyAmount}
                      onChange={(e) => handleFundingChange('hardMoneyAmount', Number(e.target.value))}
                      className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Interest Rate (%)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={funding.interestRate}
                      onChange={(e) => handleFundingChange('interestRate', Number(e.target.value))}
                      className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Points Paid at Close</label>
                    <input
                      type="number"
                      step="0.1"
                      value={funding.points}
                      onChange={(e) => handleFundingChange('points', Number(e.target.value))}
                      className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">Debt Service Reserve ($)</label>
                    <input
                      type="number"
                      value={funding.debtServiceReserve}
                      onChange={(e) => handleFundingChange('debtServiceReserve', Number(e.target.value))}
                      className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                    />
                  </div>
                </div>

                <div className="p-3 bg-zinc-950 border border-zinc-900 rounded-xl text-xs space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Estimated Purchase Price:</span>
                    <span className="font-semibold text-zinc-300">${purchasePrice.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Estimated Repair Cost:</span>
                    <span className="font-semibold text-zinc-300">${rehabCost.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between border-t border-zinc-900 pt-1.5">
                    <span className="text-zinc-400 font-bold">Total Capital Needed:</span>
                    <span className="font-bold text-zinc-200">${totalInvested.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Escrow Draw Management */}
            <div className="lg:col-span-7 bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">Reimbursement & Escrow Draws</h3>
                <span className="text-[10px] font-extrabold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">Get Money Back</span>
              </div>

              {/* Submit new draw request */}
              <div className="p-3.5 bg-zinc-950 rounded-xl border border-zinc-900 space-y-3">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Ask the Bank to Release Repair Funds</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[9px] text-zinc-500 uppercase mb-1">Target Milestone</label>
                    <select
                      value={selectedMilestoneForDraw}
                      onChange={(e) => setSelectedMilestoneForDraw(e.target.value)}
                      className="w-full text-xs bg-zinc-900 border border-zinc-850 rounded-lg p-2 text-zinc-200"
                    >
                      <option value="">-- Choose Completed Phase --</option>
                      {deal.milestones?.map((mil) => (
                        <option key={mil.id} value={mil.title}>{mil.title} (${mil.cost.toLocaleString()})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[9px] text-zinc-500 uppercase mb-1">Draw Amount ($)</label>
                    <input
                      type="number"
                      value={newDrawAmount}
                      onChange={(e) => setNewDrawAmount(Number(e.target.value))}
                      placeholder="e.g. 15000"
                      className="w-full text-xs bg-zinc-900 border border-zinc-850 rounded-lg p-2 text-zinc-200 font-bold"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[9px] text-zinc-500 uppercase mb-1">Description / Proof Documents Notes</label>
                  <input
                    type="text"
                    value={newDrawNotes}
                    onChange={(e) => setNewDrawNotes(e.target.value)}
                    placeholder="W-9 attached, lien waiver signed, electrical rough-in complete..."
                    className="w-full text-xs bg-zinc-900 border border-zinc-850 rounded-lg p-2 text-zinc-200"
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    onClick={handleAddDrawRequest}
                    className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-zinc-100 rounded-lg text-[10px] font-bold uppercase tracking-wider transition flex items-center space-x-1 cursor-pointer"
                  >
                    <Plus className="h-3 w-3" />
                    <span>Generate Draw Package</span>
                  </button>
                </div>
              </div>

              {/* Draw requests ledger */}
              <div className="space-y-2 max-h-[190px] overflow-y-auto pr-1">
                {funding.bankDrawsSubmitted.length === 0 ? (
                  <div className="text-center py-6 text-zinc-500 text-[11px] border border-dashed border-zinc-900 rounded-xl">
                    No draws submitted yet. Submit completed phases for bank reimbursement.
                  </div>
                ) : (
                  funding.bankDrawsSubmitted.map((draw) => (
                    <div key={draw.id} className="p-3 bg-zinc-950 border border-zinc-900 rounded-xl flex items-center justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-bold text-zinc-200">${draw.amount.toLocaleString()}</span>
                          <span className="text-[9px] text-zinc-500">Submitted: {draw.submittedDate}</span>
                        </div>
                        <p className="text-[10px] text-zinc-400 leading-normal">{draw.notes}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleToggleDrawStatus(draw.id)}
                          className={`px-2 py-1 rounded text-[9px] font-extrabold uppercase tracking-wide transition cursor-pointer ${
                            draw.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                            draw.status === 'rejected' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                            'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}
                        >
                          {draw.status}
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </motion.div>
      )}

          {/* --- TAB 3: CONTRACTOR GUIDELINES & WORK ORDERS --- */}
          {activeTab === "guidelines" && (
            <motion.div
              key="guidelines"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-6"
            >
          <div className="bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl">
            <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider mb-4">Write Guidelines and Rules for Your Builders</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">Target Trade</label>
                <select
                  value={newGuideline.trade}
                  onChange={(e) => setNewGuideline({ ...newGuideline, trade: e.target.value })}
                  className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-200"
                >
                  <option value="Electrical">Electrical</option>
                  <option value="Plumbing">Plumbing</option>
                  <option value="HVAC">HVAC</option>
                  <option value="Finishes & Flooring">Finishes & Flooring</option>
                  <option value="Structural & Framing">Structural & Framing</option>
                  <option value="Exterior & Landscaping">Exterior & Landscaping</option>
                </select>
              </div>

              <div className="md:col-span-3">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">Instructions for the Work</label>
                <input
                  type="text"
                  value={newGuideline.guidelineText}
                  onChange={(e) => setNewGuideline({ ...newGuideline, guidelineText: e.target.value })}
                  placeholder="e.g. All kitchen branch circuits must use dedicated 20A wiring. Install Siemens panel with AFCI breakers..."
                  className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100 font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">How We Check the Quality</label>
                <input
                  type="text"
                  value={newGuideline.qualityCheckSOP}
                  onChange={(e) => setNewGuideline({ ...newGuideline, qualityCheckSOP: e.target.value })}
                  placeholder="e.g. Test all plug outlets. Check if the water lines are solid..."
                  className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase mb-1">Safety & State Building Code Rules</label>
                <input
                  type="text"
                  value={newGuideline.safetyRequirement}
                  onChange={(e) => setNewGuideline({ ...newGuideline, safetyRequirement: e.target.value })}
                  placeholder="e.g. Turn off main power before starting. Follow NC residential builder codes..."
                  className="w-full text-xs bg-zinc-950 border border-zinc-850 rounded-xl p-2.5 text-zinc-100"
                />
              </div>
            </div>

            <div className="flex justify-end mt-4">
              <button
                onClick={handleAddGuideline}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-zinc-100 rounded-xl text-xs font-bold uppercase tracking-wider transition flex items-center space-x-1.5 cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                <span>Save Guideline Template</span>
              </button>
            </div>
          </div>

          {/* Guidelines Cards List */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {guidelines.map((sop) => (
              <div key={sop.id} className="bg-zinc-950/70 border border-zinc-850 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between">
                <div className="p-4 border-b border-zinc-900 bg-zinc-950/40 flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <FileText className="h-4 w-4 text-emerald-400" />
                    <span className="text-[10px] font-extrabold uppercase tracking-wider bg-zinc-900 border border-zinc-800 text-zinc-300 px-2.5 py-0.5 rounded-lg">
                      {sop.trade}
                    </span>
                  </div>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => handleToggleGuidelineVerify(sop.id)}
                      className={`p-1.5 rounded transition ${
                        sop.isVerifiedByPartner ? "text-emerald-400 bg-emerald-500/10" : "text-zinc-500 hover:text-zinc-300"
                      }`}
                      title={sop.isVerifiedByPartner ? "Verified Directive" : "Mark as Verified"}
                    >
                      <CheckCircle2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteGuideline(sop.id)}
                      className="p-1.5 text-zinc-600 hover:text-rose-400 transition"
                    >
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <div className="p-4 space-y-3.5 flex-1">
                  <div>
                    <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider block mb-1">Instructions & Work Specs</span>
                    <p className="text-[11px] text-zinc-300 leading-relaxed font-medium">{sop.guidelineText}</p>
                  </div>

                  <div className="p-2.5 bg-zinc-950 border border-zinc-900 rounded-xl space-y-1">
                    <span className="text-[8px] font-extrabold text-emerald-400 uppercase tracking-wider block">Quality Check Rules</span>
                    <p className="text-[10px] text-zinc-400 leading-normal">{sop.qualityCheckSOP}</p>
                  </div>

                  <div className="p-2.5 bg-zinc-950 border border-zinc-900 rounded-xl space-y-1">
                    <span className="text-[8px] font-extrabold text-amber-400 uppercase tracking-wider block">Safety & Building Codes</span>
                    <p className="text-[10px] text-zinc-400 leading-normal">{sop.safetyRequirement}</p>
                  </div>
                </div>

                <div className="p-3 bg-zinc-950/80 border-t border-zinc-900 flex justify-between items-center text-[9px] text-zinc-500">
                  <span className="flex items-center space-x-1">
                    <ShieldCheck className="h-3 w-3 text-emerald-400" />
                    <span>Verified: {sop.isVerifiedByPartner ? "YES" : "PENDING"}</span>
                  </span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`TRADE DIRECTIVE: ${sop.trade}\nGuidelines: ${sop.guidelineText}\nQuality SOP: ${sop.qualityCheckSOP}\nSafety: ${sop.safetyRequirement}`);
                      alert("Contractor scope clipboard copied! Ready to paste into SMS or contract agreements.");
                    }}
                    className="text-zinc-400 hover:text-zinc-200 flex items-center space-x-1 font-semibold transition"
                  >
                    <Clipboard className="h-3 w-3" />
                    <span>Copy SOP</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

          {/* --- TAB 4: COMPLETION CHECKLISTS & SIGN-OFFS --- */}
          {activeTab === "completion" && (
            <motion.div
              key="completion"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-6"
            >
          {/* Completion Meter Dashboard */}
          <div className="bg-zinc-950/60 border border-zinc-850 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-1">
              <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">Final Tasks Progress</h3>
              <p className="text-[11px] text-zinc-400">
                Check off every item once repairs are done! This ensures the house is perfectly clean and safe before we put it on the market.
              </p>
            </div>

            <div className="flex items-center space-x-4 shrink-0">
              <div className="text-right">
                <span className="text-xl font-black text-emerald-400">{progressPercent}%</span>
                <span className="text-[10px] text-zinc-500 block mt-0.5">{completedPunchCount} of {completion.length} Verified</span>
              </div>
              <div className="w-32 bg-zinc-900 h-3.5 rounded-full overflow-hidden border border-zinc-800">
                <div className="bg-emerald-500 h-full transition-all duration-500" style={{ width: `${progressPercent}%` }}></div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Checklists Ledger */}
            <div className="lg:col-span-8 space-y-4">
              <div className="bg-zinc-950/40 border border-zinc-850 rounded-2xl p-4 space-y-3.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">active punch items</h3>
                  
                  {/* Quick Add punch item */}
                  <div className="flex items-center space-x-2">
                    <select
                      value={newPunchTask.category}
                      onChange={(e) => setNewPunchTask({ ...newPunchTask, category: e.target.value as any })}
                      className="text-[10px] bg-zinc-950 border border-zinc-800 p-1.5 rounded-lg text-zinc-300"
                    >
                      <option value="Interior">Interior</option>
                      <option value="Exterior">Exterior</option>
                      <option value="MEP">MEP</option>
                      <option value="Code/Inspections">Code/Inspections</option>
                      <option value="Marketing">Marketing</option>
                    </select>
                    <input
                      type="text"
                      value={newPunchTask.taskName}
                      onChange={(e) => setNewPunchTask({ ...newPunchTask, taskName: e.target.value })}
                      placeholder="Add custom punch task..."
                      className="text-[10px] bg-zinc-950 border border-zinc-800 p-1.5 rounded-lg text-zinc-200 placeholder-zinc-600 focus:outline-hidden"
                    />
                    <button
                      onClick={handleAddPunchTask}
                      className="p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <AnimatePresence initial={false}>
                    {completion.map((item) => (
                      <motion.div
                        key={item.id}
                        layout
                        initial={{ opacity: 0, y: 10, height: 0 }}
                        animate={{ opacity: 1, y: 0, height: "auto" }}
                        exit={{ opacity: 0, y: -10, height: 0 }}
                        transition={{ type: "spring", stiffness: 450, damping: 30 }}
                        className="py-3 flex items-center justify-between gap-4 border-b border-zinc-900/60 last:border-b-0 overflow-hidden"
                      >
                        <div className="flex items-start space-x-3">
                          <button
                            onClick={() => handleTogglePunchTask(item.id)}
                            className={`mt-0.5 p-1 rounded-lg border transition cursor-pointer ${
                              item.checkedByPartner
                                ? "bg-emerald-500/10 border-emerald-500 text-emerald-400"
                                : "border-zinc-800 hover:border-zinc-600 text-transparent"
                            }`}
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                          <div className="space-y-1">
                            <p className={`text-xs font-medium transition-all duration-300 ${item.checkedByPartner ? "text-zinc-500 line-through italic" : "text-zinc-200"}`}>
                              {item.taskName}
                            </p>
                            <div className="flex items-center space-x-2">
                              <span className="text-[8px] font-extrabold uppercase bg-zinc-950 border border-zinc-850 px-1.5 py-0.5 rounded text-zinc-400">
                                {item.category}
                              </span>
                              {item.checkedByPartner && (
                                <motion.span
                                  initial={{ opacity: 0, x: -5 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  className="text-[9px] text-emerald-450 font-bold"
                                >
                                  Verified by {item.verifiedPartnerName} on {item.checkedDate}
                                </motion.span>
                              )}
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => handleDeletePunchTask(item.id)}
                          className="text-zinc-700 hover:text-rose-400 p-1.5 transition"
                        >
                          <Trash className="h-4 w-4" />
                        </button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            </div>

            {/* Final Project Sign-off Gating */}
            <div className="lg:col-span-4 bg-zinc-950/60 border border-zinc-850 p-5 rounded-2xl flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center space-x-1.5 text-emerald-400">
                  <ShieldCheck className="h-4 w-4" />
                  <span className="text-xs font-bold uppercase tracking-wider">Final Approval</span>
                </div>
                <h4 className="text-md font-extrabold text-zinc-200">Complete the Flip & Close Loan</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Confirming all repair tasks are done shows the bank that the house is 100% finished. This lets you get your final cash payout and prepares the house for sale!
                </p>

                <div className="p-3.5 bg-zinc-950 border border-zinc-900 rounded-xl space-y-2">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500">Contractor Retainage Held:</span>
                    <span className="font-semibold text-zinc-300">$8,500</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500">CO Inspections Passed:</span>
                    <span className="text-emerald-400 font-bold">YES</span>
                  </div>
                  <div className="flex justify-between text-[11px] border-t border-zinc-900 pt-2">
                    <span className="text-zinc-400">Partner Release Authorized:</span>
                    <span className="text-zinc-200 font-bold">Authorized</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                disabled={progressPercent < 100}
                onClick={async () => {
                  const payload: PropertyDeal = {
                    ...deal,
                    status: 'Completed'
                  };
                  await onUpdateDeal(payload);
                  setSyncMessage("✓ Final project sign-off complete. Project status advanced to Completed.");
                  setTimeout(() => setSyncMessage(null), 5000);
                }}
                className={`w-full py-3 rounded-xl text-xs font-extrabold uppercase tracking-wider transition flex items-center justify-center space-x-1.5 cursor-pointer ${
                  progressPercent === 100
                    ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-md border border-emerald-400/30"
                    : "bg-zinc-900 text-zinc-500 border border-zinc-850 cursor-not-allowed"
                }`}
              >
                <UserCheck className="h-4 w-4" />
                <span>{progressPercent === 100 ? "Finish Flip & Release Payout" : "Complete the Checklist First"}</span>
              </button>
            </div>
          </div>
        </motion.div>
      )}
        </AnimatePresence>
      </div>

    </div>
  );
}
