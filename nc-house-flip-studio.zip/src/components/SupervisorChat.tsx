/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Sparkles, MessageSquare, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Message {
  role: "user" | "assistant";
  content: string;
  uiContract?: {
    type: string;
    version: string;
    data: any;
  };
}

interface SupervisorChatProps {
  dealContext: any | null;
}

const PRESET_PROMPTS = [
  { label: "Explain wholesaling HB 797 restriction", query: "Can you explain the NC House Bill 797 wholesaling contract assignment restriction that took effect in October 2025? What is required?" },
  { label: "NC single-member LLC taxation", query: "Why is a single-member LLC recommended for flipping houses in NC, and how are profits taxed?" },
  { label: "Permits required for major rehab", query: "What are the permit requirements for electrical, HVAC, and structural work in Mecklenburg or Durham counties?" },
  { label: "Usury and Deeds of Trust rules", query: "What are the rules for recording Deeds of Trust for hard money lenders in NC, and what are usury limits?" }
];

export default function SupervisorChat({ dealContext }: SupervisorChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I am your Supervisor Agent. I orchestrate the Scout, ARV, Rehab, Compliance, and Project agents. Ask me anything about underwriting, contractor matching, or NC regulatory and tax compliance."
    }
  ]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || isSending) return;

    const userMessage: Message = { role: "user", content: textToSend };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsSending(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          dealContext: dealContext
        })
      });

      if (!response.ok) {
        throw new Error("Failed to connect to Supervisor Agent");
      }

      const data = await response.json();
      setMessages((prev) => [...prev, { role: "assistant", content: data.text, uiContract: data.uiContract }]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "I apologize, but I encountered an issue connecting to my subagent services. Please ensure your Gemini API secrets are set up correctly." }
      ]);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div id="supervisor-chat-container" className="bg-zinc-900/50 border border-zinc-800/80 rounded-3xl flex flex-col h-[500px] shadow-lg overflow-hidden backdrop-blur-md">
      {/* Header */}
      <div className="bg-zinc-900/80 border-b border-zinc-800 p-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 bg-emerald-500/10 text-emerald-400 rounded-lg border border-emerald-500/20">
            <Bot className="h-4.5 w-4.5" />
          </div>
          <div>
            <h3 className="font-extrabold text-xs text-zinc-100 uppercase tracking-wide">Supervisor Assistant</h3>
            <p className="text-[10px] text-zinc-500">NC Real Estate Compliance & Portfolio Expert</p>
          </div>
        </div>
        {dealContext && (
          <div className="flex items-center space-x-1.5 text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full font-extrabold">
            <Sparkles className="h-3 w-3" />
            <span className="truncate max-w-[120px]">Context: {dealContext.address}</span>
          </div>
        )}
      </div>

      {/* Message Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-zinc-950/10">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`flex items-start space-x-2.5 max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed ${
                msg.role === "user"
                  ? "bg-emerald-600 text-white rounded-br-none"
                  : "bg-zinc-900 text-zinc-100 rounded-bl-none border border-zinc-800/80"
              }`}
            >
              {msg.role === "assistant" && (
                <Bot className="h-3.5 w-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              )}
              <div className="flex-1">
                <p className="whitespace-pre-line">{msg.content}</p>
                {msg.uiContract && (
                  <div className="mt-3 pt-3 border-t border-zinc-800 space-y-2 text-zinc-300">
                    {msg.uiContract.type === "deal_score_card" && (
                      <div className="bg-zinc-950/60 p-3 rounded-xl border border-zinc-800 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-emerald-400">Deal Scorecard</span>
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full font-bold">
                            Score: {msg.uiContract.data.score}/100
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-[11px]">
                          <div>
                            <span className="text-zinc-500 block text-[9px]">Recommended Offer</span>
                            <span className="font-bold text-zinc-200">${msg.uiContract.data.purchasePrice?.toLocaleString()}</span>
                          </div>
                          <div>
                            <span className="text-zinc-500 block text-[9px]">Projected Profit</span>
                            <span className="font-bold text-emerald-400">${msg.uiContract.data.projectedProfit?.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    )}
                    {msg.uiContract.type === "compliance_alert" && (
                      <div className="bg-red-500/10 p-3 rounded-xl border border-red-950/50 space-y-1.5 text-[11px] text-red-200">
                        <div className="flex items-center space-x-1.5 font-bold text-red-400">
                          <AlertCircle className="h-3.5 w-3.5" />
                          <span>NC HB 797 Compliance Alert</span>
                        </div>
                        <p className="leading-relaxed text-red-300">{msg.uiContract.data.notes}</p>
                      </div>
                    )}
                    {msg.uiContract.type === "market_analysis" && (
                      <div className="bg-zinc-950/60 p-3 rounded-xl border border-zinc-800 space-y-2">
                        <span className="font-bold text-zinc-400 text-[10px] block uppercase tracking-wider">City Market Metrics</span>
                        <div className="grid grid-cols-3 gap-2 text-[10px] text-center">
                          <div className="bg-zinc-900 p-1.5 rounded-lg border border-zinc-850">
                            <span className="text-zinc-500 block text-[8px]">Avg Flip Days</span>
                            <span className="font-bold text-zinc-200">{msg.uiContract.data.avgDaysToFlip || 120} days</span>
                          </div>
                          <div className="bg-zinc-900 p-1.5 rounded-lg border border-zinc-850">
                            <span className="text-zinc-500 block text-[8px]">Avg ROI</span>
                            <span className="font-bold text-zinc-200">{msg.uiContract.data.avgRoi || "22%"}</span>
                          </div>
                          <div className="bg-zinc-900 p-1.5 rounded-lg border border-zinc-850">
                            <span className="text-zinc-500 block text-[8px]">Inventory</span>
                            <span className="font-bold text-zinc-200">{msg.uiContract.data.inventoryLevel || "Low"}</span>
                          </div>
                        </div>
                      </div>
                    )}
                    {!["deal_score_card", "compliance_alert", "market_analysis"].includes(msg.uiContract.type) && (
                      <div className="bg-zinc-950/60 p-3 rounded-xl border border-zinc-800 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-zinc-500">
                          <span>Rendering Contract Fallback</span>
                          <span>v{msg.uiContract.version}</span>
                        </div>
                        <pre className="font-mono text-[9px] bg-zinc-900 p-2 rounded-lg border border-zinc-850 overflow-x-auto text-zinc-400 leading-normal max-h-[120px]">
                          {JSON.stringify(msg.uiContract.data, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {isSending && (
          <div className="flex justify-start">
            <div className="bg-zinc-900 text-zinc-100 rounded-2xl rounded-bl-none border border-zinc-800/80 p-3 flex items-center space-x-2 text-xs">
              <Bot className="h-3.5 w-3.5 text-emerald-400 animate-pulse" />
              <div className="flex space-x-1">
                <span className="h-1.5 w-1.5 bg-zinc-600 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></span>
                <span className="h-1.5 w-1.5 bg-zinc-600 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></span>
                <span className="h-1.5 w-1.5 bg-zinc-600 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></span>
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Preset Queries Cards */}
      {messages.length === 1 && (
        <div className="px-4 pb-3 border-t border-zinc-800 pt-3.5 bg-zinc-900/40">
          <p className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-wider mb-2 flex items-center">
            <MessageSquare className="h-3 w-3 mr-1" /> Quick Compliance Inquiries
          </p>
          <div className="grid grid-cols-2 gap-2">
            {PRESET_PROMPTS.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(p.query)}
                className="text-[10px] text-left p-2.5 bg-zinc-950/60 hover:bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-300 font-semibold leading-normal hover:border-zinc-700 hover:text-zinc-100 transition duration-150 shadow-xs cursor-pointer"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Box */}
      <div className="p-3.5 border-t border-zinc-800 bg-zinc-900/60">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend(input);
          }}
          className="flex space-x-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isSending}
            placeholder={dealContext ? `Ask about ${dealContext.address}...` : "Consult the Supervisor Agent..."}
            className="flex-1 bg-zinc-950/60 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs focus:outline-hidden focus:ring-1 focus:ring-emerald-500/40 focus:bg-zinc-900 text-zinc-200 font-medium"
          />
          <button
            type="submit"
            disabled={isSending || !input.trim()}
            className="p-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-zinc-850 disabled:text-zinc-700 text-white rounded-xl transition shadow-xs flex-shrink-0 cursor-pointer"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
