/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PropertyDeal, RepairPlan, NCContractorDirectoryItem } from '../types';
import { generateContractorRFP } from '../lib/repairGuideEngine';
import { FileText, Download, Copy, Check, X, ShieldCheck, HardHat, Printer } from 'lucide-react';

interface ContractorRFPModalProps {
  deal: PropertyDeal;
  plan: RepairPlan;
  contractor: NCContractorDirectoryItem;
  onClose: () => void;
  onAssignContractor?: () => void;
}

export const ContractorRFPModal: React.FC<ContractorRFPModalProps> = ({
  deal,
  plan,
  contractor,
  onClose,
  onAssignContractor
}) => {
  const [copied, setCopied] = React.useState(false);
  const rfp = generateContractorRFP(deal, plan, contractor);

  const handleCopy = () => {
    const text = `NORTH CAROLINA SUBCONTRACTOR SCOPE OF WORK & BID REQUEST
RFP #: ${rfp.rfpId}
Date: ${rfp.date}

PROJECT LOCATION:
${deal.address}, ${deal.city}, NC ${deal.zip} (${deal.county || 'NC'})
Year Built: ${deal.yearBuilt || 'N/A'}

INVITED CONTRACTOR:
${contractor.name} (${contractor.licenseNumber})
Phone: ${contractor.phone} | Email: ${contractor.email}

SCOPE OF WORK:
Title: ${plan.title}
Trade: ${plan.trade} | Zone: ${plan.roomZone}
Target Budget Estimate: $${plan.totalEstimatedCost.toLocaleString()}
Estimated Labor: ${plan.estimatedLaborHours} Hours
NC Code Compliance: ${plan.ncCodeCitation}

EXECUTION MILESTONES:
${rfp.scopeOfWork.requiredMilestoneSteps.join('\n')}

TERMS & CONDITIONS:
${rfp.termsAndConditions.join('\n')}
`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-zinc-850 flex items-center justify-between bg-zinc-900/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded-xl">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold text-zinc-100 uppercase tracking-tight">
                NC Subcontractor Scope of Work & RFP Packet
              </h2>
              <p className="text-xs text-zinc-400">
                Formal Bid Request for {contractor.name} • {deal.address}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-200 rounded-xl hover:bg-zinc-800 transition cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Document Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-zinc-300 font-sans">
          {/* Header Metadata */}
          <div className="grid grid-cols-2 gap-4 p-4 bg-zinc-900/80 rounded-2xl border border-zinc-800">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 block">
                Project Property
              </span>
              <p className="font-bold text-zinc-100 mt-0.5">{deal.address}</p>
              <p className="text-zinc-400 text-[11px]">{deal.city}, NC {deal.zip} ({deal.county || 'Mecklenburg County'})</p>
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-zinc-500 block">
                Invited Tradesman / Contractor
              </span>
              <p className="font-bold text-emerald-400 mt-0.5">{contractor.name}</p>
              <p className="text-zinc-400 text-[11px]">{contractor.licenseNumber} • {contractor.phone}</p>
            </div>
          </div>

          {/* Scope Overview */}
          <div className="space-y-2">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
              <HardHat className="h-3.5 w-3.5" />
              <span>Scope Specification & Budget Target</span>
            </h3>
            <div className="p-4 bg-zinc-900/40 border border-zinc-850 rounded-2xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-zinc-100">{plan.title}</span>
                <span className="font-mono font-extrabold text-emerald-400">${plan.totalEstimatedCost.toLocaleString()} Target Bid</span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">{plan.problemDiagnosis}</p>
              <div className="text-[10px] font-mono text-zinc-500 bg-zinc-950 p-2 rounded-lg border border-zinc-850">
                Code Compliance: {plan.ncCodeCitation}
              </div>
            </div>
          </div>

          {/* Execution Steps */}
          <div className="space-y-2">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-zinc-400">
              Required Execution Sequence & Inspection Gates
            </h3>
            <div className="space-y-2">
              {rfp.scopeOfWork.requiredMilestoneSteps.map((step, idx) => (
                <div key={idx} className="p-3 bg-zinc-900/60 border border-zinc-850 rounded-xl text-[11px] text-zinc-300">
                  {step}
                </div>
              ))}
            </div>
          </div>

          {/* NC Legal Terms */}
          <div className="space-y-2">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-zinc-400 flex items-center space-x-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-amber-400" />
              <span>North Carolina Legal & Lien Waiver Stipulations</span>
            </h3>
            <div className="p-4 bg-zinc-950 border border-zinc-850 rounded-2xl space-y-2 text-[10px] text-zinc-400">
              {rfp.termsAndConditions.map((term, idx) => (
                <p key={idx}>{term}</p>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-zinc-850 bg-zinc-900/80 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-extrabold transition cursor-pointer"
            >
              {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied RFP Text' : 'Copy Text'}</span>
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-extrabold transition cursor-pointer"
            >
              <Printer className="h-4 w-4" />
              <span>Print PDF</span>
            </button>
          </div>

          {onAssignContractor && (
            <button
              onClick={() => {
                onAssignContractor();
                onClose();
              }}
              className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold transition shadow-lg cursor-pointer"
            >
              <ShieldCheck className="h-4 w-4" />
              <span>Assign & Dispatch to {contractor.name}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
