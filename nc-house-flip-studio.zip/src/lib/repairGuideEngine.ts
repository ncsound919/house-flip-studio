/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RepairPlan, NCContractorDirectoryItem, PropertyDeal } from '../types';
import { NC_CONTRACTOR_DIRECTORY } from './contractorCatalog';

export interface RepairTemplatePreset {
  title: string;
  trade: string;
  roomZone: string;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  description: string;
  iconName: string;
  defaultCost: number;
  laborHours: number;
}

export const COMMON_NC_REPAIR_PRESETS: RepairTemplatePreset[] = [
  {
    title: 'Crawlspace Moisture Remediation & 12-Mil Encapsulation',
    trade: 'Foundation & Crawlspace',
    roomZone: 'Crawlspace',
    severity: 'critical',
    description: 'Vapor barrier install, foundation vent sealing, commercial sump pump, and Santa Fe dehumidifier per NC Residential Code R408.',
    iconName: 'ShieldAlert',
    defaultCost: 7800,
    laborHours: 32
  },
  {
    title: '200A Main Service Panel Upgrade & Arc-Fault AFCI / GFCI Retrofit',
    trade: 'MEP - Electrical',
    roomZone: 'Utility Room',
    severity: 'high',
    description: 'Replace obsolete Fuse / Federal Pacific / Zinsco panel with 200A Square D / Eaton panel, whole-home surge protector, and dual AFCI/GFCI breakers per NEC 2020 & NC Code E3902.',
    iconName: 'Zap',
    defaultCost: 3800,
    laborHours: 16
  },
  {
    title: 'Subfloor Joist Sistering & Laser Floor Leveling',
    trade: 'Structural Framing',
    roomZone: 'Living Room',
    severity: 'high',
    description: 'Support and sister damaged 2x8 / 2x10 floor joists with pressure-treated lumber, heavy-duty structural screws, and screw jacks to eliminate bounce and sag.',
    iconName: 'Hammer',
    defaultCost: 4500,
    laborHours: 28
  },
  {
    title: 'Whole-House Polybutylene Pipe Replacement with Uponor PEX-A',
    trade: 'MEP - Plumbing',
    roomZone: 'Whole House',
    severity: 'critical',
    description: 'Tear out high-failure polybutylene blue/gray piping; install complete Uponor ProPEX expansion manifold system, quarter-turn shutoffs, and pressure regulator valve (PRV).',
    iconName: 'Droplets',
    defaultCost: 6200,
    laborHours: 36
  },
  {
    title: '30-Year Architectural Shingle Roof Tear-off & Ridge Venting',
    trade: 'Roofing & Attic',
    roomZone: 'Roof & Attic',
    severity: 'critical',
    description: 'Strip 3-tab shingles down to plywood deck, replace rotted 1/2" OSB/plywood, install ice & water shield in valleys and drip edge, install GAF Timberline HDZ shingles with cobra ridge cap.',
    iconName: 'Home',
    defaultCost: 9500,
    laborHours: 40
  },
  {
    title: 'High-Efficiency 15+ SEER2 Heat Pump & R-8 Flex Duct Installation',
    trade: 'MEP - HVAC',
    roomZone: 'Whole House',
    severity: 'high',
    description: 'Install 3-Ton 15.2 SEER2 inverter heat pump, air handler, programmable WiFi thermostat, and sealed R-8 insulated ductwork in unconditioned crawlspace/attic.',
    iconName: 'Flame',
    defaultCost: 8900,
    laborHours: 24
  },
  {
    title: 'Custom Walk-In Shower Schluter Kerdi Waterproofing & Porcelain Tile',
    trade: 'Bath & Tile',
    roomZone: 'Master Bath',
    severity: 'moderate',
    description: 'Install pre-sloped foam shower tray, Kerdi waterproof membrane with 24-hr flood test, linear drain, and 12x24 rectified porcelain tile with epoxy grout.',
    iconName: 'Sparkles',
    defaultCost: 5400,
    laborHours: 30
  },
  {
    title: 'Load-Bearing Wall Removal & Engineered LVL Header Beam Insertion',
    trade: 'Structural Framing',
    roomZone: 'Kitchen / Living',
    severity: 'critical',
    description: 'Install temporary shoring walls, demo center partition wall, hoist double 1-3/4" x 11-7/8" LVL beam supported by triple 2x4 king/jack studs down to foundation footings.',
    iconName: 'Maximize2',
    defaultCost: 6800,
    laborHours: 34
  },
  {
    title: 'Drywall Level 5 Skim Coating & Popcorn Ceiling Texture Removal',
    trade: 'Drywall & Insulation',
    roomZone: 'Living & Bedrooms',
    severity: 'moderate',
    description: 'Test for asbestos/lead, scrape acoustic popcorn texture, tape seams, apply full skim coat to Level 5 smooth finish, prime with PVA sealer.',
    iconName: 'Paintbrush',
    defaultCost: 3600,
    laborHours: 26
  },
  {
    title: 'Listing Prep Punchout, Interior Trim, Door Alignment & Touchups',
    trade: 'Flooring & Finishes',
    roomZone: 'Whole House',
    severity: 'low',
    description: 'Hang and align interior pre-hung doors, install 5-1/4" speed baseboards, adjust cabinet hinges, caulk baseboards, and execute final cosmetic touch-ups.',
    iconName: 'Wrench',
    defaultCost: 2200,
    laborHours: 18
  }
];

/**
 * High-fidelity local AI repair plan generator (grounded in NC Residential Building Code)
 */
export function generateLocalRepairPlan(
  deal: PropertyDeal,
  taskTitle: string,
  tradeCategory: string,
  roomZone: string = 'General Zone',
  severity: 'low' | 'moderate' | 'high' | 'critical' = 'moderate'
): RepairPlan {
  const planId = `plan-${deal.id}-${Date.now()}`;
  const yearBuilt = deal.yearBuilt || 1972;
  const city = deal.city || 'Charlotte';
  const county = deal.county || 'Mecklenburg County';

  // Determine trade-specific details
  let ncCodeCitation = '2024 NC Residential Code Section R502 & NC General Construction Standards';
  let permitRequired = false;
  let permitType = 'No Permit Required (Cosmetic/Maintenance)';
  let diyFeasibility: RepairPlan['diyFeasibility'] = 'Handyman Feasible';
  let laborHours = 20;
  let materialCost = 1200;
  let laborCost = 1600;

  if (tradeCategory.includes('Electrical')) {
    ncCodeCitation = 'NC Electrical Code (2020 NEC with NC Amendments) & NCRC Section E3902 (Arc-Fault / GFCI Protection)';
    permitRequired = true;
    permitType = 'Trade Permit - Electrical (City/County Inspections Dept)';
    diyFeasibility = 'Licensed Trade Required';
    laborHours = 18;
    materialCost = 1400;
    laborCost = 2100;
  } else if (tradeCategory.includes('Plumbing')) {
    ncCodeCitation = '2024 NC Plumbing Code Chapter 6 (Water Supply) & Section P2605 (Support & Piping Slope)';
    permitRequired = true;
    permitType = 'Trade Permit - Plumbing (City/County Inspections Dept)';
    diyFeasibility = 'Licensed Trade Required';
    laborHours = 26;
    materialCost = 1900;
    laborCost = 2800;
  } else if (tradeCategory.includes('HVAC')) {
    ncCodeCitation = '2024 NC Mechanical Code & NC Energy Conservation Code Section R403 (Duct Air Leakage <= 4 CFM/100 sqft)';
    permitRequired = true;
    permitType = 'Trade Permit - Mechanical / HVAC';
    diyFeasibility = 'Licensed Trade Required';
    laborHours = 22;
    materialCost = 4200;
    laborCost = 3100;
  } else if (tradeCategory.includes('Roofing')) {
    ncCodeCitation = '2024 NC Residential Code Section R905 (Roof Coverings, Ice & Water Barriers & Wind Resistance Up to 115 MPH)';
    permitRequired = true;
    permitType = 'Building Permit - Residential Roof Replacement';
    diyFeasibility = 'NC GC Required';
    laborHours = 38;
    materialCost = 4600;
    laborCost = 4400;
  } else if (tradeCategory.includes('Foundation') || tradeCategory.includes('Crawlspace')) {
    ncCodeCitation = '2024 NC Residential Code Section R408 (Under-Floor Space Moisture & Closed Crawlspace Standards)';
    permitRequired = true;
    permitType = 'Building Permit - Foundation & Moisture Mitigation';
    diyFeasibility = 'Licensed Trade Required';
    laborHours = 30;
    materialCost = 3200;
    laborCost = 3600;
  } else if (tradeCategory.includes('Structural')) {
    ncCodeCitation = '2024 NC Residential Code Section R502 (Wood Floor Framing) & Section R602 (Wall Construction)';
    permitRequired = true;
    permitType = 'Building Permit - Structural Alterations';
    diyFeasibility = 'NC GC Required';
    laborHours = 32;
    materialCost = 2200;
    laborCost = 3400;
  } else if (tradeCategory.includes('Bath') || tradeCategory.includes('Tile')) {
    ncCodeCitation = '2024 NC Residential Code Section P2708 (Showers) & ANSI A108 Ceramic Tile Waterproof Standards';
    permitRequired = false;
    permitType = 'Building / Trade Permit (if moving plumbing drain lines)';
    diyFeasibility = 'Handyman Feasible';
    laborHours = 28;
    materialCost = 1800;
    laborCost = 2400;
  }

  const totalEstimatedCost = materialCost + laborCost;

  // Matched contractor IDs
  const matched = matchContractorsForTask(tradeCategory, city, 4);

  return {
    id: planId,
    dealId: deal.id,
    propertyAddress: deal.address,
    city: deal.city,
    title: taskTitle,
    trade: tradeCategory,
    roomZone: roomZone,
    severity: severity,
    problemDiagnosis: `Targeted repair scope for ${taskTitle} at ${deal.address}, ${deal.city} NC (Built ${yearBuilt}). Existing conditions indicate age-typical degradation requiring code-compliant rehabilitation per ${county} building standards.`,
    rootCauses: [
      `Age-related wear consistent with ${yearBuilt} construction era in North Carolina.`,
      `High ambient humidity and regional temperature fluctuations typical of the Piedmont/Coastal NC climate.`,
      `Previous unpermitted cosmetic work or deferred maintenance from prior owners.`
    ],
    riskFactors: [
      `Failing rough-in county inspection if work is executed without required permit pull.`,
      `Hidden moisture or structural termite damage behind wall cavities or joists.`,
      `Cost overruns if existing framing does not meet plane and plumb tolerances.`
    ],
    ncCodeCitation,
    permitRequired,
    permitType,
    diyFeasibility,
    estimatedLaborHours: laborHours,
    estimatedMaterialCost: materialCost,
    estimatedLaborCost: laborCost,
    totalEstimatedCost,
    requiredTools: [
      { name: 'Laser Level & 4ft Stabila Box Level', category: 'Safety & Measuring', essential: true, approximateCost: 140 },
      { name: 'Brushless High-Torque Impact Driver & Bit Set', category: 'Power Tools', essential: true, approximateCost: 180 },
      { name: 'Oscillating Multi-Tool with Carbide Blades', category: 'Power Tools', essential: true, approximateCost: 120 },
      { name: 'Calibrated Non-Contact Voltage / Moisture Meter', category: 'Safety & Measuring', essential: true, approximateCost: 85 },
      { name: 'Heavy-Duty Demolition Pry Bar & Framing Hammer', category: 'Hand Tools', essential: true, approximateCost: 45 },
      { name: 'HEPA Negative-Air Dust Scrubber & Vacuum', category: 'Specialty Trade', essential: false, approximateCost: 350 }
    ],
    requiredMaterials: [
      { name: 'NC Code Compliant Fasteners & Structural Screws (GRK/Simpson)', quantity: '2 Boxes (500ct)', estimatedUnitCost: 48, totalCost: 96, ncTradeSpec: 'Simpson Strong-Tie SDWS structural', retailSku: 'HD-884102' },
      { name: 'Grade-A Pressure Treated Framing Lumber / Substrate', quantity: '14 Units', estimatedUnitCost: 28, totalCost: 392, ncTradeSpec: 'Southern Yellow Pine #2 PT', retailSku: 'LOWES-24910' },
      { name: 'Heavy-Duty Trade Grade Sealant / Waterproof Barrier', quantity: '8 Tubes / Rolls', estimatedUnitCost: 24, totalCost: 192, ncTradeSpec: 'OSI Quad MAX / Henry Blueskin', retailSku: 'HD-109283' },
      { name: 'Primary Trade Assembly Kit & Hardware Components', quantity: '1 Master Pack', estimatedUnitCost: 650, totalCost: 650, ncTradeSpec: 'UL-Listed / ASTM Standards', retailSku: 'PRO-99214' }
    ],
    safetyPPE: [
      'ANSI Z87.1 Approved Ballistic Safety Glasses',
      'N95 / P100 Dual Cartridge Particulate Respirator',
      'Level 4 Cut-Resistant Work Gloves',
      'Steel-Toe Composite Work Boots with Puncture Plate',
      'OSHA Lockout/Tagout (LOTO) Padlocks & Breaker Clips'
    ],
    criticalPitfalls: [
      'DO NOT start structural demo or electrical panel work without pulling trade permit from municipal inspections department.',
      'Always test for asbestos (pre-1980 drywall/popcorn/flooring) and lead paint before cutting or sanding.',
      'Ensure subfloor deflection criteria (L/360 or L/720 for stone/tile) is verified before setting finishes.'
    ],
    proTips: [
      'Document pre-existing conditions with date-stamped photos to protect draw requests with lenders.',
      'Purchase materials through Lowe\'s Pro or Home Depot Pro Desk with 10-15% contractor discount volume pricing.',
      'Schedule municipal rough-in inspections 48 hours in advance to avoid contractor downtime on site.'
    ],
    executionPhases: [
      {
        phaseNumber: 1,
        phaseName: 'Permit Verification & Site Isolation',
        description: 'Verify active county permits, lock out hazardous utilities, and establish dust containment barriers.',
        steps: [
          {
            stepNumber: 1,
            title: 'Utility Isolation & LOTO Procedure',
            instruction: 'Disconnect main electrical branch circuits or shut off main water ball valve before beginning work. Verify zero energy with calibrated tester.',
            toleranceMetric: '0.00V verified across all legs; 0 PSI water line pressure',
            inspectionGate: false,
            completed: false
          },
          {
            stepNumber: 2,
            title: 'Negative Air Dust Containment',
            instruction: 'Hang 6-mil poly zip-wall barriers across living zones to prevent dust migration into finished areas.',
            toleranceMetric: '100% sealed perimeters with zipper access door',
            inspectionGate: false,
            completed: false
          }
        ]
      },
      {
        phaseNumber: 2,
        phaseName: 'Surgical Demolition & Substrate Prep',
        description: 'Carefully strip compromised materials, inspect hidden framing, and prep substrate for code compliance.',
        steps: [
          {
            stepNumber: 3,
            title: 'Controlled Demo & Debris Haul-off',
            instruction: 'Remove degraded finishes, rotted subfloor, or obsolete wiring/piping. Bag debris directly into contractor dumpster.',
            toleranceMetric: 'Substrate exposed to clean sound lumber/masonry',
            inspectionGate: false,
            completed: false
          },
          {
            stepNumber: 4,
            title: 'Structural Framing & Plane Verification',
            instruction: 'Inspect underlying joists, studs, or rafters for moisture rot or termite damage. Sister or replace any compromised framing.',
            toleranceMetric: 'Plumb & level tolerance within 1/8" across 10 feet',
            inspectionGate: true,
            completed: false
          }
        ]
      },
      {
        phaseNumber: 3,
        phaseName: 'Primary Trade Assembly & Installation',
        description: 'Install new materials, hardware, conduits, or fixtures strictly adhering to NC Building Code.',
        steps: [
          {
            stepNumber: 5,
            title: 'Rough-in Assembly Execution',
            instruction: `Execute primary installation of ${taskTitle} using specified fasteners and code-approved materials.`,
            toleranceMetric: 'Fastening pattern per NC Code schedule (6" edges, 12" field)',
            inspectionGate: true,
            completed: false
          },
          {
            stepNumber: 6,
            title: 'Pre-Inspection Pressure / Load Test',
            instruction: 'Conduct trade verification (e.g. 24-hr hydrostatic water test, megohmmeter circuit test, or deflection load test).',
            toleranceMetric: 'Zero drop in test gauge pressure over 24 hours',
            inspectionGate: true,
            completed: false
          }
        ]
      },
      {
        phaseNumber: 4,
        phaseName: 'Municipal Inspection & Final Commissioning',
        description: 'Pass county building inspector sign-off, close wall cavities, and execute final cosmetic punchout.',
        steps: [
          {
            stepNumber: 7,
            title: 'County Inspector Rough-In Sign-off',
            instruction: 'Meet municipal building inspector on site; obtain green inspection tag and log permit status.',
            toleranceMetric: 'Official Green Tag posted on electrical panel / site job card',
            inspectionGate: true,
            completed: false
          },
          {
            stepNumber: 8,
            title: 'Trim, Finishes & Final Quality Walkthrough',
            instruction: 'Install drywall patches, trim, paint, and final fixtures. Verify flawless operation with owner punch list.',
            toleranceMetric: '100% punch items resolved; unconditional lien waiver signed',
            inspectionGate: false,
            completed: false
          }
        ]
      }
    ],
    matchedContractorIds: matched.map(c => c.id),
    assignedContractorId: matched[0]?.id,
    assignedContractorName: matched[0]?.name,
    assignedContractorPhone: matched[0]?.phone,
    assignedContractorRate: `$${matched[0]?.hourlyRate || 85}/hr`,
    createdAt: new Date().toISOString(),
    status: 'ready'
  };
}

/**
 * Filter and score NC contractors for a specific trade and location
 */
export function matchContractorsForTask(
  trade: string,
  city: string,
  limit: number = 6
): NCContractorDirectoryItem[] {
  const normalizedTrade = trade.toLowerCase();
  const normalizedCity = city.toLowerCase();

  return [...NC_CONTRACTOR_DIRECTORY]
    .map(contractor => {
      let score = 0;

      // Trade match
      if (contractor.trade.toLowerCase() === normalizedTrade) {
        score += 50;
      } else if (contractor.specialties.some(s => s.toLowerCase().includes(normalizedTrade) || normalizedTrade.includes(s.toLowerCase()))) {
        score += 35;
      } else if (contractor.trade === 'General Contracting') {
        score += 20; // GCs can manage almost any trade
      }

      // City match
      if (contractor.city.toLowerCase() === normalizedCity) {
        score += 30;
      } else if (
        (normalizedCity.includes('charlotte') && contractor.city === 'Charlotte') ||
        (normalizedCity.includes('raleigh') && contractor.city === 'Raleigh') ||
        (normalizedCity.includes('durham') && contractor.city === 'Durham') ||
        (normalizedCity.includes('greensboro') && contractor.city === 'Greensboro')
      ) {
        score += 25;
      } else {
        score += 10;
      }

      // Rating & verified status
      score += (contractor.rating * 4);
      if (contractor.licenseVerified) score += 10;
      if (contractor.workersCompVerified) score += 5;
      if (contractor.availability === 'Immediate') score += 5;

      return { contractor, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(item => item.contractor);
}

/**
 * Generate formal North Carolina Contractor RFP & Scope of Work bid invitation document
 */
export function generateContractorRFP(
  deal: PropertyDeal,
  plan: RepairPlan,
  contractor: NCContractorDirectoryItem
) {
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return {
    rfpId: `RFP-NC-${Date.now()}`,
    date: currentDate,
    property: {
      address: deal.address,
      city: deal.city,
      state: 'NC',
      zip: deal.zip,
      county: deal.county || 'Mecklenburg County',
      yearBuilt: deal.yearBuilt || 1970
    },
    contractor: {
      name: contractor.name,
      trade: contractor.trade,
      license: contractor.licenseNumber,
      phone: contractor.phone,
      email: contractor.email
    },
    scopeOfWork: {
      title: plan.title,
      roomZone: plan.roomZone,
      tradeCategory: plan.trade,
      diagnosis: plan.problemDiagnosis,
      ncCodeCompliance: plan.ncCodeCitation,
      targetBudgetEstimate: plan.totalEstimatedCost,
      estimatedLaborHours: plan.estimatedLaborHours,
      requiredMilestoneSteps: plan.executionPhases.flatMap(p => p.steps.map(s => `Step ${s.stepNumber}: ${s.title} - ${s.instruction}`))
    },
    termsAndConditions: [
      '1. FIXED PRICE / NOT-TO-EXCEED BID: Subcontractor shall provide a firm written estimate including labor, materials, permits, and haul-off.',
      '2. NORTH CAROLINA LIEN WAIVER REQUIREMENT: Payment disbursements are governed by progress milestones. Subcontractor must execute an NC Conditional Progress Lien Waiver (NC G.S. § 44A) prior to each bank draw release.',
      '3. LICENSING & INSURANCE: Contractor must maintain active NC trade license, minimum $1,000,000 General Liability insurance, and valid North Carolina Workers\' Compensation policy.',
      '4. MUNICIPAL INSPECTION GUARANTEE: All work must pass official city/county building inspector rough-in and final green tag sign-offs prior to retainage disbursement release.'
    ]
  };
}
