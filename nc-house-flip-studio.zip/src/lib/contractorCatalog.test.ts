import { describe, it, expect } from 'vitest';
import { NC_CONTRACTOR_DIRECTORY } from './contractorCatalog';

describe('NC Contractor Directory', () => {
  it('should contain a rich directory of North Carolina verified contractors', () => {
    expect(NC_CONTRACTOR_DIRECTORY.length).toBeGreaterThan(10);
  });

  it('should validate that all contractors have complete compliance information', () => {
    NC_CONTRACTOR_DIRECTORY.forEach((contractor) => {
      expect(contractor.id).toBeDefined();
      expect(contractor.name).toBeTruthy();
      expect(contractor.trade).toBeTruthy();
      expect(contractor.city).toBeTruthy();
      expect(contractor.county).toBeTruthy();
      expect(contractor.phone).toMatch(/^\(\d{3}\)\s\d{3}-\d{4}$/);
      expect(contractor.email).toContain('@');
      expect(contractor.rating).toBeGreaterThanOrEqual(4.0);
      expect(contractor.rating).toBeLessThanOrEqual(5.0);
      expect(contractor.hourlyRate).toBeGreaterThan(0);
      expect(contractor.insurancePolicy).toBeTruthy();
      expect(contractor.insuranceLimit).toBeTruthy();
      expect(contractor.yearsInBusiness).toBeGreaterThan(0);
      expect(contractor.completedNCProjects).toBeGreaterThan(0);
      expect(contractor.specialties.length).toBeGreaterThan(0);
      expect(contractor.badgeHighlights.length).toBeGreaterThan(0);
    });
  });

  it('should contain contractors across multiple key North Carolina metro markets', () => {
    const cities = NC_CONTRACTOR_DIRECTORY.map((c) => c.city);
    expect(cities).toContain('Charlotte');
    expect(cities).toContain('Raleigh');
    expect(cities).toContain('Durham');
    expect(cities).toContain('Greensboro');
  });

  it('should verify license verification status for licensed trade tiers', () => {
    const licensedTrades = NC_CONTRACTOR_DIRECTORY.filter(
      (c) => c.licenseTier.includes('GC') || c.licenseTier.includes('Unlimited') || c.licenseTier.includes('Class')
    );
    expect(licensedTrades.length).toBeGreaterThan(0);
    licensedTrades.forEach((c) => {
      expect(c.licenseVerified).toBe(true);
      expect(c.w9OnFile).toBe(true);
      expect(c.workersCompVerified).toBe(true);
    });
  });
});
