import { describe, it, expect } from 'vitest';
import {
  FinancingEngine,
  ContractAssignmentStrategy,
  JVEquityFlipsStrategy,
  ZeroCashFinancingStrategy,
  InvestorProfile
} from './FinancingEngine';
import { PropertyDeal } from '../types';

const testDeal: PropertyDeal = {
  id: 'deal-fin-101',
  address: '2204 Plaza Rd',
  city: 'Charlotte',
  state: 'NC',
  zip: '28205',
  county: 'Mecklenburg County',
  propertyType: 'Single Family',
  sqft: 1750,
  bed: 3,
  bath: 2,
  yearBuilt: 1965,
  lotSize: 0.25,
  description: 'Distressed single family investment property in NC',
  askingPrice: 160000,
  status: 'Underwriting',
  underwriting: {
    purchasePrice: 150000,
    arv: 295000,
    arvConfidence: 'High',
    rehabCost: 45000,
    holdingCosts: 6000,
    sellingCosts: 6000,
    acquisitionCosts: 2000,
    financingCosts: 3000,
    maxOffer70Rule: 155000,
    projectedProfit: 88000,
    roi: 42.5,
    cashOnCash: 42.5,
    holdingPeriodMonths: 6,
    contingencyRate: 10
  },
  comps: [],
  rehabItems: [],
  complianceChecks: [],
  milestones: [],
  contractors: [],
  logs: []
};

const licensedBeginnerProfile: InvestorProfile = {
  experienceLevel: 'Beginner',
  cashAvailable: 2500,
  creditScore: 680,
  priorFlips: 0,
  ownsHome: false,
  hasBrokerLicense: true
};

const beginnerProfile: InvestorProfile = {
  experienceLevel: 'Beginner',
  cashAvailable: 2500,
  creditScore: 680,
  priorFlips: 0,
  ownsHome: false,
  hasBrokerLicense: false
};

const proProfile: InvestorProfile = {
  experienceLevel: 'Professional',
  cashAvailable: 85000,
  creditScore: 780,
  priorFlips: 8,
  ownsHome: true,
  hasBrokerLicense: true
};

describe('Financing Strategy Engine & Underwriting Pathways', () => {
  describe('ContractAssignmentStrategy (Wholesaling)', () => {
    const strategy = new ContractAssignmentStrategy();

    it('recommends wholesale assignment for licensed beginner investors on wide-spread deals', () => {
      const result = strategy.evaluate(testDeal, licensedBeginnerProfile);

      expect(result.strategy).toBe('Contract Assignment (Wholesaling)');
      expect(result.cashToClose).toBe(1000);
      expect(result.loanAmount).toBe(0);
      expect(result.fitCategory).toBe('recommended');
      expect(result.fitScore).toBeGreaterThanOrEqual(70);
      expect(result.assignmentDetails).toBeDefined();
      expect(result.assignmentDetails?.buyerMatches.length).toBeGreaterThan(0);
      expect(result.stressTest).toBeDefined();
      expect(result.stressTest?.scenarios.length).toBe(4);
    });

    it('blocks unlicensed investors due to NC HB 797 compliance laws', () => {
      const result = strategy.evaluate(testDeal, beginnerProfile);
      expect(result.fitCategory).toBe('not_eligible');
      expect(result.oneLineReason).toContain('HB 797');
    });

    it('rejects deals when the spread is too narrow for assignment', () => {
      const tightDeal: PropertyDeal = {
        ...testDeal,
        underwriting: {
          ...testDeal.underwriting,
          purchasePrice: 240000,
          arv: 260000,
          rehabCost: 15000
        }
      };

      const result = strategy.evaluate(tightDeal, licensedBeginnerProfile);
      expect(result.fitCategory).toBe('not_eligible');
      expect(result.fitScore).toBe(0);
      expect(result.oneLineReason).toContain('Wholesale Spread too tight');
    });
  });

  describe('JVEquityFlipsStrategy (Joint Venture)', () => {
    const strategy = new JVEquityFlipsStrategy();

    it('evaluates JV structure with profit splits and capital exposure maps', () => {
      const result = strategy.evaluate(testDeal, beginnerProfile);

      expect(result.strategy).toBe('JV Equity Partnership');
      expect(result.cashToClose).toBe(0);
      expect(result.jvDetails).toBeDefined();
      expect(result.jvDetails?.splits.length).toBeGreaterThan(0);
      expect(result.jvDetails?.splits[0].ratio).toContain('50/50');
      expect(result.jvDetails?.partnerRoi).toBeGreaterThan(0);
    });

    it('fails eligibility if project profit is below the minimum $35k spread threshold for JV partners', () => {
      const lowProfitDeal: PropertyDeal = {
        ...testDeal,
        underwriting: {
          ...testDeal.underwriting,
          projectedProfit: 15000,
          purchasePrice: 200000,
          arv: 230000,
          rehabCost: 15000
        }
      };

      const result = strategy.evaluate(lowProfitDeal, beginnerProfile);
      expect(result.fitCategory).toBe('not_eligible');
      expect(result.oneLineReason).toContain('Spread too thin for JV');
    });
  });

  describe('ZeroCashFinancingStrategy (100% Hard Money + Gap Funding)', () => {
    const strategy = new ZeroCashFinancingStrategy();

    it('calculates full hard money + gap funding capital stack for experienced investors', () => {
      const result = strategy.evaluate(testDeal, proProfile);

      expect(result.strategy).toBe('Hard Money + Partner Gap Funding');
      expect(result.fitCategory).toBe('recommended');
      expect(result.zeroCashDetails).toBeDefined();
      expect(result.zeroCashDetails?.capitalStack.length).toBe(3);
      expect(result.zeroCashDetails?.lenderFitScore).toBeGreaterThanOrEqual(80);
      expect(result.cashToClose).toBe(0);
    });

    it('blocks zero cash hard money if user credit score is too low (<600)', () => {
      const lowCreditProfile: InvestorProfile = {
        ...beginnerProfile,
        creditScore: 580
      };

      const result = strategy.evaluate(testDeal, lowCreditProfile);
      expect(result.fitCategory).toBe('not_eligible');
      expect(result.oneLineReason).toContain('Credit too low');
    });
  });

  describe('FinancingEngine (Global Ranker & Evaluator)', () => {
    it('evaluates and sorts all financing pathways for a given deal and profile', () => {
      const engine = new FinancingEngine();
      const results = engine.evaluateAll(testDeal, licensedBeginnerProfile);

      expect(results.length).toBe(3);
      // Top result should be eligible and high score
      expect(results[0].fitCategory).not.toBe('not_eligible');
      expect(results[0].fitScore).toBeGreaterThanOrEqual(results[1].fitScore);

      // Verify stress testing exists across all results
      results.forEach((res) => {
        expect(res.stressTest).toBeDefined();
        expect(res.stressTest?.scenarios.length).toBe(4);
        expect(res.details.length).toBeGreaterThan(0);
      });
    });
  });
});
