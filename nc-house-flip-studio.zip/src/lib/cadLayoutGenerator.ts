/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PropertyDeal, HouseCADLayout, CADRoom, FixProtocolNode, FixProtocolStep, CADTradeType, CADZoneType } from '../types';

/**
 * Standard NC Residential Code Reference Catalog for Fix Protocols
 */
export const NC_CODE_CATALOG: Record<string, { code: string; title: string; inspectGate: boolean; ppe: string[] }> = {
  'Electrical Service': {
    code: 'NC Residential Code E3601 & NEC 2020 Art. 230',
    title: '200A Main Service Panel & Grounding Electrode System',
    inspectGate: true,
    ppe: ['Voltage Rated Gloves 1000V', 'Arc Flash Shield', 'Safety Glasses', 'Dielectric Boots']
  },
  'AFCI/GFCI Protection': {
    code: 'NC Residential Code E3902.1 - E3902.16',
    title: 'Kitchen, Bath & Outdoor GFCI & Bedroom AFCI Breakers',
    inspectGate: true,
    ppe: ['Safety Glasses', 'Insulated Hand Tools']
  },
  'Crawlspace Encapsulation': {
    code: 'NC Residential Code R408.3 (Closed Crawlspace)',
    title: '12-mil Sealed Vapor Barrier & Dehumidification System',
    inspectGate: true,
    ppe: ['Respirator N95 / P100', 'Tyvek Coveralls', 'Headlamp', 'Knee Pads']
  },
  'Subfloor & Joist Sistering': {
    code: 'NC Residential Code R502.3 & Table R502.3.1(2)',
    title: 'Floor Joist Spacing, Joist Hangers & #2 SYP Sistering',
    inspectGate: true,
    ppe: ['Hard Hat', 'Safety Glasses', 'Ear Protection', 'Steel Toe Boots']
  },
  'Roof Decking & Shingles': {
    code: 'NC Residential Code R905.2 (Asphalt Shingles) & R905.1.1 (Underlayment)',
    title: 'Synthetic Underlayment, Drip Edge, & Architectural Shingles',
    inspectGate: true,
    ppe: ['Fall Arrest Harness & Anchor', 'Roofing Shoes', 'Safety Glasses', 'Gloves']
  },
  'HVAC Heat Pump & Duct Sealing': {
    code: 'NC Energy Conservation Code Section R403.3 & NC Mech Code 603',
    title: '15.2+ SEER2 Heat Pump, R-8 Duct Insulation & Mastic Sealing',
    inspectGate: true,
    ppe: ['N95 Dust Mask', 'Safety Glasses', 'Work Gloves']
  },
  'Plumbing Supply & DWV': {
    code: 'NC Plumbing Code Section 604 & 704',
    title: 'PEX-A Water Distribution & PVC Sanitary Drain Waste Vent',
    inspectGate: true,
    ppe: ['Safety Glasses', 'Nitrile Gloves', 'Face Shield for Solder/Glue']
  },
  'Drywall & Fire-Rating': {
    code: 'NC Residential Code R302.6 (Garage-to-Living Separation)',
    title: '5/8" Type-X Fire Barrier on Garage Common Walls & Level 4 Finish',
    inspectGate: false,
    ppe: ['Dust Mask', 'Safety Glasses', 'Stilts / Scaffolding Safety Harness']
  },
  'Tile Waterproofing': {
    code: 'ANSI A118.10 / TCNA Guidelines B415',
    title: 'Bonded Liquid/Sheet Waterproofing Membrane in Wet Areas',
    inspectGate: true,
    ppe: ['Safety Glasses', 'Chemical Resistant Gloves']
  },
  'Egress Windows': {
    code: 'NC Residential Code R310.1 (Emergency Escape Openings)',
    title: 'Min. 5.7 sqft Clear Opening, Max 44" Sill Height',
    inspectGate: true,
    ppe: ['Safety Glasses', 'Hearing Protection', 'Gloves']
  }
};

/**
 * Generate standard execution steps for a specific trade and rehab task
 */
export function generateFixProtocolSteps(taskName: string, trade: CADTradeType): FixProtocolStep[] {
  const nameLower = taskName.toLowerCase();

  if (nameLower.includes('electric') || nameLower.includes('panel') || trade === 'MEP - Electrical') {
    return [
      {
        stepNumber: 1,
        title: 'Duke Energy / Municipal Disconnect & Permitting',
        detail: 'Coordinate with utility power provider for meter pull. Verify active electrical trade permit with county building inspections.',
        qualityCheckSOP: 'Confirm zero-voltage state with calibrated fluke multimeter across all phases.',
        inspectionGate: true,
        ncCodeSnippet: 'NC E3601.2 Disconnecting Means'
      },
      {
        stepNumber: 2,
        title: 'Demo Existing Panel & Service Entrance Conductors',
        detail: 'Remove obsolete fuse box or stab-lok panel. Clean out enclosure bay and install firestop seal around wall penetration.',
        qualityCheckSOP: 'Ensure wire insulation integrity; label all branch circuit home runs.',
        inspectionGate: false
      },
      {
        stepNumber: 3,
        title: 'Mount 200A Load Center & Grounding Electrodes',
        detail: 'Drive two 5/8" x 8ft copper ground rods spaced min 6ft apart. Bond to cold water metal supply with #4 AWG bare copper.',
        qualityCheckSOP: 'Ground resistance test < 25 ohms or dual rod bonding verified.',
        inspectionGate: true,
        ncCodeSnippet: 'NEC 250.53 Grounding Electrode System'
      },
      {
        stepNumber: 4,
        title: 'Land Branch Circuits & Dual Function AFCI/GFCI Breakers',
        detail: 'Terminate neutral and ground conductors on dedicated bus bars. Install dual-function AFCI/GFCI breakers on all bedroom and kitchen circuits.',
        qualityCheckSOP: 'Torque all terminal lugs to manufacturer specification (e.g. 50 in-lbs for main lugs).',
        inspectionGate: false
      },
      {
        stepNumber: 5,
        title: 'Final County Rough-In & Service Release Inspection',
        detail: 'Present panel schedule legend and wire tags for NC County Electrical Inspector sign-off and meter reconnect.',
        qualityCheckSOP: 'Pass city electrical inspector sticker and obtain green tag.',
        inspectionGate: true,
        ncCodeSnippet: 'NC Administrative Code Section 107'
      }
    ];
  }

  if (nameLower.includes('roof') || trade === 'Roofing & Attic') {
    return [
      {
        stepNumber: 1,
        title: 'Full Tear-Off to Bare Plywood Decking',
        detail: 'Strip existing shingle layers down to wood sheathing. Remove damaged flashing, boots, and drip edge.',
        qualityCheckSOP: 'Inspect all 4x8 plywood sheets for rot, delamination, or sagging > 1/4".',
        inspectionGate: false
      },
      {
        stepNumber: 2,
        title: 'Deck Repair & Ice/Water Shield Installation',
        detail: 'Replace rotted CDX plywood sheets. Install self-adhering ice & water barrier at eaves, valleys, and rakes per NC Coastal/Piedmont wind zones.',
        qualityCheckSOP: 'Fasten decking with 8d ring shank nails every 6" on edges and 12" in field.',
        inspectionGate: true,
        ncCodeSnippet: 'NC Residential Code R905.1.2 & R905.2.8.2'
      },
      {
        stepNumber: 3,
        title: 'Synthetic Underlayment & Metal Drip Edge',
        detail: 'Roll high-traction synthetic felt with min 4" horizontal overlap. Fasten aluminum drip edge over underlayment at rakes, under at eaves.',
        qualityCheckSOP: 'Verify smooth lay without fishmouths or exposed wood gaps.',
        inspectionGate: false
      },
      {
        stepNumber: 4,
        title: 'Install Starter Strip & Architectural Shingles',
        detail: 'Fasten starter strip along all edges. Lay architectural shingles with 6-nail high-wind pattern (130 MPH rating).',
        qualityCheckSOP: 'Check nail penetration into solid wood; nails must sit flush without breaking shingle mat.',
        inspectionGate: false
      },
      {
        stepNumber: 5,
        title: 'Continuous Ridge Vent & Lead Pipe Boots',
        detail: 'Cut 1.5" continuous slot at ridge peak. Install baffled ridge vent, cap shingles, and heavy-duty neoprene/lead pipe collars.',
        qualityCheckSOP: 'Inspect attic daylight and airflow to verify balanced NFA ventilation (1:300 rule).',
        inspectionGate: true,
        ncCodeSnippet: 'NC Residential Code R806 Attic Ventilation'
      }
    ];
  }

  if (nameLower.includes('crawl') || nameLower.includes('foundation') || trade === 'Foundation & Crawlspace') {
    return [
      {
        stepNumber: 1,
        title: 'Debris Removal, Grading & Sub-Grade Prep',
        detail: 'Clear all organic materials, wood scraps, and trash. Level soil floor and dig perimeter drainage trench pitched to sump basin.',
        qualityCheckSOP: 'Verify 0% standing water and negative soil grade away from foundation walls.',
        inspectionGate: false
      },
      {
        stepNumber: 2,
        title: 'Install Heavy Duty Sump Pump & Gravity Discharge',
        detail: 'Set 1/3 HP cast-iron submersible sump pump inside perforated basin with check valve and schedule 40 discharge to exterior daylight.',
        qualityCheckSOP: 'Test float switch actuation and exterior discharge dispersal > 10ft from footing.',
        inspectionGate: true
      },
      {
        stepNumber: 3,
        title: 'Floor Joist & Girder Sistering (if sagging)',
        detail: 'Jack floor joists in 1/8" daily increments to level. Sister new #2 SYP dimensional lumber with structural adhesive and staggered 16d nails.',
        qualityCheckSOP: 'Level check subfloor with 6ft digital level across door thresholds.',
        inspectionGate: true,
        ncCodeSnippet: 'NC Residential Code R502.3.1'
      },
      {
        stepNumber: 4,
        title: '12-Mil Reinforced Vapor Barrier Wall-to-Wall Seal',
        detail: 'Fasten 12-mil reinforced polyethylene 6" below masonry top plate with butyl tape and mechanical pins. Overlap ground seams 12" and tape airtight.',
        qualityCheckSOP: 'Confirm 100% floor coverage with termite inspection gap maintained (3" clear from sill plate).',
        inspectionGate: true,
        ncCodeSnippet: 'NC Residential Code R408.3'
      },
      {
        stepNumber: 5,
        title: 'Energy Star Dehumidifier & Monitoring Sensor',
        detail: 'Commission 70-pint commercial crawlspace dehumidifier with continuous gravity drain and digital wall-mounted relative humidity controller.',
        qualityCheckSOP: 'Maintain target crawlspace relative humidity < 55% consistently.',
        inspectionGate: false
      }
    ];
  }

  if (nameLower.includes('hvac') || nameLower.includes('heat pump') || trade === 'MEP - HVAC') {
    return [
      {
        stepNumber: 1,
        title: 'Manual J Load Calculation & Equipment Sizing',
        detail: 'Compute whole-house heating and cooling load based on square footage, window U-factors, and NC climate zone 4.',
        qualityCheckSOP: 'Confirm condenser and air handler tonnage matches Manual J spec within 10%.',
        inspectionGate: true,
        ncCodeSnippet: 'NC Energy Conservation Code R403.7'
      },
      {
        stepNumber: 2,
        title: 'Set Outdoor Heat Pump Condenser on Composite Pad',
        detail: 'Place 15.2+ SEER2 heat pump unit on level 3" anti-vibration pad. Install fused exterior disconnect switch within sight of unit.',
        qualityCheckSOP: 'Verify min 12" clearance from exterior siding and 24" service access.',
        inspectionGate: false
      },
      {
        stepNumber: 3,
        title: 'Run Lineset & Nitrogen Pressure Decay Test',
        detail: 'Brazed ACR copper lineset with nitrogen purge. Pressure test lineset and coil at 450 PSI for 30 minutes.',
        qualityCheckSOP: 'Zero pressure drop on calibrated digital manifold gauge.',
        inspectionGate: true
      },
      {
        stepNumber: 4,
        title: 'Deep Vacuum Evacuation & Refrigerant Trim',
        detail: 'Pull dual-stage vacuum down below 500 microns. Release R-410A / R-32 charge and trim for lineset length per manufacturer subcooling chart.',
        qualityCheckSOP: 'Micron decay rise test < 1000 microns after 10-minute blank-off.',
        inspectionGate: false
      },
      {
        stepNumber: 5,
        title: 'R-8 Duct Mastic Sealing & County Mechanical Sign-Off',
        detail: 'Seal all trunk and branch duct joints with fiber mesh tape and UL-181 mastic. Install programmable smart thermostat.',
        qualityCheckSOP: 'Pass NC County Mechanical and Energy Code rough/final inspection.',
        inspectionGate: true,
        ncCodeSnippet: 'NC Mechanical Code Chapter 6'
      }
    ];
  }

  if (nameLower.includes('kitchen') || trade === 'Kitchen & Cabinetry') {
    return [
      {
        stepNumber: 1,
        title: 'Demolition & MEP Rough-In Relocation',
        detail: 'Remove outdated cabinets and appliances. Rough-in 50A range receptacle, 20A dedicated countertop small appliance branch circuits, and sink DWV.',
        qualityCheckSOP: 'Verify countertop receptacle spacing <= 48" on center with GFCI protection.',
        inspectionGate: true,
        ncCodeSnippet: 'NC Electrical Code E3901.4 & E3902.1'
      },
      {
        stepNumber: 2,
        title: 'Laser-Level Ledger & Base Cabinet Installation',
        detail: 'Shoot 360-degree laser reference line. Shim and anchor solid plywood base cabinets into wall studs with #10 cabinet screws.',
        qualityCheckSOP: 'Level within 1/16" across 10ft spans; screw penetration min 1.5" into wood framing.',
        inspectionGate: false
      },
      {
        stepNumber: 3,
        title: 'Wall Cabinets & Crown Molding Attachment',
        detail: 'Fasten upper wall cabinets through reinforced hanging rail into double studs. Install matched crown molding and under-cabinet light valence.',
        qualityCheckSOP: 'Check door alignment, soft-close hinge damping, and zero face-frame racking.',
        inspectionGate: false
      },
      {
        stepNumber: 4,
        title: 'Quartz / Granite Countertop Fabrication & Sink Mount',
        detail: 'Digital laser template and install 3cm quartz slabs with silicone seam epoxy. Undermount stainless steel double-basin sink with structural brackets.',
        qualityCheckSOP: 'Inspect polished eased edges and invisible seam blending (< 1/32").',
        inspectionGate: false
      },
      {
        stepNumber: 5,
        title: 'Subway / Mosaic Tile Backsplash & Appliance Trim',
        detail: 'Install ceramic/glass backsplash on cement board substrate. Set garbage disposal, air-gap dishwasher hookup, and slide-in range.',
        qualityCheckSOP: 'Test dishwasher drain loop and verify zero leaks under sink basket strainer at full basin dump.',
        inspectionGate: true,
        ncCodeSnippet: 'NC Plumbing Code Section 412'
      }
    ];
  }

  // Default Structural / Multi-Trade SOP
  return [
    {
      stepNumber: 1,
      title: 'Scope Verification & Site Protection',
      detail: `Review architectural layout and trade specifications for ${taskName}. Lay floor protection and install zip-wall dust containment.`,
      qualityCheckSOP: 'Safety gear and permit postings verified on site.',
      inspectionGate: false
    },
    {
      stepNumber: 2,
      title: 'Material Staging & Substrate Preparation',
      detail: 'Inspect received materials for damage. Prep underlying framing, masonry, or drywall substrate to plumb and square tolerances.',
      qualityCheckSOP: 'Tolerance check <= 1/8" deviation over 8ft plane.',
      inspectionGate: false
    },
    {
      stepNumber: 3,
      title: 'Trade Execution per NC Residential Code',
      detail: `Execute primary ${trade} work according to engineered plans and NC Building Code specifications.`,
      qualityCheckSOP: 'Confirm correct fastening schedules, sealants, and load ratings.',
      inspectionGate: true,
      ncCodeSnippet: 'NC Residential Building Code 2024 Edition'
    },
    {
      stepNumber: 4,
      title: 'Finishing, Cleanup & Quality Punch Gate',
      detail: 'Clean all surfaces, touch up trim and paint, and conduct 10-point trade quality sign-off.',
      qualityCheckSOP: 'Zero blemishes, full functional verification of all hardware and fixtures.',
      inspectionGate: true
    }
  ];
}

/**
 * Generate a complete HouseCADLayout from a property deal
 */
export function generateCADLayoutForDeal(deal: PropertyDeal): HouseCADLayout {
  const sqft = deal.sqft || 1600;
  const beds = deal.bed || 3;
  const baths = deal.bath || 2;
  const isMultiLevel = sqft > 2100 || deal.propertyType?.toLowerCase().includes('2-story') || deal.propertyType?.toLowerCase().includes('colonial');

  // Compute CAD footprint dimensions (feet)
  let footprintWidth = 40;
  let footprintLength = 32;
  if (sqft < 1200) {
    footprintWidth = 34;
    footprintLength = 26;
  } else if (sqft > 2500) {
    footprintWidth = 48;
    footprintLength = 36;
  }

  const rooms: CADRoom[] = [];

  // 1. Foundation / Crawlspace Level (Level 0)
  rooms.push({
    id: `room-crawlspace-${deal.id}`,
    name: 'Foundation & Sealed Crawlspace',
    floorLevel: 0,
    x: 0,
    z: 0,
    width: footprintWidth,
    length: footprintLength,
    height: 4.5,
    wallColor: '#27272a',
    floorTexture: 'concrete',
    zoneType: 'crawlspace',
    features: ['bearing_wall', 'subfloor', 'plumbing_rough'],
    inspectionNotes: 'Masonry foundation walls, heavy-duty piers, and 12-mil vapor barrier encapsulation.'
  });

  // 2. Main Floor Rooms (Level 1)
  // Living Room (Front Left)
  rooms.push({
    id: `room-living-${deal.id}`,
    name: 'Great Living Room & Foyer',
    floorLevel: 1,
    x: -footprintWidth / 4,
    z: -footprintLength / 4,
    width: footprintWidth / 2 - 1,
    length: footprintLength / 2 - 1,
    height: 9,
    wallColor: '#3f3f46',
    floorTexture: 'hardwood',
    zoneType: 'living',
    features: ['window', 'door', 'bearing_wall'],
    inspectionNotes: 'Front entry, wide double hung vinyl windows, open concept layout.'
  });

  // Kitchen & Dining (Front Right)
  rooms.push({
    id: `room-kitchen-${deal.id}`,
    name: 'Gourmet Kitchen & Dining',
    floorLevel: 1,
    x: footprintWidth / 4,
    z: -footprintLength / 4,
    width: footprintWidth / 2 - 1,
    length: footprintLength / 2 - 1,
    height: 9,
    wallColor: '#52525b',
    floorTexture: 'tile',
    zoneType: 'kitchen',
    features: ['window', 'plumbing_rough', 'electrical_panel'],
    inspectionNotes: 'Island bar, 200A sub-feed, under-cabinet lighting, dishwasher rough-in.'
  });

  // Primary Suite Bedroom (Rear Left)
  rooms.push({
    id: `room-primary-bed-${deal.id}`,
    name: 'Primary Suite Bedroom',
    floorLevel: 1,
    x: -footprintWidth / 4,
    z: footprintLength / 4,
    width: footprintWidth / 2 - 1,
    length: footprintLength / 2 - 1,
    height: 9,
    wallColor: '#3f3f46',
    floorTexture: 'hardwood',
    zoneType: 'bedroom',
    features: ['window', 'door', 'bearing_wall'],
    inspectionNotes: 'Walk-in closet, direct access to primary bathroom, egress compliant.'
  });

  // Primary Bathroom & Hall (Rear Right)
  rooms.push({
    id: `room-primary-bath-${deal.id}`,
    name: 'Primary En-Suite Bath & Utility',
    floorLevel: 1,
    x: footprintWidth / 4,
    z: footprintLength / 4,
    width: footprintWidth / 2 - 1,
    length: footprintLength / 2 - 1,
    height: 9,
    wallColor: '#52525b',
    floorTexture: 'tile',
    zoneType: 'bath',
    features: ['window', 'door', 'plumbing_rough', 'hvac_duct'],
    inspectionNotes: 'Dual vanity, custom tiled walk-in shower, water closet, laundry hookup.'
  });

  // 3. Optional Second Level or Guest Wing
  if (isMultiLevel) {
    rooms.push({
      id: `room-upper-bed1-${deal.id}`,
      name: 'Upper Guest Suite 1',
      floorLevel: 2,
      x: -footprintWidth / 4,
      z: 0,
      width: footprintWidth / 2 - 1,
      length: footprintLength / 2 - 1,
      height: 8.5,
      wallColor: '#3f3f46',
      floorTexture: 'hardwood',
      zoneType: 'bedroom',
      features: ['window', 'door'],
      inspectionNotes: 'Upper floor bedroom with southern exposure and NC R310 egress window.'
    });

    rooms.push({
      id: `room-upper-bed2-${deal.id}`,
      name: 'Upper Guest Suite 2 & Bath',
      floorLevel: 2,
      x: footprintWidth / 4,
      z: 0,
      width: footprintWidth / 2 - 1,
      length: footprintLength / 2 - 1,
      height: 8.5,
      wallColor: '#52525b',
      floorTexture: 'tile',
      zoneType: 'bath',
      features: ['window', 'door', 'plumbing_rough'],
      inspectionNotes: 'Full hall bath with fiberglass tub surround and exhaust fan vented to exterior.'
    });
  }

  // 4. Roof & Attic Truss Level (Level 3)
  rooms.push({
    id: `room-roof-attic-${deal.id}`,
    name: 'Engineered Roof Framing & Attic',
    floorLevel: isMultiLevel ? 3 : 2,
    x: 0,
    z: 0,
    width: footprintWidth + 2,
    length: footprintLength + 2,
    height: 7,
    wallColor: '#18181b',
    floorTexture: 'subfloor',
    zoneType: 'roof',
    features: ['roof_truss', 'hvac_duct'],
    inspectionNotes: '6/12 Pitch architectural shingle roof with continuous ridge vent and R-38 blown attic insulation.'
  });

  // Map deal's rehab items into 3D Fix Protocol Nodes
  const fixProtocols: FixProtocolNode[] = [];
  const rehabItems = deal.rehabItems || [];

  if (rehabItems.length === 0) {
    // Generate default core NC flip rehab protocol nodes
    const defaultFixes = [
      {
        title: '200A Main Service Panel & AFCI/GFCI Upgrade',
        trade: 'MEP - Electrical' as CADTradeType,
        room: rooms.find(r => r.zoneType === 'kitchen') || rooms[1],
        cost: 4800,
        severity: 'critical' as const,
        pos: { x: 12, y: 3, z: -8 }
      },
      {
        title: 'Architectural Shingle Roof & Flashing Replacement',
        trade: 'Roofing & Attic' as CADTradeType,
        room: rooms.find(r => r.zoneType === 'roof') || rooms[rooms.length - 1],
        cost: 9500,
        severity: 'critical' as const,
        pos: { x: 0, y: isMultiLevel ? 18 : 11, z: 0 }
      },
      {
        title: '12-Mil Crawlspace Vapor Encapsulation & Sump Basin',
        trade: 'Foundation & Crawlspace' as CADTradeType,
        room: rooms[0],
        cost: 6200,
        severity: 'moderate' as const,
        pos: { x: -4, y: -2, z: 4 }
      },
      {
        title: '15.2 SEER2 Heat Pump & Duct Air-Sealing',
        trade: 'MEP - HVAC' as CADTradeType,
        room: rooms.find(r => r.zoneType === 'living') || rooms[0],
        cost: 8900,
        severity: 'critical' as const,
        pos: { x: -14, y: 2, z: 12 }
      },
      {
        title: 'Custom Shaker Kitchen & Quartz Island Remodel',
        trade: 'Kitchen & Cabinetry' as CADTradeType,
        room: rooms.find(r => r.zoneType === 'kitchen') || rooms[1],
        cost: 14500,
        severity: 'moderate' as const,
        pos: { x: 10, y: 4, z: -6 }
      },
      {
        title: 'Primary En-Suite Bath Tile & Double Vanity',
        trade: 'Bath & Tile' as CADTradeType,
        room: rooms.find(r => r.zoneType === 'bath') || rooms[3],
        cost: 7800,
        severity: 'moderate' as const,
        pos: { x: 8, y: 4, z: 8 }
      }
    ];

    defaultFixes.forEach((df, idx) => {
      const codeInfo = NC_CODE_CATALOG[df.trade.split(' - ')[1] || df.trade] || NC_CODE_CATALOG['Electrical Service'];
      const steps = generateFixProtocolSteps(df.title, df.trade);

      fixProtocols.push({
        id: `fix-${deal.id}-${idx + 1}`,
        dealId: deal.id,
        title: df.title,
        trade: df.trade,
        severity: df.severity,
        status: idx === 0 ? 'in_progress' : 'scoped',
        position: df.pos,
        targetRoomId: df.room.id,
        ncCodeReference: codeInfo.code,
        estimatedCost: df.cost,
        laborHours: Math.round(df.cost / 65),
        materialCost: Math.round(df.cost * 0.45),
        laborCost: Math.round(df.cost * 0.55),
        requiredTools: ['Laser Level', 'Impact Driver Kit', 'Multimeter', 'PPE Gear', 'Reciprocating Saw'],
        requiredMaterials: ['UL Listed Hardware', 'Structural Screws', 'NC Code Approved Substrates'],
        safetyPPE: codeInfo.ppe || ['Safety Glasses', 'Steel Toe Boots', 'Gloves'],
        executionSteps: steps
      });
    });
  } else {
    // Convert existing rehab line items into spatial fix protocols
    rehabItems.forEach((item, idx) => {
      let matchedTrade: CADTradeType = 'Flooring & Finishes';
      let matchedRoom = rooms[1];
      const catLower = (item.category || '').toLowerCase();
      const nameLower = (item.name || '').toLowerCase();

      if (catLower.includes('electric') || nameLower.includes('electric') || nameLower.includes('panel') || nameLower.includes('wire')) {
        matchedTrade = 'MEP - Electrical';
        matchedRoom = rooms.find(r => r.zoneType === 'kitchen') || rooms[1];
      } else if (catLower.includes('roof') || nameLower.includes('roof') || nameLower.includes('shingle')) {
        matchedTrade = 'Roofing & Attic';
        matchedRoom = rooms.find(r => r.zoneType === 'roof') || rooms[rooms.length - 1];
      } else if (catLower.includes('crawl') || catLower.includes('found') || nameLower.includes('crawl') || nameLower.includes('pier')) {
        matchedTrade = 'Foundation & Crawlspace';
        matchedRoom = rooms[0];
      } else if (catLower.includes('hvac') || nameLower.includes('hvac') || nameLower.includes('heat pump') || nameLower.includes('duct')) {
        matchedTrade = 'MEP - HVAC';
        matchedRoom = rooms.find(r => r.zoneType === 'living') || rooms[1];
      } else if (catLower.includes('kitchen') || nameLower.includes('kitchen') || nameLower.includes('cabinet') || nameLower.includes('counter')) {
        matchedTrade = 'Kitchen & Cabinetry';
        matchedRoom = rooms.find(r => r.zoneType === 'kitchen') || rooms[1];
      } else if (catLower.includes('bath') || nameLower.includes('bath') || nameLower.includes('plumb') || nameLower.includes('shower')) {
        matchedTrade = 'Bath & Tile';
        matchedRoom = rooms.find(r => r.zoneType === 'bath') || rooms[3] || rooms[1];
      } else if (catLower.includes('drywall') || nameLower.includes('paint') || nameLower.includes('sheetrock')) {
        matchedTrade = 'Drywall & Insulation';
        matchedRoom = rooms.find(r => r.zoneType === 'living') || rooms[1];
      } else if (catLower.includes('struct') || nameLower.includes('fram') || nameLower.includes('joist')) {
        matchedTrade = 'Structural Framing';
        matchedRoom = rooms[0];
      }

      // Calculate spatial position offset inside the matched room
      const offsetX = (idx % 3 - 1) * 4;
      const offsetZ = (Math.floor(idx / 3) % 3 - 1) * 4;
      let posY = matchedRoom.floorLevel * 10 + 3;
      if (matchedRoom.floorLevel === 0) posY = -1.5;

      const codeInfo = NC_CODE_CATALOG[matchedTrade.split(' - ')[1] || matchedTrade] || NC_CODE_CATALOG['Electrical Service'];
      const steps = generateFixProtocolSteps(item.name || 'General Rehab Repair', matchedTrade);

      fixProtocols.push({
        id: item.id || `fix-${deal.id}-${idx + 1}`,
        dealId: deal.id,
        rehabItemId: item.id,
        title: item.name || 'Property Repair Fix',
        trade: matchedTrade,
        severity: item.cost > 5000 ? 'critical' : item.cost > 2000 ? 'moderate' : 'cosmetic',
        status: item.status === 'completed' ? 'completed' : item.status === 'in_progress' ? 'in_progress' : 'scoped',
        position: {
          x: matchedRoom.x + offsetX,
          y: posY,
          z: matchedRoom.z + offsetZ
        },
        targetRoomId: matchedRoom.id,
        ncCodeReference: codeInfo.code,
        estimatedCost: item.cost || 2500,
        laborHours: Math.round((item.laborCost || item.cost * 0.55) / 65),
        materialCost: item.materialCost || Math.round((item.cost || 2500) * 0.45),
        laborCost: item.laborCost || Math.round((item.cost || 2500) * 0.55),
        requiredTools: ['Laser Distance Meter', 'Torque Driver', 'PPE Package', 'Trade Hand Tools'],
        requiredMaterials: ['Code Compliant Materials', 'NC Approved Fasteners & Connectors'],
        safetyPPE: codeInfo.ppe || ['Safety Glasses', 'Steel Toe Boots', 'Gloves'],
        executionSteps: steps,
        assignedContractor: item.assignedContractor,
        assignedContractorId: item.assignedContractorId,
        notes: item.notes
      });
    });
  }

  return {
    id: `cad-${deal.id}`,
    dealId: deal.id,
    styleName: deal.propertyType || `${deal.city} Residential Rehab Model`,
    totalSqft: sqft,
    lotWidth: 65,
    lotDepth: 140,
    foundationType: 'crawlspace',
    roofPitch: '6/12 Architectural Shingle',
    rooms,
    fixProtocols,
    lastModified: new Date().toISOString()
  };
}
