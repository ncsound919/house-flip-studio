import { describe, it, expect } from 'vitest';
import {
  COMMON_NC_REPAIR_PRESETS,
  generateLocalRepairPlan,
  matchContractorsForTask,
  generateContractorRFP
} from './repairGuideEngine';
import { PropertyDeal } from '../types';
import { NC_CONTRACTOR_DIRECTORY } from './contractorCatalog';

const mockDeal: PropertyDeal = {
  id: 'deal-rep-202',
  address: '3812 Sharon Rd',
  city: 'Charlotte',
  state: 'NC',
  zip: '28211',
  county: 'Mecklenburg County',
  propertyType: 'Single Family',
  sqft: 2200,
  bed: 4,
  bath: 3,
  yearBuilt: 1974,
  lotSize: 0.45,
  description: 'Mid-century single family ranch in South Charlotte',
  askingPrice: 285000,
  status: 'Underwriting',
  underwriting: {
    purchasePrice: 275000,
    arv: 495000,
    arvConfidence: 'High',
    rehabCost: 68000,
    holdingCosts: 8000,
    sellingCosts: 9500,
    acquisitionCosts: 3500,
    financingCosts: 4500,
    maxOffer70Rule: 278500,
    projectedProfit: 134500,
    roi: 38.2,
    cashOnCash: 38.2,
    holdingPeriodMonths: 6,
    contingencyRate: 10
  },
  comps: [],
  rehabItems: [],
  complianceChecks: [],
  milestones: [],
  contractors: [],
  logs: []
};

describe('NC Repair Guide & RFP Engine', () => {
  describe('COMMON_NC_REPAIR_PRESETS', () => {
    it('contains standard North Carolina rehab templates with valid pricing and scopes', () => {
      expect(COMMON_NC_REPAIR_PRESETS.length).toBeGreaterThanOrEqual(10);
      COMMON_NC_REPAIR_PRESETS.forEach((preset) => {
        expect(preset.title).toBeTruthy();
        expect(preset.trade).toBeTruthy();
        expect(preset.defaultCost).toBeGreaterThan(0);
        expect(preset.laborHours).toBeGreaterThan(0);
        expect(['low', 'moderate', 'high', 'critical']).toContain(preset.severity);
      });
    });
  });

  describe('generateLocalRepairPlan', () => {
    it('generates a licensed electrical plan with code citation and permit requirements', () => {
      const plan = generateLocalRepairPlan(mockDeal, '200A Service Panel Retrofit', 'MEP - Electrical', 'Utility Room', 'critical');
      expect(plan.id).toContain('plan-deal-rep-202');
      expect(plan.permitRequired).toBe(true);
      expect(plan.permitType).toContain('Electrical');
      expect(plan.diyFeasibility).toBe('Licensed Trade Required');
      expect(plan.ncCodeCitation).toContain('NC Electrical Code');
      expect(plan.executionPhases.length).toBe(4);
      expect(plan.requiredTools.length).toBeGreaterThan(0);
      expect(plan.requiredMaterials.length).toBeGreaterThan(0);
      expect(plan.safetyPPE.length).toBeGreaterThan(0);
      expect(plan.matchedContractorIds.length).toBeGreaterThan(0);
    });

    it('generates plumbing repair plan with Chapter 6 code compliance', () => {
      const plan = generateLocalRepairPlan(mockDeal, 'PEX-A Repipe', 'MEP - Plumbing', 'Whole House', 'high');
      expect(plan.permitRequired).toBe(true);
      expect(plan.ncCodeCitation).toContain('Plumbing Code');
      expect(plan.estimatedLaborHours).toBe(26);
    });

    it('generates HVAC mechanical plan with energy conservation standards', () => {
      const plan = generateLocalRepairPlan(mockDeal, 'Heat Pump Install', 'MEP - HVAC', 'Attic', 'high');
      expect(plan.permitRequired).toBe(true);
      expect(plan.ncCodeCitation).toContain('Mechanical Code');
      expect(plan.totalEstimatedCost).toBe(plan.estimatedMaterialCost + plan.estimatedLaborCost);
    });

    it('generates roofing plan requiring NC General Contractor license', () => {
      const plan = generateLocalRepairPlan(mockDeal, 'Architectural Roof Replacement', 'Roofing & Attic', 'Roof', 'critical');
      expect(plan.permitRequired).toBe(true);
      expect(plan.diyFeasibility).toBe('NC GC Required');
      expect(plan.ncCodeCitation).toContain('Section R905');
    });

    it('generates foundation crawlspace plan with Section R408 moisture standards', () => {
      const plan = generateLocalRepairPlan(mockDeal, 'Crawlspace Encapsulation', 'Foundation & Crawlspace', 'Crawlspace', 'critical');
      expect(plan.permitRequired).toBe(true);
      expect(plan.ncCodeCitation).toContain('Section R408');
    });

    it('generates structural framing plan with Section R502 wood framing standards', () => {
      const plan = generateLocalRepairPlan(mockDeal, 'Load-Bearing Header Removal', 'Structural Framing', 'Living Room', 'critical');
      expect(plan.permitRequired).toBe(true);
      expect(plan.diyFeasibility).toBe('NC GC Required');
      expect(plan.ncCodeCitation).toContain('Section R502');
    });

    it('generates cosmetic bath/tile plan without mandatory trade permit', () => {
      const plan = generateLocalRepairPlan(mockDeal, 'Shower Tile Waterproofing', 'Bath & Tile', 'Master Bath', 'moderate');
      expect(plan.permitRequired).toBe(false);
      expect(plan.diyFeasibility).toBe('Handyman Feasible');
    });

    it('generates general trade plan when no specific trade matches', () => {
      const plan = generateLocalRepairPlan(mockDeal, 'Custom Painting', 'Cosmetic Painting', 'All Rooms', 'low');
      expect(plan.permitRequired).toBe(false);
      expect(plan.diyFeasibility).toBe('Handyman Feasible');
    });
  });

  describe('matchContractorsForTask', () => {
    it('ranks relevant contractors highest based on trade match and location', () => {
      const matches = matchContractorsForTask('MEP - Electrical', 'Charlotte', 3);
      expect(matches.length).toBeLessThanOrEqual(3);
      expect(matches.length).toBeGreaterThan(0);
      expect(matches[0].licenseVerified).toBe(true);
    });

    it('falls back to General Contractors or nearby regional contractors when needed', () => {
      const matches = matchContractorsForTask('Custom Specialty Trade', 'Raleigh', 5);
      expect(matches.length).toBeGreaterThan(0);
      expect(matches.some((c) => c.trade === 'General Contracting' || c.city === 'Raleigh')).toBe(true);
    });
  });

  describe('generateContractorRFP', () => {
    it('creates a formal North Carolina contractor RFP scope document', () => {
      const plan = generateLocalRepairPlan(mockDeal, '200A Service Panel Retrofit', 'MEP - Electrical');
      const contractor = NC_CONTRACTOR_DIRECTORY[0];
      const rfp = generateContractorRFP(mockDeal, plan, contractor);

      expect(rfp.rfpId).toContain('RFP-NC-');
      expect(rfp.property.address).toBe(mockDeal.address);
      expect(rfp.contractor.name).toBe(contractor.name);
      expect(rfp.scopeOfWork.title).toBe(plan.title);
      expect(rfp.scopeOfWork.ncCodeCompliance).toBe(plan.ncCodeCitation);
      expect(rfp.scopeOfWork.targetBudgetEstimate).toBe(plan.totalEstimatedCost);
      expect(rfp.termsAndConditions.some((t) => t.includes('NORTH CAROLINA LIEN WAIVER'))).toBe(true);
    });
  });
});
