/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PropertyDeal } from "../types";

export interface InvestorProfile {
  experienceLevel: "Beginner" | "Intermediate" | "Professional";
  cashAvailable: number;
  creditScore: number;
  priorFlips: number;
  ownsHome: boolean;
  hasBrokerLicense: boolean;
}

export type FitCategory = "recommended" | "viable" | "not_eligible";
export type RiskLevel = "low" | "moderate" | "high";

export interface CostBreakdown {
  loanAmount: number;
  interestRate: number;
  points: number;
  monthlyPayment: number;
  cashToClose: number;
}

// Pathway-specific structural models for our zero-cash pipeline
export interface BuyerMatch {
  name: string;
  zip: string;
  speed: "Immediate (3 Days)" | "Fast (7 Days)" | "Standard (14 Days)";
  buyBox: string;
  score: number;
}

export interface JVSplit {
  ratio: string;
  partnerProfit: number;
  userProfit: number;
  partnerRoi: number;
}

export interface CapitalStackComponent {
  source: string;
  amount: number;
  rate: string;
  secured: string;
}

export interface StressTestResult {
  scenario: string;
  projectedProfit: number;
  netLoss: boolean;
  notes: string;
}

export interface FinancingResult {
  strategy: string;
  fitScore: number;
  fitCategory: FitCategory;
  cashToClose: number;
  interestRate: number;
  riskLevel: RiskLevel;
  loanAmount: number;
  oneLineReason: string;
  pros: string[];
  cons: string[];
  details: { label: string; value: string | number }[];
  
  // Pipeline details for Layer 5 / Deal Command Center UI
  assignmentDetails?: {
    viabilityScore: number;
    feeRange: string;
    buyerMatchScore: number;
    buyerMatches: BuyerMatch[];
  };
  jvDetails?: {
    partnerRoi: number;
    userRoi: number;
    partnerRiskIndex: number;
    capitalExposureMap: string;
    splits: JVSplit[];
  };
  zeroCashDetails?: {
    feasibilityScore: number;
    lenderFitScore: number;
    capitalStack: CapitalStackComponent[];
    interestReserve6Mo: number;
    pointsCost: number;
  };
  stressTest?: {
    isHighRisk: boolean;
    warningMessage: string;
    scenarios: StressTestResult[];
  };
}

export abstract class FinancingStrategy {
  abstract name: string;
  abstract oneLineReason: string;

  abstract checkEligibility(
    deal: PropertyDeal,
    user: InvestorProfile
  ): { eligible: boolean; reasons: string[]; blockages: string[] };

  abstract calculateCosts(
    deal: PropertyDeal,
    user: InvestorProfile
  ): CostBreakdown;

  abstract assessRisk(
    deal: PropertyDeal,
    user: InvestorProfile
  ): { riskLevel: RiskLevel; riskFlags: string[] };

  abstract calculateFitScore(
    deal: PropertyDeal,
    user: InvestorProfile,
    costs: CostBreakdown,
    eligible: boolean
  ): number;

  abstract getProsCons(user: InvestorProfile): { pros: string[]; cons: string[] };
  
  // Extra detailed metrics hook
  abstract generateCustomMetrics(
    deal: PropertyDeal,
    user: InvestorProfile,
    costs: CostBreakdown
  ): {
    assignmentDetails?: FinancingResult["assignmentDetails"];
    jvDetails?: FinancingResult["jvDetails"];
    zeroCashDetails?: FinancingResult["zeroCashDetails"];
  };

  evaluate(deal: PropertyDeal, user: InvestorProfile): FinancingResult {
    const { eligible, reasons, blockages } = this.checkEligibility(deal, user);
    const costs = this.calculateCosts(deal, user);
    const { riskLevel, riskFlags } = this.assessRisk(deal, user);
    const fitScore = this.calculateFitScore(deal, user, costs, eligible);
    const { pros, cons } = this.getProsCons(user);
    const customMetrics = this.generateCustomMetrics(deal, user, costs);

    let fitCategory: FitCategory = "not_eligible";
    if (eligible) {
      if (fitScore >= 70) {
        fitCategory = "recommended";
      } else {
        fitCategory = "viable";
      }
    }

    const detailsList = [
      { label: "Loan/Capital Amount", value: `$${Math.round(costs.loanAmount).toLocaleString()}` },
      { label: "Capital Rate", value: costs.interestRate > 0 ? `${(costs.interestRate * 100).toFixed(1)}%` : "N/A" },
      { label: "Upfront Points/Fees", value: costs.points > 0 ? `$${Math.round(costs.points).toLocaleString()}` : "None" },
      { label: "Monthly Hold Cost", value: costs.monthlyPayment > 0 ? `$${Math.round(costs.monthlyPayment).toLocaleString()}` : "N/A" },
      { label: "Liquid Cash Needed", value: `$${Math.round(costs.cashToClose).toLocaleString()}` }
    ];

    if (!eligible) {
      detailsList.push({ label: "Blockage Reason", value: blockages[0] || "Ineligible" });
    } else {
      detailsList.push({ label: "Core Path Standard", value: reasons[0] || "Viable" });
    }

    // LAYER 4 & RISK MITIGATION:
    // Run Sensitivity Stress Test (10% drop in market ARV & 3-month construction delays)
    const baseProfit = deal.underwriting.projectedProfit || (deal.underwriting.arv - deal.underwriting.purchasePrice - deal.underwriting.rehabCost - 20000);
    
    // Scenario 1: 3-Month Construction Delay (Incurs extra holding and finance costs)
    const delayCosts = (costs.monthlyPayment || 1200) * 3 + (deal.underwriting.holdingCosts / (deal.underwriting.holdingPeriodMonths || 6)) * 3;
    const profitDelay = baseProfit - delayCosts;

    // Scenario 2: 10% Market Downward Shift
    const arvDrop = deal.underwriting.arv * 0.10;
    const profitDrop = baseProfit - arvDrop;

    // Scenario 3: Double Trouble (Both Delay & ARV Drop)
    const profitDouble = baseProfit - delayCosts - arvDrop;

    const isHighRisk = profitDelay < 0 || profitDrop < 0 || profitDouble < 0 || riskLevel === "high";
    const warningMessage = isHighRisk 
      ? "⚠️ HIGH RISK FLAG: Under sensitivity stress tests (10% ARV drop or 3-month construction delay), this deal's profit margins could collapse or turn negative. Mitigate with safety reserves."
      : "✅ STRESS TEST PASSED: Profit margins are robust enough to withstand a 10% market crash or 3-month construction extension.";

    const stressTest = {
      isHighRisk,
      warningMessage,
      scenarios: [
        {
          scenario: "Baseline (Standard Project Timeline)",
          projectedProfit: baseProfit,
          netLoss: baseProfit <= 0,
          notes: "Timeline is maintained; no unexpected structural anomalies."
        },
        {
          scenario: "3-Month Construction Extension",
          projectedProfit: profitDelay,
          netLoss: profitDelay <= 0,
          notes: `Includes +3 months of interest reserves ($${Math.round(costs.monthlyPayment * 3).toLocaleString()}) + holding utility costs.`
        },
        {
          scenario: "10% Market Correction (ARV Drop)",
          projectedProfit: profitDrop,
          netLoss: profitDrop <= 0,
          notes: `Simulates property selling at $${Math.round(deal.underwriting.arv * 0.90).toLocaleString()} instead of ARV.`
        },
        {
          scenario: "Worst Case (3mo Delay + 10% ARV Drop)",
          projectedProfit: profitDouble,
          netLoss: profitDouble <= 0,
          notes: "Squeezes profit from both holding overhead and sales depreciation."
        }
      ]
    };

    return {
      strategy: this.name,
      fitScore: eligible ? fitScore : 0,
      fitCategory,
      cashToClose: costs.cashToClose,
      interestRate: costs.interestRate,
      riskLevel,
      loanAmount: costs.loanAmount,
      oneLineReason: eligible ? this.oneLineReason : blockages[0] || "Ineligible for this pathway.",
      pros,
      cons,
      details: detailsList,
      stressTest,
      ...customMetrics
    };
  }
}

// PATHWAY A: Contract Assignment (Wholesaling)
export class ContractAssignmentStrategy extends FinancingStrategy {
  name = "Contract Assignment (Wholesaling)";
  oneLineReason = "Assign real estate purchase rights to an institutional cash buyer for an immediate assignment fee. Zero capital needed.";

  checkEligibility(deal: PropertyDeal, user: InvestorProfile) {
    const blockages: string[] = [];
    const reasons: string[] = [];

    // Underwriting spread check (must be large enough spread)
    const rawSpread = deal.underwriting.arv - deal.underwriting.purchasePrice - deal.underwriting.rehabCost;
    if (rawSpread < 20000) {
      blockages.push("Wholesale Spread too tight: Purchase price is too close to ARV to fit assignment fee.");
    }

    // NC HB 797 broker license check
    if (!user.hasBrokerLicense) {
      blockages.push("NC Rule Restriction (HB 797): You cannot assign contracts (wholesale) in North Carolina without an active broker license.");
    } else {
      reasons.push("Broker License Verified (HB 797 Compliance Active).");
    }

    // Non-REO check (REO/HUD banks don't allow assignment)
    const isBankOwned = deal.description?.toLowerCase().includes("reo") || deal.description?.toLowerCase().includes("hud");
    if (isBankOwned) {
      blockages.push("Lender Restriction: Bank-owned (REO) or HUD property contracts are strictly non-assignable.");
    }

    if (blockages.length === 0) {
      reasons.push("Clean residential contract terms allow assignable clauses.");
      reasons.push("Distressed spread supports target assignment margins.");
    }

    return { eligible: blockages.length === 0, reasons, blockages };
  }

  calculateCosts(deal: PropertyDeal, user: InvestorProfile): CostBreakdown {
    // Wholesalers only put down Earnest Money Deposit (EMD), which is refundable/assigned to final buyer
    return {
      loanAmount: 0,
      interestRate: 0,
      points: 0,
      monthlyPayment: 0,
      cashToClose: 1000 // EMD deposit
    };
  }

  assessRisk(deal: PropertyDeal, user: InvestorProfile) {
    const riskFlags = ["Sovereign buyer default", "Strict 30-day assignment contract timelines"];
    return { riskLevel: "moderate" as const, riskFlags };
  }

  calculateFitScore(deal: PropertyDeal, user: InvestorProfile, costs: CostBreakdown, eligible: boolean) {
    if (!eligible) return 0;
    let score = 65;
    // Excellent for beginners who have an NC broker license but low capital
    if (user.cashAvailable < 15000) score += 20;
    if (user.hasBrokerLicense) score += 15;
    return Math.min(score, 100);
  }

  getProsCons(user: InvestorProfile) {
    return {
      pros: [
        "Virtually zero capital at risk ($1k earnest money only)",
        "No construction risk, subcontractor disputes, or materials delay",
        "Fast transaction cycle - cash out in 7 to 14 days"
      ],
      cons: [
        "Highly regulated under NC HB 797 (requires active broker license)",
        "Requires building a highly responsive, qualified local Cash Buyer list",
        "Earnest money can be forfeited if contract is not assigned in time"
      ]
    };
  }

  generateCustomMetrics(deal: PropertyDeal, user: InvestorProfile, costs: CostBreakdown) {
    const rawSpread = deal.underwriting.arv - deal.underwriting.purchasePrice - deal.underwriting.rehabCost;
    
    // Assignment Viability Score logic
    let viabilityScore = 50;
    if (rawSpread >= 35000) viabilityScore += 20;
    if (deal.underwriting.rehabCost < 40000) viabilityScore += 15; // Low rehab variance
    if (user.hasBrokerLicense) viabilityScore += 15;

    // Assignment fee range
    const minFee = Math.max(5000, Math.round(rawSpread * 0.15));
    const maxFee = Math.round(rawSpread * 0.25);

    // Mock Cash Buyer Graph for Zip Code
    const buyerMatches: BuyerMatch[] = [
      {
        name: "Carolinas Capital Holdings LLC",
        zip: deal.zip || "28203",
        speed: "Immediate (3 Days)",
        buyBox: "Single-Family cosmetic under 75% of ARV",
        score: 98
      },
      {
        name: "Queen City Rehab Fund VII",
        zip: deal.zip || "28203",
        speed: "Fast (7 Days)",
        buyBox: "Structural or severe distressed, up to $300k",
        score: 93
      },
      {
        name: "Triad Invest Group",
        zip: deal.zip || "28203",
        speed: "Standard (14 Days)",
        buyBox: "Any zip, cosmetic single-family builds",
        score: 87
      }
    ];

    return {
      assignmentDetails: {
        viabilityScore: Math.min(viabilityScore, 100),
        feeRange: `$${minFee.toLocaleString()} - $${maxFee.toLocaleString()}`,
        buyerMatchScore: Math.min(viabilityScore - 5, 100),
        buyerMatches
      }
    };
  }
}

// PATHWAY B: JV Equity Flips
export class JVEquityFlipsStrategy extends FinancingStrategy {
  name = "JV Equity Partnership";
  oneLineReason = "You secure the deal and manage construction; a private money equity partner funds 100% of purchase + rehab.";

  checkEligibility(deal: PropertyDeal, user: InvestorProfile) {
    const blockages: string[] = [];
    const reasons: string[] = [];

    const rawSpread = deal.underwriting.arv - deal.underwriting.purchasePrice - deal.underwriting.rehabCost;
    if (rawSpread < 35000) {
      blockages.push("Spread too thin for JV: Partner requires a larger margin to justify committing 100% cash.");
    }

    if (blockages.length === 0) {
      reasons.push("Substantial value-add margin accommodates equity return splits.");
      reasons.push("Predictable single-family layout makes passive partner underwriting smooth.");
    }

    return { eligible: blockages.length === 0, reasons, blockages };
  }

  calculateCosts(deal: PropertyDeal, user: InvestorProfile): CostBreakdown {
    // JV Partner contributes 100% of purchase + rehab cash. User puts down $0.
    return {
      loanAmount: deal.askingPrice + deal.underwriting.rehabCost,
      interestRate: 0, // No debt service; structured as profit-share
      points: 0,
      monthlyPayment: 0, // No monthly interest costs
      cashToClose: 0
    };
  }

  assessRisk(deal: PropertyDeal, user: InvestorProfile) {
    const riskFlags = ["Partner disputes over contractor delays", "Shared executive veto on final listing prices"];
    return { riskLevel: "moderate" as const, riskFlags };
  }

  calculateFitScore(deal: PropertyDeal, user: InvestorProfile, costs: CostBreakdown, eligible: boolean) {
    if (!eligible) return 0;
    let score = 75;
    // Perfect if the user has moderate experience but lacks the personal capital to cover down payments
    if (user.cashAvailable < 30000) score += 15;
    if (user.experienceLevel === "Intermediate" || user.experienceLevel === "Professional") score += 10;
    return Math.min(score, 100);
  }

  getProsCons(user: InvestorProfile) {
    return {
      pros: [
        "100% funding provided by partner (Zero capital out of your savings)",
        "Zero personal liability on debt or hard money defaults",
        "Boosts credibility when bidding by offering 'All-Cash Proof of Funds'"
      ],
      cons: [
        "Must share net profits (typically 50/50 or 60/40 to the capital provider)",
        "All major contractor bids and selling schedules require partner approval",
        "Requires drafting rigorous operating agreements and partnership entities"
      ]
    };
  }

  generateCustomMetrics(deal: PropertyDeal, user: InvestorProfile, costs: CostBreakdown) {
    const totalCapital = deal.askingPrice + deal.underwriting.rehabCost;
    const projectedProfit = deal.underwriting.projectedProfit || 40000;
    
    // Partner Risk Index (based on LTV of purchase, rehab budget)
    let partnerRiskIndex = 40; // baseline moderate
    if (deal.underwriting.rehabCost > 80000) partnerRiskIndex += 20; // high rehab is riskier
    if (deal.underwriting.roi < 15) partnerRiskIndex += 15; // low yield is riskier
    if (user.experienceLevel === "Beginner") partnerRiskIndex += 15; // inexperienced operator is riskier

    // Profit Split Scenarios
    const splits: JVSplit[] = [
      {
        ratio: "50/50 Classic split",
        partnerProfit: projectedProfit * 0.50,
        userProfit: projectedProfit * 0.50,
        partnerRoi: ((projectedProfit * 0.50) / totalCapital) * 100
      },
      {
        ratio: "70/30 (70% to Capital Provider)",
        partnerProfit: projectedProfit * 0.70,
        userProfit: projectedProfit * 0.30,
        partnerRoi: ((projectedProfit * 0.70) / totalCapital) * 100
      },
      {
        ratio: "Preferred Return (8% Pref + 60/40 split)",
        partnerProfit: (totalCapital * 0.08) + ((projectedProfit - totalCapital * 0.08) * 0.60),
        userProfit: (projectedProfit - totalCapital * 0.08) * 0.40,
        partnerRoi: (((totalCapital * 0.08) + ((projectedProfit - totalCapital * 0.08) * 0.60)) / totalCapital) * 100
      }
    ];

    return {
      jvDetails: {
        partnerRoi: splits[0].partnerRoi,
        userRoi: 100.0, // Infinite ROI since user capital contribution is $0
        partnerRiskIndex: Math.min(partnerRiskIndex, 100),
        capitalExposureMap: `Acquisition: $${deal.askingPrice.toLocaleString()} | Rehab: $${deal.underwriting.rehabCost.toLocaleString()}`,
        splits
      }
    };
  }
}

// PATHWAY C: Hard/Private Money + Gap Funding (Zero-Cash Financing)
export class ZeroCashFinancingStrategy extends FinancingStrategy {
  name = "Hard Money + Partner Gap Funding";
  oneLineReason = "Combine an asset-backed hard money loan (covering 90% cost) with a private partner's 'gap' cash to cover points and the down payment.";

  checkEligibility(deal: PropertyDeal, user: InvestorProfile) {
    const blockages: string[] = [];
    const reasons: string[] = [];

    // FICO score check for hard money
    if (user.creditScore < 600) {
      blockages.push("Credit too low: Hard money lenders require a minimum FICO of 600 to underwrite the debt.");
    }

    // ARV threshold: Hard money is asset-based, cap loan at 70% of ARV
    const totalCost = deal.askingPrice + deal.underwriting.rehabCost;
    const maxLoan = deal.underwriting.arv * 0.72;
    if (maxLoan < totalCost * 0.80) {
      blockages.push("LTV threshold fail: Property's current distress is too high relative to ARV to fit hard money loan caps.");
    }

    if (blockages.length === 0) {
      reasons.push("FICO credit score satisfies hard money lender standards.");
      reasons.push("Collateral ARV ratio supports a 90% Loan-To-Cost (LTC) leverage.");
    }

    return { eligible: blockages.length === 0, reasons, blockages };
  }

  calculateCosts(deal: PropertyDeal, user: InvestorProfile): CostBreakdown {
    // Hard money covers 90% of purchase + 100% of rehab, up to 70% ARV cap
    const totalNeeds = deal.askingPrice + deal.underwriting.rehabCost;
    const maxLoanArv = deal.underwriting.arv * 0.70;
    const maxLoanLtc = (deal.askingPrice * 0.90) + deal.underwriting.rehabCost;
    const loanAmount = Math.min(maxLoanArv, maxLoanLtc);

    const interestRate = 0.12; // 12% standard hard money rate
    const points = loanAmount * 0.02; // 2 points
    
    // Capital cost calculations include monthly interest reserves and points
    const monthlyPayment = (loanAmount * interestRate) / 12;
    const totalClosingNeeded = totalNeeds - loanAmount + points;

    // In a zero-cash model, the 'cash to close' is $0 because a private gap partner provides the closing downpayment + points
    return {
      loanAmount,
      interestRate,
      points,
      monthlyPayment,
      cashToClose: 0 // Funded entirely via Gap Partner
    };
  }

  assessRisk(deal: PropertyDeal, user: InvestorProfile) {
    const riskFlags = [
      "Extremely high monthly holding debt service",
      "Short 6-month maturity balloon with default risk",
      "Subcontractor draws must be approved on tight schedules"
    ];
    return { riskLevel: "high" as const, riskFlags };
  }

  calculateFitScore(deal: PropertyDeal, user: InvestorProfile, costs: CostBreakdown, eligible: boolean) {
    if (!eligible) return 0;
    let score = 60;
    if (user.creditScore >= 700) score += 15;
    if (user.priorFlips > 1) score += 15;
    if (user.cashAvailable >= 10000) score += 10; // good buffer reserves
    return Math.min(score, 100);
  }

  getProsCons(user: InvestorProfile) {
    return {
      pros: [
        "Unlocks 100% project financing ($0 cash required from your pocket)",
        "Builds a reliable, scalable commercial track record with professional lenders",
        "Retain majority equity control compared to joint-venture partnerships"
      ],
      cons: [
        "Very expensive capital structure (12% interest + 2% origination points)",
        "Must pay double closing costs (hard money closing + gap partner filing)",
        "Default leads to immediate collateral foreclosure of property"
      ]
    };
  }

  generateCustomMetrics(deal: PropertyDeal, user: InvestorProfile, costs: CostBreakdown) {
    const totalNeeds = deal.askingPrice + deal.underwriting.rehabCost;
    const hardMoneyLoan = costs.loanAmount;
    const closingFundsNeeded = totalNeeds - hardMoneyLoan + costs.points;

    // Lender Fit Score logic
    let lenderFitScore = 70;
    if (user.creditScore >= 740) lenderFitScore += 15;
    if (user.priorFlips >= 3) lenderFitScore += 15;

    // 6-Month Holding Capital Cost Details
    const interestReserve6Mo = costs.monthlyPayment * 6;

    // Capital Stack Constructor Output
    const capitalStack: CapitalStackComponent[] = [
      {
        source: "Hard Money First Lien",
        amount: hardMoneyLoan,
        rate: "12.0% Interest-Only",
        secured: "1st Deed of Trust on Collateral"
      },
      {
        source: "Private Gap Funding Partner",
        amount: closingFundsNeeded,
        rate: "15.0% flat interest or 20% equity slice",
        secured: "2nd Lien Deed of Trust + Promissory Note"
      },
      {
        source: "Operator Reserve (You)",
        amount: 0,
        rate: "N/A",
        secured: "Project Management / Sweat Equity"
      }
    ];

    return {
      zeroCashDetails: {
        feasibilityScore: user.creditScore >= 660 && user.priorFlips >= 1 ? 90 : 70,
        lenderFitScore: Math.min(lenderFitScore, 100),
        capitalStack,
        interestReserve6Mo,
        pointsCost: costs.points
      }
    };
  }
}

// Global engine running these deterministic pathways
export class FinancingEngine {
  private strategies: FinancingStrategy[] = [
    new ContractAssignmentStrategy(),
    new JVEquityFlipsStrategy(),
    new ZeroCashFinancingStrategy()
  ];

  evaluateAll(deal: PropertyDeal, user: InvestorProfile): FinancingResult[] {
    const results = this.strategies.map((s) => s.evaluate(deal, user));

    // Rank results: eligible first, then sorted by fit score descending
    return results.sort((a, b) => {
      const aEligible = a.fitCategory !== "not_eligible" ? 1 : 0;
      const bEligible = b.fitCategory !== "not_eligible" ? 1 : 0;

      if (aEligible !== bEligible) {
        return bEligible - aEligible;
      }
      return b.fitScore - a.fitScore;
    });
  }
}
