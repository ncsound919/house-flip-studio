import { describe, it, expect } from 'vitest';
import {
  NC_CODE_CATALOG,
  generateFixProtocolSteps,
  generateCADLayoutForDeal
} from './cadLayoutGenerator';
import { PropertyDeal, CADTradeType } from '../types';

const createMockDeal = (overrides?: Partial<PropertyDeal>): PropertyDeal => ({
  id: 'deal-test-101',
  address: '1428 Oakwood Ave',
  city: 'Charlotte',
  state: 'NC',
  zip: '28205',
  county: 'Mecklenburg County',
  propertyType: 'Single Family Residence',
  sqft: 1850,
  bed: 3,
  bath: 2,
  yearBuilt: 1968,
  lotSize: 0.3,
  description: 'Single family home ready for renovation in Charlotte NC',
  askingPrice: 185000,
  status: 'Rehab & Estimating',
  underwriting: {
    purchasePrice: 180000,
    arv: 335000,
    arvConfidence: 'High',
    rehabCost: 52000,
    holdingCosts: 6500,
    sellingCosts: 7000,
    acquisitionCosts: 2500,
    financingCosts: 3500,
    maxOffer70Rule: 182500,
    projectedProfit: 89500,
    roi: 36.5,
    cashOnCash: 36.5,
    holdingPeriodMonths: 6,
    contingencyRate: 10
  },
  comps: [],
  rehabItems: [],
  complianceChecks: [],
  milestones: [],
  contractors: [],
  logs: [],
  ...overrides
});

describe('CAD Layout & Protocol Generator', () => {
  describe('NC_CODE_CATALOG', () => {
    it('contains valid North Carolina building code citations', () => {
      expect(NC_CODE_CATALOG['Electrical Service']).toBeDefined();
      expect(NC_CODE_CATALOG['Electrical Service'].code).toContain('NC Residential Code');
      expect(NC_CODE_CATALOG['Crawlspace Encapsulation'].ppe.length).toBeGreaterThan(0);
      expect(NC_CODE_CATALOG['Roof Decking & Shingles'].inspectGate).toBe(true);
    });
  });

  describe('generateFixProtocolSteps', () => {
    it('generates electrical steps with inspection gates and safety SOPs', () => {
      const steps = generateFixProtocolSteps('200A Main Service Panel Upgrade', 'MEP - Electrical');
      expect(steps.length).toBe(5);
      expect(steps[0].title).toContain('Duke Energy');
      expect(steps[0].inspectionGate).toBe(true);
      expect(steps.some((s) => s.ncCodeSnippet?.includes('NEC'))).toBe(true);
    });

    it('generates roofing steps with high-wind fastening standards', () => {
      const steps = generateFixProtocolSteps('Complete Shingle Tear-off & Deck Repair', 'Roofing & Attic');
      expect(steps.length).toBe(5);
      expect(steps[0].title).toContain('Tear-Off');
      expect(steps[1].ncCodeSnippet).toContain('R905');
      expect(steps[3].detail).toContain('6-nail high-wind pattern');
    });

    it('generates crawlspace encapsulation steps', () => {
      const steps = generateFixProtocolSteps('12-Mil Encapsulation & Sump Basin', 'Foundation & Crawlspace');
      expect(steps.length).toBe(5);
      expect(steps[1].title).toContain('Sump Pump');
      expect(steps[3].detail).toContain('12-mil reinforced polyethylene');
    });

    it('generates HVAC heat pump installation steps', () => {
      const steps = generateFixProtocolSteps('15.2 SEER2 Heat Pump Replacement', 'MEP - HVAC');
      expect(steps.length).toBe(5);
      expect(steps[0].title).toContain('Manual J');
      expect(steps[2].detail.toLowerCase()).toContain('nitrogen');
      expect(steps[4].detail).toContain('UL-181 mastic');
    });

    it('generates kitchen cabinetry and rough-in steps', () => {
      const steps = generateFixProtocolSteps('Custom Shaker Kitchen & Island Remodel', 'Kitchen & Cabinetry');
      expect(steps.length).toBe(5);
      expect(steps[0].title).toContain('MEP Rough-In');
      expect(steps[1].title).toContain('Base Cabinet');
      expect(steps[3].title).toContain('Countertop');
    });

    it('generates fallback standard multi-trade SOP for generic tasks', () => {
      const steps = generateFixProtocolSteps('Custom Interior Painting & Trim', 'Flooring & Finishes');
      expect(steps.length).toBe(4);
      expect(steps[0].title).toContain('Scope Verification');
      expect(steps[2].ncCodeSnippet).toContain('NC Residential Building Code');
    });
  });

  describe('generateCADLayoutForDeal', () => {
    it('generates a 1-story standard CAD footprint for single-level deals', () => {
      const deal = createMockDeal({ sqft: 1600, propertyType: 'Ranch' });
      const layout = generateCADLayoutForDeal(deal);

      expect(layout.id).toBe(`cad-${deal.id}`);
      expect(layout.dealId).toBe(deal.id);
      expect(layout.totalSqft).toBe(1600);
      expect(layout.foundationType).toBe('crawlspace');
      expect(layout.rooms.length).toBeGreaterThanOrEqual(5);

      // Verify level 0 crawlspace, level 1 main floor, and roof attic
      const crawlspace = layout.rooms.find((r) => r.floorLevel === 0);
      const living = layout.rooms.find((r) => r.zoneType === 'living');
      const kitchen = layout.rooms.find((r) => r.zoneType === 'kitchen');
      const roof = layout.rooms.find((r) => r.zoneType === 'roof');

      expect(crawlspace).toBeDefined();
      expect(living).toBeDefined();
      expect(kitchen).toBeDefined();
      expect(roof).toBeDefined();
      expect(layout.fixProtocols.length).toBeGreaterThan(0);
    });

    it('generates a 2-story footprint for multi-level homes or >2100 sqft', () => {
      const deal = createMockDeal({ sqft: 2600, propertyType: '2-Story Colonial' });
      const layout = generateCADLayoutForDeal(deal);

      const upperBed1 = layout.rooms.find((r) => r.floorLevel === 2);
      expect(upperBed1).toBeDefined();
      expect(upperBed1?.name).toContain('Upper Guest Suite');
      expect(layout.rooms.find((r) => r.floorLevel === 3)).toBeDefined(); // Attic is on level 3 for multi-story
    });

    it('adapts footprint width and length based on small and large sqft thresholds', () => {
      const smallDeal = createMockDeal({ sqft: 950 });
      const largeDeal = createMockDeal({ sqft: 2800 });

      const smallLayout = generateCADLayoutForDeal(smallDeal);
      const largeLayout = generateCADLayoutForDeal(largeDeal);

      const smallCrawl = smallLayout.rooms.find((r) => r.floorLevel === 0)!;
      const largeCrawl = largeLayout.rooms.find((r) => r.floorLevel === 0)!;

      expect(smallCrawl.width).toBe(34);
      expect(smallCrawl.length).toBe(26);
      expect(largeCrawl.width).toBe(48);
      expect(largeCrawl.length).toBe(36);
    });

    it('converts custom rehab line items into spatial 3D fix protocol nodes', () => {
      const customDeal = createMockDeal({
        rehabItems: [
          {
            id: 'item-elec-1',
            category: 'Electrical',
            name: 'Upgrade Panel to 200A Square D',
            cost: 4200,
            notes: 'Requires utility disconnect',
            status: 'in_progress',
            assignedContractor: 'Carolina Circuit Pros'
          },
          {
            id: 'item-roof-1',
            category: 'Roofing',
            name: 'GAF Timberline Architectural Roof',
            cost: 11000,
            notes: 'Replace rotted decking',
            status: 'completed'
          },
          {
            id: 'item-crawl-1',
            category: 'Crawlspace',
            name: 'Vapor Barrier & French Drain',
            cost: 5500,
            notes: 'Sealed crawlspace',
            status: 'estimated'
          },
          {
            id: 'item-hvac-1',
            category: 'HVAC',
            name: 'Heat Pump Dual Zone 16 SEER',
            cost: 9200,
            notes: 'Replace air handler in attic',
            status: 'estimated'
          },
          {
            id: 'item-kitchen-1',
            category: 'Kitchen',
            name: 'Solid Wood Cabinets & Quartz',
            cost: 16000,
            notes: 'Soft close hinges',
            status: 'estimated'
          },
          {
            id: 'item-bath-1',
            category: 'Bathroom',
            name: 'Tile Walk-in Shower',
            cost: 6000,
            notes: 'Schluter system',
            status: 'estimated'
          },
          {
            id: 'item-drywall-1',
            category: 'Drywall',
            name: 'Level 5 Skim Coat',
            cost: 3000,
            notes: 'Popcorn removal',
            status: 'estimated'
          },
          {
            id: 'item-struct-1',
            category: 'Structural',
            name: 'Floor Joist Sistering',
            cost: 4800,
            notes: 'Eliminate bounce',
            status: 'estimated'
          }
        ]
      });

      const layout = generateCADLayoutForDeal(customDeal);
      expect(layout.fixProtocols.length).toBe(8);

      const elecNode = layout.fixProtocols.find((p) => p.rehabItemId === 'item-elec-1');
      expect(elecNode).toBeDefined();
      expect(elecNode?.trade).toBe('MEP - Electrical');
      expect(elecNode?.status).toBe('in_progress');
      expect(elecNode?.assignedContractor).toBe('Carolina Circuit Pros');

      const roofNode = layout.fixProtocols.find((p) => p.rehabItemId === 'item-roof-1');
      expect(roofNode?.trade).toBe('Roofing & Attic');
      expect(roofNode?.status).toBe('completed');
      expect(roofNode?.severity).toBe('critical');
    });
  });
});
