/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type DealStatus =
  | 'Lead Ingest'
  | 'Property Enrichment'
  | 'ARV & Comps'
  | 'Rehab & Estimating'
  | 'Underwriting'
  | 'Compliance & Offer'
  | 'Renovation'
  | 'Listed'
  | 'Completed';

export type AgentType =
  | 'Supervisor'
  | 'Scout'
  | 'ARV'
  | 'Rehab'
  | 'Compliance'
  | 'Project';

export interface AgentLog {
  id: string;
  timestamp: string;
  agentName: AgentType;
  message: string;
  status: 'info' | 'success' | 'warning' | 'error';
}

export interface Comp {
  address: string;
  city: string;
  price: number;
  distance: number; // in miles
  sqft: number;
  bed: number;
  bath: number;
  yearBuilt: number;
  saleDate: string;
  pricePerSqft: number;
}

export interface ChangeOrder {
  id: string;
  orderNumber: string;
  date: string;
  description: string;
  contractorName: string;
  trade: string;
  costImpact: number;
  status: 'approved' | 'pending' | 'rejected';
  reason: string;
}

export interface RehabLineItem {
  id?: string;
  category: string;
  name: string;
  cost: number;
  notes: string;
  laborCost?: number;
  materialCost?: number;
  quantity?: number;
  unit?: string;
  status?: 'estimated' | 'contracted' | 'in_progress' | 'completed';
  assignedContractor?: string;
  assignedContractorId?: string;
  actualCost?: number;
}

export interface ComplianceCheck {
  id: string;
  label: string;
  status: 'passed' | 'warning' | 'failed' | 'pending';
  notes: string;
  category: 'Entity' | 'Licensing' | 'Finance' | 'Contract' | 'General';
}

export interface Milestone {
  id: string;
  title: string;
  status: 'pending' | 'in_progress' | 'completed';
  dueDate: string;
  cost: number;
  notes: string;
  contractorId?: string;
  inspectionPassed?: boolean;
  lienWaiverSigned?: boolean;
}

export interface Contractor {
  id: string;
  name: string;
  trade: string;
  rating: number;
  contact: string;
  email?: string;
  status: 'active' | 'completed' | 'available';
  licenseNumber?: string;
  licenseBoard?: string;
  licenseVerified?: boolean;
  insurancePolicy?: string;
  insuranceExpiry?: string;
  insuranceLimit?: string;
  workersCompVerified?: boolean;
  w9OnFile?: boolean;
  lienWaiverStatus?: 'current' | 'pending' | 'signed_unconditional' | 'n/a';
  assignedScope?: string;
  contractAmount?: number;
  paidToDate?: number;
  retainageHoldback?: number;
  onTimeRate?: number;
}

export interface UnderwritingDetails {
  arv: number;
  arvConfidence: 'High' | 'Medium' | 'Low';
  rehabCost: number;
  purchasePrice: number;
  maxOffer70Rule: number;
  acquisitionCosts: number;
  holdingCosts: number;
  sellingCosts: number;
  financingCosts: number;
  projectedProfit: number;
  roi: number; // in %
  cashOnCash: number; // in %
  holdingPeriodMonths: number;
  contingencyRate: number; // in %
  baseRehabCost?: number;
  contingencyAmount?: number;
  changeOrdersTotal?: number;
  laborTotal?: number;
  materialTotal?: number;
}

export interface SurveyNotes {
  structuralRating: 'good' | 'fair' | 'poor';
  foundationNotes: string;
  waterDamageFound: boolean;
  waterDamageNotes: string;
  roofNotes: string;
  electricalNotes: string;
  plumbingNotes: string;
  generalSurveyNotes: string;
  surveyDate?: string;
  surveyedBy?: string;
}

export interface BankDraw {
  id: string;
  amount: number;
  submittedDate: string;
  status: 'pending' | 'approved' | 'rejected';
  notes: string;
}

export interface FundingDetails {
  hardMoneySource: string;
  hardMoneyAmount: number;
  interestRate: number;
  points: number;
  partnerEquityAmount: number;
  additionalCapitalNeeded: number;
  ltcRatio: number;
  ltvRatio: number;
  debtServiceReserve: number;
  bankDrawsSubmitted: BankDraw[];
}

export interface ContractorGuideline {
  id: string;
  trade: string;
  guidelineText: string;
  qualityCheckSOP: string;
  safetyRequirement: string;
  isVerifiedByPartner: boolean;
}

export interface CompletionChecklistItem {
  id: string;
  category: 'Interior' | 'Exterior' | 'MEP' | 'Code/Inspections' | 'Marketing';
  taskName: string;
  checkedByPartner: boolean;
  checkedDate?: string;
  verifiedPartnerName?: string;
  notes?: string;
}

export interface WorkSession {
  id: string;
  name: string;
  createdAt: string;
  lastUpdated: string;
  isActive: boolean;
  notes?: string;
  surveyNotes?: SurveyNotes;
  fundingDetails?: FundingDetails;
  contractorGuidelines?: ContractorGuideline[];
  completionChecklist?: CompletionChecklistItem[];
  rehabItems?: RehabLineItem[];
  underwriting?: UnderwritingDetails;
}

export interface PropertyDeal {
  id: string;
  address: string;
  city: string;
  state: 'NC';
  zip: string;
  imageUrl?: string;
  description: string;
  askingPrice: number;
  status: DealStatus;
  bed: number;
  bath: number;
  sqft: number;
  yearBuilt: number;
  lotSize: number; // in acres or sqft
  
  // Real estate verified public records & MLS metadata
  mlsNumber?: string;
  parcelId?: string;
  county?: string;
  neighborhood?: string;
  propertyType?: string;
  taxAssessment?: number;
  listingSource?: string;
  verifiedListing?: boolean;
  gisPortalUrl?: string;

  // Underwriting information
  underwriting: UnderwritingDetails;
  
  // Detailed breakdowns
  comps: Comp[];
  rehabItems: RehabLineItem[];
  complianceChecks: ComplianceCheck[];
  milestones: Milestone[];
  contractors: Contractor[];
  changeOrders?: ChangeOrder[];
  logs: AgentLog[];

  // Human-in-the-Loop Operations Hub data
  surveyNotes?: SurveyNotes;
  fundingDetails?: FundingDetails;
  contractorGuidelines?: ContractorGuideline[];
  completionChecklist?: CompletionChecklistItem[];
  sessions?: WorkSession[];

  // 3D CAD & Repair Fix Protocol System
  cadLayout?: HouseCADLayout;
  
  // AI Step-by-Step Repair Guides & Plans
  repairPlans?: RepairPlan[];
}

export type CADTradeType =
  | 'Structural Framing'
  | 'MEP - Electrical'
  | 'MEP - Plumbing'
  | 'MEP - HVAC'
  | 'Roofing & Attic'
  | 'Foundation & Crawlspace'
  | 'Drywall & Insulation'
  | 'Kitchen & Cabinetry'
  | 'Bath & Tile'
  | 'Doors & Windows'
  | 'Exterior & Siding'
  | 'Flooring & Finishes';

export type CADZoneType =
  | 'living'
  | 'kitchen'
  | 'bath'
  | 'bedroom'
  | 'crawlspace'
  | 'roof'
  | 'exterior'
  | 'utility'
  | 'garage'
  | 'hallway';

export interface CADRoom {
  id: string;
  name: string;
  floorLevel: number; // 0 = crawlspace/foundation, 1 = main floor, 2 = 2nd story, 3 = attic/roof
  x: number; // center coordinate X (feet relative to origin)
  z: number; // center coordinate Z (feet relative to origin)
  width: number; // width along X (feet)
  length: number; // length along Z (feet)
  height: number; // wall height (feet, e.g., 9)
  wallColor?: string;
  floorTexture?: 'hardwood' | 'tile' | 'concrete' | 'subfloor' | 'carpet';
  zoneType: CADZoneType;
  features: Array<'window' | 'door' | 'bearing_wall' | 'subfloor' | 'plumbing_rough' | 'electrical_panel' | 'hvac_duct' | 'roof_truss' | 'fire_rated'>;
  inspectionNotes?: string;
}

export interface FixProtocolStep {
  stepNumber: number;
  title: string;
  detail: string;
  qualityCheckSOP: string;
  inspectionGate: boolean;
  ncCodeSnippet?: string;
  completed?: boolean;
}

export interface FixProtocolNode {
  id: string;
  dealId: string;
  rehabItemId?: string;
  title: string;
  trade: CADTradeType;
  severity: 'critical' | 'moderate' | 'cosmetic';
  status: 'scoped' | 'in_progress' | 'passed_inspection' | 'completed';
  
  // 3D Spatial Position in CAD space
  position: { x: number; y: number; z: number };
  targetRoomId: string;
  targetSurface?: 'floor' | 'wall_north' | 'wall_south' | 'wall_east' | 'wall_west' | 'ceiling' | 'crawlspace' | 'roof';
  
  // NC Building Code & Execution SOPs
  ncCodeReference: string;
  estimatedCost: number;
  laborHours: number;
  materialCost: number;
  laborCost: number;
  
  requiredTools: string[];
  requiredMaterials: string[];
  safetyPPE: string[];
  
  executionSteps: FixProtocolStep[];
  dimensions?: { width?: number; height?: number; depth?: number };
  assignedContractor?: string;
  assignedContractorId?: string;
  notes?: string;
}

export interface HouseCADLayout {
  id: string;
  dealId: string;
  styleName: string;
  totalSqft: number;
  lotWidth: number;
  lotDepth: number;
  foundationType: 'crawlspace' | 'slab' | 'basement';
  roofPitch: string;
  rooms: CADRoom[];
  fixProtocols: FixProtocolNode[];
  lastModified: string;
}

export interface RepairToolItem {
  name: string;
  category: 'Power Tools' | 'Hand Tools' | 'Safety & Measuring' | 'Specialty Trade';
  essential: boolean;
  approximateCost?: number;
}

export interface RepairMaterialItem {
  name: string;
  quantity: string;
  estimatedUnitCost: number;
  totalCost: number;
  ncTradeSpec?: string;
  retailSku?: string;
}

export interface RepairExecutionStep {
  stepNumber: number;
  title: string;
  instruction: string;
  toleranceMetric?: string;
  inspectionGate?: boolean;
  completed?: boolean;
}

export interface RepairPhase {
  phaseNumber: number;
  phaseName: string;
  description: string;
  steps: RepairExecutionStep[];
}

export interface RepairPlan {
  id: string;
  dealId: string;
  propertyAddress: string;
  city: string;
  title: string;
  trade: string;
  roomZone: string;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  problemDiagnosis: string;
  rootCauses: string[];
  riskFactors: string[];
  ncCodeCitation: string;
  permitRequired: boolean;
  permitType: string;
  diyFeasibility: 'DIY-Friendly' | 'Handyman Feasible' | 'Licensed Trade Required' | 'NC GC Required';
  estimatedLaborHours: number;
  estimatedMaterialCost: number;
  estimatedLaborCost: number;
  totalEstimatedCost: number;
  requiredTools: RepairToolItem[];
  requiredMaterials: RepairMaterialItem[];
  safetyPPE: string[];
  criticalPitfalls: string[];
  proTips: string[];
  executionPhases: RepairPhase[];
  matchedContractorIds?: string[];
  assignedContractorId?: string;
  assignedContractorName?: string;
  assignedContractorPhone?: string;
  assignedContractorRate?: string;
  createdAt: string;
  status: 'draft' | 'ready' | 'contracted' | 'in_progress' | 'passed_inspection' | 'completed';
}

export interface NCContractorDirectoryItem {
  id: string;
  name: string;
  trade: string;
  specialties: string[];
  city: string;
  county: string;
  serviceRadiusMiles: number;
  phone: string;
  email: string;
  rating: number;
  reviewCount: number;
  hourlyRate: number;
  licenseNumber: string;
  licenseBoard: string;
  licenseTier: 'Unlimited GC' | 'Intermediate GC' | 'Limited GC' | 'Master Electrician' | 'Master Plumber' | 'HVAC Class I' | 'Specialty Trade' | 'Punchout Handyman';
  licenseVerified: boolean;
  insurancePolicy: string;
  insuranceLimit: string;
  workersCompVerified: boolean;
  w9OnFile: boolean;
  yearsInBusiness: number;
  completedNCProjects: number;
  availability: 'Immediate' | 'Within 48 Hours' | 'Next Week' | 'Booked 2+ Weeks';
  emergencyCallout: boolean;
  badgeHighlights: string[];
}

